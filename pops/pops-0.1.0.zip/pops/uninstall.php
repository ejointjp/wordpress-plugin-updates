<?php
/**
 * 削除したときの後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * 設定の「プラグインを削除したとき、閲覧数と設定も消す」がオンのときだけ消す。
 * テーマの旧テーブル（haku_post_views）は、オンでも触らない。
 *
 * @package pops
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$pops_settings = get_option( 'pops_settings' );
if ( ! is_array( $pops_settings ) || empty( $pops_settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'pops_views' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Removes the plugin's own table on uninstall.

delete_option( 'pops_settings' );
delete_option( 'pops_db_version' );
delete_option( 'pops_import' );
delete_option( 'pops_cache_salt' );
delete_option( 'pops_error' );
delete_site_transient( 'pops_update_info' );
delete_metadata( 'user', 0, 'pops_per_page', '', true );
