<?php
/**
 * POPS → 設定
 *
 * 「設定」メニューの外なので、コアはsettings_errors()を呼ばない。保存の結果は、この画面が出す。
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 項目を登録する。
 */
function pops_add_settings_fields() {
	add_settings_section( 'pops_main', '', '__return_empty_string', POPS_SETTINGS_PAGE );
	add_settings_field(
		'pops_enabled',
		'閲覧数の集計',
		'pops_render_checkbox',
		POPS_SETTINGS_PAGE,
		'pops_main',
		array(
			'key'         => 'enabled',
			'label'       => '記事の閲覧数を数える',
			'description' => 'ログインしている人の閲覧は数えません。同じ人が同じ記事を24時間以内に開いても、1回と数えます。オフにしても、これまでの閲覧数と人気記事の表示は残ります。',
		)
	);
	add_settings_field(
		'pops_period',
		'表示の期間',
		'pops_render_period',
		POPS_SETTINGS_PAGE,
		'pops_main',
		array( 'label_for' => 'pops_period' )
	);
	add_settings_field(
		'pops_delete_data_on_uninstall',
		'削除時のデータ',
		'pops_render_checkbox',
		POPS_SETTINGS_PAGE,
		'pops_main',
		array(
			'key'         => 'delete_data_on_uninstall',
			'label'       => 'プラグインを削除したとき、閲覧数と設定も消す',
			'description' => '消した閲覧数は元に戻せません。',
		)
	);
}
add_action( 'admin_init', 'pops_add_settings_fields' );

/**
 * チェックボックスを出す。オフのときも値が送られるように、hiddenを先に置く。
 *
 * @param array $args key・label・description。
 */
function pops_render_checkbox( $args ) {
	$name = POPS_SETTINGS . '[' . $args['key'] . ']';
	?>
	<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
	<label>
		<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( pops_get_setting( $args['key'] ) ); ?>>
		<?php echo esc_html( $args['label'] ); ?>
	</label>
	<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
	<?php
}

/**
 * 期間の選択を出す。
 */
function pops_render_period() {
	$current = pops_get_setting( 'period' );
	?>
	<select name="<?php echo esc_attr( POPS_SETTINGS ); ?>[period]" id="pops_period">
		<?php foreach ( pops_display_periods() as $key => $label ) : ?>
			<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current, $key ); ?>><?php echo esc_html( $label ); ?></option>
		<?php endforeach; ?>
	</select>
	<p class="description">
		年間・月間・週間は、今日からさかのぼった1年・1か月・1週間の閲覧数で並べます。期間内に閲覧がなければ、人気記事は出ません。
		ブロックでは、ブロックごとに期間を選べます。順位は最大1時間遅れて変わります。すぐに変えたいときは、<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . POPS_RANKING_PAGE ) ); ?>">ランキング</a>の「表示のキャッシュをクリア」を押してください。
	</p>
	<?php
}

/**
 * 画面を出す。
 */
function pops_render_settings_page() {
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<hr class="wp-header-end">
		<?php settings_errors(); // 引数で絞ると、generalに登録されるコアの「設定を保存しました。」が出ない. ?>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'pops' );
			do_settings_sections( POPS_SETTINGS_PAGE );
			submit_button();
			?>
		</form>
	</div>
	<?php
}
