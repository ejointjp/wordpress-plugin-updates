<?php
/**
 * ブロック（人気記事）の登録
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ブロックを登録する。
 */
function pops_register_block() {
	$manifest = POPS_DIR . 'build/blocks-manifest.php';
	if ( ! file_exists( $manifest ) ) {
		_doing_it_wrong( __FUNCTION__, 'build/がありません。pnpm buildを実行してください。', '0.1.0' );
		return;
	}
	wp_register_block_types_from_metadata_collection( POPS_DIR . 'build', $manifest );
}
add_action( 'init', 'pops_register_block' );

/**
 * ブロックのCSSの版を、プラグインの版に揃える（block.jsonの版と二重に管理しない）。
 *
 * @param array $metadata block.jsonの中身。
 * @return array
 */
function pops_block_version( $metadata ) {
	if ( isset( $metadata['name'] ) && 'pops/ranking' === $metadata['name'] ) {
		$metadata['version'] = POPS_VERSION;
	}
	return $metadata;
}
add_filter( 'block_type_metadata', 'pops_block_version' );

/**
 * ブロックの属性を、表示の引数にする。
 *
 * @param array $attributes ブロックの属性。
 * @return array
 */
function pops_block_args( array $attributes ) {
	$args = array_intersect_key( $attributes, array_flip( array( 'layout', 'period', 'limit', 'rank' ) ) );
	if ( isset( $args['limit'] ) ) {
		$args['limit'] = max( 1, min( 20, (int) $args['limit'] ) );
	}
	return $args;
}
