<?php
/**
 * 集計の期間
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * すべての期間（キー => ラベル）。
 *
 * @return array<string,string>
 */
function pops_periods() {
	return array(
		'all'   => '全期間',
		'year'  => '年間',
		'month' => '月間',
		'week'  => '週間',
		'today' => '今日',
	);
}

/**
 * 表示で選べる期間（キー => ラベル）。
 *
 * 「今日」は1日分では記事が足りず、欄ごと消えやすいので、管理画面のランキングだけで使う。
 *
 * @return array<string,string>
 */
function pops_display_periods() {
	$periods = pops_periods();
	unset( $periods['today'] );
	return $periods;
}

/**
 * 期間の始まりの日を返す。今日からさかのぼった1週間・1か月・1年。
 *
 * @param string            $period 期間のキー。
 * @param DateTimeImmutable $now    サイトのタイムゾーンの現在時刻（current_datetime()）。
 * @return string|null YYYY-MM-DD。全期間と、知らないキーはnull。
 */
function pops_period_start( $period, DateTimeImmutable $now ) {
	switch ( $period ) {
		case 'today':
			return $now->format( 'Y-m-d' );
		case 'week':
			return $now->modify( '-7 days' )->format( 'Y-m-d' );
		case 'month':
			return pops_months_ago( $now, 1 )->format( 'Y-m-d' );
		case 'year':
			return pops_months_ago( $now, 12 )->format( 'Y-m-d' );
		default:
			return null;
	}
}

/**
 * 何か月か前の同じ日を返す。その月に同じ日がなければ、月末にする（3月31日の1か月前は2月28日か29日）。
 *
 * DateTimeの「-1 month」は、3月31日を2月31日とみなして3月3日まで繰り上げるので使わない。
 *
 * @param DateTimeImmutable $now    基準の日時。
 * @param int               $months 何か月前か。
 * @return DateTimeImmutable
 */
function pops_months_ago( DateTimeImmutable $now, $months ) {
	$first = $now->modify( 'first day of this month' )->modify( '-' . (int) $months . ' months' );
	$day   = min( (int) $now->format( 'j' ), (int) $first->format( 't' ) );
	return $first->setDate( (int) $first->format( 'Y' ), (int) $first->format( 'n' ), $day );
}
