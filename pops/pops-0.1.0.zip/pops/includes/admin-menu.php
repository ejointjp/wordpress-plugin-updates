<?php
/**
 * 管理メニュー「POPS」（ランキング・設定）
 *
 * 画面の中身は、ranking-page.phpとsettings-page.php。
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const POPS_RANKING_PAGE  = 'pops';
const POPS_SETTINGS_PAGE = 'pops-settings';

/**
 * メニューに足す。大メニューを開くと、ランキングが出る。
 */
function pops_add_admin_menu() {
	$ranking_hook = add_menu_page(
		'人気記事ランキング',
		'POPS',
		'manage_options',
		POPS_RANKING_PAGE,
		'pops_render_ranking_page',
		'dashicons-chart-bar',
		26 // 「コメント」の下
	);
	add_action( "load-$ranking_hook", 'pops_add_screen_option' );

	// 親と同じスラッグで足すと、1つ目の項目の名前を変えられる
	add_submenu_page(
		POPS_RANKING_PAGE,
		'人気記事ランキング',
		'ランキング',
		'manage_options',
		POPS_RANKING_PAGE,
		'pops_render_ranking_page'
	);
	add_submenu_page(
		POPS_RANKING_PAGE,
		'POPSの設定',
		'設定',
		'manage_options',
		POPS_SETTINGS_PAGE,
		'pops_render_settings_page'
	);
}
add_action( 'admin_menu', 'pops_add_admin_menu' );
