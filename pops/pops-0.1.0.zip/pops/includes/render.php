<?php
/**
 * 人気記事の表示
 *
 * テーマからの使い方は2通り。
 * - そのまま表示する: pops_display()。見出しは出さない（置く側が、pops_get_posts()が
 *   空でないことを確かめてから出す）
 * - データだけを使う: pops_query()（WP_Query）かpops_get_posts()（配列）。
 *   見た目はテーマが描く。CSSは読み込まない
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 表示の引数を整える。知らない値は既定値に戻し、件数は範囲に収める。
 *
 * @param array $args {
 *     引数。
 *
 *     @type string $layout          'list'（縦に並べる。既定）か'slider'（横に流す）。
 *     @type string $period          期間のキー。空なら設定の期間。
 *     @type int    $limit           件数（1〜100。既定10）。
 *     @type bool   $rank            順位を出すか（既定true）。
 *     @type bool   $exclude_current 個別ページで、表示中の記事を除くか（既定true）。
 *     @type string $heading         タイトルの要素。'h2'・'h3'・'h4'。既定は'p'。
 *     @type bool   $author          著者を出すか（既定false。スライダーだけ）。
 * }
 * @return array
 */
function pops_parse_args( array $args ) {
	$args    = wp_parse_args(
		$args,
		array(
			'layout'          => 'list',
			'period'          => '',
			'limit'           => 10,
			'rank'            => true,
			'exclude_current' => true,
			'heading'         => '',
			'author'          => false,
		)
	);
	$periods = pops_display_periods();

	return array(
		'layout'          => 'slider' === $args['layout'] ? 'slider' : 'list',
		'period'          => is_string( $args['period'] ) && array_key_exists( $args['period'], $periods )
			? $args['period']
			: pops_get_setting( 'period' ),
		'limit'           => max( 1, min( 100, (int) $args['limit'] ) ),
		'rank'            => (bool) $args['rank'],
		'exclude_current' => (bool) $args['exclude_current'],
		'heading'         => in_array( $args['heading'], array( 'h2', 'h3', 'h4' ), true ) ? $args['heading'] : 'p',
		'author'          => (bool) $args['author'],
	);
}

/**
 * 人気記事を、順位の順の問い合わせとして返す。テーマのループでそのまま回せる。
 *
 * 使うのは、引数のperiod・limit・exclude_currentだけ。回したあとは、呼んだ側がwp_reset_postdata()を呼ぶ。
 *
 * @param array $args pops_parse_args()の引数。
 * @return WP_Query なければ、記事のない問い合わせ（have_posts()がfalse）。
 */
function pops_query( array $args = array() ) {
	$args    = pops_parse_args( $args );
	$types   = pops_post_types();
	$exclude = $args['exclude_current'] && is_singular( $types ) ? get_queried_object_id() : 0;
	$ids     = pops_get_ids( $args['period'], $args['limit'], $exclude );
	if ( ! $ids ) {
		return new WP_Query(); // post__inが空の問い合わせは、すべての記事を返してしまう
	}

	$query = new WP_Query(
		array(
			'post__in'            => $ids,
			'orderby'             => 'post__in',
			'post_type'           => $types,
			'post_status'         => 'publish',
			'posts_per_page'      => count( $ids ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
	update_post_thumbnail_cache( $query );
	return $query;
}

/**
 * 人気記事を、順位の順に返す。
 *
 * @param array $args pops_parse_args()の引数。
 * @return WP_Post[] なければ空。
 */
function pops_get_posts( array $args = array() ) {
	return (array) pops_query( $args )->posts;
}

/**
 * 人気記事を出す。記事がなければ何も出さない。
 *
 * @param array $args pops_parse_args()の引数。
 */
function pops_display( array $args = array() ) {
	$posts = pops_get_posts( $args );
	if ( ! $posts ) {
		return;
	}
	pops_enqueue_style();

	$args     = pops_parse_args( $args );
	$list_tag = $args['rank'] ? 'ol' : 'ul';
	?>
	<div class="pops pops--<?php echo esc_attr( $args['layout'] ); ?>">
		<<?php echo tag_escape( $list_tag ); ?> class="pops__items" role="list">
			<?php
			foreach ( $posts as $index => $item ) {
				pops_display_item( $item, $args['rank'] ? $index + 1 : 0, $args );
			}
			?>
		</<?php echo tag_escape( $list_tag ); ?>>
	</div>
	<?php
}

/**
 * 1件を出す。
 *
 * @param WP_Post $item 記事。
 * @param int     $rank 順位。0なら出さない（読み上げはolに任せる）。
 * @param array   $args 整えた引数。
 */
function pops_display_item( $item, $rank, array $args ) {
	$is_slider  = 'slider' === $args['layout'];
	$categories = $is_slider ? get_the_category( $item->ID ) : array();
	$title      = get_the_title( $item );
	if ( '' === trim( $title ) ) {
		$title = '（タイトルなし）';
	}

	/**
	 * タイトルのHTMLを変える。通るタグはwbr・span・em・strong・brだけ。
	 *
	 * @param string  $html エスケープ済みのタイトル。
	 * @param WP_Post $item 記事。
	 */
	$title_html = apply_filters( 'pops_title_html', esc_html( $title ), $item );

	/**
	 * タイトルの要素にクラスを足す。
	 *
	 * @param string  $class 足すクラス。
	 * @param WP_Post $item  記事。
	 */
	$title_class = trim( 'pops__title ' . apply_filters( 'pops_title_class', '', $item ) );
	?>
	<li class="pops__item">
		<div class="pops__thumbnail">
			<?php echo wp_kses( pops_thumbnail( $item, $is_slider ), pops_image_kses() ); ?>
			<?php if ( $rank > 0 ) : ?>
				<span class="pops__rank" aria-hidden="true"><?php echo esc_html( (string) $rank ); ?></span>
			<?php endif; ?>
		</div>
		<div class="pops__body">
			<?php if ( $categories ) : ?>
				<span class="pops__category"><?php echo esc_html( $categories[0]->name ); ?></span>
			<?php endif; ?>
			<<?php echo tag_escape( $args['heading'] ); ?> class="<?php echo esc_attr( $title_class ); ?>">
				<a href="<?php echo esc_url( get_permalink( $item ) ); ?>"><?php echo wp_kses( $title_html, pops_title_kses() ); ?></a>
			</<?php echo tag_escape( $args['heading'] ); ?>>
			<?php if ( $is_slider ) : ?>
				<p class="pops__meta">
					<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C, $item ) ); ?>"><?php echo esc_html( get_the_date( '', $item ) ); ?></time>
					<?php if ( $args['author'] ) : ?>
						<span><?php echo esc_html( get_the_author_meta( 'display_name', (int) $item->post_author ) ); ?></span>
					<?php endif; ?>
				</p>
			<?php endif; ?>
		</div>
	</li>
	<?php
}

/**
 * サムネイルのHTMLを返す。アイキャッチがなければ、フィルタが返す画像。それもなければ空。
 *
 * @param WP_Post $item      記事。
 * @param bool    $is_slider スライダーか。
 * @return string
 */
function pops_thumbnail( $item, $is_slider ) {
	// sizesの幅は、style.cssのサムネイルの列とスライダーの項目の幅
	$thumbnail = get_the_post_thumbnail(
		$item,
		$is_slider ? 'medium_large' : 'medium',
		array(
			'alt'     => '',
			'loading' => 'lazy',
			'sizes'   => $is_slider ? '(max-width: 47.99em) 16rem, 24rem' : '6.5rem',
		)
	);
	if ( '' !== $thumbnail ) {
		return $thumbnail;
	}

	/**
	 * アイキャッチのない記事に出す画像のURL。
	 *
	 * @param string  $url  URL。空なら無地の面だけを出す。
	 * @param WP_Post $item 記事。
	 */
	$url = apply_filters( 'pops_placeholder_url', '', $item );
	if ( ! is_string( $url ) || '' === $url ) {
		return '';
	}
	return '<img class="pops__placeholder" src="' . esc_url( $url ) . '" alt="" loading="lazy">';
}

/**
 * タイトルに通すタグ。
 *
 * @return array
 */
function pops_title_kses() {
	return array(
		'wbr'    => array(),
		'br'     => array(),
		'em'     => array(),
		'strong' => array(),
		'span'   => array( 'class' => true ),
	);
}

/**
 * サムネイルに通すタグ。画像の最適化のプラグインがpictureやdata-*を足すことがある。
 *
 * @return array
 */
function pops_image_kses() {
	$image = array_fill_keys(
		array( 'src', 'srcset', 'sizes', 'alt', 'width', 'height', 'class', 'loading', 'decoding', 'fetchpriority', 'data-*' ),
		true
	);
	return array(
		'img'      => $image,
		'noscript' => array(),
		'picture'  => array( 'class' => true ),
		'source'   => array(
			'srcset' => true,
			'sizes'  => true,
			'type'   => true,
			'media'  => true,
			'data-*' => true,
		),
	);
}

/**
 * 表示のCSSを読み込む。テーマが<head>で読み込みたいときは、wp_enqueue_scriptsで呼ぶ。
 */
function pops_enqueue_style() {
	wp_enqueue_style( 'pops-ranking-style' );
}
