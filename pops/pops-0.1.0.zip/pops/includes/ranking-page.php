<?php
/**
 * POPS → ランキング
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 表示オプションに、1ページの件数を足す。
 */
function pops_add_screen_option() {
	add_screen_option(
		'per_page',
		array(
			'label'   => '1ページに表示する件数',
			'default' => 20,
			'option'  => 'pops_per_page',
		)
	);
}

/**
 * 1ページの件数を保存する。
 *
 * @param mixed  $status 保存する値。falseなら保存しない。
 * @param string $option オプション名。
 * @param int    $value  送られてきた件数。
 * @return int
 */
function pops_save_screen_option( $status, $option, $value ) {
	return max( 1, min( 999, (int) $value ) );
}
add_filter( 'set_screen_option_pops_per_page', 'pops_save_screen_option', 10, 3 );

/**
 * 期間のキーを整える。知らないキーは全期間。
 *
 * @param string $period 送られてきた値（sanitize_key()済み）。
 * @return string
 */
function pops_ranking_period( $period ) {
	return array_key_exists( $period, pops_periods() ) ? $period : 'all';
}

/**
 * ランキング画面のURLを返す。
 *
 * @param array $args 足すクエリ。
 * @return string
 */
function pops_ranking_url( array $args ) {
	return add_query_arg( array( 'page' => POPS_RANKING_PAGE ) + $args, admin_url( 'admin.php' ) );
}

/**
 * 対象の日付（YYYY-MM-DD 〜 YYYY-MM-DD）を返す。
 *
 * @param string $period 期間のキー。
 * @return string
 */
function pops_period_dates( $period ) {
	$now   = current_datetime();
	$start = pops_period_start( $period, $now );
	if ( null === $start ) {
		global $wpdb;
		$start = $wpdb->get_var( $wpdb->prepare( 'SELECT MIN( view_date ) FROM %i', pops_table() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table, admin screen only.
	}
	$today = $now->format( 'Y-m-d' );
	return ( $start ? $start : $today ) . ' 〜 ' . $today;
}

/**
 * 画面を出す。
 */
function pops_render_ranking_page() {
	$period = pops_ranking_period( isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : 'all' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only: only selects which period to show.

	require_once POPS_DIR . 'includes/class-pops-list-table.php';
	$table = new Pops_List_Table( $period );
	$table->prepare_items();

	$clear_url = wp_nonce_url(
		add_query_arg(
			array(
				'action' => 'pops_clear_cache',
				'period' => $period,
			),
			admin_url( 'admin-post.php' )
		),
		'pops_clear_cache'
	);
	$periods   = pops_periods();
	$last      = array_key_last( $periods );
	?>
	<div class="wrap">
		<h1 class="wp-heading-inline"><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<a href="<?php echo esc_url( $clear_url ); ?>" class="page-title-action">表示のキャッシュをクリア</a>
		<hr class="wp-header-end">
		<?php settings_errors(); // 「設定」メニューの外なので、コアは呼ばない。キャッシュのクリアの結果が出る. ?>

		<p>対象の期間: <strong><?php echo esc_html( pops_period_dates( $period ) ); ?></strong></p>

		<ul class="subsubsub">
			<?php foreach ( $periods as $key => $label ) : ?>
				<li>
					<a href="<?php echo esc_url( pops_ranking_url( array( 'period' => $key ) ) ); ?>"<?php echo $key === $period ? ' class="current" aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a><?php echo $key === $last ? '' : ' |'; ?>
				</li>
			<?php endforeach; ?>
		</ul>

		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
			<input type="hidden" name="page" value="<?php echo esc_attr( POPS_RANKING_PAGE ); ?>">
			<input type="hidden" name="period" value="<?php echo esc_attr( $period ); ?>">
			<?php $table->display(); ?>
		</form>
	</div>
	<?php
}

/**
 * 「表示のキャッシュをクリア」の処理（admin-post.php）。処理したら画面へ戻し、結果を通知で出す。
 */
function pops_handle_clear_cache() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html( 'この操作を行う権限がありません。' ), 403 );
	}
	check_admin_referer( 'pops_clear_cache' );

	$period = pops_ranking_period( isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : 'all' );

	if ( pops_flush_cache() ) {
		add_settings_error( 'pops', 'cache_cleared', esc_html( '人気記事の表示のキャッシュをクリアしました。' ), 'success' );
	} else {
		add_settings_error( 'pops', 'cache_not_cleared', esc_html( '人気記事の表示のキャッシュをクリアできませんでした。データベースに書き込めていません。もう一度実行し、続くときはPHPのエラーログを確かめてください。' ) );
	}

	set_transient( 'settings_errors', get_settings_errors(), 30 );
	wp_safe_redirect(
		pops_ranking_url(
			array(
				'period'           => $period,
				'settings-updated' => 'true',
			)
		)
	);
	exit;
}
add_action( 'admin_post_pops_clear_cache', 'pops_handle_clear_cache' );
