<?php
/**
 * 設定の値（既定値・読み出し・保存前の検証）。画面はsettings-page.php
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const POPS_SETTINGS = 'pops_settings';

/**
 * 設定の既定値。
 *
 * @return array{enabled:bool,period:string,delete_data_on_uninstall:bool}
 */
function pops_default_settings() {
	return array(
		'enabled'                  => true,
		'period'                   => 'all',
		'delete_data_on_uninstall' => false,
	);
}

/**
 * 設定をすべて返す。保存されていない項目は既定値。
 *
 * @return array{enabled:bool,period:string,delete_data_on_uninstall:bool}
 */
function pops_get_settings() {
	$defaults = pops_default_settings();
	$saved    = get_option( POPS_SETTINGS, array() );
	$settings = array_merge( $defaults, is_array( $saved ) ? array_intersect_key( $saved, $defaults ) : array() );

	if ( ! is_string( $settings['period'] ) || ! array_key_exists( $settings['period'], pops_display_periods() ) ) {
		$settings['period'] = $defaults['period'];
	}
	$settings['enabled']                  = (bool) $settings['enabled'];
	$settings['delete_data_on_uninstall'] = (bool) $settings['delete_data_on_uninstall'];
	return $settings;
}

/**
 * 設定を1つ返す。
 *
 * @param string $key キー。
 * @return mixed 知らないキーはnull。
 */
function pops_get_setting( $key ) {
	$settings = pops_get_settings();
	return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
}

/**
 * 設定を登録する。
 */
function pops_register_settings() {
	register_setting(
		'pops',
		POPS_SETTINGS,
		array(
			'type'              => 'object',
			'sanitize_callback' => 'pops_sanitize_settings',
			'show_in_rest'      => false,
		)
	);
}
add_action( 'admin_init', 'pops_register_settings' );

/**
 * 保存する前に検証する。送られてこない項目と、選択肢にない値は、前の値を残す。
 *
 * @param mixed $input 送られてきた値。
 * @return array
 */
function pops_sanitize_settings( $input ) {
	$settings = pops_get_settings();
	$input    = is_array( $input ) ? $input : array();

	foreach ( array( 'enabled', 'delete_data_on_uninstall' ) as $key ) {
		if ( isset( $input[ $key ] ) ) {
			$settings[ $key ] = (bool) $input[ $key ];
		}
	}

	if ( isset( $input['period'] ) ) {
		$period = is_string( $input['period'] ) ? sanitize_key( $input['period'] ) : '';
		if ( array_key_exists( $period, pops_display_periods() ) ) {
			$settings['period'] = $period;
		} else {
			pops_add_settings_error(
				'invalid_period',
				esc_html( '「表示の期間」の値が選択肢にないため、前の値を残しました。一覧から選び直して保存してください。' )
			);
		}
	}

	return $settings;
}

/**
 * 設定のエラーを登録する。sanitize_callbackの中では、add_settings_error()を直接呼ばずにこれを使う。
 *
 * オプションがまだない初回の保存では、sanitize_callbackが2回走るので、同じコードは1回だけ登録する。
 * RESTやcronからの保存では、add_settings_error()が読み込まれていない。
 *
 * @param string $code    エラーコード。
 * @param string $message エスケープ済みの文言。
 */
function pops_add_settings_error( $code, $message ) {
	if ( ! function_exists( 'add_settings_error' ) ) {
		return;
	}
	if ( in_array( $code, wp_list_pluck( get_settings_errors( POPS_SETTINGS ), 'code' ), true ) ) {
		return;
	}
	add_settings_error( POPS_SETTINGS, $code, $message );
}
