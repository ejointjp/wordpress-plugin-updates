<?php
/**
 * 閲覧数のテーブル
 *
 * 1つの記事の1日分を1行に持つ。期間ごとの順位は、日付で絞って合計する。
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const POPS_DB_VERSION = '1';

/**
 * テーブル名を返す。
 *
 * @return string
 */
function pops_table() {
	global $wpdb;
	return $wpdb->prefix . 'pops_views';
}

/**
 * テーブルを今の版にし、まだなら旧データを取り込む。
 *
 * 自己ホストの更新では有効化のフックが走らないので、admin_initでも呼ぶ。
 */
function pops_upgrade() {
	if ( get_option( 'pops_db_version' ) !== POPS_DB_VERSION ) {
		if ( ! pops_create_table() ) {
			global $wpdb;
			pops_set_error( '閲覧数のテーブルを作れませんでした。' . $wpdb->last_error );
			return;
		}
		update_option( 'pops_db_version', POPS_DB_VERSION );
	}
	pops_maybe_import();
}
add_action( 'admin_init', 'pops_upgrade' );

/**
 * テーブルを作る。すでにあれば、足りない列とキーを足す。
 *
 * @return bool できたか。
 */
function pops_create_table() {
	global $wpdb;
	$table           = pops_table();
	$charset_collate = $wpdb->get_charset_collate();

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta(
		"CREATE TABLE $table (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint unsigned NOT NULL,
			view_date date NOT NULL,
			view_count bigint unsigned NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY post_date (post_id, view_date),
			KEY post_id (post_id),
			KEY view_date (view_date)
		) $charset_collate;"
	);

	return pops_table_exists( $table );
}

/**
 * テーブルがあるか。
 *
 * @param string $table テーブル名。
 * @return bool
 */
function pops_table_exists( $table ) {
	global $wpdb;
	$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Checks whether a custom table exists; there is no core API for it.
	return $found === $table;
}

/**
 * 記事を完全に消したとき、その記事の閲覧数も消す（ゴミ箱へ入れただけでは消さない）。
 *
 * @param int     $post_id 記事のID。
 * @param WP_Post $post    消した記事。
 */
function pops_delete_views( $post_id, $post ) {
	if ( ! in_array( $post->post_type, pops_post_types(), true ) ) {
		return;
	}
	global $wpdb;
	$wpdb->delete( pops_table(), array( 'post_id' => (int) $post_id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table; the ranking cache is invalidated below.
	pops_flush_cache();
}
add_action( 'deleted_post', 'pops_delete_views', 10, 2 );

/**
 * 準備（テーブルの作成・取り込み）の失敗を残す。空なら消す。
 *
 * @param string $message 失敗の内容。
 */
function pops_set_error( $message ) {
	if ( '' === $message ) {
		delete_option( 'pops_error' );
		return;
	}
	update_option( 'pops_error', $message, false );
}

/**
 * 準備の失敗を、管理画面の通知で知らせる。
 */
function pops_show_error() {
	$message = get_option( 'pops_error', '' );
	if ( ! is_string( $message ) || '' === $message || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	wp_admin_notice(
		esc_html( 'POPSの準備に失敗しました。データベースの権限と空き容量を確かめて、管理画面を開き直してください（自動でやり直します）。 ' . $message ),
		array( 'type' => 'error' )
	);
}
add_action( 'admin_notices', 'pops_show_error' );
