<?php
/**
 * 順位の計算とキャッシュ
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 数える投稿タイプ。
 *
 * @return string[]
 */
function pops_post_types() {
	/**
	 * 数える投稿タイプを変える。
	 *
	 * @param string[] $post_types 投稿タイプ。
	 */
	$types = apply_filters( 'pops_post_types', array( 'post' ) );
	$types = array_values( array_filter( (array) $types, 'is_string' ) );
	return $types ? $types : array( 'post' );
}

/**
 * 人気記事のIDを、閲覧数の多い順に返す。
 *
 * @param string $period  期間のキー。知らないキーは全期間。
 * @param int    $limit   件数（1〜100）。
 * @param int    $exclude 除く記事のID。0なら除かない。
 * @return int[]
 */
function pops_get_ids( $period = 'all', $limit = 10, $exclude = 0 ) {
	if ( ! array_key_exists( $period, pops_periods() ) ) {
		$period = 'all';
	}
	$limit = max( 1, min( 100, (int) $limit ) );

	// 除く前の配列をキャッシュし、記事ごとにキャッシュを増やさない。1件多く取って、除いた分を埋める
	$ids = pops_cached_ids( $period, $limit + 1 );
	if ( $exclude > 0 ) {
		$ids = array_values( array_diff( $ids, array( (int) $exclude ) ) );
	}
	return array_slice( $ids, 0, $limit );
}

/**
 * 順位のIDを、1時間キャッシュして返す。
 *
 * @param string $period 期間のキー。
 * @param int    $count  件数。
 * @return int[]
 */
function pops_cached_ids( $period, $count ) {
	$salt   = (string) get_option( 'pops_cache_salt', '' );
	$key    = 'pops_' . md5( implode( '|', array( $salt, $period, $count, implode( ',', pops_post_types() ) ) ) );
	$cached = get_transient( $key );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$ids = wp_list_pluck( pops_query_views( $period, $count, 0 ), 'post_id' );
	if ( $ids ) {
		// 空はキャッシュしない（集計が立ち上がる前に、空のまま固まらないように）
		set_transient( $key, $ids, HOUR_IN_SECONDS );
	}
	return $ids;
}

/**
 * 順位のキャッシュを、件数や期間によらずすべて無効にする。
 *
 * @return bool できたか。
 */
function pops_flush_cache() {
	return update_option( 'pops_cache_salt', wp_generate_uuid4() );
}

/**
 * 設定が変わったら、順位のキャッシュを無効にする。
 */
function pops_flush_on_settings_change() {
	pops_flush_cache();
}
add_action( 'add_option_' . POPS_SETTINGS, 'pops_flush_on_settings_change' );
add_action( 'update_option_' . POPS_SETTINGS, 'pops_flush_on_settings_change' );

/**
 * 記事が公開になる・公開でなくなるときに、順位のキャッシュを無効にする。
 *
 * @param string  $new_status 新しい状態。
 * @param string  $old_status 前の状態。
 * @param WP_Post $post       記事。
 */
function pops_flush_on_status_change( $new_status, $old_status, $post ) {
	if ( $new_status === $old_status || ! in_array( 'publish', array( $new_status, $old_status ), true ) ) {
		return;
	}
	if ( in_array( $post->post_type, pops_post_types(), true ) ) {
		pops_flush_cache();
	}
}
add_action( 'transition_post_status', 'pops_flush_on_status_change', 10, 3 );

/**
 * 期間内の閲覧数を、公開中の記事について多い順に返す。
 *
 * @param string $period 期間のキー。
 * @param int    $limit  件数。
 * @param int    $offset 飛ばす件数。
 * @return array<int,array{post_id:int,views:int}>
 */
function pops_query_views( $period, $limit, $offset ) {
	global $wpdb;
	list( $where, $args ) = pops_where( $period );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $where holds only placeholders, its values are in $args. Custom table, cached by the caller.
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT v.post_id, SUM( v.view_count ) AS views
			FROM %i AS v
			INNER JOIN %i AS p ON p.ID = v.post_id
			WHERE $where
			GROUP BY v.post_id
			ORDER BY views DESC, MAX( p.post_date ) DESC, v.post_id DESC
			LIMIT %d OFFSET %d",
			array_merge( $args, array( (int) $limit, (int) $offset ) )
		),
		ARRAY_A
	);
	// phpcs:enable

	$views = array();
	foreach ( (array) $rows as $row ) {
		$views[] = array(
			'post_id' => (int) $row['post_id'],
			'views'   => (int) $row['views'],
		);
	}
	return $views;
}

/**
 * 期間内に閲覧のあった、公開中の記事の数を返す。
 *
 * @param string $period 期間のキー。
 * @return int
 */
function pops_count_posts( $period ) {
	global $wpdb;
	list( $where, $args ) = pops_where( $period );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $where holds only placeholders, its values are in $args. Custom table, admin screen only.
	$count = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT( DISTINCT v.post_id )
			FROM %i AS v
			INNER JOIN %i AS p ON p.ID = v.post_id
			WHERE $where",
			$args
		)
	);
	// phpcs:enable
	return (int) $count;
}

/**
 * 順位のSQLのWHERE句と、prepare()に渡す値（先頭の2つはテーブル名）を返す。
 *
 * @param string $period 期間のキー。
 * @return array{0:string,1:array<int,string>}
 */
function pops_where( $period ) {
	global $wpdb;
	$types = pops_post_types();
	$where = "p.post_status = 'publish' AND p.post_type IN ( " . implode( ', ', array_fill( 0, count( $types ), '%s' ) ) . ' )';
	$args  = array_merge( array( pops_table(), $wpdb->posts ), $types );

	$start = pops_period_start( $period, current_datetime() );
	if ( null !== $start ) {
		$where .= ' AND v.view_date >= %s';
		$args[] = $start;
	}
	return array( $where, $args );
}
