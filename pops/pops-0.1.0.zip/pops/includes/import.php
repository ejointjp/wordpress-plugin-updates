<?php
/**
 * テーマ（haku / haku2）が数えていた閲覧数と設定の取り込み。1回だけ行う
 *
 * 元のテーブルと設定は消さない。プラグインがテーマのことを知っているのは、このファイルだけ。
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * まだ取り込んでいなければ取り込む。失敗したら記録し、次の機会にやり直す。
 */
function pops_maybe_import() {
	$status = get_option( 'pops_import' );
	if ( is_array( $status ) && ! empty( $status['done'] ) ) {
		return;
	}

	$rows = pops_import_views();
	if ( is_wp_error( $rows ) ) {
		pops_set_error( 'テーマの閲覧数を取り込めませんでした。' . $rows->get_error_message() );
		return;
	}
	pops_import_settings();

	update_option(
		'pops_import',
		array(
			'done' => true,
			'rows' => $rows,
			'time' => time(),
		),
		false
	);
	pops_set_error( '' );
	pops_flush_cache();
}

/**
 * 旧テーブルの行を写す。同じ記事・同じ日の行がすでにあれば、新しいテーブルの値を残す。
 *
 * @return int|WP_Error 写した行数。旧テーブルがなければ0。
 */
function pops_import_views() {
	global $wpdb;
	$legacy = $wpdb->prefix . 'haku_post_views';
	if ( ! pops_table_exists( $legacy ) ) {
		return 0;
	}

	$rows = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time copy between custom tables.
		$wpdb->prepare(
			'INSERT IGNORE INTO %i (post_id, view_date, view_count) SELECT post_id, view_date, view_count FROM %i',
			pops_table(),
			$legacy
		)
	);
	if ( false === $rows ) {
		return new WP_Error( 'pops_import', $wpdb->last_error );
	}
	return (int) $rows;
}

/**
 * Haku2の設定を、このプラグインの設定の初期値にする。すでに設定があれば何もしない。
 */
function pops_import_settings() {
	if ( false !== get_option( POPS_SETTINGS, false ) ) {
		return;
	}
	$enabled = get_option( 'haku_enable_popular_posts', null );
	$period  = get_option( 'haku_popular_posts_period', null );
	if ( null === $enabled && null === $period ) {
		return;
	}

	$settings = pops_default_settings();
	if ( null !== $enabled ) {
		$settings['enabled'] = (bool) $enabled;
	}
	if ( is_string( $period ) && array_key_exists( $period, pops_display_periods() ) ) {
		$settings['period'] = $period;
	}
	update_option( POPS_SETTINGS, $settings );
}
