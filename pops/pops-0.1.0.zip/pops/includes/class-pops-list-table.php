<?php
/**
 * 人気記事ランキングの一覧表。ランキング画面でだけ読み込む
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * 期間内の閲覧数の順に、公開中の記事を並べる。
 */
class Pops_List_Table extends WP_List_Table {
	/**
	 * 期間のキー。
	 *
	 * @var string
	 */
	private $period;

	/**
	 * 期間を受け取る。
	 *
	 * @param string $period 期間のキー。
	 */
	public function __construct( $period ) {
		parent::__construct(
			array(
				'singular' => 'popular_post',
				'plural'   => 'popular_posts',
				'ajax'     => false,
			)
		);
		$this->period = $period;
	}

	/**
	 * 列。
	 *
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'rank'  => '順位',
			'title' => 'タイトル',
			'views' => '閲覧数',
			'date'  => '公開日',
		);
	}

	/**
	 * 行アクションを付ける列。
	 *
	 * @return string
	 */
	protected function get_default_primary_column_name() {
		return 'title';
	}

	/**
	 * 表のクラス。既定のfixedを外し、列の幅を中身に合わせる。
	 *
	 * @return string[]
	 */
	protected function get_table_classes() {
		return array( 'widefat', 'striped', $this->_args['plural'] );
	}

	/**
	 * 表示中のページの分を取り出す。
	 */
	public function prepare_items() {
		$this->_column_headers = array( $this->get_columns(), array(), array(), 'title' );

		$per_page = $this->get_items_per_page( 'pops_per_page', 20 );
		$offset   = ( $this->get_pagenum() - 1 ) * $per_page;

		$this->set_pagination_args(
			array(
				'total_items' => pops_count_posts( $this->period ),
				'per_page'    => $per_page,
			)
		);

		$this->items = array();
		foreach ( pops_query_views( $this->period, $per_page, $offset ) as $index => $row ) {
			$this->items[] = array( 'rank' => $offset + $index + 1 ) + $row;
		}
		_prime_post_caches( wp_list_pluck( $this->items, 'post_id' ), false, false );
	}

	/**
	 * 記事がないときの文言。
	 */
	public function no_items() {
		echo esc_html( 'この期間に閲覧のあった記事はありません。' );
	}

	/**
	 * 順位・閲覧数・公開日の列。
	 *
	 * @param array  $item        行。
	 * @param string $column_name 列のキー。
	 * @return string エスケープ済みのHTML。
	 */
	protected function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'rank':
				return '<strong>' . esc_html( number_format_i18n( $item['rank'] ) ) . '</strong>';
			case 'views':
				return esc_html( number_format_i18n( $item['views'] ) );
			case 'date':
				return esc_html( get_the_date( '', $item['post_id'] ) );
			default:
				return '';
		}
	}

	/**
	 * タイトルの列。
	 *
	 * @param array $item 行。
	 * @return string エスケープ済みのHTML。
	 */
	protected function column_title( $item ) {
		$title   = get_the_title( $item['post_id'] );
		$title   = '' === trim( $title ) ? '（タイトルなし）' : $title;
		$edit    = get_edit_post_link( $item['post_id'] );
		$actions = array(
			'view' => '<a href="' . esc_url( get_permalink( $item['post_id'] ) ) . '">表示</a>',
		);

		if ( ! $edit ) {
			return '<strong>' . esc_html( $title ) . '</strong>' . $this->row_actions( $actions );
		}
		$actions = array( 'edit' => '<a href="' . esc_url( $edit ) . '">編集</a>' ) + $actions;
		return '<strong><a class="row-title" href="' . esc_url( $edit ) . '">' . esc_html( $title ) . '</a></strong>' . $this->row_actions( $actions );
	}
}
