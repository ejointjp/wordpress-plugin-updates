<?php
/**
 * 閲覧の集計（REST APIと、閲覧を送るJSの読み込み）
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 閲覧を受け取るルートを登録する（POST /pops/v1/views/{id}）。
 *
 * nonceは使わない。ページキャッシュの中のnonceは期限が切れ、コアが403を返して数えられなくなる。
 * 公開の加算だけで、nonceで守るものがない。
 */
function pops_register_route() {
	register_rest_route(
		'pops/v1',
		'/views/(?P<id>\d+)',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'pops_handle_view',
			'permission_callback' => '__return_true',
			'args'                => array(
				'id' => array(
					'type'     => 'integer',
					'minimum'  => 1,
					'required' => true,
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'pops_register_route' );

/**
 * 閲覧を1回分数える。
 *
 * @param WP_REST_Request $request リクエスト。
 * @return WP_REST_Response|WP_Error
 */
function pops_handle_view( $request ) {
	$post_id = (int) $request['id'];

	if ( ! pops_get_setting( 'enabled' ) ) {
		return new WP_REST_Response( array( 'counted' => false ), 200 );
	}
	if ( ! pops_is_countable( $post_id ) ) {
		return new WP_Error( 'pops_not_found', '数える記事がありません。', array( 'status' => 404 ) );
	}

	// nonceのないリクエストは、コアが未ログインとして扱う（is_user_logged_in()は常にfalse）。cookieを直接確かめる
	if ( wp_validate_auth_cookie( '', 'logged_in' ) ) {
		return new WP_REST_Response( array( 'counted' => false ), 200 );
	}

	if ( ! pops_add_view( $post_id ) ) {
		return new WP_Error( 'pops_db', '閲覧数を記録できませんでした。', array( 'status' => 500 ) );
	}
	return new WP_REST_Response( array( 'counted' => true ), 200 );
}

/**
 * 数える記事か（公開中で、対象の投稿タイプ）。
 *
 * @param int $post_id 記事のID。
 * @return bool
 */
function pops_is_countable( $post_id ) {
	$post = get_post( $post_id );
	return $post instanceof WP_Post
		&& 'publish' === $post->post_status
		&& in_array( $post->post_type, pops_post_types(), true );
}

/**
 * 今日の閲覧数に1を足す。
 *
 * @param int $post_id 記事のID。
 * @return bool できたか。
 */
function pops_add_view( $post_id ) {
	global $wpdb;
	$result = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic upsert on a custom table; core has no API for it.
		$wpdb->prepare(
			'INSERT INTO %i (post_id, view_date, view_count) VALUES (%d, %s, 1) ON DUPLICATE KEY UPDATE view_count = view_count + 1',
			pops_table(),
			$post_id,
			current_datetime()->format( 'Y-m-d' )
		)
	);
	return false !== $result;
}

/**
 * 閲覧を送るJSを読み込む。数える記事の個別ページで、ログインしていないときだけ。
 */
function pops_enqueue_counter() {
	if ( ! is_singular( pops_post_types() ) || is_preview() || is_user_logged_in() || ! pops_get_setting( 'enabled' ) ) {
		return;
	}

	$asset_file = POPS_DIR . 'build/view-counter.asset.php';
	if ( ! file_exists( $asset_file ) ) {
		_doing_it_wrong( __FUNCTION__, 'build/がありません。pnpm buildを実行してください。', '0.1.0' );
		return;
	}
	$asset   = require $asset_file;
	$post_id = get_queried_object_id();

	wp_enqueue_script(
		'pops-view-counter',
		plugins_url( 'build/view-counter.js', POPS_FILE ),
		$asset['dependencies'],
		$asset['version'],
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_script(
		'pops-view-counter',
		'window.popsCounter = ' . wp_json_encode(
			array(
				'endpoint' => esc_url_raw( rest_url( 'pops/v1/views/' . $post_id ) ),
				'postId'   => $post_id,
			),
			JSON_HEX_TAG | JSON_UNESCAPED_SLASHES
		) . ';',
		'before'
	);
}
add_action( 'wp_enqueue_scripts', 'pops_enqueue_counter' );
