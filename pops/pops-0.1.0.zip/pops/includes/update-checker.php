<?php
/**
 * 自己ホストの更新チェック
 *
 * wordpress.orgには載せていないので、更新の情報は配布用のリポジトリ（ejointjp/wordpress-plugin-updates）に置いたinfo.jsonから取る。
 * メインファイルのヘッダーにUpdate URI（https://yuiami.jp/wp-plugins/pops）があると、WordPressはこのプラグインの更新を
 * wordpress.orgに問い合わせず、そのホスト名の付いたフィルタupdate_plugins_yuiami.jpを呼ぶ。Update URIは識別子で、実在しなくてよい。
 *
 * - 更新の判定（update_plugins_yuiami.jp）は、キャッシュを読まずに毎回取得する。確認の間隔は本体に任せる
 *   （画面によって1分〜1時間、定期の確認は12時間）。「再確認」ですぐ反映させたいため
 * - 画面から動く確認では待ち時間を3秒に抑える（本体がwordpress.orgへ問い合わせるときと同じ考え方）。
 *   GitHubが応答しないとき、管理画面の表示が止まらないように
 * - 詳細の表示（plugins_api）は、1時間キャッシュした情報を使う
 * - 取得できなければ、理由をPHPのエラーログに残して「更新なし」として扱う
 * - 問い合わせで送るのは、info.jsonのURLと固定のUser-Agentだけ。サイトのURLやデータは送らない
 * - アイコンは、プラグインに同梱したassets/icon.svgのURLを返す（ダッシュボード → 更新に出る）。配布用のリポジトリに置くと、
 *   更新の画面を開くたびに管理者のブラウザがGitHubへ画像を取りに行き、サイトのURL（origin）も送られるため
 * - バナーも同じ理由で、同梱のassets/banner-1544x500.pngのURLを返す（「詳細を表示」のポップアップに出る）。
 *   highだけを返し、本体が普通の解像度の画面でもこれを縮めて使う（772x250は同梱しない）
 *
 * 定期の更新チェックはwp-cronで動くので、is_admin()の外で読み込むこと。プラグインが停止中のサイトでは動かない。
 * ひな形と導入の手順は/wp-plugin-publishのreferences/selfhost.md。
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const POPS_UPDATE_SLUG     = 'pops';
const POPS_UPDATE_BASE_URL = 'https://raw.githubusercontent.com/ejointjp/wordpress-plugin-updates/main/pops/';

/**
 * 更新の情報（info.json）を返す。
 *
 * @param bool $fresh trueならキャッシュを読まずに取得する。
 * @return array|null 取得できなければnull。
 */
function pops_get_update_info( $fresh ) {
	if ( ! $fresh ) {
		$cached = get_site_transient( 'pops_update_info' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	// WordPressの既定のUser-AgentはサイトのURLを含む。配布元へ送らないよう、固定の文字列にする
	$response = wp_remote_get(
		POPS_UPDATE_BASE_URL . 'info.json',
		array(
			'timeout'    => wp_doing_cron() ? 10 : 3,
			'user-agent' => 'pops update check',
		)
	);
	if ( is_wp_error( $response ) ) {
		pops_log_update_error( $response->get_error_message() );
		return null;
	}
	$status = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $status ) {
		pops_log_update_error( 'HTTP ' . $status );
		return null;
	}
	$info = json_decode( wp_remote_retrieve_body( $response ), true );
	// zipのURLは、このプラグインの置き場にあるものだけを受け付ける
	if (
		! is_array( $info )
		|| '' === pops_update_field( $info, 'version' )
		|| 0 !== strpos( pops_update_field( $info, 'package' ), POPS_UPDATE_BASE_URL )
	) {
		pops_log_update_error( 'info.json is not valid' );
		return null;
	}

	set_site_transient( 'pops_update_info', $info, HOUR_IN_SECONDS );
	return $info;
}

/**
 * 更新の情報を取得できなかった理由を、PHPのエラーログに残す。
 *
 * @param string $reason 理由。
 */
function pops_log_update_error( $reason ) {
	error_log( 'POPS update check: ' . $reason ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Records why the update information could not be retrieved.
}

/**
 * 更新の情報から文字列の項目を取り出す。なければ空文字。
 *
 * @param array  $info 更新の情報。
 * @param string $key  項目名。
 * @return string
 */
function pops_update_field( array $info, $key ) {
	return isset( $info[ $key ] ) && is_string( $info[ $key ] ) ? $info[ $key ] : '';
}

/**
 * 「Tested up to」を、サイトのWordPressと同じ系列なら、サイトの版に読み替える。
 *
 * readme.txtにはメジャー番号だけ（7.1）を書く。本体はversion_compare()で比べるので、そのまま返すと、
 * 7.1.2のサイトで「テストされていない」と表示される。wordpress.orgのAPIも、同じ系列の最新のパッチ版に読み替えて返す。
 *
 * @param string $tested info.jsonのtested。
 * @return string
 */
function pops_update_tested( $tested ) {
	$current = get_bloginfo( 'version' );
	if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $current, $tested . '.' ) ) {
		return $current;
	}
	return $tested;
}

/**
 * 更新の情報に載せるアイコンを返す。同梱のassets/icon.svgがなければ空にする（本体の既定のアイコンになる）。
 *
 * @return array
 */
function pops_update_icons() {
	if ( ! file_exists( plugin_dir_path( POPS_FILE ) . 'assets/icon.svg' ) ) {
		return array();
	}
	return array( 'svg' => plugins_url( 'assets/icon.svg', POPS_FILE ) );
}

/**
 * 詳細の表示に載せるバナーを返す。同梱のassets/banner-1544x500.pngがなければ空にする（バナーなしになる）。
 *
 * @return array
 */
function pops_update_banners() {
	if ( ! file_exists( plugin_dir_path( POPS_FILE ) . 'assets/banner-1544x500.png' ) ) {
		return array();
	}
	return array( 'high' => plugins_url( 'assets/banner-1544x500.png', POPS_FILE ) );
}

/**
 * 更新の判定に、配布用のリポジトリにある最新版の情報を返す。新しいかどうかは本体が比べる。
 *
 * @param array|false $update      ここまでのフィルタの結果。
 * @param array       $plugin_data プラグインのヘッダー。
 * @param string      $plugin_file プラグインのファイル（plugin_basename()の形）。
 * @return array|false
 */
function pops_filter_update( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( POPS_FILE ) !== $plugin_file ) {
		return $update;
	}
	$info = pops_get_update_info( true );
	if ( null === $info ) {
		return $update;
	}
	return array(
		'slug'         => POPS_UPDATE_SLUG,
		'version'      => $info['version'],
		'package'      => $info['package'],
		'url'          => isset( $plugin_data['AuthorURI'] ) ? $plugin_data['AuthorURI'] : '',
		'requires'     => pops_update_field( $info, 'requires' ),
		'requires_php' => pops_update_field( $info, 'requires_php' ),
		'tested'       => pops_update_tested( pops_update_field( $info, 'tested' ) ),
		'icons'        => pops_update_icons(),
	);
}
add_filter( 'update_plugins_yuiami.jp', 'pops_filter_update', 10, 3 );

/**
 * 「詳細を表示」のポップアップに、配布用のリポジトリにある情報を返す。
 *
 * @param false|object|array $result ここまでのフィルタの結果。
 * @param string             $action plugins_api()の種類。
 * @param object             $args   plugins_api()の引数。
 * @return false|object|array|WP_Error
 */
function pops_filter_plugin_information( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || ! isset( $args->slug ) || POPS_UPDATE_SLUG !== $args->slug ) {
		return $result;
	}
	$info = pops_get_update_info( false );
	if ( null === $info ) {
		// falseのまま返すと、本体がwordpress.orgの同じslugを見に行く。エラーにして止める
		return new WP_Error( 'pops_update_info', '更新情報を取得できませんでした。後ほどもう一度お試しください。' );
	}
	$sections = isset( $info['sections'] ) && is_array( $info['sections'] ) ? array_filter( $info['sections'], 'is_string' ) : array();
	return (object) array(
		'name'          => esc_html( pops_update_field( $info, 'name' ) ),
		'slug'          => POPS_UPDATE_SLUG,
		'version'       => $info['version'],
		'author'        => esc_html( pops_update_field( $info, 'author' ) ),
		'requires'      => pops_update_field( $info, 'requires' ),
		'requires_php'  => pops_update_field( $info, 'requires_php' ),
		'tested'        => pops_update_tested( pops_update_field( $info, 'tested' ) ),
		'last_updated'  => pops_update_field( $info, 'last_updated' ),
		'sections'      => $sections,
		'banners'       => pops_update_banners(),
		'download_link' => $info['package'],
		'external'      => true, // wordpress.orgのプラグインページへのリンクを出さない
	);
}
add_filter( 'plugins_api', 'pops_filter_plugin_information', 10, 3 );
