<?php
/**
 * 投稿一覧の「閲覧数」の列と並べ替え
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const POPS_COLUMN = 'pops_views';

/**
 * 数える投稿タイプの一覧に、列を足す。
 */
function pops_register_columns() {
	foreach ( pops_post_types() as $type ) {
		add_filter( "manage_{$type}_posts_columns", 'pops_add_column' );
		add_action( "manage_{$type}_posts_custom_column", 'pops_show_column', 10, 2 );
		add_filter( "manage_edit-{$type}_sortable_columns", 'pops_sortable_column' );
	}
}
add_action( 'admin_init', 'pops_register_columns' );

/**
 * 列を足す。
 *
 * @param array $columns 列。
 * @return array
 */
function pops_add_column( $columns ) {
	$columns[ POPS_COLUMN ] = '閲覧数';
	return $columns;
}

/**
 * 並べ替えられるようにする（最初は多い順）。
 *
 * @param array $columns 並べ替えられる列。
 * @return array
 */
function pops_sortable_column( $columns ) {
	$columns[ POPS_COLUMN ] = array( POPS_COLUMN, true );
	return $columns;
}

/**
 * 列の値を出す。
 *
 * @param string $column  列のキー。
 * @param int    $post_id 記事のID。
 */
function pops_show_column( $column, $post_id ) {
	if ( POPS_COLUMN !== $column ) {
		return;
	}
	echo esc_html( number_format_i18n( pops_column_views( (int) $post_id ) ) );
}

/**
 * 記事の閲覧数の合計を返す。一覧に出ている記事の分を、まとめて1回で問い合わせる。
 *
 * @param int $post_id 記事のID。
 * @return int
 */
function pops_column_views( $post_id ) {
	static $views = array();

	if ( ! array_key_exists( $post_id, $views ) ) {
		global $wp_query;
		$listed = $wp_query instanceof WP_Query && is_array( $wp_query->posts ) ? wp_list_pluck( $wp_query->posts, 'ID' ) : array();
		// クイック編集の保存では、一覧の問い合わせがない
		$ids    = array_unique( array_map( 'intval', array_merge( $listed, array( $post_id ) ) ) );
		$views += array_fill_keys( $ids, 0 );
		foreach ( pops_total_views( $ids ) as $id => $total ) {
			$views[ $id ] = $total;
		}
	}
	return $views[ $post_id ];
}

/**
 * 記事ごとの、閲覧数の合計を返す。
 *
 * @param int[] $ids 記事のID。
 * @return array<int,int> 閲覧のあった記事だけ。
 */
function pops_total_views( array $ids ) {
	global $wpdb;
	$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- $placeholders holds only placeholders. Custom table, admin list only.
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT post_id, SUM( view_count ) AS views FROM %i WHERE post_id IN ( $placeholders ) GROUP BY post_id",
			array_merge( array( pops_table() ), $ids )
		),
		ARRAY_A
	);
	// phpcs:enable

	return array_map( 'intval', array_column( (array) $rows, 'views', 'post_id' ) );
}

/**
 * 閲覧数で並べ替える。閲覧のない記事は0として扱う。
 *
 * @param string[] $clauses SQLの句。
 * @param WP_Query $query   問い合わせ。
 * @return string[]
 */
function pops_sort_clauses( $clauses, $query ) {
	if ( ! is_admin() || ! $query->is_main_query() || POPS_COLUMN !== $query->get( 'orderby' ) ) {
		return $clauses;
	}
	global $wpdb;
	$order = 'ASC' === strtoupper( (string) $query->get( 'order' ) ) ? 'ASC' : 'DESC';

	$clauses['join']   .= $wpdb->prepare(
		' LEFT JOIN ( SELECT post_id, SUM( view_count ) AS views FROM %i GROUP BY post_id ) AS pops ON pops.post_id = %i.ID ',
		pops_table(),
		$wpdb->posts
	);
	$clauses['orderby'] = "COALESCE( pops.views, 0 ) $order, {$wpdb->posts}.post_date DESC";
	return $clauses;
}
add_filter( 'posts_clauses', 'pops_sort_clauses', 10, 2 );
