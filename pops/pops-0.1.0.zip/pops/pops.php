<?php
/**
 * Plugin Name:       POPS – Popular Posts Ranking
 * Description:       記事の閲覧数を数え、人気記事のランキングを、どのテーマでも同じデザインで表示します。
 * Version:           0.1.0
 * Requires at least: 6.8
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pops
 * Update URI:        https://yuiami.jp/wp-plugins/pops
 *
 * @package pops
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'POPS_VERSION', '0.1.0' );
define( 'POPS_FILE', __FILE__ );
define( 'POPS_DIR', plugin_dir_path( __FILE__ ) );

require_once POPS_DIR . 'includes/periods.php';
require_once POPS_DIR . 'includes/settings.php';
require_once POPS_DIR . 'includes/database.php';
require_once POPS_DIR . 'includes/import.php';
require_once POPS_DIR . 'includes/ranking.php';
require_once POPS_DIR . 'includes/counter.php';
require_once POPS_DIR . 'includes/render.php';
require_once POPS_DIR . 'includes/block.php';

// 自己ホストの更新チェック。定期の更新チェックはwp-cronで動くので、is_admin()の中に入れない。
require_once POPS_DIR . 'includes/update-checker.php';

if ( is_admin() ) {
	require_once POPS_DIR . 'includes/admin-menu.php';
	require_once POPS_DIR . 'includes/settings-page.php';
	require_once POPS_DIR . 'includes/admin-column.php';
	require_once POPS_DIR . 'includes/ranking-page.php';
}

register_activation_hook( __FILE__, 'pops_upgrade' );
