=== POPS – Popular Posts Ranking ===
Contributors: ejointjp
Tags: popular posts, ranking, views
Requires at least: 6.8
Tested up to: 7.1
Stable tag: 0.1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

記事の閲覧数を数え、人気記事のランキングを、どのテーマでも同じデザインで表示します。

== Description ==

記事の閲覧数を数え、人気記事のランキングを表示します。

- 人気記事のブロック。縦に並べるリストと、横に流すスライダーの2つの形
- 全期間・年間・月間・週間の順位
- 投稿一覧の閲覧数の列と、人気記事ランキングの画面
- ページキャッシュの中でも数えられます。ログインしている人の閲覧は数えません
- テーマ（haku / haku2）が数えていた閲覧数を、最初に1回だけ取り込みます。元のデータは消しません

更新の確認でGitHub（raw.githubusercontent.com）に問い合わせます。サイトのURLやデータは送りません。そのほかの外部との通信はありません。

== Installation ==

1. プラグインを`/wp-content/plugins/pops`に置きます。
2. 「プラグイン」の画面で有効化します。
3. 人気記事のブロックを、本文やウィジェットエリアに置きます。

== Frequently Asked Questions ==

= 閲覧数が増えません =

ログインしている人の閲覧は数えません。同じ人が同じ記事を24時間以内に開いても、1回と数えます。

テーマやプラグインで、未ログインのREST APIを制限しているときは、`/pops/v1/views`を許可してください。

= テーマのテンプレートに置けますか？ =

2通りの使い方があります。

そのまま表示する: `pops_get_posts()`で記事があるかを確かめ、`pops_display()`で出します。引数は`layout`（`list` / `slider`）・`period`・`limit`・`rank`・`exclude_current`・`heading`・`author`です。

データだけを使う: `pops_query()`が、順位の順の`WP_Query`を返します。テーマのループで好きな見た目に描けます。引数は`period`・`limit`・`exclude_current`です。

= 色や大きさを変えられますか？ =

テーマのCSSで、`--pops-color-text`などのCSS変数を指定してください。変数の一覧は、プラグインのCSSの冒頭にあります。

== Changelog ==

= 0.1.0 =
* 最初の版
