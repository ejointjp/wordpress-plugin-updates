<?php
/**
 * アンインストール時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 *
 * ステータスの登録が外れるとrewriting / archivedの投稿は管理画面の一覧から見えなくなるため、
 * どちらもdraftへ戻す。投稿と投稿メタ（_rewrite_archive_*）は利用者のコンテンツなので消さない。
 * 残ったメタは再インストール後に参照の検証で残骸として掃除される。
 * プラグインのファイルは読み込まれず、ガードもステータスもない状態なので、$wpdbで直接更新する。
 * write_log()もこの時点では読み込まれていないため、IDの読み出し（SELECT）やUPDATEに失敗したときは
 * 同じ接頭辞でerror_log()に直接書く。
 *
 * オプションは設定（対象の投稿タイプ）のrewrite_archive_settingsだけで、ここで消す。
 * 更新の情報のキャッシュ（サイトのトランジェントrewrite_archive_update_info。includes/update-checker.php）も消す。
 * cron・カスタムテーブルは持たないため、他に消すものはない。
 * 保存するデータを増やしたら、同じコミットでここも更新すること。
 *
 * マルチサイトでは全サイトを回る（オプションも投稿もサイトごとに持つため）。
 * 検証（tests/uninstall-cases.php）が同じプロセスで何度もrequireするため、処理はクロージャに持たせる。
 *
 * @package RewriteArchive
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * 1サイト分の後始末
 *
 * @return void
 */
$rewrite_archive_uninstall_site = static function (): void {
	global $wpdb;

	delete_option( 'rewrite_archive_settings' );

	foreach ( array( 'rewriting', 'archived' ) as $status ) {
		$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- アンインストール時の一括更新。キャッシュは下で個別に消す
			$wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = %s", $status )
		);

		// get_col()は失敗しても空の配列を返すため、$wpdb->last_errorで見分ける。
		if ( '' !== $wpdb->last_error ) {
			error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- write_log()はプラグイン本体の関数でアンインストール時は読み込まれていない
				sprintf(
					'rewrite-archive: アンインストールで%1$sの投稿を読み出せなかったため、draftへ戻していない。一覧に出ないまま残る投稿があるかもしれない。%2$s',
					$status,
					$wpdb->last_error
				)
			);
			continue;
		}

		if ( empty( $ids ) ) {
			continue;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 同上
			$wpdb->posts,
			array( 'post_status' => 'draft' ),
			array( 'post_status' => $status )
		);

		if ( false === $updated ) {
			error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- write_log()はプラグイン本体の関数でアンインストール時は読み込まれていない
				sprintf(
					'rewrite-archive: アンインストールで%1$sの投稿をdraftへ戻せなかった。%2$d件が一覧に出ないまま残る。%3$s',
					$status,
					count( $ids ),
					$wpdb->last_error
				)
			);
			continue;
		}

		foreach ( $ids as $id ) {
			clean_post_cache( (int) $id );
		}
	}
};

if ( is_multisite() ) {
	// number=0で件数の上限を外し、ネットワークの全サイトを回る。
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $rewrite_archive_site_id ) {
		switch_to_blog( (int) $rewrite_archive_site_id );
		$rewrite_archive_uninstall_site();
		restore_current_blog();
	}
} else {
	$rewrite_archive_uninstall_site();
}

// 更新の情報のキャッシュは、マルチサイトでもネットワーク全体で1つ。サイトごとの後始末の外で消す。
delete_site_transient( 'rewrite_archive_update_info' );
