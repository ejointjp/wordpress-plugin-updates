<?php
/**
 * 誤操作ガード
 *
 * rewriting / archivedの投稿のステータスは、このプラグインの操作以外では変えられない。
 * rewritingへ入れるのも「リライトを始める」だけ（archivedへはクイック編集やRESTからも入れられる）。
 * REST・クイック編集・一括編集・XML-RPC・WP-CLI・他プラグインのwp_update_post()は
 * すべてwp_insert_post_dataを通るため、そこで止める。
 * コピーは「リライトをやめる」以外でゴミ箱にも完全削除にもできない（画像の付け替えを必ず通すため）。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ガードのバイパス状態を保持する
 *
 * @param bool|null $set 指定すると状態を書き換える。nullなら読むだけ.
 * @return bool バイパス中ならtrue。
 */
function guard_bypassed( ?bool $set = null ): bool {
	static $bypassed = false;

	if ( null !== $set ) {
		$bypassed = $set;
	}

	return $bypassed;
}

/**
 * ガードを外した状態でコールバックを実行する
 *
 * プラグイン自身がステータスを変える・コピーを消すときだけ使う。
 *
 * @param callable $callback 実行する処理.
 * @return mixed コールバックの戻り値。
 */
function without_guard( callable $callback ) {
	$previous = guard_bypassed();
	guard_bypassed( true );

	try {
		return $callback();
	} finally {
		guard_bypassed( $previous );
	}
}

/**
 * ガード対象のステータスかどうか
 *
 * @param string $status ステータス名.
 * @return bool
 */
function is_guarded_status( string $status ): bool {
	return in_array( $status, array( STATUS_REWRITING, STATUS_ARCHIVED ), true );
}

/**
 * ガード対象の投稿なら返す
 *
 * 添付ファイルとリビジョンは対象外。添付ファイルはget_post_status()が親のステータスを返すため、
 * 生のpost_statusを見る。
 *
 * @param int $post_id 投稿ID.
 * @return \WP_Post|null ガード対象ならその投稿。
 */
function get_guarded_post( int $post_id ): ?\WP_Post {
	$post = get_post( $post_id );

	if ( ! $post instanceof \WP_Post || in_array( $post->post_type, array( 'attachment', 'revision' ), true ) ) {
		return null;
	}

	return is_guarded_status( $post->post_status ) ? $post : null;
}

/**
 * 保存直前のデータを検査する
 *
 * 1. ガード対象の投稿のステータスが変わるなら据え置く（archived→trashだけは通す）
 * 2. リライト中のコピーを持つ元記事をarchivedにしようとしたら据え置く（switch_archive_status()と同じ条件。
 *    クイック編集・REST・他プラグインのwp_update_post()はswitch_archive_status()を通らないため、ここで止める）
 * 3. rewritingへ入れるのは「リライトを始める」（start_rewrite()）だけ。新規作成と保存前の新規投稿（auto-draft）
 *    ならdraftにし、既存の投稿なら今のステータスのまま据え置く。RESTのstatusの選択肢にはrewritingが入るため、公開中の投稿がフロントから
 *    消えたり、4の日付の固定で元の公開日が失われたりしないよう、ここで止める
 * 4. 最終的にrewritingのまま保存する投稿はpost_dateを現在時刻にする（画像を作成月のフォルダに入れるため。SPEC §5.3）
 *
 * @param array $data                保存するデータ.
 * @param array $postarr             wp_insert_post()に渡された配列.
 * @param array $unsanitized_postarr サニタイズ前の配列（使わない）.
 * @param bool  $update              既存投稿の更新ならtrue.
 * @return array 保存するデータ。
 */
function filter_insert_post_data( $data, $postarr, $unsanitized_postarr = array(), $update = false ) {
	unset( $unsanitized_postarr );

	if ( ! is_array( $data ) ) {
		return $data;
	}

	$next_status = isset( $data['post_status'] ) ? (string) $data['post_status'] : '';
	$post_type   = isset( $data['post_type'] ) ? (string) $data['post_type'] : '';

	if ( $update && ! guard_bypassed() && ! empty( $postarr['ID'] ) ) {
		$current = get_guarded_post( (int) $postarr['ID'] );

		if ( $current && $next_status !== $current->post_status && ! ( STATUS_ARCHIVED === $current->post_status && 'trash' === $next_status ) ) {
			write_log(
				sprintf(
					'投稿%1$dのステータスを%2$sへ変えようとしたので%3$sのまま据え置いた。プラグインの操作で切り替えること。',
					$current->ID,
					$next_status,
					$current->post_status
				)
			);
			$data['post_status'] = $current->post_status;
			$next_status         = $current->post_status;
		}

		if ( ! $current && STATUS_ARCHIVED === $next_status ) {
			$original = get_post( (int) $postarr['ID'] );

			if ( $original instanceof \WP_Post && get_copy_id( $original->ID ) ) {
				write_log( sprintf( '投稿%dにはリライト中のコピーがあるのでarchivedへ変えなかった。先に差し替えるか、リライトをやめること。', $original->ID ) );
				$data['post_status'] = $original->post_status;
				$next_status         = $original->post_status;
			}
		}
	}

	if ( STATUS_REWRITING === $next_status && 'revision' !== $post_type && ! guard_bypassed() ) {
		$existing = ( $update && ! empty( $postarr['ID'] ) ) ? get_post( (int) $postarr['ID'] ) : null;

		if ( ! $existing instanceof \WP_Post ) {
			write_log( '新規投稿をrewritingで作ろうとしたのでdraftにした。リライトは「リライトを始める」から始めること。' );
			$data['post_status'] = 'draft';
			$next_status         = 'draft';

			// 日付を渡していない新規投稿は、下書きの慣例どおり日付を浮かせる（post_date_gmtをゼロにする）。
			// rewritingは日付が浮かないステータスのため、WP本体がここまでにgmtを埋めている。
			if ( empty( $postarr['post_date'] ) && empty( $postarr['post_date_gmt'] ) ) {
				$data['post_date_gmt'] = '0000-00-00 00:00:00';
			}
		} elseif ( 'auto-draft' === $existing->post_status ) {
			// 保存前の新規投稿を据え置くと、保存したのにauto-draftのまま残る（WP本体が消す対象と見る）ため、draftにする。
			write_log(
				sprintf(
					'投稿%dをauto-draftからrewritingへ変えようとしたので、保存前の新規投稿のためdraftにした。リライトは「リライトを始める」から始めること。',
					$existing->ID
				)
			);
			$data['post_status'] = 'draft';
			$next_status         = 'draft';
		} elseif ( STATUS_REWRITING !== $existing->post_status ) {
			write_log(
				sprintf(
					'投稿%1$dを%2$sからrewritingへ変えようとしたので据え置いた。リライトは「リライトを始める」から始めること。',
					$existing->ID,
					$existing->post_status
				)
			);
			$data['post_status'] = $existing->post_status;
			$next_status         = $existing->post_status;
		}
	}

	if ( STATUS_REWRITING === $next_status && 'revision' !== $post_type ) {
		$data['post_date']     = current_time( 'mysql' );
		$data['post_date_gmt'] = current_time( 'mysql', true );
	}

	return $data;
}
add_filter( 'wp_insert_post_data', __NAMESPACE__ . '\filter_insert_post_data', 99, 4 );

/**
 * コピーのゴミ箱移動・完全削除を止めるかどうか決める
 *
 * @param bool|null $check  null以外なら他のコードが既に判断している.
 * @param mixed     $post   対象の投稿.
 * @param string    $action ログに書く操作名（「ゴミ箱へ移動」か「完全削除」）.
 * @return bool|null 止めるならfalse。止めないときは$checkをそのまま返す。
 */
function refuse_copy_removal( $check, $post, string $action ) {
	if ( null !== $check || guard_bypassed() || ! $post instanceof \WP_Post || STATUS_REWRITING !== $post->post_status ) {
		return $check;
	}

	write_log( sprintf( '投稿%1$dはリライト中のコピーなので%2$sしなかった。「リライトをやめる」で消すこと。', $post->ID, $action ) );

	return false;
}

/**
 * コピーがゴミ箱へ移動されるのを止める
 *
 * @param bool|null $check null以外なら他のコードが既に判断している.
 * @param \WP_Post  $post  対象の投稿.
 * @return bool|null falseで止める。
 */
function filter_pre_trash_post( $check, $post ) {
	return refuse_copy_removal( $check, $post, 'ゴミ箱へ移動' );
}
add_filter( 'pre_trash_post', __NAMESPACE__ . '\filter_pre_trash_post', 10, 2 );

/**
 * コピーが完全削除されるのを止める
 *
 * @param bool|null $check null以外なら他のコードが既に判断している.
 * @param \WP_Post  $post  対象の投稿.
 * @return bool|null falseで止める。
 */
function filter_pre_delete_post( $check, $post ) {
	return refuse_copy_removal( $check, $post, '完全削除' );
}
add_filter( 'pre_delete_post', __NAMESPACE__ . '\filter_pre_delete_post', 10, 2 );

/**
 * ゴミ箱から戻すときの復元先
 *
 * WP本体はどのステータスからでもdraftに戻す。アーカイブはarchivedに戻す。
 *
 * @param string $new_status      復元先のステータス.
 * @param int    $post_id         投稿ID（使わない）.
 * @param string $previous_status ゴミ箱に入れる前のステータス.
 * @return string
 */
function filter_untrash_post_status( $new_status, $post_id, $previous_status ) {
	unset( $post_id );

	return STATUS_ARCHIVED === $previous_status ? STATUS_ARCHIVED : $new_status;
}
add_filter( 'wp_untrash_post_status', __NAMESPACE__ . '\filter_untrash_post_status', 10, 3 );
