<?php
/**
 * アーカイブの出し入れと一括操作
 *
 * lovemac.jpのmu-plugin（lovemac-archived-status.php）の移植。対象タイプ全部に効かせる。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 投稿をarchivedにする、またはarchivedからdraftへ戻す
 *
 * リライト中のコピーと、コピーを持つ元記事はarchivedにできない。
 * ゴミ箱の投稿もarchivedにできない（ゴミ箱に入れたときのメタが残り、復元先が狂うため）。
 * 保存前の新規投稿（auto-draft）は対象の投稿として扱わない。
 * 差し替え前の版（META_REASONがREASON_REWRITE）はdraftへ戻せない。別の記事として復活させないため
 * （SPEC §13-1）。
 *
 * @param int    $post_id 対象の投稿ID.
 * @param string $to      切り替え先。archivedかdraft.
 * @return bool|\WP_Error 成功ならtrue。
 */
function switch_archive_status( int $post_id, string $to ): bool|\WP_Error {
	$post = get_post( $post_id );

	if ( ! $post instanceof \WP_Post || ! is_target_post_type( $post->post_type ) || 'auto-draft' === $post->post_status ) {
		return make_error( 'rewrite_archive_not_found' );
	}

	if ( ! in_array( $to, array( STATUS_ARCHIVED, 'draft' ), true ) ) {
		return make_error( 'rewrite_archive_invalid_status' );
	}

	if ( STATUS_REWRITING === $post->post_status ) {
		return make_error( 'rewrite_archive_is_rewriting' );
	}

	if ( 'draft' === $to && STATUS_ARCHIVED !== $post->post_status ) {
		return make_error( 'rewrite_archive_not_archived' );
	}

	// ゴミ箱の投稿をarchivedにすると_wp_trash_meta_status / _timeが残ったままになり、もう一度ゴミ箱に
	// 入れると2行目が足され、復元で古い行が読まれてarchivedではなくdraftに戻る。
	if ( 'trash' === $post->post_status ) {
		return make_error( 'rewrite_archive_in_trash' );
	}

	if ( 'draft' === $to && REASON_REWRITE === get_post_meta( $post->ID, META_REASON, true ) ) {
		return make_error( 'rewrite_archive_pre_replace' );
	}

	if ( STATUS_ARCHIVED === $to && get_copy_id( $post->ID ) ) {
		return make_error( 'rewrite_archive_has_copy' );
	}

	if ( ! current_user_can( 'edit_post', $post->ID ) ) {
		return make_error( 'rewrite_archive_forbidden' );
	}

	$result = without_guard(
		static function () use ( $post, $to ) {
			// wp_update_post()は既存のpage_templateを混ぜ込み、有効なテーマにないテンプレートだと
			// 投稿の状態を書き込んだあとでinvalid_page_templateを返す。空にして検証を飛ばす。
			return wp_update_post(
				array(
					'ID'            => $post->ID,
					'post_status'   => $to,
					'page_template' => '',
				),
				true
			);
		}
	);

	if ( is_wp_error( $result ) ) {
		return $result;
	}

	return true;
}

/**
 * 対象タイプごとに一括操作のフックを張る
 *
 * 投稿タイプはinitで登録されるため、admin_initで回す。
 *
 * @return void
 */
function register_bulk_actions(): void {
	foreach ( get_target_post_types() as $post_type ) {
		add_filter( "bulk_actions-edit-{$post_type}", __NAMESPACE__ . '\add_bulk_actions' );
		add_filter( "handle_bulk_actions-edit-{$post_type}", __NAMESPACE__ . '\handle_bulk_actions', 10, 3 );
	}
}
add_action( 'admin_init', __NAMESPACE__ . '\register_bulk_actions' );

/**
 * 一括操作の項目を足す
 *
 * WP本体はゴミ箱を含むどの絞り込みでもこのフィルタを通す。ゴミ箱の絞り込みでは足さない。
 * 「リライト中」の絞り込みでも足さず、WP本体の「ゴミ箱へ移動」「完全に削除する」も外す
 * （コピーはガードでゴミ箱にも削除にもできず、edit.phpがエラー画面で止まるため）。
 *
 * @param array $actions 一括操作の項目.
 * @return array
 */
function add_bulk_actions( array $actions ): array {
	// WP本体もWP_Posts_List_Table::prepare_items()で同じ値からゴミ箱の絞り込みかどうかを決めている
	// （一覧の$is_trashはprivateで、外から読むと非推奨の警告が出る）。
	$view = isset( $_REQUEST['post_status'] ) ? sanitize_key( wp_unslash( $_REQUEST['post_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 一括操作の項目の出し分け（表示）にだけ使う。操作はWP本体がnonceを検証している

	if ( 'trash' === $view ) {
		return $actions;
	}

	if ( STATUS_REWRITING === $view ) {
		unset( $actions['trash'], $actions['delete'] );

		return $actions;
	}

	$actions['rewrite_archive_archive']   = 'アーカイブに移動';
	$actions['rewrite_archive_unarchive'] = 'アーカイブから下書きへ戻す';

	return $actions;
}

/**
 * 一括操作を実行し、件数をリダイレクト先に付ける
 *
 * @param string $redirect リダイレクト先.
 * @param string $doaction 実行する操作.
 * @param array  $post_ids 対象の投稿ID.
 * @return string リダイレクト先。
 */
function handle_bulk_actions( $redirect, $doaction, $post_ids ) {
	if ( ! in_array( $doaction, array( 'rewrite_archive_archive', 'rewrite_archive_unarchive' ), true ) ) {
		return $redirect;
	}

	$to      = 'rewrite_archive_archive' === $doaction ? STATUS_ARCHIVED : 'draft';
	$changed = 0;
	$failed  = 0;

	foreach ( (array) $post_ids as $post_id ) {
		$result = switch_archive_status( (int) $post_id, $to );

		if ( is_wp_error( $result ) ) {
			++$failed;
			write_log( sprintf( '投稿%1$dを%2$sへ変更できなかった。%3$s', (int) $post_id, $to, $result->get_error_message() ) );
			continue;
		}

		++$changed;
	}

	return add_query_arg(
		array(
			'rewrite_archive_bulk_count'  => $changed,
			'rewrite_archive_bulk_failed' => $failed,
			'rewrite_archive_bulk_to'     => $to,
		),
		(string) $redirect
	);
}
