<?php
/**
 * 複製: 元と関係を持たない新しい下書きを作る
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 投稿を複製して新しい下書きを作る
 *
 * リライトとは別の機能。メタも印も付けず、作ったあとは普通の下書き。
 * スラグは空のままWPに任せる。日付は下書きの挙動どおり保存のたびに現在時刻になる。
 * 差し替え前の版は複製しない。記録として残す版で、複製しても別の記事になり、元の版に戻す用途には
 * 使えないため（手動のアーカイブは統合前の記事を素材にする用途があるので複製できる）。
 *
 * @param int $source_id 元の投稿ID.
 * @return int|\WP_Error 新しい下書きのID。
 */
function duplicate_post( int $source_id ): int|\WP_Error {
	$source = get_post( $source_id );

	if ( ! $source instanceof \WP_Post || ! is_target_post_type( $source->post_type ) ) {
		return make_error( 'rewrite_archive_not_found' );
	}

	if ( in_array( $source->post_status, array( STATUS_REWRITING, 'trash', 'auto-draft' ), true ) ) {
		return make_error( 'rewrite_archive_not_duplicable' );
	}

	if ( STATUS_ARCHIVED === $source->post_status && REASON_REWRITE === get_post_meta( $source->ID, META_REASON, true ) ) {
		return make_error( 'rewrite_archive_not_duplicable' );
	}

	$type_object = get_post_type_object( $source->post_type );

	if ( ! $type_object || ! current_user_can( 'edit_post', $source->ID ) || ! current_user_can( $type_object->cap->create_posts ) ) {
		return make_error( 'rewrite_archive_forbidden' );
	}

	$postarr                = copy_fields( $source );
	$postarr['post_status'] = 'draft';
	$postarr['post_author'] = get_current_user_id();
	$postarr['post_name']   = '';

	$new_id = without_kses(
		static function () use ( $postarr ) {
			return wp_insert_post( $postarr, true, false );
		}
	);

	if ( is_wp_error( $new_id ) ) {
		return make_error( 'rewrite_archive_copy_failed', $new_id->get_error_message() );
	}

	copy_terms( $source->ID, $new_id );
	copy_meta( $source->ID, $new_id );

	// wp_after_insert_postは、投稿・ターム・メタを保存し終えてから発火すると決まっているフック。
	// 挿入時には止めておき、写し終えてから発火する（他のプラグインが写し終えた状態を見るため）。
	wp_after_insert_post( $new_id, false, null );

	return $new_id;
}
