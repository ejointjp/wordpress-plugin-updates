<?php
/**
 * 対象の投稿タイプの解決・エラーログ・通知とエラーの文言
 *
 * どのファイルからも使う小さな関数だけを置く。対象の投稿タイプを選ぶ設定画面はsettings.php。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 設定のオプション名。値は配列で、post_typesに対象の投稿タイプ名の配列を持つ */
const OPTION_SETTINGS = 'rewrite_archive_settings';

/** 設定がないときの対象の投稿タイプ */
const DEFAULT_POST_TYPES = array( 'post', 'page' );

/**
 * 設定で選べる投稿タイプを返す
 *
 * publicかつ管理画面を持つ投稿タイプすべて。attachmentは除く。
 *
 * @return string[] 投稿タイプ名の配列（登録順）。
 */
function get_selectable_post_types(): array {
	$types = get_post_types(
		array(
			'public'  => true,
			'show_ui' => true,
		),
		'names'
	);

	unset( $types['attachment'] );

	return array_values( $types );
}

/**
 * 設定に保存された対象の投稿タイプを返す
 *
 * 設定がなければDEFAULT_POST_TYPES。選べない投稿タイプ（プラグインの停止で登録が消えたものなど）は除く。
 *
 * @return string[] 投稿タイプ名の配列。
 */
function get_saved_post_types(): array {
	$settings = get_option( OPTION_SETTINGS );
	$saved    = is_array( $settings ) && isset( $settings['post_types'] ) && is_array( $settings['post_types'] )
		? array_map( 'strval', $settings['post_types'] )
		: DEFAULT_POST_TYPES;

	return array_values( array_intersect( get_selectable_post_types(), $saved ) );
}

/**
 * このプラグインが扱う投稿タイプを返す
 *
 * 設定（設定 → 投稿設定）で選んだ投稿タイプ。既定はpostとpage。
 * `rewrite_archive_post_types`フィルタで増減できる。
 *
 * @return string[] 投稿タイプ名の配列。
 */
function get_target_post_types(): array {
	/**
	 * リライト・複製・アーカイブの対象にする投稿タイプを増減する
	 *
	 * @param string[] $types 設定で選んだ投稿タイプ名の配列。
	 */
	$types = apply_filters( 'rewrite_archive_post_types', get_saved_post_types() );

	return array_values( array_unique( array_filter( array_map( 'strval', (array) $types ) ) ) );
}

/**
 * 対象の投稿タイプかどうか
 *
 * @param string $post_type 投稿タイプ名.
 * @return bool 対象ならtrue。
 */
function is_target_post_type( string $post_type ): bool {
	return in_array( $post_type, get_target_post_types(), true );
}

/**
 * エラーログに書く
 *
 * 握り潰した操作や、続行した失敗を記録する。接頭辞で他のログと見分ける。
 *
 * @param string $message 本文.
 * @return void
 */
function write_log( string $message ): void {
	error_log( 'rewrite-archive: ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 握り潰した操作を記録に残すための出力
}

/**
 * 成功通知の文言を返す
 *
 * @param string $key 通知のキー（admin-post.phpのリダイレクトで付くrewrite_archive_noticeの値）.
 * @return string 文言。未知のキーは空文字。
 */
function notice_message( string $key ): string {
	$messages = array(
		'started'            => 'リライト用のコピーを作りました。書き終えたらサイドバーの「元記事に差し替える」を押してください。',
		'copy_exists'        => 'リライト中のコピーが既にあるので、そのコピーを開きました。',
		'replaced'           => '差し替えました。差し替え前の版はアーカイブにあります。',
		'replaced_copy_kept' => '差し替えました。ただし、コピーに上げた画像を元記事へ付け替えられなかったため、コピーは残しています。サーバーのエラーログを確認し、コピーの「リライトをやめる」でもう一度付け替えてください。',
		'abandoned'          => 'リライトをやめました。コピーに上げた画像は元記事に付け替えました。',
		'duplicated'         => '複製しました。元の投稿とは関係のない新しい下書きです。',
		'archived'           => 'アーカイブに移動しました。',
		'unarchived'         => '下書きに戻しました。',
	);

	return $messages[ $key ] ?? '';
}

/**
 * 通知の種類を返す
 *
 * 一部だけできた通知（replaced_copy_kept）はwarning、それ以外はsuccess。
 *
 * @param string $key 通知のキー.
 * @return string success / warning。
 */
function notice_type( string $key ): string {
	return 'replaced_copy_kept' === $key ? 'warning' : 'success';
}

/**
 * エラーの文言を返す
 *
 * 操作関数が返すWP_Errorのコードと、リダイレクトで付くrewrite_archive_errorの値に共通。
 *
 * @param string $code エラーコード.
 * @return string 文言。未知のコードは汎用の文言。
 */
function error_message( string $code ): string {
	$messages = array(
		'rewrite_archive_not_found'        => '対象の投稿が見つかりません。',
		'rewrite_archive_not_published'    => '公開中の投稿だけリライトできます。',
		'rewrite_archive_forbidden'        => 'この投稿を操作する権限がありません。',
		'rewrite_archive_not_copy'         => 'リライト中のコピーではありません。',
		'rewrite_archive_original_missing' => '元記事が見つからないか、公開中ではありません。元記事を公開してから差し替えるか、リライトをやめてください。',
		'rewrite_archive_copy_unlinked'    => 'このコピーは元記事とのつながりが切れているため、差し替えられません。「リライトをやめる」で消してから、元記事でリライトを始め直してください。',
		'rewrite_archive_original_locked'  => '元記事を別のユーザーが編集中のため、差し替えを中止しました。その人の編集が終わってから、もう一度差し替えてください。',
		'rewrite_archive_copy_failed'      => 'コピーの作成に失敗しました。サーバーのエラーログを確認してください。',
		'rewrite_archive_archive_failed'   => '差し替え前の版をアーカイブに保存できなかったため、差し替えを中止しました。元記事は変わっていません。サーバーのエラーログを確認してください。',
		'rewrite_archive_replace_failed'   => '元記事の書き換えに失敗したため、差し替えを中止しました。元記事は変わっていません。サーバーのエラーログを確認してください。',
		'rewrite_archive_delete_failed'    => 'コピーを削除できませんでした。サーバーのエラーログを確認してください。',
		'rewrite_archive_reattach_failed'  => 'コピーに上げた画像を元記事へ付け替えられなかったため、コピーを削除しませんでした。サーバーのエラーログを確認して、もう一度やり直してください。',
		'rewrite_archive_not_duplicable'   => 'この投稿は複製できません。リライト中のコピー・差し替え前の版・ゴミ箱の投稿・未保存の投稿は複製の対象外です。',
		'rewrite_archive_is_rewriting'     => 'リライト中のコピーはアーカイブに移動できません。「リライトをやめる」で消してください。',
		'rewrite_archive_has_copy'         => 'リライト中のコピーがある投稿はアーカイブに移動できません。先に差し替えるか、リライトをやめてください。',
		'rewrite_archive_in_trash'         => 'ゴミ箱の投稿はアーカイブに移動できません。先にゴミ箱から復元してください。',
		'rewrite_archive_invalid_status'   => '切り替え先のステータスが不正です。',
		'rewrite_archive_not_archived'     => 'アーカイブの投稿だけ下書きに戻せます。',
		'rewrite_archive_pre_replace'      => '差し替え前の版は下書きに戻せません。この版の内容に戻すときは、リライト版でリライトを始め、本文を貼り付けてから差し替えてください。',
	);

	return $messages[ $code ] ?? '処理に失敗しました。サーバーのエラーログを確認してください。';
}

/**
 * コードに対応する文言を持ったWP_Errorを作る
 *
 * @param string $code   エラーコード（error_message()の表にあるもの）.
 * @param string $detail ログ用の補足（WP本体が返したエラー文言など）。利用者には見せない.
 * @return \WP_Error
 */
function make_error( string $code, string $detail = '' ): \WP_Error {
	return new \WP_Error( $code, error_message( $code ), '' === $detail ? '' : array( 'detail' => $detail ) );
}
