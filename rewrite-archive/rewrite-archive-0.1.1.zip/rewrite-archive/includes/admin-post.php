<?php
/**
 * admin-post.phpのハンドラ
 *
 * 一覧の行アクションとエディタのボタンはここへGETで来る。nonceと権限を確かめ、
 * 操作関数を呼び、結果のフラグを付けてリダイレクトする。
 * wp_die()はnonceと権限の失敗にだけ使い、操作の失敗は元の画面へ戻して通知する。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const ACTION_START     = 'rewrite_archive_start';
const ACTION_REPLACE   = 'rewrite_archive_replace';
const ACTION_ABANDON   = 'rewrite_archive_abandon';
const ACTION_DUPLICATE = 'rewrite_archive_duplicate';
const ACTION_SWITCH    = 'rewrite_archive_switch';

/**
 * admin-post.phpのURLを組み立てる
 *
 * wp_nonce_url()は使わない。戻り値をesc_html()するため&が&#038;になり、
 * JSのlocation.hrefに渡すとリンクが壊れる。HTMLに出すときは呼び出し側でesc_url()する。
 *
 * @param string $action  アクション名（ACTION_*）.
 * @param int    $post_id 対象の投稿ID.
 * @param array  $extra   追加のクエリ引数.
 * @return string
 */
function action_url( string $action, int $post_id, array $extra = array() ): string {
	return add_query_arg(
		array_merge(
			array(
				'action'   => $action,
				'post'     => $post_id,
				'_wpnonce' => wp_create_nonce( $action . '_' . $post_id ),
			),
			$extra
		),
		admin_url( 'admin-post.php' )
	);
}

/**
 * 編集画面のURL
 *
 * @param int $post_id 投稿ID.
 * @return string
 */
function edit_url( int $post_id ): string {
	return add_query_arg(
		array(
			'post'   => $post_id,
			'action' => 'edit',
		),
		admin_url( 'post.php' )
	);
}

/**
 * 投稿一覧のURL
 *
 * @param string $post_type 投稿タイプ.
 * @param string $status    絞り込むステータス。空なら絞り込まない.
 * @return string
 */
function list_url( string $post_type, string $status = '' ): string {
	$args = array( 'post_type' => $post_type );

	if ( '' !== $status ) {
		$args['post_status'] = $status;
	}

	return add_query_arg( $args, admin_url( 'edit.php' ) );
}

/**
 * 通知のフラグを表示後にアドレスバーから消す
 *
 * WP本体がadmin_headでhistory.replaceState()する対象に足す。再読み込みで同じ通知を出さないため。
 *
 * @param array $args 消すクエリ引数.
 * @return array
 */
function removable_query_args( $args ): array {
	return array_merge(
		(array) $args,
		array(
			'rewrite_archive_notice',
			'rewrite_archive_error',
			'rewrite_archive_archive',
			'rewrite_archive_bulk_count',
			'rewrite_archive_bulk_failed',
			'rewrite_archive_bulk_to',
		)
	);
}
add_filter( 'removable_query_args', __NAMESPACE__ . '\removable_query_args' );

/**
 * admin-post.phpのリダイレクトで付いた結果フラグを読む
 *
 * 一覧（list-table.php）とエディタ（editor.php）の通知が使う。一括操作の件数は一覧だけが読む。
 *
 * @return array notice（通知のキー）・error（エラーコード）・archive（差し替えで作ったアーカイブのID）。
 */
function read_result_flags(): array {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- 表示の切り替えにだけ使う。処理はadmin-post.php側でnonceを検証している
	$flags = array(
		'notice'  => isset( $_GET['rewrite_archive_notice'] ) ? sanitize_key( wp_unslash( $_GET['rewrite_archive_notice'] ) ) : '',
		'error'   => isset( $_GET['rewrite_archive_error'] ) ? sanitize_key( wp_unslash( $_GET['rewrite_archive_error'] ) ) : '',
		'archive' => isset( $_GET['rewrite_archive_archive'] ) ? absint( wp_unslash( $_GET['rewrite_archive_archive'] ) ) : 0,
	);
	// phpcs:enable

	return $flags;
}

/**
 * リクエストの投稿IDを読み、nonceを確かめる
 *
 * IDがなければ400、nonceが合わなければcheck_admin_referer()が403で止める。
 *
 * @param string $action アクション名（ACTION_*）.
 * @return int 投稿ID。
 */
function request_post_id( string $action ): int {
	$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 直後のcheck_admin_referer()で検証する

	if ( ! $post_id ) {
		wp_die( 'リクエストが不正です。', '', array( 'response' => 400 ) );
	}

	check_admin_referer( $action . '_' . $post_id );

	return $post_id;
}

/**
 * 許可された値だけを受け付けるクエリ引数を読む
 *
 * @param string $key      引数名.
 * @param array  $allowed  許可する値.
 * @param string $fallback 許可外・未指定のときの値.
 * @return string
 */
function request_param( string $key, array $allowed, string $fallback ): string {
	$value = isset( $_GET[ $key ] ) ? sanitize_key( wp_unslash( $_GET[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- request_post_id()で検証済み

	return in_array( $value, $allowed, true ) ? $value : $fallback;
}

/**
 * 失敗したときの戻り先を決める
 *
 * 一覧の行アクションから来たとき（from=list）と、戻る先の投稿がもうないとき（二重送信など）は
 * 一覧へ、それ以外は編集画面へ戻る。
 *
 * @param int    $post_id   戻り先の投稿ID.
 * @param string $post_type 一覧の絞り込みに使う投稿タイプ.
 * @return string
 */
function failure_url( int $post_id, string $post_type ): string {
	$from_list = 'list' === request_param( 'from', array( 'list', 'editor' ), 'editor' );

	if ( $from_list || ! get_post( $post_id ) ) {
		return list_url( $post_type );
	}

	return edit_url( $post_id );
}

/**
 * リダイレクトして終了する
 *
 * @param string $url 行き先.
 * @return void
 */
function redirect( string $url ): void {
	wp_safe_redirect( $url );
	exit;
}

/**
 * 操作の失敗を処理する
 *
 * 権限なしは403で止める。それ以外はログに残し、エラーコードを付けて元の画面へ戻す。
 * ログには、どのadmin-postのアクションで、どの投稿を操作して失敗したかを書く。WP_Errorのdataが
 * make_error()のdetailか、WP本体のエラーが持つ文字列（db_update_errorの$wpdb->last_errorなど）なら、
 * それも書く。
 *
 * @param \WP_Error $error    操作関数が返したエラー.
 * @param int       $post_id  リクエストで操作した投稿のID.
 * @param string    $back_url 戻り先.
 * @return void
 */
function redirect_with_error( \WP_Error $error, int $post_id, string $back_url ): void {
	if ( 'rewrite_archive_forbidden' === $error->get_error_code() ) {
		wp_die( esc_html( $error->get_error_message() ), '', array( 'response' => 403 ) );
	}

	$data   = $error->get_error_data();
	$detail = '';

	if ( is_array( $data ) && isset( $data['detail'] ) ) {
		$detail = (string) $data['detail'];
	} elseif ( is_scalar( $data ) ) {
		$detail = (string) $data;
	}

	write_log(
		sprintf(
			'%1$sで投稿%2$dの操作に失敗した。%3$s: %4$s%5$s',
			(string) current_action(),
			$post_id,
			$error->get_error_code(),
			$error->get_error_message(),
			'' === $detail ? '' : '（' . $detail . '）'
		)
	);

	redirect( add_query_arg( 'rewrite_archive_error', $error->get_error_code(), $back_url ) );
}

/**
 * リライトを始める
 *
 * @return void
 */
function handle_start(): void {
	$post_id   = request_post_id( ACTION_START );
	$post      = get_post( $post_id );
	$post_type = $post instanceof \WP_Post ? $post->post_type : 'post';
	$existing  = get_copy_id( $post_id );
	$result    = start_rewrite( $post_id );

	if ( is_wp_error( $result ) ) {
		redirect_with_error( $result, $post_id, failure_url( $post_id, $post_type ) );
		return;
	}

	// 既にコピーがあれば（別のタブで始めた直後など）start_rewrite()は作らずにそのIDを返すので、文言を分ける。
	$notice = ( $existing && $existing === $result ) ? 'copy_exists' : 'started';

	redirect( add_query_arg( 'rewrite_archive_notice', $notice, edit_url( $result ) ) );
}
add_action( 'admin_post_' . ACTION_START, __NAMESPACE__ . '\handle_start' );

/**
 * 元記事に差し替える
 *
 * @return void
 */
function handle_replace(): void {
	$copy_id     = request_post_id( ACTION_REPLACE );
	$date_mode   = request_param( 'date', array( 'keep', 'today' ), 'keep' );
	$original_id = get_original_id( $copy_id );
	$copy        = get_post( $copy_id );
	$post_type   = $copy instanceof \WP_Post ? $copy->post_type : 'post';
	$result      = replace_original( $copy_id, $date_mode );

	if ( is_wp_error( $result ) ) {
		redirect_with_error( $result, $copy_id, failure_url( $copy_id, $post_type ) );
		return;
	}

	// 付け替えられなかった添付ファイルがあると、replace_original()はコピーを消さずに残す。文言を分ける。
	$notice = get_post( $copy_id ) instanceof \WP_Post ? 'replaced_copy_kept' : 'replaced';

	redirect(
		add_query_arg(
			array(
				'rewrite_archive_notice'  => $notice,
				'rewrite_archive_archive' => $result,
			),
			edit_url( $original_id )
		)
	);
}
add_action( 'admin_post_' . ACTION_REPLACE, __NAMESPACE__ . '\handle_replace' );

/**
 * リライトをやめる
 *
 * 一覧から押したとき（from=list）と元記事がないときは一覧へ、それ以外は元記事の編集画面へ戻る。
 *
 * @return void
 */
function handle_abandon(): void {
	$copy_id   = request_post_id( ACTION_ABANDON );
	$from_list = 'list' === request_param( 'from', array( 'list', 'editor' ), 'editor' );
	$copy      = get_post( $copy_id );
	$post_type = $copy instanceof \WP_Post ? $copy->post_type : 'post';
	$result    = abandon_rewrite( $copy_id );

	if ( is_wp_error( $result ) ) {
		redirect_with_error( $result, $copy_id, failure_url( $copy_id, $post_type ) );
		return;
	}

	$back = ( $result && ! $from_list ) ? edit_url( $result ) : list_url( $post_type );

	redirect( add_query_arg( 'rewrite_archive_notice', 'abandoned', $back ) );
}
add_action( 'admin_post_' . ACTION_ABANDON, __NAMESPACE__ . '\handle_abandon' );

/**
 * 複製する
 *
 * @return void
 */
function handle_duplicate(): void {
	$post_id   = request_post_id( ACTION_DUPLICATE );
	$post      = get_post( $post_id );
	$post_type = $post instanceof \WP_Post ? $post->post_type : 'post';
	$result    = duplicate_post( $post_id );

	if ( is_wp_error( $result ) ) {
		redirect_with_error( $result, $post_id, failure_url( $post_id, $post_type ) );
		return;
	}

	redirect( add_query_arg( 'rewrite_archive_notice', 'duplicated', edit_url( $result ) ) );
}
add_action( 'admin_post_' . ACTION_DUPLICATE, __NAMESPACE__ . '\handle_duplicate' );

/**
 * アーカイブに移動する / 下書きに戻す
 *
 * 移動はもう触らない宣言なので一覧のアーカイブ絞り込みへ、戻すのは本文を直すためなので編集画面へ。
 *
 * @return void
 */
function handle_switch(): void {
	$post_id = request_post_id( ACTION_SWITCH );
	$to      = request_param( 'to', array( STATUS_ARCHIVED, 'draft' ), '' );

	if ( '' === $to ) {
		wp_die( 'リクエストが不正です。', '', array( 'response' => 400 ) );
	}

	$post      = get_post( $post_id );
	$post_type = $post instanceof \WP_Post ? $post->post_type : 'post';
	$result    = switch_archive_status( $post_id, $to );

	if ( is_wp_error( $result ) ) {
		redirect_with_error( $result, $post_id, failure_url( $post_id, $post_type ) );
		return;
	}

	if ( STATUS_ARCHIVED === $to ) {
		redirect( add_query_arg( 'rewrite_archive_notice', 'archived', list_url( $post_type, STATUS_ARCHIVED ) ) );
		return;
	}

	redirect( add_query_arg( 'rewrite_archive_notice', 'unarchived', edit_url( $post_id ) ) );
}
add_action( 'admin_post_' . ACTION_SWITCH, __NAMESPACE__ . '\handle_switch' );
