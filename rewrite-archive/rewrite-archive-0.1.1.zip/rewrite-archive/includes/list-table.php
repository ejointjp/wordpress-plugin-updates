<?php
/**
 * 投稿一覧: 状態ラベル・行アクション・通知・クイック編集と行アクションのスクリプト
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * タイトル横の状態ラベル
 *
 * _post_states()はエスケープせずに出力するため、タイトルはここでesc_html()する。
 *
 * @param array    $states 状態ラベル.
 * @param \WP_Post $post   投稿.
 * @return array
 */
function post_states( $states, $post ) {
	if ( ! $post instanceof \WP_Post || ! is_target_post_type( $post->post_type ) ) {
		return $states;
	}

	$states = (array) $states;

	if ( STATUS_REWRITING === $post->post_status ) {
		$original_id               = get_original_id( $post->ID );
		$states['rewrite_archive'] = $original_id
			? sprintf( 'リライト中（元記事: %s）', esc_html( get_the_title( $original_id ) ) )
			: 'リライト中（元記事なし）';

		return $states;
	}

	if ( STATUS_ARCHIVED === $post->post_status ) {
		if ( REASON_REWRITE !== get_post_meta( $post->ID, META_REASON, true ) ) {
			$states['rewrite_archive'] = 'アーカイブ';

			return $states;
		}

		$archived_at = (string) get_post_meta( $post->ID, META_ARCHIVED_AT, true );

		$states['rewrite_archive'] = '' !== $archived_at
			? sprintf( '差し替え済み（%s）', esc_html( mysql2date( 'Y-m-d', $archived_at ) ) )
			: '差し替え済み';

		return $states;
	}

	if ( get_copy_id( $post->ID ) ) {
		$states['rewrite_archive'] = 'リライト中';
	}

	return $states;
}
add_filter( 'display_post_states', __NAMESPACE__ . '\post_states', 10, 2 );

/**
 * コピーを持つ元記事の行にクラスを付ける
 *
 * クイック編集（assets/quick-edit.js）が、この行のステータス欄に「アーカイブ」を出さないために見る
 * （コピーを持つ元記事はアーカイブにできず、サーバーのガードが拒否する）。
 * 一覧の行だけに付ける。WP_Posts_List_Table::single_row()は`iedit`を含むクラスで
 * get_post_class()を呼ぶので、それで見分ける（クイック編集の保存後にAJAXで行を描き直すときも同じ）。
 *
 * @param string[] $classes   クラス.
 * @param string[] $css_class 呼び出し側が渡したクラス.
 * @param int      $post_id   投稿ID.
 * @return string[]
 */
function post_class( $classes, $css_class, $post_id ) {
	if ( ! is_admin() || ! in_array( 'iedit', (array) $css_class, true ) ) {
		return $classes;
	}

	$post = get_post( (int) $post_id );

	if ( $post instanceof \WP_Post && is_target_post_type( $post->post_type ) && get_copy_id( $post->ID ) ) {
		$classes[] = 'rewrite-archive-has-copy';
	}

	return $classes;
}
add_filter( 'post_class', __NAMESPACE__ . '\post_class', 10, 3 );

/**
 * 行アクションのリンクを組む
 *
 * 新しいタブで開くリンクには、WP本体と同じくスクリーンリーダー向けにその旨を添える。
 *
 * @param string $url     遷移先.
 * @param string $label   文言.
 * @param bool   $new_tab 新しいタブで開くか.
 * @return string
 */
function action_link( string $url, string $label, bool $new_tab = false ): string {
	if ( $new_tab ) {
		return sprintf(
			'<a href="%1$s" target="_blank">%2$s<span class="screen-reader-text">（新しいタブで開く）</span></a>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	return sprintf( '<a href="%1$s">%2$s</a>', esc_url( $url ), esc_html( $label ) );
}

/**
 * 行アクション
 *
 * - rewriting・差し替え前の版以外でゴミ箱でもない行: 複製
 * - 公開中でコピーなし: リライト
 * - コピーを持つ元記事: リライト中のコピーを開く
 * - コピー: 元記事を開く / リライトをやめる。ゴミ箱は外す（ガードで止まるため）
 * - 差し替え前の版: リライト版を開く（新しいタブ）だけ。複製は対象外（duplicate_post()が拒否する）
 *
 * @param array    $actions 行アクション.
 * @param \WP_Post $post    投稿.
 * @return array
 */
function row_actions( $actions, $post ) {
	if ( ! $post instanceof \WP_Post || ! is_target_post_type( $post->post_type ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $actions;
	}

	$actions = (array) $actions;
	$status  = $post->post_status;

	if ( STATUS_REWRITING === $status ) {
		unset( $actions['trash'] );

		$original_id = get_original_id( $post->ID );

		if ( $original_id ) {
			$actions['rewrite_archive_original'] = action_link( edit_url( $original_id ), '元記事を開く' );
		}

		$actions['rewrite_archive_abandon'] = action_link( action_url( ACTION_ABANDON, $post->ID, array( 'from' => 'list' ) ), 'リライトをやめる' );

		return $actions;
	}

	if ( 'trash' === $status ) {
		return $actions;
	}

	if ( STATUS_ARCHIVED === $status && REASON_REWRITE === get_post_meta( $post->ID, META_REASON, true ) ) {
		$original_id = (int) get_post_meta( $post->ID, META_ARCHIVED_FROM, true );

		if ( $original_id && get_post( $original_id ) instanceof \WP_Post ) {
			$actions['rewrite_archive_original'] = action_link( edit_url( $original_id ), 'リライト版を開く', true );
		}

		return $actions;
	}

	$actions['rewrite_archive_duplicate'] = action_link( action_url( ACTION_DUPLICATE, $post->ID, array( 'from' => 'list' ) ), '複製' );

	if ( STATUS_ARCHIVED === $status ) {
		return $actions;
	}

	$copy_id = get_copy_id( $post->ID );

	if ( $copy_id ) {
		$actions['rewrite_archive_copy'] = action_link( edit_url( $copy_id ), 'リライト中のコピーを開く' );
	} elseif ( 'publish' === $status ) {
		$actions['rewrite_archive_start'] = action_link( action_url( ACTION_START, $post->ID, array( 'from' => 'list' ) ), 'リライト' );
	}

	return $actions;
}
add_filter( 'post_row_actions', __NAMESPACE__ . '\row_actions', 10, 2 );
add_filter( 'page_row_actions', __NAMESPACE__ . '\row_actions', 10, 2 );

/**
 * クイック編集用のスクリプトと、行アクション「リライトをやめる」を2段にするスクリプトを
 * 対象タイプの一覧で読み込む
 *
 * @param string $hook_suffix 画面のフック名.
 * @return void
 */
function enqueue_list_assets( $hook_suffix ): void {
	if ( 'edit.php' !== $hook_suffix ) {
		return;
	}

	$screen = get_current_screen();

	if ( ! $screen || 'edit' !== $screen->base || ! is_target_post_type( (string) $screen->post_type ) ) {
		return;
	}

	wp_enqueue_script(
		'rewrite-archive-quick-edit',
		REWRITE_ARCHIVE_URL . 'assets/quick-edit.js',
		array( 'jquery', 'inline-edit-post' ),
		REWRITE_ARCHIVE_VERSION,
		true
	);

	wp_add_inline_script(
		'rewrite-archive-quick-edit',
		'window.rewriteArchiveQuickEdit = ' . wp_json_encode(
			array(
				'rewriting' => array(
					'value' => STATUS_REWRITING,
					'label' => 'リライト中',
				),
				'archived'  => array(
					'value' => STATUS_ARCHIVED,
					'label' => 'アーカイブ',
				),
			)
		) . ';',
		'before'
	);

	wp_enqueue_script(
		'rewrite-archive-row-actions',
		REWRITE_ARCHIVE_URL . 'assets/row-actions.js',
		array(),
		REWRITE_ARCHIVE_VERSION,
		true
	);
}
add_action( 'admin_enqueue_scripts', __NAMESPACE__ . '\enqueue_list_assets' );

/**
 * 一覧に戻ったときの結果通知
 *
 * URLには決まったコードだけが載る（文言は載せない）。対象タイプの一覧だけに出す。
 *
 * @return void
 */
function admin_notices(): void {
	$screen = get_current_screen();

	if ( ! $screen || 'edit' !== $screen->base || ! is_target_post_type( (string) $screen->post_type ) ) {
		return;
	}

	$flags = read_result_flags();

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- 表示の切り替えにだけ使う。一括操作はWP本体がnonceを検証している
	$bulk_count = isset( $_GET['rewrite_archive_bulk_count'] ) ? absint( wp_unslash( $_GET['rewrite_archive_bulk_count'] ) ) : null;
	$bulk_fail  = isset( $_GET['rewrite_archive_bulk_failed'] ) ? absint( wp_unslash( $_GET['rewrite_archive_bulk_failed'] ) ) : 0;
	$bulk_to    = isset( $_GET['rewrite_archive_bulk_to'] ) ? sanitize_key( wp_unslash( $_GET['rewrite_archive_bulk_to'] ) ) : '';
	// phpcs:enable

	/*
	 * 読み終えた結果フラグをREQUEST_URIから外す。WP本体のedit.phpも自分の結果フラグ（trashedなど）を
	 * 表示したあとで同じように外している。残すと一覧のフォームの_wp_http_referer（一括操作のあとの
	 * 戻り先になる）に載り、次にWP本体や他のプラグインの一括操作をしたときに同じ通知がもう一度出る。
	 * removable_query_args()に空の配列を渡すと、このプラグインの結果フラグだけが返る。
	 */
	if ( isset( $_SERVER['REQUEST_URI'] ) ) {
		// admin-post.phpの自前関数RewriteArchive\removable_query_args()を呼ぶ。WP本体の関数ではないため、先頭に\を付けると動かなくなる。
		$_SERVER['REQUEST_URI'] = remove_query_arg( removable_query_args( array() ) );
	}

	if ( '' !== $flags['notice'] && '' !== notice_message( $flags['notice'] ) ) {
		wp_admin_notice(
			esc_html( notice_message( $flags['notice'] ) ),
			array(
				'type'        => notice_type( $flags['notice'] ),
				'dismissible' => true,
			)
		);
	}

	if ( '' !== $flags['error'] ) {
		wp_admin_notice(
			esc_html( error_message( $flags['error'] ) ),
			array(
				'type'        => 'error',
				'dismissible' => true,
			)
		);
	}

	if ( null === $bulk_count ) {
		return;
	}

	$label = STATUS_ARCHIVED === $bulk_to ? 'アーカイブに移動しました' : '下書きに戻しました';

	if ( $bulk_count > 0 ) {
		wp_admin_notice(
			esc_html( sprintf( '%1$d件を%2$s。', $bulk_count, $label ) ),
			array(
				'type'        => 'success',
				'dismissible' => true,
			)
		);
	}

	if ( $bulk_fail > 0 ) {
		$reason = STATUS_ARCHIVED === $bulk_to
			? 'リライト中のコピーと、リライト中のコピーを持つ投稿はアーカイブに移動できません。'
			: 'アーカイブ以外の投稿と、差し替え前の版は下書きに戻せません。';

		wp_admin_notice(
			esc_html( sprintf( '%1$d件は変更できませんでした。%2$s権限とサーバーのエラーログも確認してください。', $bulk_fail, $reason ) ),
			array(
				'type'        => 'error',
				'dismissible' => true,
			)
		);
	}
}
add_action( 'admin_notices', __NAMESPACE__ . '\admin_notices' );
