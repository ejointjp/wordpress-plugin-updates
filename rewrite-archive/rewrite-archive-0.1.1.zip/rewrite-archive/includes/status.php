<?php
/**
 * カスタムステータスの登録と、ステータス名・メタキーの定数
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** リライト作業用コピーのステータス */
const STATUS_REWRITING = 'rewriting';

/**
 * アーカイブのステータス
 *
 * lovemac.jpのmu-plugin（lovemac-archived-status.php）と同じ文字列。本番に入っている投稿を
 * 引き継ぐため変えないこと。
 */
const STATUS_ARCHIVED = 'archived';

/** コピー側: 元記事のID */
const META_REWRITE_OF = '_rewrite_archive_rewrite_of';

/** 元記事側: コピーのID */
const META_REWRITING = '_rewrite_archive_rewriting';

/** 差し替え前の版: 元記事のID */
const META_ARCHIVED_FROM = '_rewrite_archive_archived_from';

/** 差し替え前の版: 差し替えた日時（current_time('mysql')） */
const META_ARCHIVED_AT = '_rewrite_archive_archived_at';

/** 差し替え前の版: 理由。手動でアーカイブした投稿には付かない */
const META_REASON = '_rewrite_archive_reason';

/** 差し替え前の版: 差し替え時点の元記事のスラグ */
const META_ARCHIVED_SLUG = '_rewrite_archive_archived_slug';

/** META_REASONの値: 差し替え前の版 */
const REASON_REWRITE = 'rewrite';

/**
 * 2つのステータスを登録する
 *
 * どちらも「すべて」「下書き」に混ざらず、一覧上部に専用のリンクが出る。フロントでは404。
 * label_countは_n_noop()で組む。i18nはしないが、一覧が期待する配列の形を作るのに使う。
 * テキストドメインは翻訳には効かないが、Plugin Checkが省略をERRORにするため渡す。
 *
 * @return void
 */
function register_statuses(): void {
	register_post_status(
		STATUS_REWRITING,
		array(
			'label'                     => 'リライト中',
			'public'                    => false,
			'internal'                  => false,
			'protected'                 => true,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => false,
			'show_in_admin_status_list' => true,
			// translators: %s: リライト中の投稿の件数.
			'label_count'               => _n_noop( 'リライト中 <span class="count">(%s)</span>', 'リライト中 <span class="count">(%s)</span>', 'rewrite-archive' ),
		)
	);

	register_post_status(
		STATUS_ARCHIVED,
		array(
			'label'                     => 'アーカイブ',
			'public'                    => false,
			'internal'                  => false,
			'protected'                 => true,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => false,
			'show_in_admin_status_list' => true,
			// translators: %s: アーカイブの投稿の件数.
			'label_count'               => _n_noop( 'アーカイブ <span class="count">(%s)</span>', 'アーカイブ <span class="count">(%s)</span>', 'rewrite-archive' ),
		)
	);
}
add_action( 'init', __NAMESPACE__ . '\register_statuses' );
