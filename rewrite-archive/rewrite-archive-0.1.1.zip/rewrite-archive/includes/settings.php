<?php
/**
 * 設定: 対象の投稿タイプ（設定 → 投稿設定 の「Rewrite and Archive」セクション）
 *
 * 独自の設定ページは持たず、options-writing.phpにSettings APIでセクションを足す。
 * 保存結果の通知はWP本体が出す（「設定」メニュー配下のページでは、options-head.phpが
 * settings_errors()を呼び、options.phpが「設定を保存しました。」を登録する）。
 * 対象の解決（get_target_post_types()）はcommon.php。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * オプションを登録する
 *
 * initで登録し、options.php以外（WP-CLIの`wp option update`など）のupdate_option()でも
 * sanitize_settings()を通す。
 *
 * @return void
 */
function register_settings(): void {
	register_setting(
		'writing',
		OPTION_SETTINGS,
		array(
			'type'              => 'array',
			'sanitize_callback' => __NAMESPACE__ . '\sanitize_settings',
			'default'           => array( 'post_types' => DEFAULT_POST_TYPES ),
			'show_in_rest'      => false,
		)
	);
}
add_action( 'init', __NAMESPACE__ . '\register_settings' );

/**
 * 設定の入力を検証する
 *
 * チェックボックスの値のうち、選べる投稿タイプにあるものだけを選べる順に残す。画面から来る値はすべて
 * 選べるものなので、落ちるのは改変されたリクエストの値か、選んだあとに登録が消えた投稿タイプだけ。
 * 通知は出さない。すべて外して保存すると$inputはnullで、対象なしになる。
 *
 * @param mixed $input 保存しようとした値.
 * @return array post_typesに投稿タイプ名の配列を持つ配列。
 */
function sanitize_settings( $input ): array {
	$input  = is_array( $input ) ? $input : array();
	$chosen = isset( $input['post_types'] ) ? array_map( 'strval', (array) $input['post_types'] ) : array();

	return array( 'post_types' => array_values( array_intersect( get_selectable_post_types(), $chosen ) ) );
}

/**
 * 投稿設定にセクションと項目を足す
 *
 * add_settings_section()はwp-admin/includes/template.phpの関数なのでadmin_initで足す。
 *
 * @return void
 */
function add_settings_ui(): void {
	add_settings_section( 'rewrite_archive', 'Rewrite and Archive', '__return_null', 'writing' );
	add_settings_field( 'rewrite_archive_post_types', 'リライトとアーカイブの対象', __NAMESPACE__ . '\render_post_types_field', 'writing', 'rewrite_archive' );
}
add_action( 'admin_init', __NAMESPACE__ . '\add_settings_ui' );

/**
 * 対象の投稿タイプのチェックボックスを出す
 *
 * 選べる投稿タイプを登録順に並べ、設定に保存されたものをチェックする。
 *
 * @return void
 */
function render_post_types_field(): void {
	$saved = get_saved_post_types();

	echo '<fieldset><legend class="screen-reader-text"><span>リライトとアーカイブの対象</span></legend>';

	foreach ( get_selectable_post_types() as $post_type ) {
		$object = get_post_type_object( $post_type );
		$label  = $object && isset( $object->labels->name ) ? (string) $object->labels->name : $post_type;

		printf(
			'<label><input type="checkbox" name="%1$s[post_types][]" value="%2$s"%3$s> %4$s</label><br>',
			esc_attr( OPTION_SETTINGS ),
			esc_attr( $post_type ),
			checked( in_array( $post_type, $saved, true ), true, false ),
			esc_html( $label )
		);
	}

	echo '<p class="description">チェックした投稿タイプの一覧と編集画面に、リライト・複製・アーカイブの操作が出ます。すべて外すと、このプラグインは何もしません。</p>';
	echo '</fieldset>';
}
