<?php
/**
 * ブロックエディタ: サイドバー用スクリプトの読み込みと設定の受け渡し
 *
 * ボタンの中身はassets/editor.js。ここは「どの投稿で何を出すか」を決めてJSへ渡す。
 * PHPのadmin_noticesはブロックエディタの画面では表示されない（#wpbody-contentの直下がCSSで隠される）
 * ため、結果通知もここで文言に解決してJSに出させる。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 対象タイプの編集画面でスクリプトとスタイルを読み込む
 *
 * wp_localize_script()は真偽値を文字列にするため、wp_json_encode()した設定をinline scriptで渡す。
 *
 * @return void
 */
function enqueue_editor_assets(): void {
	$screen = get_current_screen();

	if ( ! $screen || 'post' !== $screen->base ) {
		return;
	}

	$post = get_post();

	if ( ! $post instanceof \WP_Post || ! is_target_post_type( $post->post_type ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}

	wp_enqueue_script(
		'rewrite-archive-editor',
		REWRITE_ARCHIVE_URL . 'assets/editor.js',
		array( 'wp-plugins', 'wp-editor', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-notices' ),
		REWRITE_ARCHIVE_VERSION,
		true
	);

	wp_enqueue_style(
		'rewrite-archive-editor',
		REWRITE_ARCHIVE_URL . 'assets/editor.css',
		array( 'wp-edit-post' ),
		REWRITE_ARCHIVE_VERSION
	);

	wp_add_inline_script(
		'rewrite-archive-editor',
		'window.rewriteArchiveEditor = ' . wp_json_encode( editor_config( $post ) ) . ';',
		'before'
	);
}
add_action( 'enqueue_block_editor_assets', __NAMESPACE__ . '\enqueue_editor_assets' );

/**
 * get_the_title()が通すthe_titleフィルタ（wptexturize・convert_chars）で入る実体参照を戻す
 *
 * 例: &amp;・&#038;は&に、&#8217;等は実際の文字に戻す。戻さないとJS側はテキストとして
 * 描画するため、画面に実体参照がそのまま出てしまう。
 *
 * @param string $title get_the_title()の戻り値.
 * @return string
 */
function decode_title( string $title ): string {
	return html_entity_decode( $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
}

/**
 * 投稿の要約（JSのリンク用）
 *
 * @param int $post_id 投稿ID.
 * @return array|null なければnull。
 */
function post_summary( int $post_id ): ?array {
	$post = $post_id ? get_post( $post_id ) : null;

	if ( ! $post instanceof \WP_Post ) {
		return null;
	}

	return array(
		'id'      => $post->ID,
		'title'   => decode_title( get_the_title( $post ) ),
		'editUrl' => edit_url( $post->ID ),
	);
}

/**
 * JSへ渡す設定を組む
 *
 * @param \WP_Post $post 編集中の投稿.
 * @return array
 */
function editor_config( \WP_Post $post ): array {
	$role = 'default';

	if ( STATUS_REWRITING === $post->post_status ) {
		$role = 'copy';
	} elseif ( STATUS_ARCHIVED === $post->post_status ) {
		$role = 'archived';
	}

	$config = array(
		'role'     => $role,
		'original' => null,
		'copy'     => null,
		'archives' => array(),
		'reason'   => '',
		'urls'     => array(
			'start'        => action_url( ACTION_START, $post->ID ),
			'replaceKeep'  => action_url( ACTION_REPLACE, $post->ID, array( 'date' => 'keep' ) ),
			'replaceToday' => action_url( ACTION_REPLACE, $post->ID, array( 'date' => 'today' ) ),
			'abandon'      => action_url( ACTION_ABANDON, $post->ID ),
			'duplicate'    => action_url( ACTION_DUPLICATE, $post->ID ),
			'archive'      => action_url( ACTION_SWITCH, $post->ID, array( 'to' => STATUS_ARCHIVED ) ),
			'unarchive'    => action_url( ACTION_SWITCH, $post->ID, array( 'to' => 'draft' ) ),
		),
		'notice'   => editor_notice(),
	);

	if ( 'copy' === $role ) {
		$config['original'] = post_summary( get_original_id( $post->ID ) );

		return $config;
	}

	if ( 'archived' === $role ) {
		$config['reason'] = (string) get_post_meta( $post->ID, META_REASON, true );

		if ( REASON_REWRITE === $config['reason'] ) {
			$config['original'] = post_summary( (int) get_post_meta( $post->ID, META_ARCHIVED_FROM, true ) );
		}

		return $config;
	}

	$config['copy'] = post_summary( get_copy_id( $post->ID ) );

	foreach ( get_pre_replace_versions( $post->ID ) as $archive ) {
		$archived_at          = (string) get_post_meta( $archive->ID, META_ARCHIVED_AT, true );
		$config['archives'][] = array(
			'id'      => $archive->ID,
			'title'   => decode_title( get_the_title( $archive ) ),
			'date'    => '' !== $archived_at ? mysql2date( 'Y-m-d', $archived_at ) : '',
			'editUrl' => edit_url( $archive->ID ),
		);
	}

	return $config;
}

/**
 * admin-post.phpから戻ったときの結果通知を文言に解決する
 *
 * @return array|null type（success / warning / error）/ message / actionLabel / actionUrl。フラグがなければnull。
 */
function editor_notice(): ?array {
	$flags = read_result_flags();

	if ( '' !== $flags['error'] ) {
		return array(
			'type'    => 'error',
			'message' => error_message( $flags['error'] ),
		);
	}

	if ( '' === $flags['notice'] || '' === notice_message( $flags['notice'] ) ) {
		return null;
	}

	$data = array(
		'type'    => notice_type( $flags['notice'] ),
		'message' => notice_message( $flags['notice'] ),
	);

	if ( in_array( $flags['notice'], array( 'replaced', 'replaced_copy_kept' ), true ) && $flags['archive'] && get_post( $flags['archive'] ) instanceof \WP_Post ) {
		$data['actionLabel'] = 'アーカイブを開く';
		$data['actionUrl']   = edit_url( $flags['archive'] );
	}

	return $data;
}
