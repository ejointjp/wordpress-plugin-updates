<?php
/**
 * 自己ホストの更新チェック
 *
 * wordpress.orgには載せていないので、更新の情報は配布用のリポジトリ（ejointjp/wordpress-plugin-updates）に置いたinfo.jsonから取る。
 * メインファイルのヘッダーにUpdate URI（https://yuiami.jp/wp-plugins/rewrite-archive）があると、WordPressはこのプラグインの更新を
 * wordpress.orgに問い合わせず、そのホスト名の付いたフィルタupdate_plugins_yuiami.jpを呼ぶ。Update URIは識別子で、実在しなくてよい。
 *
 * - 更新の判定（update_plugins_yuiami.jp）は、キャッシュを読まずに毎回取得する。本体が12時間おきにしか確認しないうえ、
 *   「再確認」ですぐ反映させたいため
 * - 詳細の表示（plugins_api）は、1時間キャッシュした情報を使う
 * - 取得できなければ、理由をwrite_log()で残して「更新なし」として扱う
 * - 問い合わせで送るのは、info.jsonのURLと固定のUser-Agentだけ。サイトのURLやデータは送らない
 *
 * 定期の更新チェックはwp-cronで動くので、is_admin()の外で読み込むこと。プラグインが停止中のサイトでは動かない。
 * 中身は/wp-plugin-publishのひな形（assets/selfhost/update-checker.php）と同じで、名前空間・型宣言・write_log()を
 * このプラグインの書き方に合わせてある。導入の手順は同スキルのreferences/selfhost.md。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 更新の判定と詳細の表示で使うslug */
const UPDATE_SLUG = 'rewrite-archive';

/** 配布用のリポジトリの、このプラグインの置き場 */
const UPDATE_BASE_URL = 'https://raw.githubusercontent.com/ejointjp/wordpress-plugin-updates/main/rewrite-archive/';

/** 更新の情報のキャッシュ（サイトのトランジェント）の名前。uninstall.phpが同じ名前で消す */
const UPDATE_INFO_TRANSIENT = 'rewrite_archive_update_info';

/**
 * 更新の情報（info.json）を返す
 *
 * @param bool $fresh trueならキャッシュを読まずに取得する.
 * @return array|null 取得できなければnull。
 */
function get_update_info( bool $fresh ): ?array {
	if ( ! $fresh ) {
		$cached = get_site_transient( UPDATE_INFO_TRANSIENT );

		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	// WordPressの既定のUser-AgentはサイトのURLを含む。配布元へ送らないよう、固定の文字列にする。
	$response = wp_remote_get(
		UPDATE_BASE_URL . 'info.json',
		array(
			'timeout'    => 10,
			'user-agent' => 'rewrite-archive update check',
		)
	);

	if ( is_wp_error( $response ) ) {
		write_log( '更新情報を取得できなかった。' . $response->get_error_message() );

		return null;
	}

	$status = wp_remote_retrieve_response_code( $response );

	if ( 200 !== $status ) {
		write_log( '更新情報を取得できなかった。HTTP ' . $status );

		return null;
	}

	$info = json_decode( wp_remote_retrieve_body( $response ), true );

	// zipのURLは、このプラグインの置き場にあるものだけを受け付ける。
	if (
		! is_array( $info )
		|| '' === update_field( $info, 'version' )
		|| ! str_starts_with( update_field( $info, 'package' ), UPDATE_BASE_URL )
	) {
		write_log( '更新情報を取得できなかった。info.jsonの中身が正しくない' );

		return null;
	}

	set_site_transient( UPDATE_INFO_TRANSIENT, $info, HOUR_IN_SECONDS );

	return $info;
}

/**
 * 更新の情報から文字列の項目を取り出す
 *
 * @param array  $info 更新の情報.
 * @param string $key  項目名.
 * @return string なければ空文字。
 */
function update_field( array $info, string $key ): string {
	return isset( $info[ $key ] ) && is_string( $info[ $key ] ) ? $info[ $key ] : '';
}

/**
 * 「Tested up to」を、サイトのWordPressと同じ系列なら、サイトの版に読み替える
 *
 * readme.txtにはメジャー番号だけ（7.1）を書く。本体はversion_compare()で比べるので、そのまま返すと、
 * 7.1.2のサイトで「テストされていない」と表示される。wordpress.orgのAPIも、同じ系列の最新のパッチ版に読み替えて返す。
 *
 * @param string $tested info.jsonのtested.
 * @return string
 */
function update_tested( string $tested ): string {
	$current = get_bloginfo( 'version' );

	if ( preg_match( '/^\d+\.\d+$/', $tested ) && str_starts_with( $current, $tested . '.' ) ) {
		return $current;
	}

	return $tested;
}

/**
 * 更新の判定に、配布用のリポジトリにある最新版の情報を返す
 *
 * 新しいかどうかは本体が比べる。
 *
 * @param array|false $update      ここまでのフィルタの結果.
 * @param array       $plugin_data プラグインのヘッダー.
 * @param string      $plugin_file プラグインのファイル（plugin_basename()の形）.
 * @return array|false
 */
function filter_update( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( REWRITE_ARCHIVE_FILE ) !== $plugin_file ) {
		return $update;
	}

	$info = get_update_info( true );

	if ( null === $info ) {
		return $update;
	}

	return array(
		'slug'         => UPDATE_SLUG,
		'version'      => $info['version'],
		'package'      => $info['package'],
		'url'          => $plugin_data['AuthorURI'] ?? '',
		'requires'     => update_field( $info, 'requires' ),
		'requires_php' => update_field( $info, 'requires_php' ),
		'tested'       => update_tested( update_field( $info, 'tested' ) ),
	);
}
add_filter( 'update_plugins_yuiami.jp', __NAMESPACE__ . '\filter_update', 10, 3 );

/**
 * 「詳細を表示」のポップアップに、配布用のリポジトリにある情報を返す
 *
 * @param false|object|array $result ここまでのフィルタの結果.
 * @param string             $action plugins_api()の種類.
 * @param object             $args   plugins_api()の引数.
 * @return false|object|array|\WP_Error
 */
function filter_plugin_information( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || ! isset( $args->slug ) || UPDATE_SLUG !== $args->slug ) {
		return $result;
	}

	$info = get_update_info( false );

	if ( null === $info ) {
		// falseのまま返すと、本体がwordpress.orgの同じslugを見に行く。エラーにして止める。
		return new \WP_Error( 'rewrite_archive_update_info', '更新情報を取得できませんでした。後ほどもう一度お試しください。' );
	}

	$sections = isset( $info['sections'] ) && is_array( $info['sections'] ) ? array_filter( $info['sections'], 'is_string' ) : array();

	return (object) array(
		'name'          => esc_html( update_field( $info, 'name' ) ),
		'slug'          => UPDATE_SLUG,
		'version'       => $info['version'],
		'author'        => esc_html( update_field( $info, 'author' ) ),
		'requires'      => update_field( $info, 'requires' ),
		'requires_php'  => update_field( $info, 'requires_php' ),
		'tested'        => update_tested( update_field( $info, 'tested' ) ),
		'last_updated'  => update_field( $info, 'last_updated' ),
		'sections'      => $sections,
		'download_link' => $info['package'],
		// wordpress.orgのプラグインページへのリンクを出さない。
		'external'      => true,
	);
}
add_filter( 'plugins_api', __NAMESPACE__ . '\filter_plugin_information', 10, 3 );
