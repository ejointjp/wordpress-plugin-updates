<?php
/**
 * 複製プリミティブ
 *
 * コピー作成・差し替え・アーカイブ作成・複製の4操作が共通で使う、投稿の写し方を1箇所に置く。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 写すフィールド
 *
 * post_status / post_author / post_date / post_nameは呼び出し側が決める。
 * post_content_filteredはMarkdown系のプラグインが原文を置く欄。写さないと差し替え後の元記事に
 * 古い原文が残る。
 */
const COPIED_FIELDS = array(
	'post_title',
	'post_content',
	'post_content_filtered',
	'post_excerpt',
	'comment_status',
	'ping_status',
	'post_password',
	'post_parent',
	'menu_order',
	'post_type',
);

/**
 * 写さないメタキーを返す
 *
 * `_rewrite_archive_`で始まるキーはis_excluded_meta_key()が別に除く。
 * `rewrite_archive_excluded_meta_keys`フィルタで、差し替えで壊したくないキー（閲覧数など）を足せる。
 * 除外キーは写さず、差し替え先からも消さない。
 *
 * @return string[]
 */
function get_excluded_meta_keys(): array {
	$keys = array( '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_old_date', '_pingme', '_encloseme' );

	/**
	 * 写さないメタキーを足す
	 *
	 * @param string[] $keys メタキーの配列。
	 */
	$keys = apply_filters( 'rewrite_archive_excluded_meta_keys', $keys );

	return array_values( array_unique( array_filter( array_map( 'strval', (array) $keys ) ) ) );
}

/**
 * 写さないメタキーかどうか
 *
 * @param string $key メタキー.
 * @return bool
 */
function is_excluded_meta_key( string $key ): bool {
	return str_starts_with( $key, '_rewrite_archive_' ) || in_array( $key, get_excluded_meta_keys(), true );
}

/**
 * ksesを外した状態でコールバックを実行する
 *
 * 写し元の本文・タイトル・抜粋は保存済みの値で、書いた人の権限で一度フィルタを通っている。写すときに
 * 操作した人の権限でもう一度ksesを通すと、unfiltered_htmlを持たない人（Author以下。マルチサイトでは
 * サイト管理者も持たない）の操作でiframe等が消える。写しは再フィルタしない。
 * 写し先に入る値は「写し元にあった値」か「操作した人が自分の権限で保存した値」だけなので、外しても
 * 操作した人が書けないHTMLは入らない。終わったらkses_init()で今の利用者の権限に応じた状態へ戻す。
 *
 * @param callable $callback 実行する処理.
 * @return mixed コールバックの戻り値。
 */
function without_kses( callable $callback ) {
	kses_remove_filters();

	try {
		return $callback();
	} finally {
		kses_init();
	}
}

/**
 * 写すフィールドをwp_insert_post() / wp_update_post()用に返す
 *
 * 両関数はスラッシュ付きのデータを期待する（内部でwp_unslash()する）ため、
 * WP_Postから取った値をwp_slash()して返す。しないと本文の「\」が欠ける。
 *
 * @param \WP_Post $source 写し元.
 * @return array
 */
function copy_fields( \WP_Post $source ): array {
	$fields = array();

	foreach ( COPIED_FIELDS as $field ) {
		$fields[ $field ] = $source->$field;
	}

	return wp_slash( $fields );
}

/**
 * タクソノミーのタームを写す
 *
 * 写し元の投稿タイプに登録された全タクソノミーが対象。写し先の既存タームは置き換える。
 *
 * @param int $from 写し元の投稿ID.
 * @param int $to   写し先の投稿ID.
 * @return void
 */
function copy_terms( int $from, int $to ): void {
	$source = get_post( $from );

	if ( ! $source instanceof \WP_Post ) {
		return;
	}

	foreach ( get_object_taxonomies( $source->post_type ) as $taxonomy ) {
		$terms = wp_get_object_terms( $from, $taxonomy, array( 'fields' => 'ids' ) );

		if ( is_wp_error( $terms ) ) {
			write_log( sprintf( '投稿%1$dの%2$sを読めなかった。%3$s', $from, $taxonomy, $terms->get_error_message() ) );
			continue;
		}

		$result = wp_set_object_terms( $to, $terms, $taxonomy, false );

		if ( is_wp_error( $result ) ) {
			write_log( sprintf( '投稿%1$dへ%2$sを写せなかった。%3$s', $to, $taxonomy, $result->get_error_message() ) );
		}
	}
}

/**
 * カスタムフィールドを写す
 *
 * 写し先の除外キー以外のメタをすべて消してから、写し元の除外キー以外をすべて足す。
 * get_post_meta()をキーなしで呼ぶと値はシリアライズされたまま返るため、maybe_unserialize()してから
 * add_post_meta()に渡す。add_post_meta()もスラッシュ付きを期待するためwp_slash()する。
 * 値がオブジェクトのときだけcopy_meta_row()で行のまま写す。
 *
 * @param int $from 写し元の投稿ID.
 * @param int $to   写し先の投稿ID.
 * @return void
 */
function copy_meta( int $from, int $to ): void {
	foreach ( array_keys( (array) get_post_meta( $to ) ) as $key ) {
		if ( ! is_excluded_meta_key( (string) $key ) ) {
			delete_post_meta( $to, (string) $key );
		}
	}

	foreach ( (array) get_post_meta( $from ) as $key => $values ) {
		if ( is_excluded_meta_key( (string) $key ) ) {
			continue;
		}

		foreach ( (array) $values as $value ) {
			$unserialized = maybe_unserialize( $value );

			if ( is_object( $unserialized ) ) {
				copy_meta_row( $to, (string) $key, (string) $value );
				continue;
			}

			add_post_meta( $to, (string) $key, wp_slash( $unserialized ) );
		}
	}
}

/**
 * オブジェクトのメタを、DBの行のまま写す
 *
 * オブジェクトはadd_post_meta()を通せない。中のwp_unslash()（map_deep()）がプロパティへ書き込むため、
 * 停止・削除済みのプラグインが残したクラスのないオブジェクト（__PHP_Incomplete_Class）だとPHP 8で
 * Errorになる。シリアライズ済みの文字列のまま渡すのも不可（maybe_serialize()が二重にシリアライズする）。
 * 行をそのまま複製し、写し先のメタキャッシュを消す。sanitize_metaなどのフィルタは通らない。
 *
 * @param int    $to    写し先の投稿ID.
 * @param string $key   メタキー.
 * @param string $value DBに入っている値（シリアライズ済み）.
 * @return void
 */
function copy_meta_row( int $to, string $key, string $value ): void {
	global $wpdb;

	$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- add_post_meta()を通せないオブジェクトのメタ（上記）。キャッシュは直後に消す
		$wpdb->postmeta,
		array(
			'post_id'    => $to,
			'meta_key'   => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- 1行のINSERT
			'meta_value' => $value, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- 同上
		),
		array( '%d', '%s', '%s' )
	);

	if ( false === $inserted ) {
		write_log( sprintf( '投稿%1$dへメタ%2$sを写せなかった。%3$s', $to, $key, $wpdb->last_error ) );
		return;
	}

	wp_cache_delete( $to, 'post_meta' );
}

/**
 * 添付ファイルの親を付け替える
 *
 * wp_delete_post()は削除する投稿の添付ファイルの親を「その投稿の親」に付け替える（投稿なら0になり
 * 未添付になる）ため、コピーを消す前に必ずこれを呼ぶ。呼び出し側は、failedが0でなければコピーを消さない。
 *
 * @param int $from 今の親（コピー）.
 * @param int $to   新しい親（元記事）.
 * @return array{moved: int, failed: int} 付け替えた件数と、付け替えられなかった件数。
 */
function reattach_media( int $from, int $to ): array {
	$attachment_ids = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => array( 'inherit', 'private', 'trash' ),
			'post_parent'    => $from,
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);

	$moved  = 0;
	$failed = 0;

	foreach ( $attachment_ids as $attachment_id ) {
		$result = wp_update_post(
			array(
				'ID'          => (int) $attachment_id,
				'post_parent' => $to,
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			write_log( sprintf( '添付ファイル%1$dの親を投稿%2$dへ付け替えられなかった。%3$s', $attachment_id, $to, $result->get_error_message() ) );
			++$failed;
			continue;
		}

		++$moved;
	}

	return array(
		'moved'  => $moved,
		'failed' => $failed,
	);
}
