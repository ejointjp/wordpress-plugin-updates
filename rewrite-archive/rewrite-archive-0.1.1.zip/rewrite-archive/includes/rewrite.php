<?php
/**
 * リライト: コピーの作成・差し替え・中止と、元記事とコピーの相互参照
 *
 * ここの関数はリダイレクトも出力もしない。結果はintかWP_Errorで返す。
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 元記事のコピーのIDを返す
 *
 * メタが指す投稿がない・rewritingでない・自分を指し返していないときは残骸として消し、0を返す。
 *
 * @param int $original_id 元記事のID.
 * @return int コピーのID。なければ0。
 */
function get_copy_id( int $original_id ): int {
	$copy_id = (int) get_post_meta( $original_id, META_REWRITING, true );

	if ( ! $copy_id ) {
		return 0;
	}

	$copy = get_post( $copy_id );

	if ( $copy instanceof \WP_Post && STATUS_REWRITING === $copy->post_status && (int) get_post_meta( $copy_id, META_REWRITE_OF, true ) === $original_id ) {
		return $copy_id;
	}

	delete_post_meta( $original_id, META_REWRITING );

	return 0;
}

/**
 * コピーの元記事のIDを返す
 *
 * @param int $copy_id コピーのID.
 * @return int 元記事のID。元記事がなければ0。
 */
function get_original_id( int $copy_id ): int {
	$original_id = (int) get_post_meta( $copy_id, META_REWRITE_OF, true );

	return ( $original_id && get_post( $original_id ) instanceof \WP_Post ) ? $original_id : 0;
}

/**
 * リライトを始める
 *
 * 元記事の中身を写したrewritingのコピーを作る。1つの元記事にコピーは1つ。
 *
 * @param int $original_id 元記事のID.
 * @return int|\WP_Error コピーのID（既にあればそのID）。
 */
function start_rewrite( int $original_id ): int|\WP_Error {
	$original = get_post( $original_id );

	if ( ! $original instanceof \WP_Post || ! is_target_post_type( $original->post_type ) ) {
		return make_error( 'rewrite_archive_not_found' );
	}

	if ( 'publish' !== $original->post_status ) {
		return make_error( 'rewrite_archive_not_published' );
	}

	if ( ! current_user_can( 'edit_post', $original->ID ) ) {
		return make_error( 'rewrite_archive_forbidden' );
	}

	$existing = get_copy_id( $original->ID );

	if ( $existing ) {
		return $existing;
	}

	$postarr                  = copy_fields( $original );
	$postarr['post_status']   = STATUS_REWRITING;
	$postarr['post_author']   = get_current_user_id();
	$postarr['post_date']     = current_time( 'mysql' );
	$postarr['post_date_gmt'] = current_time( 'mysql', true );
	// スラグは200文字まで（post_nameの列幅）。長いと末尾の-rewriteが切れて印が消えるため、元を詰めてから足す。
	$postarr['post_name'] = _truncate_post_slug( $original->post_name, 200 - strlen( '-rewrite' ) ) . '-rewrite';

	// ガードはこの操作以外でrewritingの投稿を作らせない（新規作成はdraftにする）ため、外して作る。
	// 保存済みの本文の写しなので、ksesも外す（copy.phpのwithout_kses()）。
	$copy_id = without_kses(
		static function () use ( $postarr ) {
			return without_guard(
				static function () use ( $postarr ) {
					return wp_insert_post( $postarr, true, false );
				}
			);
		}
	);

	if ( is_wp_error( $copy_id ) ) {
		return make_error( 'rewrite_archive_copy_failed', $copy_id->get_error_message() );
	}

	copy_terms( $original->ID, $copy_id );
	copy_meta( $original->ID, $copy_id );
	update_post_meta( $copy_id, META_REWRITE_OF, $original->ID );
	update_post_meta( $original->ID, META_REWRITING, $copy_id );

	// wp_after_insert_postは投稿・ターム・メタを保存し終えてから発火するフック。写し終えてから発火する。
	wp_after_insert_post( $copy_id, false, null );

	return $copy_id;
}

/**
 * 元記事を丸ごと複製してarchivedにする（差し替え前の版）
 *
 * 公開日と作者は元のまま。wp_insert_post()は新規投稿の更新日をpost_dateにするため、
 * 挿入後に元記事の更新日を直接書き戻す。
 *
 * @param \WP_Post $original 元記事.
 * @return int|\WP_Error アーカイブのID。
 */
function create_archive( \WP_Post $original ): int|\WP_Error {
	global $wpdb;

	$postarr                  = copy_fields( $original );
	$postarr['post_status']   = STATUS_ARCHIVED;
	$postarr['post_author']   = $original->post_author;
	$postarr['post_date']     = $original->post_date;
	$postarr['post_date_gmt'] = $original->post_date_gmt;
	// スラグは200文字まで（post_nameの列幅）。長いと末尾の日付が切れるため、元を詰めてから足す。
	$suffix               = '-archived-' . current_time( 'Ymd' );
	$postarr['post_name'] = _truncate_post_slug( $original->post_name, 200 - strlen( $suffix ) ) . $suffix;

	$archive_id = without_kses(
		static function () use ( $postarr ) {
			return wp_insert_post( $postarr, true, false );
		}
	);

	if ( is_wp_error( $archive_id ) ) {
		return make_error( 'rewrite_archive_archive_failed', $archive_id->get_error_message() );
	}

	$restored = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- wp_insert_post()は新規投稿の更新日をpost_dateにするため、元記事の更新日を直接書き戻す
		$wpdb->posts,
		array(
			'post_modified'     => $original->post_modified,
			'post_modified_gmt' => $original->post_modified_gmt,
		),
		array( 'ID' => $archive_id )
	);

	if ( false === $restored ) {
		write_log( sprintf( 'アーカイブ%1$dの更新日を元記事の値に戻せなかった。%2$s', $archive_id, $wpdb->last_error ) );
	}

	clean_post_cache( $archive_id );

	copy_terms( $original->ID, $archive_id );
	copy_meta( $original->ID, $archive_id );
	update_post_meta( $archive_id, META_ARCHIVED_FROM, $original->ID );
	update_post_meta( $archive_id, META_ARCHIVED_AT, current_time( 'mysql' ) );
	update_post_meta( $archive_id, META_REASON, REASON_REWRITE );
	update_post_meta( $archive_id, META_ARCHIVED_SLUG, $original->post_name );

	// wp_after_insert_postは投稿・ターム・メタを保存し終えてから発火するフック。写し終えてから発火する。
	wp_after_insert_post( $archive_id, false, null );

	return $archive_id;
}

/**
 * コピーの中身を元記事へ差し替える
 *
 * 1. 元記事をarchivedへ複製（失敗したら何もせず中止）
 * 2. コピーの中身を元記事へ写す（失敗したら1のアーカイブを消して中止）
 * 3. コピーの添付ファイルを元記事へ付け替える（必ず4より前。付け替えられなかったものがあれば、
 *    4と5をせずにコピーと相互参照を残す。消すとその添付ファイルが未添付になるため。
 *    コピーの「リライトをやめる」でもう一度付け替えられる）
 * 4. コピーを完全削除
 * 5. 元記事の相互参照メタを消す
 *
 * 元記事を別のユーザーが編集中（_edit_lock）なら何もせず中止する。その人の次の保存で差し替え後の本文が
 * 上書きされるため。
 * 元記事のID・URL・スラグ・作者・コメント・guidは変わらない。
 *
 * @param int    $copy_id   コピーのID.
 * @param string $date_mode 公開日。keep（元のまま）かtoday（今にする）。それ以外はkeep扱い.
 * @return int|\WP_Error アーカイブのID。
 */
function replace_original( int $copy_id, string $date_mode = 'keep' ): int|\WP_Error {
	$copy = get_post( $copy_id );

	if ( ! $copy instanceof \WP_Post || STATUS_REWRITING !== $copy->post_status ) {
		return make_error( 'rewrite_archive_not_copy' );
	}

	$original_id = get_original_id( $copy_id );
	$original    = $original_id ? get_post( $original_id ) : null;

	if ( ! $original instanceof \WP_Post || 'publish' !== $original->post_status ) {
		return make_error( 'rewrite_archive_original_missing' );
	}

	if ( get_copy_id( $original->ID ) !== $copy_id ) {
		return make_error( 'rewrite_archive_copy_unlinked' );
	}

	if ( ! current_user_can( 'edit_post', $copy_id ) || ! current_user_can( 'edit_post', $original->ID ) ) {
		return make_error( 'rewrite_archive_forbidden' );
	}

	// wp_check_post_lock()はwp-admin/includes/post.phpの関数。admin-post.phpでは読み込まれているが、
	// WP-CLIなど管理画面の外から呼ばれたときのために読み込む。
	if ( ! function_exists( 'wp_check_post_lock' ) ) {
		require_once ABSPATH . 'wp-admin/includes/post.php';
	}

	if ( wp_check_post_lock( $original->ID ) ) {
		return make_error( 'rewrite_archive_original_locked' );
	}

	$archive_id = create_archive( $original );

	if ( is_wp_error( $archive_id ) ) {
		return $archive_id;
	}

	$postarr       = copy_fields( $copy );
	$postarr['ID'] = $original->ID;
	unset( $postarr['post_type'] );

	if ( 'today' === $date_mode ) {
		$postarr['post_date']     = current_time( 'mysql' );
		$postarr['post_date_gmt'] = current_time( 'mysql', true );
	}

	// wp_update_post()は既存のpage_templateを混ぜ込み、有効なテーマにないテンプレートだと
	// 投稿を書き込んだあとでinvalid_page_templateを返す。空にして検証を飛ばす
	// （テンプレートのメタはcopy_meta()で写す）。
	$postarr['page_template'] = '';

	$result = without_kses(
		static function () use ( $postarr ) {
			return wp_update_post( $postarr, true, false );
		}
	);

	if ( is_wp_error( $result ) ) {
		if ( ! wp_delete_post( $archive_id, true ) ) {
			write_log( sprintf( '差し替えを中止したが、アーカイブ%dを消せなかった。手動で削除すること。', $archive_id ) );
		}

		return make_error( 'rewrite_archive_replace_failed', $result->get_error_message() );
	}

	copy_terms( $copy_id, $original->ID );
	copy_meta( $copy_id, $original->ID );

	// wp_after_insert_postは投稿・ターム・メタを保存し終えてから発火するフック。写し終えてから発火する。
	wp_after_insert_post( $original->ID, true, $original );

	$reattached = reattach_media( $copy_id, $original->ID );

	if ( $reattached['failed'] > 0 ) {
		write_log( sprintf( '差し替え後、コピー%1$dの添付ファイル%2$d件を元記事%3$dへ付け替えられなかったため、コピーを残した。コピーの「リライトをやめる」でもう一度付け替えること。', $copy_id, $reattached['failed'], $original->ID ) );

		return $archive_id;
	}

	$deleted = without_guard(
		static function () use ( $copy_id ) {
			return wp_delete_post( $copy_id, true );
		}
	);

	if ( ! $deleted ) {
		write_log( sprintf( '差し替え後にコピー%dを削除できなかった。一覧の「リライト中」から「リライトをやめる」で消すこと。', $copy_id ) );
	}

	delete_post_meta( $original->ID, META_REWRITING, $copy_id );

	return $archive_id;
}

/**
 * リライトをやめる
 *
 * コピーに上げた画像を元記事へ付け替えてから、コピーを完全削除する（ゴミ箱を経由しない）。
 * 付け替えられなかった画像があれば、コピーを消さずに中止する（消すとその画像が未添付になるため）。
 * 元記事が消えていてもコピーは消す。その場合、添付ファイルは未添付として残る。
 *
 * @param int $copy_id コピーのID.
 * @return int|\WP_Error 元記事のID。元記事がなければ0。
 */
function abandon_rewrite( int $copy_id ): int|\WP_Error {
	$copy = get_post( $copy_id );

	if ( ! $copy instanceof \WP_Post || STATUS_REWRITING !== $copy->post_status ) {
		return make_error( 'rewrite_archive_not_copy' );
	}

	if ( ! current_user_can( 'edit_post', $copy_id ) || ! current_user_can( 'delete_post', $copy_id ) ) {
		return make_error( 'rewrite_archive_forbidden' );
	}

	$original_id = get_original_id( $copy_id );

	if ( $original_id && reattach_media( $copy_id, $original_id )['failed'] > 0 ) {
		return make_error( 'rewrite_archive_reattach_failed' );
	}

	$deleted = without_guard(
		static function () use ( $copy_id ) {
			return wp_delete_post( $copy_id, true );
		}
	);

	if ( ! $deleted ) {
		return make_error( 'rewrite_archive_delete_failed' );
	}

	// 元記事の相互参照は、このコピーを指しているときだけ消す。別のコピーへのつながりを切らないため。
	if ( $original_id ) {
		delete_post_meta( $original_id, META_REWRITING, $copy_id );
	}

	return $original_id;
}

/**
 * 元記事の差し替え前の版を新しい順に返す
 *
 * @param int $original_id 元記事のID.
 * @return \WP_Post[]
 */
function get_pre_replace_versions( int $original_id ): array {
	return get_posts(
		array(
			'post_type'      => get_target_post_types(),
			'post_status'    => STATUS_ARCHIVED,
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- 管理画面のサイドバー用。1記事の差し替え前の版は数本
				array(
					'key'   => META_ARCHIVED_FROM,
					'value' => (string) $original_id,
				),
			),
		)
	);
}
