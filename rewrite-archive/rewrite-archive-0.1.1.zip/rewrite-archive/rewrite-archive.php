<?php
/**
 * Plugin Name:       Rewrite and Archive
 * Description:       Rewrite a published post in a working copy while the original stays live, replace it in one step, and keep the old version as an archive.
 * Version:           0.1.1
 * Requires at least: 6.7
 * Requires PHP:      8.0
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rewrite-archive
 * Update URI:        https://yuiami.jp/wp-plugins/rewrite-archive
 *
 * @package RewriteArchive
 */

namespace RewriteArchive;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'REWRITE_ARCHIVE_VERSION', '0.1.1' );
define( 'REWRITE_ARCHIVE_FILE', __FILE__ );
define( 'REWRITE_ARCHIVE_DIR', plugin_dir_path( __FILE__ ) );
define( 'REWRITE_ARCHIVE_URL', plugin_dir_url( __FILE__ ) );

/*
 * 実装はincludes/に分けてrequireする。読み込み順に依存はないが、共通関数（common.php）を先にする。
 * クラスが増えたらlink-canaryのspl_autoload_register方式に移すこと。
 */
require_once REWRITE_ARCHIVE_DIR . 'includes/common.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/settings.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/status.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/guard.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/copy.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/rewrite.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/duplicate.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/archive.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/admin-post.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/list-table.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/editor.php';
require_once REWRITE_ARCHIVE_DIR . 'includes/update-checker.php';
