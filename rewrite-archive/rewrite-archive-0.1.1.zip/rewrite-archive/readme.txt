=== Rewrite and Archive ===
Contributors: ejointjp
Tags: rewrite, republish, archive, revision, workflow
Requires at least: 6.7
Tested up to: 7.1
Stable tag: 0.1.1
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Rewrite a published post in a working copy while the original stays live, replace it in one step, and keep the old version as an archive.

== Description ==

Rewriting a post that is already published is awkward. Edit it in place and half-finished text goes live. Duplicate it and you end up with two posts that look the same in the list, one of which you might publish by mistake.

Rewrite and Archive gives the rewrite its own status.

- Start a rewrite from the posts list or the editor sidebar. The plugin makes a working copy with the "Rewriting" status. It never shows up in "All" or "Drafts", and it cannot be published.
- The copy always carries the current date, so images you upload while rewriting land in the current month's uploads folder, not the original post's.
- When you are done, replace the original in one step from the block editor sidebar of the copy. The post ID, URL, slug and comments stay exactly as they were. Images uploaded to the copy are re-attached to the original.
- The version you replaced is kept as an "Archived" post, so nothing is lost.
- You can also move any post to "Archived" by hand, for posts you have merged into another or retired. An archived post keeps its slug, so a new post cannot take over that URL by accident; a new post with the same slug gets a "-2" suffix.

Posts in the "Rewriting" and "Archived" statuses cannot have their status changed by the block editor, quick edit, bulk edit or XML-RPC. Only the plugin's own actions move them. Editing the title and content still works.

The title, content and excerpt are copied exactly as they are stored. The plugin does not run them through the acting user's HTML filters again, so embeds and other markup that an administrator published survive a rewrite done by an author, on multisite too. Whatever the author types into the copy is still filtered as usual when they save it.

Duplicate is a separate action. From the posts list or the editor sidebar, any post except a rewriting copy or a replaced version can be duplicated into a new draft with the same content, featured image, terms and custom fields. The draft has no slug yet and no link back to the source, so it is an ordinary, unrelated post.

Rewrite, duplicate and archive are available for posts and pages by default. Turn them on for other public post types under Settings → Writing → Rewrite and Archive, or adjust the list with the `rewrite_archive_post_types` filter. Use `rewrite_archive_excluded_meta_keys` to protect custom fields (view counters, for example) that must never be copied or overwritten by a replacement.

Archived posts can be moved to the trash like any other post and come back as "Archived" when restored. A rewriting copy cannot be trashed or deleted directly. It is removed when you replace the original or choose "Stop rewriting", and in both cases the images uploaded to it are re-attached to the original first.

Deleting the plugin turns every "Rewriting" and "Archived" post back into a draft so nothing disappears from the admin, and removes the setting (on every site of a multisite network). Post meta is left in place.

One setting (which post types to handle) and no custom tables.

To check for updates, it requests a small file (`info.json`) from GitHub (`raw.githubusercontent.com`), where the plugin is distributed. The request does not include your site's URL or any site data. It makes no other external requests.

The buttons for replacing the original, stopping a rewrite, duplicating and archiving live in the block editor sidebar ("Summary" panel). The posts list offers "Rewrite", "Duplicate" and "Stop rewriting" as row actions, but replacing is done from the block editor only, so the classic editor cannot finish a rewrite.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/rewrite-archive` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Open a published post and start a rewrite from the editor sidebar.

== Changelog ==

= 0.1.1 =
* Added an update checker. New versions now appear on the Plugins screen and can be installed from there.

= 0.1.0 =
* Initial release.
