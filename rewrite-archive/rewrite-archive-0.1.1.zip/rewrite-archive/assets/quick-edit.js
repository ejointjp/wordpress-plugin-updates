/**
 * クイック編集のステータス欄を調整する
 *
 * - rewriting / archivedの行: その値のoptionを足して選び、欄をdisabledにする。
 *   disabledの欄は送信されず、_statusがないとinline-saveがPHPの警告を出してdraft扱いに
 *   するため、同じ値のhidden inputを足す（ステータス自体はサーバーのガードが守る）。
 * - それ以外の行: archivedのoptionを足す（アーカイブに入れる方向はクイック編集からもできる）。
 *   ただしコピーを持つ元記事（行にrewrite-archive-has-copyクラスが付く）には足さない。
 *   アーカイブにできず、サーバーのガードが拒否するだけになるため。rewritingは選択肢に出さない。
 *
 * inlineEditPost.edit()は#inline-editのテンプレートを行ごとにcloneするため、
 * 変更は開いた行（#edit-<ID>）にだけ効き、次に開く行には引き継がれない。
 */
( function ( $, inlineEditPost ) {
	'use strict';

	var cfg = window.rewriteArchiveQuickEdit;

	if ( ! cfg || ! $ || ! inlineEditPost || 'function' !== typeof inlineEditPost.edit ) {
		return;
	}

	var originalEdit = inlineEditPost.edit;

	function ensureOption( $select, value, label ) {
		var $option = $select.find( 'option[value="' + value + '"]' );
		if ( ! $option.length ) {
			$option = $( '<option>', { value: value, text: label } );
			$select.append( $option );
		}
		return $option;
	}

	inlineEditPost.edit = function ( id ) {
		var result = originalEdit.apply( this, arguments );
		var postId = 'object' === typeof id ? this.getId( id ) : id;
		var $row = $( '#edit-' + postId );
		var $select = $row.find( 'select[name="_status"]' );
		var status = $( '#inline_' + postId + ' ._status' ).text();

		if ( ! $select.length ) {
			return result;
		}

		$select.prop( 'disabled', false );
		$row.find( 'input.rewrite-archive-status' ).remove();

		if ( cfg.rewriting.value === status || cfg.archived.value === status ) {
			var label = cfg.rewriting.value === status ? cfg.rewriting.label : cfg.archived.label;
			ensureOption( $select, status, label );
			$select.val( status ).prop( 'disabled', true );
			$select.after(
				$( '<input>', {
					type: 'hidden',
					name: '_status',
					value: status,
					'class': 'rewrite-archive-status',
				} )
			);
			return result;
		}

		if ( ! $( '#post-' + postId ).hasClass( 'rewrite-archive-has-copy' ) ) {
			ensureOption( $select, cfg.archived.value, cfg.archived.label );
		}
		$select.find( 'option[value="' + cfg.rewriting.value + '"]' ).remove();

		return result;
	};
} )( window.jQuery, window.inlineEditPost );
