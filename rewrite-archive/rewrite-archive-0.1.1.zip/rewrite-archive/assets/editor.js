/**
 * ブロックエディタのサイドバー「概要」パネルに、リライト・複製・アーカイブのボタンを出す
 *
 * ビルド工程を持たないため、JSXを使わずwp.element.createElementを直接呼ぶ。
 * 設定はincludes/editor.phpがwindow.rewriteArchiveEditorに入れる。
 * サーバー側の処理はadmin-post.php。ボタンは未保存の変更を保存してから遷移する。
 */
( function ( wp ) {
	'use strict';

	var cfg = window.rewriteArchiveEditor;

	if (
		! cfg ||
		! wp ||
		! wp.plugins ||
		! wp.data ||
		! wp.element ||
		! wp.components ||
		! wp.editor ||
		! wp.editor.PluginPostStatusInfo
	) {
		return;
	}

	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useRef = wp.element.useRef;
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;
	var Button = wp.components.Button;
	var RadioControl = wp.components.RadioControl;

	// 2段ボタンが1回目の押下から元の文言に戻るまでの時間
	var CONFIRM_RESET_MS = 6000;

	/**
	 * 未保存の変更を保存してからURLへ遷移する
	 *
	 * window.confirm()は「このページでこれ以上ダイアログを表示しない」を踏まれると
	 * 以後falseを返して無反応になるため使わない。確認はConfirmButtonの2段押しで行う。
	 * savePost()は保存に失敗してもrejectせず解決する。理由は2つあるため両方を見る:
	 * 保存自体が失敗したとき（本番はWAFに弾かれて保存が403になることがある。
	 * didPostSaveRequestFail()がtrueになる）と、保存が実際には走らずに解決したとき
	 * （他の保存やオートセーブと重なった・preSavePostが拒否した等。この場合
	 * didPostSaveRequestFail()はfalseのままだが、isEditedPostDirty()がtrueのまま残る）。
	 * どちらのときも遷移せず中止する。
	 *
	 * leave()の第2引数requireCleanがtrueのとき（「リライトを始める」「複製する」）は、
	 * 未保存の変更を保存せずに中止して知らせる。公開中の記事で押すと、保存した変更が
	 * そのまま公開されてしまうため。ブロックエディタは未保存の変更をオートセーブで
	 * 持っているので、中止しても変更は失われない。
	 *
	 * @return {Object} { leave: Function( url, requireClean ), isBusy: boolean }
	 */
	function useLeave() {
		var isDirty = useSelect( function ( select ) {
			return select( 'core/editor' ).isEditedPostDirty();
		}, [] );
		var savePost = useDispatch( 'core/editor' ).savePost;
		var createErrorNotice = useDispatch( 'core/notices' ).createErrorNotice;
		var createWarningNotice = useDispatch( 'core/notices' ).createWarningNotice;
		var busyState = useState( false );
		var isBusy = busyState[ 0 ];
		var setBusy = busyState[ 1 ];

		function leave( url, requireClean ) {
			if ( requireClean && isDirty ) {
				createWarningNotice( '未保存の変更があるため中止しました。変更を保存するか元に戻してから、もう一度押してください。', {
					type: 'snackbar',
					isDismissible: true,
				} );
				return;
			}

			setBusy( true );

			var go = function () {
				window.location.href = url;
			};

			var abort = function ( detail ) {
				setBusy( false );
				createErrorNotice( '保存に失敗したので中止しました。もう一度保存してから押してください。', {
					type: 'snackbar',
					isDismissible: true,
				} );
				if ( detail ) {
					window.console.error( 'rewrite-archive', detail );
				}
			};

			if ( ! isDirty ) {
				go();
				return;
			}

			savePost().then( function () {
				var editor = wp.data.select( 'core/editor' );
				if ( editor.didPostSaveRequestFail() || editor.isEditedPostDirty() ) {
					abort( null );
					return;
				}
				go();
			}, abort );
		}

		return { leave: leave, isBusy: isBusy };
	}

	/**
	 * 2段ボタン。1回目で文言が変わり、2回目で実行する。6秒で元に戻る
	 */
	function ConfirmButton( props ) {
		var armedState = useState( false );
		var armed = armedState[ 0 ];
		var setArmed = armedState[ 1 ];
		var timer = useRef( null );

		useEffect( function () {
			return function () {
				if ( timer.current ) {
					window.clearTimeout( timer.current );
				}
			};
		}, [] );

		function onClick() {
			if ( ! armed ) {
				setArmed( true );
				timer.current = window.setTimeout( function () {
					setArmed( false );
				}, CONFIRM_RESET_MS );
				return;
			}
			window.clearTimeout( timer.current );
			setArmed( false );
			props.onConfirm();
		}

		return el(
			Button,
			{
				variant: 'secondary',
				isDestructive: !! props.isDestructive,
				isBusy: props.isBusy,
				disabled: props.isBusy,
				accessibleWhenDisabled: true,
				className: 'rewrite-archive__button',
				onClick: onClick,
			},
			armed ? props.confirmLabel : props.label
		);
	}

	function ActionButton( props ) {
		return el(
			Button,
			{
				variant: 'secondary',
				isBusy: props.isBusy,
				disabled: props.isBusy,
				accessibleWhenDisabled: true,
				className: 'rewrite-archive__button',
				onClick: props.onClick,
			},
			props.label
		);
	}

	function LinkButton( props ) {
		return el(
			Button,
			{
				variant: 'secondary',
				href: props.href,
				target: props.newTab ? '_blank' : undefined,
				className: 'rewrite-archive__button',
			},
			props.label,
			props.newTab ? el( 'span', { className: 'screen-reader-text' }, '（新しいタブで開く）' ) : null
		);
	}

	function note( text ) {
		return el( 'p', { className: 'rewrite-archive__note' }, text );
	}

	/**
	 * 読み込み時に1回だけ、コピーの警告帯とadmin-post.phpからの結果通知を出す
	 *
	 * URLのフラグはWP本体がremovable_query_argsで消すので、ここでは触らない。
	 */
	function useNotices() {
		useEffect( function () {
			var notices = wp.data.dispatch( 'core/notices' );

			if ( 'copy' === cfg.role ) {
				var title = cfg.original ? cfg.original.title : '（元記事なし）';
				notices.createWarningNotice(
					'これは「' + title + '」のリライト用コピーです。公開されることはありません。差し替えはサイドバーの「元記事に差し替える」から。',
					{ id: 'rewrite-archive-copy', isDismissible: false }
				);
			}

			if ( cfg.notice ) {
				var options = { id: 'rewrite-archive-result', isDismissible: true };
				if ( cfg.notice.actionUrl ) {
					options.actions = [ { label: cfg.notice.actionLabel, url: cfg.notice.actionUrl } ];
				}
				if ( 'error' === cfg.notice.type ) {
					notices.createErrorNotice( cfg.notice.message, options );
				} else if ( 'warning' === cfg.notice.type ) {
					notices.createWarningNotice( cfg.notice.message, options );
				} else {
					notices.createSuccessNotice( cfg.notice.message, options );
				}
			}
		}, [] );
	}

	function copyChildren( leave, isBusy, dateMode, setDateMode ) {
		var children = [
			note( 'リライト用のコピーです。「公開」を押しても公開されず、保存されるだけです。' ),
			el( RadioControl, {
				label: '差し替え後の公開日',
				help: 'パーマリンクに日付を含むサイトでは、「今日にする」でURLが変わります。元のURLは新しいURLへ転送されます。',
				selected: dateMode,
				options: [
					{ label: '元記事のまま', value: 'keep' },
					{ label: '今日にする', value: 'today' },
				],
				onChange: setDateMode,
			} ),
			el( ConfirmButton, {
				label: '元記事に差し替える',
				confirmLabel: '本当に差し替える',
				isDestructive: true,
				isBusy: isBusy,
				onConfirm: function () {
					leave( 'today' === dateMode ? cfg.urls.replaceToday : cfg.urls.replaceKeep );
				},
			} ),
			el( ConfirmButton, {
				label: 'リライトをやめる',
				confirmLabel: '本当にやめる（コピーを削除）',
				isBusy: isBusy,
				onConfirm: function () {
					leave( cfg.urls.abandon );
				},
			} ),
		];

		if ( cfg.original ) {
			children.push( el( LinkButton, { href: cfg.original.editUrl, label: '元記事を開く' } ) );
		}

		return children;
	}

	function archivedChildren( leave, isBusy ) {
		var children = [];

		if ( 'rewrite' === cfg.reason ) {
			children.push( note( '差し替え前の版です。上のステータス欄は空欄になり、「公開」を押してもアーカイブのままです。この版の内容に戻すときは、リライト版でリライトを始め、本文を貼り付けてから差し替えてください。' ) );
			if ( cfg.original ) {
				children.push( el( LinkButton, { href: cfg.original.editUrl, label: 'リライト版を開く', newTab: true } ) );
			}
		} else {
			children.push( note( 'アーカイブ中。上のステータス欄は空欄になり、「公開」を押してもアーカイブのままです。本文を直すときは下書きに戻してください。' ) );
			children.push( el( ActionButton, {
				label: '下書きに戻して編集する',
				isBusy: isBusy,
				onClick: function () {
					leave( cfg.urls.unarchive );
				},
			} ) );
			children.push( el( ActionButton, {
				label: '複製する',
				isBusy: isBusy,
				onClick: function () {
					leave( cfg.urls.duplicate, true );
				},
			} ) );
		}

		return children;
	}

	function defaultChildren( leave, isBusy, status ) {
		var children = [];

		if ( cfg.copy ) {
			children.push( note( 'リライト中のコピーがあります。差し替えとやめる操作はコピーの編集画面から。' ) );
			children.push( el( LinkButton, { href: cfg.copy.editUrl, label: 'リライト中のコピーを開く' } ) );
		} else if ( 'publish' === status ) {
			children.push( el( ActionButton, {
				label: 'リライトを始める',
				isBusy: isBusy,
				onClick: function () {
					leave( cfg.urls.start, true );
				},
			} ) );
		}

		children.push( el( ActionButton, {
			label: '複製する',
			isBusy: isBusy,
			onClick: function () {
				leave( cfg.urls.duplicate, true );
			},
		} ) );

		if ( ! cfg.copy ) {
			children.push( el( ConfirmButton, {
				label: 'アーカイブに移動',
				confirmLabel: '本当にアーカイブに移動',
				isDestructive: true,
				isBusy: isBusy,
				onConfirm: function () {
					leave( cfg.urls.archive );
				},
			} ) );
		}

		if ( cfg.archives && cfg.archives.length ) {
			children.push( note( '差し替え前の版' ) );
			children.push( el(
				'ul',
				{ className: 'rewrite-archive__archives' },
				cfg.archives.map( function ( archive ) {
					return el( 'li', { key: archive.id }, el( 'a', { href: archive.editUrl }, archive.date + ' ' + archive.title ) );
				} )
			) );
		}

		return children;
	}

	function Panel() {
		// DB側のステータス。編集中の未保存の切り替えでは判定を変えない。
		var status = useSelect( function ( select ) {
			return select( 'core/editor' ).getCurrentPostAttribute( 'status' );
		}, [] );
		var leaveState = useLeave();
		var dateState = useState( 'keep' );

		useNotices();

		// 保存前の新規投稿には出さない。操作する対象がまだない。
		if ( ! status || 'auto-draft' === status ) {
			return null;
		}

		var children;
		if ( 'copy' === cfg.role ) {
			children = copyChildren( leaveState.leave, leaveState.isBusy, dateState[ 0 ], dateState[ 1 ] );
		} else if ( 'archived' === cfg.role ) {
			children = archivedChildren( leaveState.leave, leaveState.isBusy );
		} else {
			children = defaultChildren( leaveState.leave, leaveState.isBusy, status );
		}

		// 子要素は配列ではなく可変長引数で渡す（配列だとkeyが要る）。
		return el.apply(
			null,
			[ wp.editor.PluginPostStatusInfo, { className: 'rewrite-archive rewrite-archive--' + cfg.role } ].concat( children )
		);
	}

	wp.plugins.registerPlugin( 'rewrite-archive', { render: Panel } );
} )( window.wp );
