/**
 * 投稿一覧の行アクション「リライトをやめる」を2段にする
 *
 * 1回目のクリックでは遷移せず、文言を「本当にやめる（コピーを削除）」に変える。6秒以内にもう一度
 * クリックするとリンクをたどる（admin-post.phpがコピーを消す）。6秒たつと元の文言に戻る。
 * window.confirm()は使わない（「このページでこれ以上ダイアログを表示しない」を選ばれると、以後
 * falseを返して無反応になるため）。文言と時間はエディタの2段ボタン（assets/editor.js）に揃える。
 *
 * クイック編集の保存で行が差し替わっても効くよう、documentで委譲して受ける。
 * 中クリック（新しいタブで開く）はclickではなくauxclickで来て、2段確認を通らずにリンクをたどるため止める
 * （auxclickを発火しないブラウザでは止まらない）。
 */
( function () {
	'use strict';

	// 1回目のクリックから元の文言に戻るまでの時間
	var CONFIRM_RESET_MS = 6000;
	var CONFIRM_LABEL = '本当にやめる（コピーを削除）';
	var SELECTOR = '.row-actions .rewrite_archive_abandon a';

	// 1回目を押したリンクごとの、元の文言と元に戻すタイマー
	var armed = new WeakMap();

	function disarm( link ) {
		var state = armed.get( link );

		if ( ! state ) {
			return;
		}

		window.clearTimeout( state.timer );
		link.textContent = state.label;
		armed.delete( link );
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target instanceof Element ? event.target.closest( SELECTOR ) : null;

		if ( ! link ) {
			return;
		}

		// 2回目: 文言を戻して、リンクどおりに遷移させる
		if ( armed.has( link ) ) {
			disarm( link );
			return;
		}

		event.preventDefault();

		armed.set( link, {
			label: link.textContent,
			timer: window.setTimeout( function () {
				disarm( link );
			}, CONFIRM_RESET_MS ),
		} );
		link.textContent = CONFIRM_LABEL;
	} );

	// 中クリックは確認なしに新しいタブで実行されてしまうため、たどらせない
	document.addEventListener( 'auxclick', function ( event ) {
		if ( 1 !== event.button ) {
			return;
		}

		var link = event.target instanceof Element ? event.target.closest( SELECTOR ) : null;

		if ( link ) {
			event.preventDefault();
		}
	} );
} )();
