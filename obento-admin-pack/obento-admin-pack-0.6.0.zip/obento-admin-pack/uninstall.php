<?php
/**
 * 削除時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * 投稿のmenu_orderはコアの列なので触らない。
 *
 * マルチサイトでは、ネットワーク管理画面から削除したときにメインサイトの文脈で1回だけ走る。
 * 設定と順序のデータはサイトごとのテーブルにあるので、サイトを切り替えて全サイトから消す。
 * 更新情報のキャッシュ（site transient）はネットワークで共通なので、ループの外で1回だけ消す。
 *
 * @package Obento
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * いまのサイトの設定と順序のデータを消す
 */
function obento_uninstall_site() {
	delete_option( 'obento_settings' );
	delete_option( 'obento_order_state' );
	delete_option( 'obento_menu' );
	delete_option( 'obento_dashboard' );
	delete_option( 'obento_toolbar' );
	delete_option( 'obento_dashboard_seen' );
	delete_option( 'obento_toolbar_seen' );
	delete_metadata( 'term', 0, '_obento_order', '', true );
}

if ( is_multisite() ) {
	$obento_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);
	foreach ( $obento_site_ids as $obento_site_id ) {
		switch_to_blog( $obento_site_id );
		obento_uninstall_site();
		restore_current_blog();
	}
} else {
	obento_uninstall_site();
}
delete_site_transient( 'obento_update_info' );
