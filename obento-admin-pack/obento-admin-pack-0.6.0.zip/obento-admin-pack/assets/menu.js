/**
 * 「管理メニュー」タブ（設定 > Obento Admin Pack）
 *
 * 表はPHP（includes/menu-screen.php）が描く。ここで持つのは、
 * - ☰のドラッグ（jQuery UI sortable）。トップはトップの中、サブは同じ親の中だけで動く（別の親へは移せない）。
 *   サブを自分のリストの外で離したら、ドラッグ前の並びに戻す
 * - サブの開閉
 * - 名前の編集（クリックで入力欄に。空にすると元の名前に戻る。元と違えば「元: X」を出す）
 * - チェックの連動（親を隠したロールのサブは操作できなくする。閉じた親に隠したサブがあれば「一部非表示」）
 * - 送信前のJSON化（表全体をhidden欄1つで送る）と、「初期状態に戻す」の確認
 * - 表が横にあふれない幅では、表のoverflow-x: autoを外す（ドラッグ中にページが自動スクロールするように）。
 *   ウィンドウの幅が変わったときと、左のメニューを折りたたんだり開いたりしたときに、判定し直す
 * JSが動かないあいだは、保存のボタンはdisabledで、hidden欄にはPHPが入れたいまの設定が入っている。
 * 初期化の途中で例外になったときも、この状態のまま残す（注意を消してボタンを有効にするのは、初期化の最後）。
 *
 * 行のデータ属性: data-slug（メニューのslug）、data-parent（サブなら親のslug）、data-label（元の名前）
 */

/* global jQuery */

( function ( $ ) {
	'use strict';

	$( function () {
		var $form = $( '#obento-menu-form' );
		var $list = $( '#obento-menu-list' );
		if ( ! $form.length || ! $list.length ) {
			return;
		}
		if ( ! $.fn.sortable ) {
			console.error( 'Obento Admin Pack: jQuery UI sortableを読み込めなかったため、管理メニューを編集できません。' );
			return;
		}
		var $json = $( '#obento-menu-json' );
		var $save = $( '#obento-menu-save' );
		var $reset = $( '#obento-menu-reset' );
		var resetting = false;

		// 行のいまの名前（名前のボタンの文字）。名前のない行（区切り線など）は空
		function currentLabel( $item ) {
			var $name = $item.children( '.obento-menu-row' ).find( '.obento-menu-name' );
			return $name.length ? $name.text() : '';
		}

		// 名前を表示し直す。空なら元の名前に戻す。元と違えば「元: X」を出す
		function setLabel( $item, label ) {
			var original = $item.attr( 'data-label' ) || '';
			var $row = $item.children( '.obento-menu-row' );
			label = String( label ).trim();
			if ( '' === label ) {
				label = original;
			}
			$row.find( '.obento-menu-name' ).text( label );
			$row.find( '.obento-menu-origin' ).prop( 'hidden', label === original );
		}

		// 名前をクリックすると入力欄に変わる。Enterかフォーカスが外れたら確定、Escapeで取り消し。
		// フォーカスを名前のボタンへ戻すのは、EnterとEscapeのときだけ（フォーカスが外れたときは、移った先を奪わない）
		$list.on( 'click', '.obento-menu-name', function () {
			var $button = $( this );
			var $item = $button.closest( '.obento-menu-item' );
			var $input = $( '<input type="text" class="obento-menu-name-input">' )
				.attr( 'aria-label', '名前（空にすると元の名前に戻ります）' )
				.val( $button.text() );
			var done = false;
			function commit( value, refocus ) {
				if ( done ) {
					return;
				}
				done = true;
				$input.replaceWith( $button );
				setLabel( $item, value );
				if ( refocus ) {
					$button.trigger( 'focus' );
				}
			}
			$input
				.on( 'keydown', function ( event ) {
					// IMEの変換中のEnter・Escapeは、変換の確定・取り消しに使われる。名前の確定・取り消しにはしない。
					// .trigger()で作ったイベントにはoriginalEventがないので、eventそのものにもフォールバックする
					if ( ( event.originalEvent || event ).isComposing || 229 === event.keyCode ) {
						return;
					}
					if ( 'Enter' === event.key ) {
						event.preventDefault();
						commit( $input.val(), true );
					} else if ( 'Escape' === event.key ) {
						event.preventDefault();
						commit( $button.text(), true );
					}
				} )
				.on( 'blur', function () {
					commit( $input.val(), false );
				} );
			$button.replaceWith( $input );
			$input.trigger( 'focus' ).trigger( 'select' );
		} );

		// サブの開閉
		$list.on( 'click', '.obento-menu-toggle', function () {
			var $toggle = $( this );
			var $item = $toggle.closest( '.obento-menu-item' );
			var open = ! $item.hasClass( 'is-open' );
			$item.toggleClass( 'is-open', open );
			$item.children( '.obento-menu-sublist' ).prop( 'hidden', ! open );
			$toggle.attr( 'aria-expanded', open ? 'true' : 'false' );
			$toggle.find( '.dashicons' ).toggleClass( 'dashicons-arrow-right', ! open ).toggleClass( 'dashicons-arrow-down', open );
		} );

		// 親のチェック（ロールR）が外れていたら、同じロールのサブのチェックを操作できなくする（親ごと隠れるため）。
		// サブに外れているチェックがあれば「一部非表示」を出す（CSSが、開いている親では隠す）
		function refreshItem( $item ) {
			var $row = $item.children( '.obento-menu-row' );
			var $subs = $item.children( '.obento-menu-sublist' ).children( '.obento-menu-item' );
			if ( ! $subs.length ) {
				return;
			}
			$row.find( '.obento-menu-show' ).each( function () {
				var role = $( this ).attr( 'data-role' );
				var inherit = ! this.checked;
				$subs
					.children( '.obento-menu-row' )
					.find( '.obento-menu-show' )
					.filter( function () {
						return $( this ).attr( 'data-role' ) === role;
					} )
					.prop( 'disabled', inherit )
					.closest( '.obento-menu-cell' )
					.toggleClass( 'obento-menu-inherit', inherit );
			} );
			var partial = $subs.children( '.obento-menu-row' ).find( '.obento-menu-show' ).filter( function () {
				return ! this.checked;
			} ).length > 0;
			$row.find( '.obento-menu-partial' ).prop( 'hidden', ! partial );
		}
		$list.on( 'change', '.obento-menu-show', function () {
			var $item = $( this ).closest( '.obento-menu-item' );
			if ( $item.hasClass( 'obento-menu-sub' ) ) {
				$item = $item.closest( '.obento-menu-top' );
			}
			refreshItem( $item );
		} );
		$list.children( '.obento-menu-item' ).each( function () {
			refreshItem( $( this ) );
		} );

		// ドラッグ。ハンドルは「その行の」☰だけにする（'> .obento-menu-row > .obento-menu-grip'）。
		// サブのリストはトップのリストの中にあるが、両方が同時に動き出すことはない（mousedownは内側のsortableが先に受け、
		// jQuery UIのmouseプラグインが外側を止める）。ハンドルを絞るのは念のための備え
		function sortableOptions( containment ) {
			return {
				items: '> li',
				handle: '> .obento-menu-row > .obento-menu-grip',
				axis: 'y',
				tolerance: 'pointer',
				containment: containment,
				placeholder: 'obento-menu-placeholder',
				forcePlaceholderSize: true,
				helper: function ( event, $item ) {
					return $item.clone().width( $item.outerWidth() );
				},
			};
		}
		$list.sortable( sortableOptions( false ) );

		// サブは、自分のリストの外（別の親の領域など）で離したら、ドラッグ前の並びに戻す。
		// containment: 'parent'はヘルパーをリストの中に閉じ込めるだけで、外で離してもリストの端に収まってしまう。
		// そこで、離したときのポインターの縦の位置がリストの上下の外なら、stopでcancelして元に戻す（リストの中なら今までどおり）
		function revertIfDroppedOutside( event ) {
			var $sublist = $( this );
			var top = $sublist.offset().top;
			if ( event.pageY < top || event.pageY > top + $sublist.outerHeight() ) {
				$sublist.sortable( 'cancel' );
			}
		}
		$list.find( '.obento-menu-sublist' ).sortable( $.extend( sortableOptions( 'parent' ), { stop: revertIfDroppedOutside } ) );

		// 表全体をJSONにする（設計書の「保存の形」）。
		// labelsには元の名前と違うものだけ、hiddenにはチェックが外れている欄だけを入れる（「—」と鍵の欄にはチェックがない）
		function collect() {
			var data = { order: [], sub_order: {}, labels: { top: {}, sub: {} }, hidden: {} };
			function hiddenEntry( role ) {
				if ( ! data.hidden[ role ] ) {
					data.hidden[ role ] = { top: [], sub: {} };
				}
				return data.hidden[ role ];
			}
			function labelOf( $item ) {
				var label = currentLabel( $item );
				return label && label !== ( $item.attr( 'data-label' ) || '' ) ? label : '';
			}
			$list.children( '.obento-menu-item' ).each( function () {
				var $top = $( this );
				var slug = $top.attr( 'data-slug' );
				var label = labelOf( $top );
				data.order.push( slug );
				if ( label ) {
					data.labels.top[ slug ] = label;
				}
				$top.children( '.obento-menu-row' ).find( '.obento-menu-show' ).each( function () {
					if ( ! this.checked ) {
						hiddenEntry( $( this ).attr( 'data-role' ) ).top.push( slug );
					}
				} );
				var $subs = $top.children( '.obento-menu-sublist' ).children( '.obento-menu-item' );
				if ( ! $subs.length ) {
					return;
				}
				data.sub_order[ slug ] = [];
				$subs.each( function () {
					var $sub = $( this );
					var subSlug = $sub.attr( 'data-slug' );
					var subLabel = labelOf( $sub );
					data.sub_order[ slug ].push( subSlug );
					if ( subLabel ) {
						if ( ! data.labels.sub[ slug ] ) {
							data.labels.sub[ slug ] = {};
						}
						data.labels.sub[ slug ][ subSlug ] = subLabel;
					}
					$sub.children( '.obento-menu-row' ).find( '.obento-menu-show' ).each( function () {
						if ( this.checked ) {
							return;
						}
						var entry = hiddenEntry( $( this ).attr( 'data-role' ) );
						if ( ! entry.sub[ slug ] ) {
							entry.sub[ slug ] = [];
						}
						entry.sub[ slug ].push( subSlug );
					} );
				} );
			} );
			return data;
		}

		// 「初期状態に戻す」は取り消せないので確認する。取り消したら送らない
		$reset.on( 'click', function ( event ) {
			if ( ! window.confirm( '管理メニューの並び・名前・非表示の設定をすべて消して、WordPressの初期状態に戻します。よろしいですか？' ) ) {
				event.preventDefault();
				return;
			}
			resetting = true;
		} );
		$save.on( 'click', function () {
			resetting = false;
		} );

		// 送信の直前にhidden欄を埋める（Enterでの送信も通る）
		$form.on( 'submit', function () {
			$json.val( JSON.stringify( resetting ? { reset: true } : collect() ) );
		} );

		// 表が横にあふれない幅では、overflow-x: autoを外す（クラスis-fitがoverflow: visibleにする）。
		// overflow-x: autoのままだとoverflow-yもautoになり、jQuery UIが表をスクロールの親と見なして、
		// ドラッグ中にページではなく表をスクロールしようとする（長いメニューで、行を画面の端より先へ運べない）。
		// ロールが多くて表が横にあふれるときだけ、横スクロールを残す。
		// 判定し直すのは、ウィンドウの幅が変わったとき（resize）と、左のメニューを折りたたんだり開いたりしたとき。
		// 後者は表の幅を変えるが、ウィンドウのresizeは起きない。WordPressがdocumentに'wp-collapse-menu'を出す
		var $table = $list.closest( '.obento-menu-table' );
		function fitTable() {
			var table = $table[ 0 ];
			if ( ! table ) {
				return;
			}
			$table.removeClass( 'is-fit' );
			$table.toggleClass( 'is-fit', table.clientWidth > 0 && table.scrollWidth <= table.clientWidth );
		}
		fitTable();
		$( window ).on( 'resize', fitTable );
		$( document ).on( 'wp-collapse-menu', fitTable );

		// 初期化の最後に、「JavaScriptが動いていない」の注意を消して、ボタンを有効にする。
		// 途中で例外になったときは、注意が残りボタンも無効のまま（古いJSONを送る保存ボタンを出さない）
		$( '.obento-menu-nojs' ).remove();
		$save.prop( 'disabled', false );
		$reset.prop( 'disabled', false );
	} );
} )( jQuery );
