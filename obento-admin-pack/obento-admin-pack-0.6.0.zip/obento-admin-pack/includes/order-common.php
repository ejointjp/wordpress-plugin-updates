<?php
/**
 * 並び替えの共通部分
 *
 * 並び替えモード（URLにobento_sort=1）の判定とURL、順序を保存した投稿タイプ・タクソノミーの記録（obento_order_state）、
 * 権限の判定、AJAXで送られた順序の読み取りと応答、並び替えモードのスクリプトの読み込み、全件を1ページに出す処理。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 並び替えモードか
 *
 * @return bool
 */
function obento_is_sort_mode() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 一覧の表示モードを読むだけ
	return ! empty( $_GET['obento_sort'] );
}

/**
 * 並び替えモードへ入るURLと出るURL
 *
 * 入るときは列のソートとページ送りを外す（保存した順序どおりに全件を並べるため）。
 *
 * @return array{sortUrl: string, exitUrl: string}
 */
function obento_get_sort_mode_urls() {
	$removable = wp_removable_query_args();
	return array(
		'sortUrl' => esc_url_raw( add_query_arg( 'obento_sort', '1', remove_query_arg( array_merge( $removable, array( 'orderby', 'order', 'paged' ) ) ) ) ),
		'exitUrl' => esc_url_raw( remove_query_arg( array_merge( $removable, array( 'obento_sort' ) ) ) ),
	);
}

/**
 * 順序を保存したことのある投稿タイプ・タクソノミーの記録を返す
 *
 * @return array{post_types?: array<string, int>, taxonomies?: array<string, int>}
 */
function obento_get_order_state() {
	$state = get_option( 'obento_order_state' );
	return is_array( $state ) ? $state : array();
}

/**
 * 順序を一度でも保存したか
 *
 * @param string $group post_types / taxonomies。
 * @param string $name  投稿タイプ名かタクソノミー名。
 * @return bool
 */
function obento_has_saved_order( $group, $name ) {
	$state = obento_get_order_state();
	return ! empty( $state[ $group ][ $name ] );
}

/**
 * 順序を保存したことを記録する
 *
 * @param string $group post_types / taxonomies。
 * @param string $name  投稿タイプ名かタクソノミー名。
 */
function obento_mark_order_saved( $group, $name ) {
	$state = obento_get_order_state();
	if ( ! empty( $state[ $group ][ $name ] ) ) {
		return;
	}
	$state[ $group ][ $name ] = 1;
	update_option( 'obento_order_state', $state );
}

/**
 * 投稿の並び替えができるか（対象の投稿タイプで、edit_others_postsに相当する権限がある）
 *
 * @param string $post_type 投稿タイプ名。
 * @return WP_Post_Type|WP_Error
 */
function obento_authorize_post_order( $post_type ) {
	$object = post_type_exists( $post_type ) ? get_post_type_object( $post_type ) : null;
	if ( ! $object || ! obento_is_order_post_type( $post_type ) ) {
		return new WP_Error( 'obento_not_orderable', 'この投稿タイプは並び替えの対象ではありません。設定 > Obento Admin Packで対象にしてください。' );
	}
	if ( ! current_user_can( $object->cap->edit_others_posts ) ) {
		return new WP_Error( 'obento_forbidden', '並び替える権限がありません。' );
	}
	return $object;
}

/**
 * タームの並び替えができるか（対象のタクソノミーで、manage_termsの権限がある）
 *
 * @param string $taxonomy タクソノミー名。
 * @return WP_Taxonomy|WP_Error
 */
function obento_authorize_term_order( $taxonomy ) {
	$object = taxonomy_exists( $taxonomy ) ? get_taxonomy( $taxonomy ) : null;
	if ( ! $object || ! obento_is_order_taxonomy( $taxonomy ) ) {
		return new WP_Error( 'obento_not_orderable', 'このタクソノミーは並び替えの対象ではありません。設定 > Obento Admin Packで対象にしてください。' );
	}
	if ( ! current_user_can( $object->cap->manage_terms ) ) {
		return new WP_Error( 'obento_forbidden', '並び替える権限がありません。' );
	}
	return $object;
}

/**
 * AJAXで送られてきた順序を、idとpositionの整数の配列にする
 *
 * @param mixed $raw JSONを復号した値（obento_read_order_payload()から渡る）。
 * @return array<int, array{id: int, position: int}>
 */
function obento_sanitize_order_payload( $raw ) {
	$order = array();
	if ( ! is_array( $raw ) ) {
		return $order;
	}
	foreach ( $raw as $item ) {
		if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
			continue;
		}
		$order[] = array(
			'id'       => absint( $item['id'] ),
			'position' => isset( $item['position'] ) ? absint( $item['position'] ) : 0,
		);
	}
	return $order;
}

/**
 * AJAXで送られてきた順序を読む（投稿とタームで共通）
 *
 * orderはJSON文字列1つ（[{"id":12,"position":0},...]）、countは送った件数。
 * order[n][id]のように1件ごとに変数を使うと、PHPのmax_input_vars（既定1000）を超えた分が黙って捨てられ、
 * 届いた分だけが保存されて成功と返ってしまう。1つの変数にまとめ、整形したあとの件数がcountと食い違えば、
 * 一部しか届いていないとして拒否する（idのない項目が捨てられた場合も同じ）。
 * nonceと権限の確認は、呼び出し元のハンドラーが済ませてから呼ぶ。
 *
 * @return array|WP_Error 読めたとき array( array( 'id' => int, 'position' => int ), ... )。
 *                        orderがない・JSONでないときはobento_invalid_order、件数が食い違うときはobento_incomplete_orderのWP_Error。
 */
function obento_read_order_payload() {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 呼び出し元のハンドラーがcheck_ajax_referer()で確かめたあとに呼ぶ。復号した値はobento_sanitize_order_payload()で整数にする
	$raw = isset( $_POST['order'] ) && is_string( $_POST['order'] ) ? json_decode( wp_unslash( $_POST['order'] ), true ) : null;
	if ( ! is_array( $raw ) ) {
		return new WP_Error( 'obento_invalid_order', '並び替えのデータが不正です。ページを読み込み直して、もう一度並び替えてください。' );
	}
	$order = obento_sanitize_order_payload( $raw );

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- 同上。件数はabsint()で整数にする
	$count = isset( $_POST['count'] ) && is_string( $_POST['count'] ) ? absint( wp_unslash( $_POST['count'] ) ) : 0;
	if ( count( $order ) !== $count ) {
		return new WP_Error( 'obento_incomplete_order', '並び替えのデータが一部しか届きませんでした。ページを読み込み直して、もう一度保存してください。' );
	}
	return $order;
}

/**
 * 保存の結果をJSONで返して終了する
 *
 * @param array|WP_Error $result obento_apply_post_order() / obento_apply_term_order()の戻り。
 */
function obento_send_order_result( $result ) {
	if ( is_wp_error( $result ) ) {
		wp_send_json_error(
			array( 'message' => $result->get_error_message() ),
			'obento_forbidden' === $result->get_error_code() ? 403 : 400
		);
	}
	if ( $result['failed'] > 0 ) {
		wp_send_json_error(
			array(
				'message' => sprintf( '%d件の順序を保存できませんでした。もう一度お試しください。', $result['failed'] ),
				'result'  => $result,
			),
			500
		);
	}
	wp_send_json_success(
		array(
			'message' => '順序を保存しました。',
			'result'  => $result,
		)
	);
}

/**
 * いまの一覧の並び替えの文脈（スクリプトに渡す値）。対象外か権限がなければnull
 *
 * @return array|null
 */
function obento_get_order_context() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen ) {
		return null;
	}
	if ( 'edit' === $screen->base ) {
		$object = obento_authorize_post_order( $screen->post_type );
		if ( is_wp_error( $object ) ) {
			return null;
		}
		return array(
			'kind'         => 'post',
			'objectType'   => $screen->post_type,
			'hierarchical' => (bool) $object->hierarchical,
			'idPrefix'     => 'post-',
			'action'       => 'obento_save_post_order',
		);
	}
	if ( 'edit-tags' === $screen->base ) {
		$object = obento_authorize_term_order( $screen->taxonomy );
		if ( is_wp_error( $object ) ) {
			return null;
		}
		return array(
			'kind'         => 'term',
			'objectType'   => $screen->taxonomy,
			'hierarchical' => (bool) $object->hierarchical,
			'idPrefix'     => 'tag-',
			'action'       => 'obento_save_term_order',
		);
	}
	return null;
}

/**
 * 対象の一覧に、並び替えモードのスクリプトとスタイルを読み込む
 *
 * @param string $hook 管理画面のページ。
 */
function obento_order_enqueue( $hook ) {
	if ( 'edit.php' !== $hook && 'edit-tags.php' !== $hook ) {
		return;
	}
	$context = obento_get_order_context();
	if ( ! $context ) {
		return;
	}
	wp_enqueue_style( 'obento-order', OBENTO_URL . 'assets/order.css', array(), OBENTO_VERSION );
	wp_enqueue_script( 'obento-order', OBENTO_URL . 'assets/order.js', array( 'jquery', 'jquery-ui-sortable', 'wp-a11y' ), OBENTO_VERSION, true );
	$data = array_merge(
		$context,
		array(
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'obento_order' ),
			'isSortMode' => obento_is_sort_mode(),
		),
		obento_get_sort_mode_urls()
	);
	wp_add_inline_script( 'obento-order', 'var obentoOrder = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', 'obento_order_enqueue' );

/**
 * 並び替えモードの目印をbodyに付ける（CSSが表示の最初から効くように）
 *
 * @param string $classes bodyのクラス（空白区切り）。
 * @return string
 */
function obento_order_body_class( $classes ) {
	if ( obento_is_sort_mode() && obento_get_order_context() ) {
		$classes .= ' obento-sort-mode';
	}
	return $classes;
}
add_filter( 'admin_body_class', 'obento_order_body_class' );

/**
 * 並び替えモードの投稿一覧では全件を1ページに出す
 *
 * ページをまたぐと、順序がページごとに0から振り直されて衝突するため。
 * スクリプトやbodyクラスと同じく、並び替えの対象の投稿タイプで、保存と同じ権限（edit_others_posts相当）がある人だけに効かせる。
 * 権限を見ないと、一覧を開ける人なら誰でも?obento_sort=1を付けて総件数を1ページに出せ、表示オプションの上限（999）を迂回できてしまう。
 *
 * 引き上げるのは一覧の準備（wp_edit_posts_query()とprepare_items()。admin-header.phpより前に済む）だけ。
 * 表示オプションの件数の欄（WP_Screen::render_per_page_options()）は、in_admin_headerのあとに同じフィルタを通って描かれるので、
 * そこでは受け取った値（利用者の件数）を返す。総件数のまま「適用」を押すと、その値が利用者の件数として保存されるため。
 *
 * @param int    $per_page  1ページの件数。
 * @param string $post_type 投稿タイプ。
 * @return int
 */
function obento_order_posts_per_page( $per_page, $post_type ) {
	if ( did_action( 'in_admin_header' ) || ! obento_is_sort_mode() || is_wp_error( obento_authorize_post_order( $post_type ) ) ) {
		return $per_page;
	}
	return max( (int) $per_page, (int) array_sum( (array) wp_count_posts( $post_type ) ) );
}
add_filter( 'edit_posts_per_page', 'obento_order_posts_per_page', 10, 2 );

/**
 * 並び替えモードのターム一覧では全件を1ページに出す（タクソノミーごとのフィルタを登録する）
 *
 * 投稿と同じく、並び替えの対象のタクソノミーで、保存と同じ権限（manage_terms）がある人だけに効かせる。
 */
function obento_order_terms_per_page_setup() {
	$screen = get_current_screen();
	if ( ! $screen || ! $screen->taxonomy || ! obento_is_sort_mode() || is_wp_error( obento_authorize_term_order( $screen->taxonomy ) ) ) {
		return;
	}
	add_filter( "edit_{$screen->taxonomy}_per_page", 'obento_order_terms_per_page' );
}
add_action( 'load-edit-tags.php', 'obento_order_terms_per_page_setup' );

/**
 * ターム一覧の1ページの件数を総件数まで上げる
 *
 * 投稿と同じく、一覧の準備（prepare_items()）だけで引き上げ、in_admin_headerのあとに描かれる表示オプションの件数の欄には、
 * 受け取った値（利用者の件数）を返す。
 *
 * @param int $per_page 1ページの件数。
 * @return int
 */
function obento_order_terms_per_page( $per_page ) {
	if ( did_action( 'in_admin_header' ) ) {
		return $per_page;
	}
	$screen = get_current_screen();
	$count  = wp_count_terms(
		array(
			'taxonomy'   => $screen->taxonomy,
			'hide_empty' => false,
		)
	);
	return is_wp_error( $count ) ? $per_page : max( (int) $per_page, (int) $count );
}
