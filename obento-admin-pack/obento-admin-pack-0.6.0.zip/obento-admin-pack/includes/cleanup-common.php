<?php
/**
 * ダッシュボードとツールバーの片付けの共通部分（純粋な関数）
 *
 * 設定（obento_dashboard / obento_toolbar。hidden: ロール => 隠すIDの配列）の正規化と読み出し、sanitizeの本体、
 * 利用者のロールから隠すIDの集合を作る処理、記録（obento_dashboard_seen / obento_toolbar_seen）の読み出し、
 * タイトルから表に出す名前を作る処理。ここにはフックを書かない。
 * ロールの一覧と利用者のロールは、管理メニュー編集（includes/menu-common.php）の関数を使う。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定の空の形（設定なし）
 *
 * @return array{hidden: array<string, string[]>}
 */
function obento_cleanup_empty_settings() {
	return array( 'hidden' => array() );
}

/**
 * optionの値を設定の形に整える
 *
 * 読めない部分は捨てる。配列でない、hiddenが配列でない、ロールの中身が配列でない壊れ方はbrokenで知らせる。
 * IDは文字列だけを残し、重複を除く。空になったロールは落とす。ロールが実在するか、鍵のIDかは見ない（sanitizeの仕事）。
 *
 * @param mixed $raw get_option( …, array() )の値。
 * @return array{settings: array{hidden: array<string, string[]>}, broken: bool}
 */
function obento_cleanup_normalize( $raw ) {
	$settings = obento_cleanup_empty_settings();
	if ( ! is_array( $raw ) ) {
		return array(
			'settings' => $settings,
			'broken'   => true,
		);
	}
	$broken = false;
	if ( isset( $raw['hidden'] ) ) {
		if ( ! is_array( $raw['hidden'] ) ) {
			$broken = true;
		} else {
			foreach ( $raw['hidden'] as $role => $ids ) {
				if ( ! is_array( $ids ) ) {
					$broken = true;
					continue;
				}
				$ids = array_values( array_unique( array_filter( $ids, 'is_string' ) ) );
				if ( $ids ) {
					$settings['hidden'][ (string) $role ] = $ids;
				}
			}
		}
	}
	return array(
		'settings' => $settings,
		'broken'   => $broken,
	);
}

/**
 * 設定を返す（形を整えたもの。設定がなければ空の形）
 *
 * @param string $option obento_dashboard / obento_toolbar。
 * @return array
 */
function obento_get_cleanup_settings( $option ) {
	$read = obento_cleanup_normalize( get_option( $option, array() ) );
	return $read['settings'];
}

/**
 * 保存されている設定が壊れているか（設定画面の通知に使う）
 *
 * @param string $option obento_dashboard / obento_toolbar。
 * @return bool
 */
function obento_cleanup_settings_broken( $option ) {
	$read = obento_cleanup_normalize( get_option( $option, array() ) );
	return $read['broken'];
}

/**
 * 記録を返す（配列でなければ空）
 *
 * @param string $option obento_dashboard_seen / obento_toolbar_seen。
 * @return array
 */
function obento_cleanup_seen( $option ) {
	$seen = get_option( $option, array() );
	return is_array( $seen ) ? $seen : array();
}

/**
 * タイトルから表に出す名前を作る（タグを除き、連続する空白を1つにしてtrim）
 *
 * @param mixed $title ウィジェットのタイトルか、ツールバーのノードのtitle。
 * @return string
 */
function obento_cleanup_title_text( $title ) {
	return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $title ) ) );
}

/**
 * 利用者のロールから、隠すIDの集合を作る
 *
 * 持っているロールのどれか1つで表示なら出す（すべてのロールで隠しているIDだけを隠す）。設定のないロールは何も隠さない。
 *
 * @param array    $settings obento_get_cleanup_settings()の値。
 * @param string[] $roles    利用者のロール。
 * @return array<string, true>
 */
function obento_cleanup_hidden_for_roles( $settings, $roles ) {
	$hidden = null;
	foreach ( $roles as $role ) {
		$ids    = isset( $settings['hidden'][ $role ] ) ? array_fill_keys( $settings['hidden'][ $role ], true ) : array();
		$hidden = null === $hidden ? $ids : array_intersect_key( $hidden, $ids );
	}
	return (array) $hidden;
}

/**
 * 設定の通知を登録する
 *
 * - settings_errors()は文言をエスケープせずに出すので、ここでesc_html()する
 * - optionがまだないときの初回の保存ではsanitizeが2回走る。同じコードは1回だけ登録する
 * - WP-CLIなどからのupdate_option()ではadd_settings_error()が読み込まれていなくて通知を出せない。エラーは黙って捨てず、error_logへ1行残す
 *
 * @param string $option  obento_dashboard / obento_toolbar（通知のsettingの名前にもする）。
 * @param string $code    コード。
 * @param string $message 文言。
 * @param string $type    error / success。
 */
function obento_cleanup_add_settings_error( $option, $code, $message, $type = 'error' ) {
	if ( ! function_exists( 'add_settings_error' ) ) {
		if ( 'error' === $type ) {
			error_log( sprintf( 'Obento Admin Pack: %s（%s）', $message, $code ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 通知を出せない文脈（WP-CLIなど）で、設定を保存できなかったことを黙って捨てないため
		}
		return;
	}
	if ( in_array( $code, wp_list_pluck( get_settings_errors( $option ), 'code' ), true ) ) {
		return;
	}
	add_settings_error( $option, $code, esc_html( $message ), $type );
}

/**
 * sanitizeの本体（ダッシュボードとツールバーで共通）
 *
 * 画面からはJSON文字列1つで届く。update_option()に配列を渡したとき（初回の保存の2回目、WP-CLI、検証）は配列のまま受ける。
 * - 読めない送信（JSONでない、空、配列でない、形が壊れている）は前の値を返し、エラーを登録する
 * - {"reset":true}は空の配列（設定なし）
 * - {"reset_seen":true}は記録のoptionを消し、$seen_reset_messageを成功の通知として登録して、設定は前の値のまま返す。
 *   記録のoptionを渡さないときは前の値を返すだけ
 * - 知らないロール（wp_rolesにない）と、鍵のIDを落とす
 *
 * @param string $option             obento_dashboard / obento_toolbar。
 * @param mixed  $input              送られてきた値。
 * @param array  $locked             鍵のID => 理由。
 * @param string $seen_option        記録のoption名。空なら「記録をリセット」を受け付けない。
 * @param string $seen_reset_message 記録をリセットしたときの通知の文言（エスケープ前）。
 * @return array
 */
function obento_cleanup_sanitize( $option, $input, $locked, $seen_option = '', $seen_reset_message = '記録をリセットしました。' ) {
	$previous = get_option( $option, array() );
	$previous = is_array( $previous ) ? $previous : array();
	$invalid  = '設定を保存できませんでした。ページを読み込み直して、もう一度お試しください。';

	if ( is_string( $input ) ) {
		$data = '' === trim( $input ) ? null : json_decode( $input, true );
	} else {
		$data = $input;
	}
	if ( ! is_array( $data ) ) {
		obento_cleanup_add_settings_error( $option, 'obento_cleanup_invalid', $invalid );
		return $previous;
	}
	if ( ! empty( $data['reset'] ) ) {
		return array();
	}
	if ( ! empty( $data['reset_seen'] ) ) {
		if ( '' !== $seen_option ) {
			delete_option( $seen_option );
			obento_cleanup_add_settings_error( $option, 'obento_cleanup_seen_reset', $seen_reset_message, 'success' );
		}
		return $previous;
	}

	$read = obento_cleanup_normalize( $data );
	if ( $read['broken'] ) {
		obento_cleanup_add_settings_error( $option, 'obento_cleanup_invalid', $invalid );
		return $previous;
	}
	$roles  = obento_menu_role_slugs();
	$hidden = array();
	foreach ( $read['settings']['hidden'] as $role => $ids ) {
		if ( ! in_array( $role, $roles, true ) ) {
			continue;
		}
		$ids = array_values( array_diff( $ids, array_keys( $locked ) ) );
		if ( $ids ) {
			$hidden[ $role ] = $ids;
		}
	}
	return array( 'hidden' => $hidden );
}
