<?php
/**
 * 設定の既定値・読み出し・sanitize・設定画面（設定 > Obento Admin Pack）
 *
 * optionはobento_settingsの1つ。保存されていないあいだは実行時に既定値を計算する。
 * 管理メニューの設定（obento_menu）はincludes/menu-screen.phpが持ち、この画面の「管理メニュー」タブに出す。
 * ダッシュボードとツールバーの設定（obento_dashboard / obento_toolbar）はincludes/cleanup-screen.phpが持ち、この画面の「ダッシュボード」「ツールバー」タブに出す。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定画面に並べる投稿タイプ（show_uiのもの。メディアは除く）
 *
 * @return WP_Post_Type[] 投稿タイプ名 => オブジェクト。
 */
function obento_get_post_types() {
	$types = get_post_types( array( 'show_ui' => true ), 'objects' );
	unset( $types['attachment'] );
	return $types;
}

/**
 * 設定画面に並べるタクソノミー（show_uiで、show_uiの投稿タイプに付いているもの）
 *
 * link_categoryのように、管理画面に一覧のないものを外す。
 *
 * @return WP_Taxonomy[] タクソノミー名 => オブジェクト。
 */
function obento_get_taxonomies() {
	$ui_post_types = array_keys( get_post_types( array( 'show_ui' => true ), 'names' ) );
	$taxonomies    = array();
	foreach ( get_taxonomies( array( 'show_ui' => true ), 'objects' ) as $name => $taxonomy ) {
		if ( array_intersect( (array) $taxonomy->object_type, $ui_post_types ) ) {
			$taxonomies[ $name ] = $taxonomy;
		}
	}
	return $taxonomies;
}

/**
 * 設定の既定値（optionが保存されていないあいだに使う）
 *
 * 列幅（resize_post_types / auto_layout_post_types）は、有効にしただけで一覧の見た目が変わらないよう空にする。
 * 選んだらすぐ絞り込む（auto_filter）はオンにする。
 *
 * @return array{filter_taxonomies: string[], order_post_types: string[], order_taxonomies: string[], resize_post_types: string[], auto_layout_post_types: string[], auto_filter: bool}
 */
function obento_get_default_settings() {
	$hierarchical_types = array();
	foreach ( obento_get_post_types() as $name => $type ) {
		if ( $type->hierarchical ) {
			$hierarchical_types[] = $name;
		}
	}
	$taxonomies              = obento_get_taxonomies();
	$hierarchical_taxonomies = array();
	foreach ( $taxonomies as $name => $taxonomy ) {
		if ( $taxonomy->hierarchical ) {
			$hierarchical_taxonomies[] = $name;
		}
	}
	return array(
		'filter_taxonomies'      => $hierarchical_taxonomies,
		'order_post_types'       => $hierarchical_types,
		'order_taxonomies'       => array_keys( $taxonomies ),
		'resize_post_types'      => array(),
		'auto_layout_post_types' => array(),
		'auto_filter'            => true,
	);
}

/**
 * 設定を返す
 *
 * @param string $key filter_taxonomies / order_post_types / order_taxonomies / resize_post_types / auto_layout_post_types。
 * @return string[]
 */
function obento_get_setting( $key ) {
	$settings = get_option( 'obento_settings' );
	if ( ! is_array( $settings ) ) {
		$settings = obento_get_default_settings();
	}
	return isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
}

/**
 * ドロップダウンを選んだらすぐ絞り込むか
 *
 * この設定ができる前に保存したoptionにはキーがないので、そのときもオンとして扱う。
 *
 * @return bool
 */
function obento_is_auto_filter() {
	$settings = get_option( 'obento_settings' );
	if ( ! is_array( $settings ) || ! array_key_exists( 'auto_filter', $settings ) ) {
		return true;
	}
	return (bool) $settings['auto_filter'];
}

/**
 * 絞り込みのドロップダウンを出すタクソノミーか
 *
 * @param string $taxonomy タクソノミー名。
 * @return bool
 */
function obento_is_filter_taxonomy( $taxonomy ) {
	return taxonomy_exists( $taxonomy ) && in_array( $taxonomy, obento_get_setting( 'filter_taxonomies' ), true );
}

/**
 * 並び替えの対象の投稿タイプか
 *
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obento_is_order_post_type( $post_type ) {
	return post_type_exists( $post_type ) && in_array( $post_type, obento_get_setting( 'order_post_types' ), true );
}

/**
 * 並び替えの対象のタクソノミーか
 *
 * @param string $taxonomy タクソノミー名。
 * @return bool
 */
function obento_is_order_taxonomy( $taxonomy ) {
	return taxonomy_exists( $taxonomy ) && in_array( $taxonomy, obento_get_setting( 'order_taxonomies' ), true );
}

/**
 * 名前のリストを、許可された名前だけに絞る
 *
 * 文字列の値だけを残し、許可リストとそのまま突き合わせる。sanitize_key()は通さない
 * （register_taxonomy()は大文字を含む名前もそのまま登録するので、小文字にすると一致しなくなる）。
 * 入れ子の配列などの文字列でない値は、突き合わせる前に捨てる（strval()に渡すと警告が出るため）。
 *
 * @param array    $input   送られてきた設定。
 * @param string   $key     キー。
 * @param string[] $allowed 許可する名前。
 * @return string[] 許可リストの順に並んだ名前。
 */
function obento_sanitize_name_list( $input, $key, $allowed ) {
	if ( empty( $input[ $key ] ) || ! is_array( $input[ $key ] ) ) {
		return array();
	}
	$values = array_filter( $input[ $key ], 'is_string' );
	return array_values( array_intersect( $allowed, $values ) );
}

/**
 * 設定のsanitize。登録済みでshow_uiのものだけを通す
 *
 * @param mixed $input 送られてきた設定。
 * @return array
 */
function obento_sanitize_settings( $input ) {
	$input      = is_array( $input ) ? $input : array();
	$taxonomies = array_keys( obento_get_taxonomies() );
	$post_types = array_keys( obento_get_post_types() );
	return array(
		'filter_taxonomies'      => obento_sanitize_name_list( $input, 'filter_taxonomies', $taxonomies ),
		'order_post_types'       => obento_sanitize_name_list( $input, 'order_post_types', $post_types ),
		'order_taxonomies'       => obento_sanitize_name_list( $input, 'order_taxonomies', $taxonomies ),
		'resize_post_types'      => obento_sanitize_name_list( $input, 'resize_post_types', $post_types ),
		'auto_layout_post_types' => obento_sanitize_name_list( $input, 'auto_layout_post_types', $post_types ),
		'auto_filter'            => ! empty( $input['auto_filter'] ),
	);
}

/**
 * 設定画面をメニューに登録する
 */
function obento_add_settings_page() {
	add_options_page( 'Obento Admin Pack', 'Obento Admin Pack', 'manage_options', 'obento-admin-pack', 'obento_render_settings_page' );
}
add_action( 'admin_menu', 'obento_add_settings_page' );

/**
 * 設定とセクション・フィールドを登録する
 */
function obento_register_settings() {
	register_setting(
		'obento-admin-pack',
		'obento_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_sanitize_settings',
		)
	);

	// 項目名（title）は、チェックボックスの組のlegendにも使うので引数でも渡す
	add_settings_section( 'obento_filters', '一覧の絞り込み', 'obento_render_filters_section', 'obento-admin-pack' );
	$title = 'ドロップダウンを出すタクソノミー';
	add_settings_field(
		'filter_taxonomies',
		$title,
		'obento_render_taxonomy_checkboxes',
		'obento-admin-pack',
		'obento_filters',
		array(
			'key'   => 'filter_taxonomies',
			'title' => $title,
		)
	);
	add_settings_field(
		'auto_filter',
		'選んだらすぐ絞り込む',
		'obento_render_auto_filter_checkbox',
		'obento-admin-pack',
		'obento_filters',
		array( 'label_for' => 'obento-auto-filter' )
	);

	add_settings_section( 'obento_order', '並び替え', 'obento_render_order_section', 'obento-admin-pack' );
	$title = '対象の投稿タイプ';
	add_settings_field(
		'order_post_types',
		$title,
		'obento_render_post_type_checkboxes',
		'obento-admin-pack',
		'obento_order',
		array(
			'key'   => 'order_post_types',
			'title' => $title,
		)
	);
	$title = '対象のタクソノミー';
	add_settings_field(
		'order_taxonomies',
		$title,
		'obento_render_taxonomy_checkboxes',
		'obento-admin-pack',
		'obento_order',
		array(
			'key'   => 'order_taxonomies',
			'title' => $title,
		)
	);

	add_settings_section( 'obento_columns', '列幅', 'obento_render_columns_section', 'obento-admin-pack' );
	$title = 'ドラッグで列幅を変える投稿タイプ';
	add_settings_field(
		'resize_post_types',
		$title,
		'obento_render_post_type_checkboxes',
		'obento-admin-pack',
		'obento_columns',
		array(
			'key'   => 'resize_post_types',
			'title' => $title,
		)
	);
	$title = '列幅を中身に合わせる投稿タイプ';
	add_settings_field(
		'auto_layout_post_types',
		$title,
		'obento_render_post_type_checkboxes',
		'obento-admin-pack',
		'obento_columns',
		array(
			'key'   => 'auto_layout_post_types',
			'title' => $title,
		)
	);
}
add_action( 'admin_init', 'obento_register_settings' );

/**
 * 「一覧の絞り込み」セクションの説明
 */
function obento_render_filters_section() {
	echo '<p>チェックしたタクソノミーのドロップダウンを、投稿一覧の上に出します。カテゴリーはWordPressが出すので、ここには出しません。階層ありの投稿タイプには「親で絞り込み」も出します。</p>';
}

/**
 * 「選んだらすぐ絞り込む」のチェックボックス
 */
function obento_render_auto_filter_checkbox() {
	printf(
		'<input type="checkbox" id="obento-auto-filter" name="obento_settings[auto_filter]" value="1"%s>',
		checked( obento_is_auto_filter(), true, false )
	);
	echo '<p class="description">一覧の上のドロップダウンを選ぶと、「絞り込み」ボタンを押さずに絞り込みます（ボタンは隠します）。WordPressや他のプラグインのドロップダウンにも効きます。キーボードで選んだときは、Enterを押すか、もう一度出るボタンを押すと絞り込みます。</p>';
}

/**
 * 「並び替え」セクションの説明
 */
function obento_render_order_section() {
	echo '<p>チェックした投稿タイプ・タクソノミーの一覧に「並び替えモード」ボタンを出します。並び替えを一度保存すると、表側の並びにも反映されます。</p>';
}

/**
 * 「列幅」セクションの説明
 */
function obento_render_columns_section() {
	echo '<p>「ドラッグで列幅を変える」にチェックした投稿タイプの一覧では、見出しの右端をドラッグして列幅を変えられます。変えた幅はブラウザに保存され、見出しの右端をダブルクリックすると元に戻ります。</p>';
	echo '<p>「列幅を中身に合わせる」にチェックした投稿タイプの一覧は、列幅を固定せず、中身の長さに合わせて広げます（<code>table-layout: auto</code>）。両方にチェックすると、ドラッグで広げられますが、中身より狭くはなりません。</p>';
}

/**
 * チェックボックスの一覧を出す
 *
 * 組の名前（項目名と同じ文言）を、スクリーンリーダー用のlegendで付ける。
 *
 * @param string   $key   設定のキー。
 * @param string[] $names 名前の配列（キー）とラベル（値）。
 * @param string   $title 項目名。
 */
function obento_render_checkboxes( $key, $names, $title ) {
	$current = obento_get_setting( $key );
	echo '<fieldset>';
	printf( '<legend class="screen-reader-text">%s</legend>', esc_html( $title ) );
	foreach ( $names as $name => $label ) {
		printf(
			'<label><input type="checkbox" name="obento_settings[%1$s][]" value="%2$s"%3$s> %4$s <code>%2$s</code></label><br>',
			esc_attr( $key ),
			esc_attr( $name ),
			checked( in_array( $name, $current, true ), true, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
}

/**
 * 投稿タイプのチェックボックス
 *
 * @param array $args add_settings_fieldの引数（key、title）。
 */
function obento_render_post_type_checkboxes( $args ) {
	$names = array();
	foreach ( obento_get_post_types() as $name => $type ) {
		$names[ $name ] = $type->labels->name;
	}
	obento_render_checkboxes( $args['key'], $names, $args['title'] );
}

/**
 * タクソノミーのチェックボックス（絞り込みではcategoryを出さない）
 *
 * @param array $args add_settings_fieldの引数（key、title）。
 */
function obento_render_taxonomy_checkboxes( $args ) {
	$names = array();
	foreach ( obento_get_taxonomies() as $name => $taxonomy ) {
		if ( 'filter_taxonomies' === $args['key'] && 'category' === $name ) {
			continue;
		}
		$names[ $name ] = $taxonomy->labels->name;
	}
	obento_render_checkboxes( $args['key'], $names, $args['title'] );
}

/**
 * 設定画面のタブ（キー => 表示名）。キーがURLのtab
 *
 * @return array<string, string>
 */
function obento_settings_tabs() {
	return array(
		'list'      => '一覧',
		'menu'      => '管理メニュー',
		'dashboard' => 'ダッシュボード',
		'toolbar'   => 'ツールバー',
	);
}

/**
 * 開いているタブ（obento_settings_tabs()のキー。知らない値はlist）
 *
 * @return string
 */
function obento_get_settings_tab() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示するタブを選ぶだけ
	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
	return isset( obento_settings_tabs()[ $tab ] ) ? $tab : 'list';
}

/**
 * 設定画面を描く（タブで「一覧」「管理メニュー」「ダッシュボード」「ツールバー」を分ける）
 *
 * 「設定」メニュー配下なので、保存の通知はコアがsettings_errors()で出す。ここでは呼ばない。
 * タブの切り替えはリンク（PHPで出し分ける。JSで隠さない）。
 */
function obento_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$tab  = obento_get_settings_tab();
	$base = admin_url( 'options-general.php?page=obento-admin-pack' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<nav class="nav-tab-wrapper" aria-label="設定の種類">
			<?php foreach ( obento_settings_tabs() as $key => $label ) : ?>
				<?php $url = 'list' === $key ? $base : add_query_arg( 'tab', $key, $base ); ?>
				<a href="<?php echo esc_url( $url ); ?>" class="nav-tab<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>"<?php echo $key === $tab ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php if ( 'menu' === $tab ) : ?>
			<?php obento_render_menu_tab(); ?>
		<?php elseif ( 'dashboard' === $tab || 'toolbar' === $tab ) : ?>
			<?php obento_render_cleanup_tab( $tab ); ?>
		<?php else : ?>
			<p>ID列は常に表示します。隠すには、一覧の右上の「表示オプション」を使ってください。</p>
			<form action="options.php" method="post">
				<?php
				settings_fields( 'obento-admin-pack' );
				do_settings_sections( 'obento-admin-pack' );
				submit_button();
				?>
			</form>
		<?php endif; ?>
	</div>
	<?php
}
