<?php
/**
 * 「管理メニュー」タブ（設定 > Obento Admin Pack）
 *
 * option obento_menuの登録とsanitize、表の描画。表はPHPが描き、JS（assets/menu.js）はドラッグ・名前の編集・
 * チェックの連動・送信前のJSON化だけを持つ。表の行に必要な値（slug、親のslug、元の名前、保存された設定）は、
 * 行のデータ属性とチェックの状態としてHTMLに持たせる。
 *
 * 保存はSettings API。表全体をhidden欄（obento_menu）1つのJSONで送る。行ごとに変数を分けると、
 * PHPのmax_input_vars（既定1000）を超えた分が黙って捨てられるため。
 * option groupはobento_menu（「一覧」タブのobento_settingsとは別）。片方の保存でもう片方を消さない。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_menu_setting() {
	register_setting(
		'obento_menu',
		'obento_menu',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_sanitize_menu_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_menu_setting' );

/**
 * 設定のエラーを登録する
 *
 * - settings_errors()は文言をエスケープせずに出すので、ここでesc_html()する
 * - optionがまだないときの初回の保存では、update_option()からadd_option()へ進んでsanitizeが2回走る。同じコードは1回だけ登録する
 * - WP-CLIなどからのupdate_option()ではadd_settings_error()が読み込まれていなくて、通知を出せない。黙って捨てず、error_logへ1行残す
 *
 * @param string $code    エラーコード。
 * @param string $message 文言。
 */
function obento_menu_add_settings_error( $code, $message ) {
	if ( ! function_exists( 'add_settings_error' ) ) {
		error_log( sprintf( 'Obento Admin Pack: %s（%s）', $message, $code ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 通知を出せない文脈（WP-CLIなど）で、設定を保存できなかったことを黙って捨てないため
		return;
	}
	if ( in_array( $code, wp_list_pluck( get_settings_errors( 'obento_menu' ), 'code' ), true ) ) {
		return;
	}
	add_settings_error( 'obento_menu', $code, esc_html( $message ) );
}

/**
 * sanitize
 *
 * 画面からはJSON文字列1つで届く。update_option()に配列を渡したとき（初回の保存の2回目、WP-CLI、検証）は配列のまま受ける。
 * 読めない送信（JSONでない、空、配列でない、形が壊れている）は前の値を返し、エラーを登録する。
 * {"reset":true}は空の配列（設定なし）にする。optionの削除はしない（Settings APIの経路で消すと、options.phpがあとから空の値で作り直すため）。
 * 知らないロール（wp_rolesにない）と、鍵の項目への非表示を落とす。名前はobento_menu_normalize()がタグを除いて空を落とす。
 *
 * @param mixed $input 送られてきた値。
 * @return array
 */
function obento_sanitize_menu_settings( $input ) {
	$previous = get_option( 'obento_menu', array() );
	$previous = is_array( $previous ) ? $previous : array();

	if ( is_string( $input ) ) {
		$data = '' === trim( $input ) ? null : json_decode( $input, true );
	} else {
		$data = $input;
	}
	if ( ! is_array( $data ) ) {
		obento_menu_add_settings_error( 'obento_menu_invalid', '設定を保存できませんでした。ページを読み込み直して、もう一度お試しください。' );
		return $previous;
	}
	if ( ! empty( $data['reset'] ) ) {
		return array();
	}

	$read = obento_menu_normalize( $data );
	if ( $read['broken'] ) {
		obento_menu_add_settings_error( 'obento_menu_invalid', '設定を保存できませんでした。ページを読み込み直して、もう一度お試しください。' );
		return $previous;
	}
	$settings = $read['settings'];
	$roles    = obento_menu_role_slugs();
	$hidden   = array();
	foreach ( $settings['hidden'] as $role => $entry ) {
		if ( ! in_array( $role, $roles, true ) ) {
			continue;
		}
		$top = array_values(
			array_filter(
				$entry['top'],
				function ( $slug ) {
					return ! obento_menu_is_locked( $slug );
				}
			)
		);
		$sub = array();
		foreach ( $entry['sub'] as $parent => $slugs ) {
			$slugs = array_values(
				array_filter(
					$slugs,
					function ( $slug ) use ( $parent ) {
						return ! obento_menu_is_locked( $slug, $parent );
					}
				)
			);
			if ( $slugs ) {
				$sub[ $parent ] = $slugs;
			}
		}
		if ( $top || $sub ) {
			$hidden[ $role ] = array(
				'top' => $top,
				'sub' => $sub,
			);
		}
	}
	$settings['hidden'] = $hidden;
	return $settings;
}

/**
 * 表の行を、写し取ったメニューと設定から作る
 *
 * - トップは、開いている管理者がトップ自身の権限を持つか、開けるサブが1つでもあるときだけ出す。
 *   コアは、権限のないトップを、開けるサブがないときだけ消す（あるときは、サブの最初へのリンクとして出す）。サブは権限のあるものだけ出す
 * - サブが1つだけで親と同じslugなら、サブなしとして扱う（コアが描画の前に消すのと同じ）
 * - 並びは、保存した並びに新しい項目を差し込んだもの（いまの効き方と同じ）。トップはコアの並び（キーの自然順）を元にする
 *
 * @param array $snapshot obento_menu_snapshot()の値。
 * @param array $settings obento_get_menu_settings()の値。
 * @return array[] 各行: slug, parent（トップは空）, title（元の名前の文字の部分。区切り線は空）, cap, separator, subs（同じ形の配列）。
 */
function obento_menu_build_rows( $snapshot, $settings ) {
	$menu    = $snapshot['menu'];
	$submenu = $snapshot['submenu'];
	uksort( $menu, 'strnatcasecmp' );
	$by_slug     = array();
	$sub_by_slug = array();
	$sub_current = array();
	$current     = array();
	foreach ( $menu as $item ) {
		$slug = (string) $item[2];
		if ( isset( $by_slug[ $slug ] ) ) {
			continue;
		}
		$subs = isset( $submenu[ $slug ] ) ? array_values( (array) $submenu[ $slug ] ) : array();
		if ( 1 === count( $subs ) && (string) $subs[0][2] === $slug ) {
			$subs = array();
		}
		$found   = array();
		$ordered = array();
		foreach ( $subs as $sub ) {
			$sub_slug = (string) $sub[2];
			if ( isset( $found[ $sub_slug ] ) || ! current_user_can( $sub[1] ) ) {
				continue;
			}
			$found[ $sub_slug ] = $sub;
			$ordered[]          = $sub_slug;
		}
		if ( ! $ordered && ! current_user_can( $item[1] ) ) {
			continue;
		}
		$by_slug[ $slug ]     = $item;
		$sub_by_slug[ $slug ] = $found;
		$sub_current[ $slug ] = $ordered;
		$current[]            = $slug;
	}
	$rows = array();
	foreach ( obento_menu_merge_order( $settings['order'], $current ) as $slug ) {
		$item      = $by_slug[ $slug ];
		$sub_rows  = array();
		$saved_sub = isset( $settings['sub_order'][ $slug ] ) ? $settings['sub_order'][ $slug ] : array();
		foreach ( obento_menu_merge_order( $saved_sub, $sub_current[ $slug ] ) as $sub_slug ) {
			$sub        = $sub_by_slug[ $slug ][ $sub_slug ];
			$sub_rows[] = array(
				'slug'      => $sub_slug,
				'parent'    => $slug,
				'title'     => obento_menu_label_text( $sub[0] ),
				'cap'       => (string) $sub[1],
				'separator' => false,
				'subs'      => array(),
			);
		}
		$rows[] = array(
			'slug'      => $slug,
			'parent'    => '',
			'title'     => obento_menu_label_text( $item[0] ),
			'cap'       => (string) $item[1],
			'separator' => obento_menu_is_separator( $item ),
			'subs'      => $sub_rows,
		);
	}
	return $rows;
}

/**
 * 「管理メニュー」タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。ここで出すのは、保存されている設定が壊れているときの通知だけ。
 * JSが動くまで保存のボタンはdisabledにし、hidden欄にはいまの設定を入れておく（JSなしで送られても、いまの設定が保存されるだけで壊れない）。
 */
function obento_render_menu_tab() {
	if ( obento_menu_settings_broken() ) {
		wp_admin_notice( esc_html( '保存されている設定が読めません。「初期状態に戻す」で消してください。' ), array( 'type' => 'error' ) );
	}
	$snapshot = obento_menu_snapshot();
	if ( ! $snapshot ) {
		wp_admin_notice( esc_html( 'メニューを読み取れませんでした。ページを読み込み直してください。' ), array( 'type' => 'error' ) );
		return;
	}
	$settings = obento_get_menu_settings();
	$roles    = wp_roles()->get_names();
	$rows     = obento_menu_build_rows( $snapshot, $settings );
	?>
	<p>メニューから隠すだけです。URLを直接開けば表示されます。閲覧を制限するには、ロールの権限を変えてください。</p>
	<p>☰をドラッグして並べ替え、名前をクリックして変更、チェックを外してそのロールから隠します。並び順と名前はすべてのロールで共通です。サブメニューは同じ親の中だけで動きます。</p>
	<form action="options.php" method="post" id="obento-menu-form">
		<?php settings_fields( 'obento_menu' ); ?>
		<input type="hidden" name="obento_menu" id="obento-menu-json" value="<?php echo esc_attr( wp_json_encode( $settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?>">
		<div class="notice notice-warning inline obento-menu-nojs"><p>JavaScriptが動いていないため編集できません。</p></div>
		<div class="obento-menu-table" style="--obento-menu-roles: <?php echo (int) count( $roles ); ?>">
			<div class="obento-menu-head">
				<span></span><span></span><span>メニュー</span>
				<?php foreach ( $roles as $name ) : ?>
					<span class="obento-menu-role"><?php echo esc_html( translate_user_role( $name ) ); ?></span>
				<?php endforeach; ?>
			</div>
			<ul class="obento-menu-list" id="obento-menu-list">
				<?php
				foreach ( $rows as $row ) {
					obento_render_menu_row( $row, $roles, $settings );
				}
				?>
			</ul>
		</div>
		<p class="submit">
			<button type="submit" class="button button-primary" id="obento-menu-save" disabled>変更を保存</button>
			<button type="submit" class="button" id="obento-menu-reset" disabled>初期状態に戻す</button>
		</p>
	</form>
	<?php
}

/**
 * 1行（トップならサブの行も）を描く
 *
 * 行の<li>と中の<div class="obento-menu-row">は1行に出す（検証がgrepで1行ずつ見るため）。サブの<ul>は次の行から。
 *
 * @param array $row      obento_menu_build_rows()の1行。
 * @param array $roles    wp_roles()->get_names()。
 * @param array $settings obento_get_menu_settings()の値。
 */
function obento_render_menu_row( $row, $roles, $settings ) {
	$is_sub = '' !== $row['parent'];
	$labels = $settings['labels']['top'];
	if ( $is_sub ) {
		$labels = isset( $settings['labels']['sub'][ $row['parent'] ] ) ? $settings['labels']['sub'][ $row['parent'] ] : array();
	}
	$label    = isset( $labels[ $row['slug'] ] ) ? $labels[ $row['slug'] ] : '';
	$editable = ! $row['separator'] && '' !== $row['title'];
	$classes  = 'obento-menu-item ' . ( $is_sub ? 'obento-menu-sub' : 'obento-menu-top' ) . ( $row['separator'] ? ' obento-menu-separator' : '' );

	printf(
		'<li class="%1$s" data-slug="%2$s" data-parent="%3$s" data-label="%4$s"><div class="obento-menu-row">',
		esc_attr( $classes ),
		esc_attr( $row['slug'] ),
		esc_attr( $row['parent'] ),
		esc_attr( $row['title'] )
	);
	echo '<span class="obento-menu-grip" aria-hidden="true">&#x2630;</span>';
	if ( $row['subs'] ) {
		printf(
			'<button type="button" class="obento-menu-toggle" aria-expanded="false" aria-label="%sのサブメニューを開閉"><span class="dashicons dashicons-arrow-right" aria-hidden="true"></span></button>',
			esc_attr( '' !== $row['title'] ? $row['title'] : $row['slug'] )
		);
	} else {
		echo '<span></span>';
	}
	echo '<span class="obento-menu-name-cell">';
	if ( $row['separator'] ) {
		echo '<span class="obento-menu-name-static">区切り線</span>';
	} elseif ( ! $editable ) {
		echo '<span class="obento-menu-name-static">（名前のないメニュー）</span>';
	} else {
		printf(
			'<button type="button" class="obento-menu-name" title="クリックして名前を変更">%s</button><span class="obento-menu-origin"%s>元: %s</span>',
			esc_html( '' !== $label ? $label : $row['title'] ),
			'' === $label ? ' hidden' : '',
			esc_html( $row['title'] )
		);
	}
	if ( $row['subs'] ) {
		echo '<span class="obento-menu-partial" hidden>一部非表示</span>';
	}
	echo '</span>';
	foreach ( $roles as $role => $name ) {
		obento_render_menu_cell( $row, $role, translate_user_role( $name ), $settings );
	}
	echo '</div>';
	if ( $row['subs'] ) {
		echo "\n" . '<ul class="obento-menu-sublist" hidden>' . "\n";
		foreach ( $row['subs'] as $sub ) {
			obento_render_menu_row( $sub, $roles, $settings );
		}
		echo '</ul>';
	}
	echo '</li>' . "\n";
}

/**
 * ロールがメニューの権限を持つか（そのロールの人にメニューが元から出るか）
 *
 * 次のどれかなら真にする（上から順に見る）。
 * 1. 権限がロールの名前そのもの。古いプラグインはadd_menu_page()にadministratorのようなロール名を渡す。
 *    WP_Userはロール名を権限の一覧（allcaps）に混ぜるのでcurrent_user_can( 'administrator' )は通るが、WP_Role::has_cap()は通さない
 * 2. ロールがその権限を直接持つ。map_meta_cap()より先に見るのは、edit_usersのように、利用者のIDが0だとdo_not_allowに読み替える権限があり、
 *    読み替えに頼ると、その権限を持つ管理者にまで「—」が出るため
 * 3. map_meta_cap()で基本の権限に読み替えて、ロールがそのすべてを持つ。読み替えないと、「プライバシー」のmanage_privacy_optionsや
 *    「カスタマイズ」のcustomize、Contact Form 7のwpcf7_read_contact_formsのような権限で、管理者にまで「—」が出る。
 *    existはWordPressがすべての利用者に与えるので、ロールになくても持つものとして扱う
 *
 * user_has_capフィルターで利用者ごとに足される権限は反映されない（ロールしか見ないため）。
 *
 * @param WP_Role $role_object ロール。
 * @param string  $capability  メニューに登録された権限。
 * @return bool
 */
function obento_menu_role_can( $role_object, $capability ) {
	if ( $capability === $role_object->name || $role_object->has_cap( $capability ) ) {
		return true;
	}
	foreach ( map_meta_cap( $capability, 0 ) as $cap ) {
		if ( 'exist' !== $cap && ! $role_object->has_cap( $cap ) ) {
			return false;
		}
	}
	return true;
}

/**
 * 行が、そのロールの人にメニューとして元から出るか
 *
 * サブの行は、自分の権限だけで決める。トップの行は、自分の権限か、サブのどれか1つの権限があれば出る。
 * コアは、権限のないトップを、開けるサブがないときだけ消し、あるときはサブの最初へのリンクとして出すため
 * （たとえば、トップの権限がmanage_optionsでサブがedit_postsのメニューは、編集者にも出る）。
 *
 * 例外は「ユーザー」（users.php）。コアのmenu.phpは、list_usersのないロールには「ユーザー」を作らず、トップの「プロフィール」（profile.php）を作る。
 * 「ユーザー」の下の「プロフィール」（read）は、そのロールが「ユーザー」を見る根拠にならないので、自分の権限だけで決める。
 *
 * @param array   $row         行（obento_menu_build_rows()の1行）。
 * @param WP_Role $role_object ロール。
 * @return bool
 */
function obento_menu_row_visible_for_role( $row, $role_object ) {
	if ( obento_menu_role_can( $role_object, $row['cap'] ) ) {
		return true;
	}
	if ( 'users.php' === $row['slug'] && '' === $row['parent'] ) {
		return false;
	}
	foreach ( $row['subs'] as $sub ) {
		if ( obento_menu_role_can( $role_object, $sub['cap'] ) ) {
			return true;
		}
	}
	return false;
}

/**
 * ロールの欄を1つ描く
 *
 * - 区切り線: 空
 * - ロールにメニューの権限がない: 「—」（元から出ないので操作できない）。判定はobento_menu_row_visible_for_role()
 * - 鍵の項目で、ロールがmanage_optionsを持つ: 鍵（隠せない）
 * - それ以外: チェック（オンが表示）
 *
 * @param array  $row       行。
 * @param string $role      ロールのslug。
 * @param string $role_name ロールの表示名。
 * @param array  $settings  obento_get_menu_settings()の値。
 */
function obento_render_menu_cell( $row, $role, $role_name, $settings ) {
	if ( $row['separator'] ) {
		echo '<span class="obento-menu-cell"></span>';
		return;
	}
	$role_object = get_role( $role );
	if ( ! $role_object || ! obento_menu_row_visible_for_role( $row, $role_object ) ) {
		printf(
			'<span class="obento-menu-cell obento-menu-na" title="%1$sには元から出ません">&mdash;<span class="screen-reader-text">%1$sには元から出ません</span></span>',
			esc_attr( $role_name )
		);
		return;
	}
	if ( obento_menu_is_locked( $row['slug'], $row['parent'] ) && $role_object->has_cap( 'manage_options' ) ) {
		printf(
			'<span class="obento-menu-cell obento-menu-lock" title="%1$s"><span class="dashicons dashicons-lock" aria-hidden="true"></span><span class="screen-reader-text">%1$s</span></span>',
			esc_attr( 'このプラグインの設定があるため隠せません' )
		);
		return;
	}
	$hidden = isset( $settings['hidden'][ $role ] ) ? $settings['hidden'][ $role ] : array(
		'top' => array(),
		'sub' => array(),
	);
	if ( '' === $row['parent'] ) {
		$is_hidden = in_array( $row['slug'], $hidden['top'], true );
	} else {
		$is_hidden = isset( $hidden['sub'][ $row['parent'] ] ) && in_array( $row['slug'], $hidden['sub'][ $row['parent'] ], true );
	}
	printf(
		'<span class="obento-menu-cell"><input type="checkbox" class="obento-menu-show" data-role="%1$s" aria-label="%2$sに表示: %3$s"%4$s></span>',
		esc_attr( $role ),
		esc_attr( $role_name ),
		esc_attr( '' !== $row['title'] ? $row['title'] : $row['slug'] ),
		checked( ! $is_hidden, true, false )
	);
}

/**
 * 「管理メニュー」タブにスクリプトとスタイルを読み込む
 *
 * @param string $hook 管理画面のページ（add_options_page()の戻り。settings_page_obento-admin-pack）。
 */
function obento_menu_enqueue( $hook ) {
	if ( 'settings_page_obento-admin-pack' !== $hook || 'menu' !== obento_get_settings_tab() ) {
		return;
	}
	wp_enqueue_style( 'obento-menu', OBENTO_URL . 'assets/menu.css', array(), OBENTO_VERSION );
	wp_enqueue_script( 'obento-menu', OBENTO_URL . 'assets/menu.js', array( 'jquery', 'jquery-ui-sortable' ), OBENTO_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'obento_menu_enqueue' );
