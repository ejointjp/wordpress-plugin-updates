<?php
/**
 * 投稿一覧の列幅
 *
 * 設定のresize_post_typesにある投稿タイプの一覧では、見出しの右端のドラッグで列幅を変えられるようにする（assets/column-width.js）。
 * 幅は利用者のブラウザ（localStorage）に、投稿タイプと列のキーごとに持つ。サーバーには保存しない。
 * 設定のauto_layout_post_typesにある投稿タイプの一覧は、コアの固定の列幅（.fixedのtable-layout: fixed）をやめ、中身に合わせる。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 開いている投稿一覧の投稿タイプ（投稿一覧でなければ空）
 *
 * @return string
 */
function obento_column_width_post_type() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'edit' !== $screen->base || ! $screen->post_type ) {
		return '';
	}
	return $screen->post_type;
}

/**
 * 投稿タイプが、列幅の設定のどちらかに入っているか
 *
 * @param string $key       resize_post_types / auto_layout_post_types。
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obento_is_column_width_post_type( $key, $post_type ) {
	return '' !== $post_type && post_type_exists( $post_type ) && in_array( $post_type, obento_get_setting( $key ), true );
}

/**
 * 対象の投稿一覧に、列幅のスクリプトとスタイルを読み込む
 *
 * @param string $hook 管理画面のページ。
 */
function obento_column_width_enqueue( $hook ) {
	if ( 'edit.php' !== $hook ) {
		return;
	}
	$post_type = obento_column_width_post_type();
	$resize    = obento_is_column_width_post_type( 'resize_post_types', $post_type );
	$auto      = obento_is_column_width_post_type( 'auto_layout_post_types', $post_type );
	if ( ! $resize && ! $auto ) {
		return;
	}
	wp_enqueue_style( 'obento-column-width', OBENTO_URL . 'assets/column-width.css', array(), OBENTO_VERSION );
	if ( ! $resize ) {
		return;
	}
	wp_enqueue_script( 'obento-column-width', OBENTO_URL . 'assets/column-width.js', array(), OBENTO_VERSION, true );
	$data = array( 'storeKey' => 'obento_column_widths_' . $post_type );
	wp_add_inline_script( 'obento-column-width', 'var obentoColumnWidth = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', 'obento_column_width_enqueue' );

/**
 * 列幅を中身に合わせる一覧の目印をbodyに付ける（CSSが表示の最初から効くように）
 *
 * @param string $classes bodyのクラス（空白区切り）。
 * @return string
 */
function obento_column_width_body_class( $classes ) {
	if ( obento_is_column_width_post_type( 'auto_layout_post_types', obento_column_width_post_type() ) ) {
		$classes .= ' obento-auto-layout';
	}
	return $classes;
}
add_filter( 'admin_body_class', 'obento_column_width_body_class' );
