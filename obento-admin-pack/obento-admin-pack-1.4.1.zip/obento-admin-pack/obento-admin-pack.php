<?php
/**
 * Plugin Name:       Obento Admin Pack
 * Description:       管理画面の一覧にID列・絞り込み・ドラッグ＆ドロップの並び替え・列幅の変更を足し、左の管理メニュー・ダッシュボードのウィジェット・ツールバーをロール別に片付けられ、リビジョンの上限と削除を管理でき、公開前の投稿をログインなしで見せる有効期限付きのリンクを作れ、外部リンクに新しいタブで開く属性や印を足せ、コメントを丸ごと止めたり自分のサイトへのピンバックを送らないようにしたりでき、ユーザーのアバターをメディアライブラリの画像にでき、サイトをメンテナンス中にでき、SVGを選んだロールにだけ安全な形で上げさせられる、小さな便利機能の詰め合わせ。
 * Version:           1.4.1
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * Update URI:        https://yuiami.jp/wp-plugins/obento-admin-pack
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       obento-admin-pack
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OBENTO_VERSION', '1.4.1' );
define( 'OBENTO_FILE', __FILE__ );
define( 'OBENTO_DIR', plugin_dir_path( __FILE__ ) );
define( 'OBENTO_URL', plugin_dir_url( __FILE__ ) );

// 自己ホストの更新チェック。定期の更新チェックはwp-cronで動くので、is_admin()の中に入れない。
require_once OBENTO_DIR . 'includes/update-checker.php';
require_once OBENTO_DIR . 'includes/settings.php';
require_once OBENTO_DIR . 'includes/id-column.php';
require_once OBENTO_DIR . 'includes/list-filters.php';
require_once OBENTO_DIR . 'includes/auto-filter.php';
require_once OBENTO_DIR . 'includes/column-width.php';
require_once OBENTO_DIR . 'includes/order-common.php';
require_once OBENTO_DIR . 'includes/order-posts.php';
require_once OBENTO_DIR . 'includes/order-terms.php';
require_once OBENTO_DIR . 'includes/menu-common.php';
require_once OBENTO_DIR . 'includes/menu-apply.php';
require_once OBENTO_DIR . 'includes/menu-screen.php';
require_once OBENTO_DIR . 'includes/cleanup-common.php';
require_once OBENTO_DIR . 'includes/cleanup-dashboard.php';
require_once OBENTO_DIR . 'includes/cleanup-toolbar.php';
require_once OBENTO_DIR . 'includes/cleanup-screen.php';
require_once OBENTO_DIR . 'includes/revisions-common.php';
require_once OBENTO_DIR . 'includes/revisions-screen.php';
require_once OBENTO_DIR . 'includes/revisions-list.php';
require_once OBENTO_DIR . 'includes/preview-common.php';
require_once OBENTO_DIR . 'includes/preview-front.php';
require_once OBENTO_DIR . 'includes/preview-screen.php';
require_once OBENTO_DIR . 'includes/preview-editor.php';
require_once OBENTO_DIR . 'includes/preview-list.php';
require_once OBENTO_DIR . 'includes/external-links-common.php';
require_once OBENTO_DIR . 'includes/external-links-front.php';
require_once OBENTO_DIR . 'includes/external-links-screen.php';
require_once OBENTO_DIR . 'includes/comments-common.php';
require_once OBENTO_DIR . 'includes/comments-apply.php';
require_once OBENTO_DIR . 'includes/comments-screen.php';
require_once OBENTO_DIR . 'includes/avatars-common.php';
require_once OBENTO_DIR . 'includes/avatars-apply.php';
require_once OBENTO_DIR . 'includes/avatars-profile.php';
require_once OBENTO_DIR . 'includes/avatars-screen.php';
require_once OBENTO_DIR . 'includes/avatars-migrate.php';
require_once OBENTO_DIR . 'includes/maintenance-common.php';
require_once OBENTO_DIR . 'includes/maintenance-apply.php';
require_once OBENTO_DIR . 'includes/maintenance-screen.php';
require_once OBENTO_DIR . 'includes/svg-common.php';
require_once OBENTO_DIR . 'includes/svg-apply.php';
require_once OBENTO_DIR . 'includes/svg-screen.php';

// アバターの既定の目印（avatar_default）を、停止したときに戻す
register_deactivation_hook( OBENTO_FILE, 'obento_avatars_deactivate' );
