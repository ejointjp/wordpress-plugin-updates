<?php
/**
 * アバターの共通部分（純粋な関数）
 *
 * 設定（option obento_avatars）とユーザーのアバター（ユーザーメタ<サイトの接頭辞>obento_avatar）の読み出し、画像の判定とURL、
 * 権限の判定、get_avatar()に渡されたものからのユーザーの割り出し。フックは持たない。
 * 表示のフックはincludes/avatars-apply.php、プロフィール画面はincludes/avatars-profile.php、
 * 「アバター」タブとディスカッションの欄はincludes/avatars-screen.php、WP User Avatarsからの引き継ぎはincludes/avatars-migrate.phpが持つ。
 *
 * 画像はメディアライブラリの添付ファイルだけ。サイズ違いはコアの中間サイズを使い、自前でリサイズしない。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 既定アバターの目印（コアのavatar_defaultに入れる値。表示のときに画像のURLに置き換える）
 *
 * @return string
 */
function obento_avatars_default_sentinel() {
	return 'obento_avatar';
}

/**
 * 切り抜いた画像の一辺の最大（px。assets/avatars.jsのMAXと同じ）
 *
 * @return int
 */
function obento_avatars_max_size() {
	return 512;
}

/**
 * 設定を返す（optionがない・壊れている・キーがないときは、default_idが0）
 *
 * @return array{default_id: int}
 */
function obento_avatars_get_settings() {
	$option = get_option( 'obento_avatars', array() );
	$option = is_array( $option ) ? $option : array();
	return array(
		'default_id' => isset( $option['default_id'] ) ? absint( $option['default_id'] ) : 0,
	);
}

/**
 * ユーザーのアバターのユーザーメタのキー（サイトの接頭辞付き。マルチサイトではサイトごと）
 *
 * @return string
 */
function obento_avatars_user_meta_key() {
	global $wpdb;
	return $wpdb->get_blog_prefix() . 'obento_avatar';
}

/**
 * ユーザーのアバターの添付ファイルのID（なければ0）
 *
 * get_user_option()は、サイトの接頭辞付きのキーがないと接頭辞なしのキーも見るので使わない。
 *
 * @param int $user_id ユーザー。
 * @return int
 */
function obento_avatars_get_user_avatar_id( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return 0;
	}
	return absint( get_user_meta( $user_id, obento_avatars_user_meta_key(), true ) );
}

/**
 * 画像の添付ファイルで、幅と高さが同じか
 *
 * @param int $attachment_id 添付ファイル。
 * @return bool
 */
function obento_avatars_is_square_image( $attachment_id ) {
	$attachment_id = absint( $attachment_id );
	if ( ! $attachment_id || ! wp_attachment_is_image( $attachment_id ) ) {
		return false;
	}
	$meta = wp_get_attachment_metadata( $attachment_id );
	return is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) && (int) $meta['width'] === (int) $meta['height'];
}

/**
 * 要求の大きさに合う画像のURL（コアの中間サイズから選ぶ。合うものがなければ原寸）
 *
 * @param int $attachment_id 添付ファイル。
 * @param int $size          要求の一辺（px）。
 * @return string 取れなければ空文字。
 */
function obento_avatars_image_url( $attachment_id, $size ) {
	$size = max( 1, (int) $size );
	$src  = wp_get_attachment_image_src( (int) $attachment_id, array( $size, $size ) );
	if ( is_array( $src ) && ! empty( $src[0] ) ) {
		return $src[0];
	}
	$url = wp_get_attachment_url( (int) $attachment_id );
	return is_string( $url ) ? $url : '';
}

/**
 * ユーザーのアバターのURL
 *
 * @param int $user_id ユーザー。
 * @param int $size    要求の一辺（px）。
 * @return string アバターがない・画像でなければ空文字。
 */
function obento_avatars_user_avatar_url( $user_id, $size ) {
	$id = obento_avatars_get_user_avatar_id( $user_id );
	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return '';
	}
	return obento_avatars_image_url( $id, $size );
}

/**
 * 既定アバターに使える画像の形式（MIMEタイプ）
 *
 * GravatarのURLのd=は、拡張子がjpg・jpeg・gif・png・heicの公開URLだけを受け付ける。WebPやAVIFを指定すると、Gravatarの
 * 標準の画像が出る。heicはコアがアップロード時にJPEGへ変換するので、ここには入れない。個人のアバターはGravatarを通さないので、
 * どの形式でもよい。assets/avatars.jsには、既定アバターの欄のdata-typesで渡す。
 *
 * @return string[]
 */
function obento_avatars_default_mime_types() {
	return array( 'image/jpeg', 'image/png', 'image/gif' );
}

/**
 * 既定アバターに使える形式の添付ファイルか（JPEG・PNG・GIF）
 *
 * @param int $attachment_id 添付ファイル。
 * @return bool
 */
function obento_avatars_is_default_format( $attachment_id ) {
	$attachment_id = absint( $attachment_id );
	return $attachment_id > 0 && in_array( get_post_mime_type( $attachment_id ), obento_avatars_default_mime_types(), true );
}

/**
 * 既定アバターの画像（default_idが正方形で、JPEG・PNG・GIFの画像ならそのID、そうでなければ0）
 *
 * 選んだあとに画像が消されたり差し替えられたりするので、使うたびに確かめる。
 *
 * @return int
 */
function obento_avatars_default_image_id() {
	$id = obento_avatars_get_settings()['default_id'];
	return obento_avatars_is_square_image( $id ) && obento_avatars_is_default_format( $id ) ? $id : 0;
}

/**
 * いまのユーザーが、そのユーザーのアバターを設定できるか（対象へのedit_userと、upload_files）
 *
 * @param int $user_id 対象のユーザー。
 * @return bool
 */
function obento_avatars_can_edit( $user_id ) {
	$user_id = (int) $user_id;
	return $user_id > 0 && current_user_can( 'edit_user', $user_id ) && current_user_can( 'upload_files' );
}

/**
 * いまのユーザーが、その画像をアバターに使えるか（正方形の画像で、edit_postできる）
 *
 * コアの切り抜き（wp_ajax_crop_image()）も元の画像にedit_postを求めるので、それに揃える。
 *
 * @param int $attachment_id 添付ファイル。
 * @return bool
 */
function obento_avatars_can_use_image( $attachment_id ) {
	return obento_avatars_is_square_image( $attachment_id ) && current_user_can( 'edit_post', (int) $attachment_id );
}

/**
 * get_avatar()に渡されたものから、ユーザーIDを割り出す（なければ0）
 *
 * 数値はそのID、WP_UserはそのID、WP_Postは投稿者、WP_Commentはuser_id（未登録の人は0。コアがアバターを出さない種類
 * （ピンバックなど）も0）、文字列はメールアドレスとして探す（Gravatarのハッシュのアドレス（<md5>@md5.gravatar.com、
 * <sha256>@sha256.gravatar.com）は0）。
 *
 * comment_IDを持つオブジェクトは、コアのget_avatar_data()と同じくget_comment()でWP_Commentにしてから見る
 * （コアがそうするのはpre_get_avatar_dataの後なので、テーマやウィジェットが$wpdbの行（stdClass）をそのまま渡すと、
 * ここでは登録ユーザーのコメントと分からない）。
 *
 * メールアドレスの結果は、リクエストのあいだ覚える（見つからなかったときはコアがキャッシュしないので、get_avatar()1回で
 * 1x・2xの2回、ゲストのコメントの多いページでは何度もクエリが走る）。
 *
 * @param mixed $id_or_email get_avatar()の第1引数。
 * @return int
 */
function obento_avatars_resolve_user_id( $id_or_email ) {
	static $emails = array();
	if ( is_object( $id_or_email ) && isset( $id_or_email->comment_ID ) ) {
		$id_or_email = get_comment( $id_or_email );
		if ( ! $id_or_email instanceof WP_Comment ) {
			return 0;
		}
	}
	if ( is_numeric( $id_or_email ) ) {
		return max( 0, (int) $id_or_email );
	}
	if ( $id_or_email instanceof WP_User ) {
		return (int) $id_or_email->ID;
	}
	if ( $id_or_email instanceof WP_Post ) {
		return (int) $id_or_email->post_author;
	}
	if ( $id_or_email instanceof WP_Comment ) {
		if ( ! is_avatar_comment_type( get_comment_type( $id_or_email ) ) ) {
			return 0;
		}
		return (int) $id_or_email->user_id;
	}
	if ( is_string( $id_or_email ) && '' !== $id_or_email && ! preg_match( '/@(md5|sha256)\.gravatar\.com$/', $id_or_email ) ) {
		if ( ! isset( $emails[ $id_or_email ] ) ) {
			$user                   = get_user_by( 'email', $id_or_email );
			$emails[ $id_or_email ] = $user ? (int) $user->ID : 0;
		}
		return $emails[ $id_or_email ];
	}
	return 0;
}
