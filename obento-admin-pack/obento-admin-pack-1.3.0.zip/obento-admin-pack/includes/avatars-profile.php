<?php
/**
 * アバター: プロフィール画面（「プロフィール写真」の行）
 *
 * コアのプロフィール画面（profile.php / user-edit.php）の「プロフィール写真」の行の説明（user_profile_picture_description）に、
 * 「画像を選ぶ」「削除」のボタンとhiddenの欄を足し、「プロフィールを更新」で保存する。選ぶ・切り抜く・プレビューはassets/avatars.js。
 * コアは「アバターを表示」がオフのときこの行を出さないので、そのときは欄も出ない。
 * 設定できるのは、対象のユーザーへのedit_userとupload_filesを持つ人（obento_avatars_can_edit()）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 画像を選ぶ欄のスクリプトを読み込む（プロフィール、「アバター」タブ、ディスカッションで共用）
 *
 * wp_enqueue_media()は、管理画面では切り抜きに要るimgareaselectも読み込む。欄のエラーの文字（.obento-avatar-error）は、
 * 説明の灰色のままだと目立たないので、コアのエラーの赤にする（CSSのファイルは足さず、コアの管理画面のCSSに足す）。
 */
function obento_avatars_enqueue_picker() {
	wp_enqueue_media();
	wp_enqueue_script( 'obento-avatars', OBENTO_URL . 'assets/avatars.js', array( 'jquery', 'media-views' ), OBENTO_VERSION, true );
	wp_add_inline_style( 'common', '.obento-avatar-error{color:#d63638}' );
}

/**
 * プロフィール画面にスクリプトを読み込む（設定できる人が開いたときだけ）
 *
 * @param string $hook 管理画面のページ。
 */
function obento_avatars_profile_enqueue( $hook ) {
	if ( 'profile.php' !== $hook && 'user-edit.php' !== $hook ) {
		return;
	}
	if ( ! get_option( 'show_avatars' ) ) {
		return;
	}
	if ( 'profile.php' === $hook ) {
		$user_id = get_current_user_id();
	} else {
		// $_REQUESTにするのは、コアのuser-edit.php（16行目）と同じ。保存でedit_user()がエラーを返したときは、クエリのないPOSTのまま画面を描き直す。
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 開いている画面のユーザーを見るだけ（保存はコアのuser-edit.phpがnonceを確かめたあと）
		$user_id = isset( $_REQUEST['user_id'] ) ? absint( $_REQUEST['user_id'] ) : 0;
	}
	if ( obento_avatars_can_edit( $user_id ) ) {
		obento_avatars_enqueue_picker();
	}
}
add_action( 'admin_enqueue_scripts', 'obento_avatars_profile_enqueue' );

/**
 * 「プロフィール写真」の行の説明に、アバターの欄を足す
 *
 * 設定できない人には、コアの説明をそのまま返す。コアの説明（自分のときのGravatarへの案内）は、アバターがあるあいだは隠す。
 * 他人の画像を編集できない人（edit_others_postsがない）には、モーダルの一覧を自分の画像に絞る（data-author）。
 * 削除したときのプレビューの戻り先は、個人のアバターを使わないURL（obento_avatars_skip）。
 *
 * @param string  $description  コアの説明（HTML）。
 * @param WP_User $profile_user 開いているユーザー。
 * @return string
 */
function obento_avatars_profile_description( $description, $profile_user ) {
	if ( ! $profile_user instanceof WP_User || ! obento_avatars_can_edit( $profile_user->ID ) ) {
		return $description;
	}
	$user_id = (int) $profile_user->ID;
	$has     = '' !== obento_avatars_user_avatar_url( $user_id, 96 );
	$author  = current_user_can( 'edit_others_posts' ) ? '' : (string) get_current_user_id();
	$fall_1x = get_avatar_url(
		$user_id,
		array(
			'size'                => 96,
			'obento_avatars_skip' => true,
		)
	);
	$fall_2x = get_avatar_url(
		$user_id,
		array(
			'size'                => 192,
			'obento_avatars_skip' => true,
		)
	);
	ob_start();
	?>
	<span class="obento-avatar-gravatar"<?php echo $has ? ' hidden' : ''; ?>><?php echo wp_kses_post( $description ); ?></span>
	<span class="obento-avatar-local"<?php echo $has ? '' : ' hidden'; ?>>ここで選んだ画像を、Gravatarより優先して使います。</span>
	<span class="obento-avatar-field" data-author="<?php echo esc_attr( $author ); ?>" data-fallback="<?php echo esc_url( (string) $fall_1x ); ?>" data-fallback2x="<?php echo esc_url( (string) $fall_2x ); ?>">
		<input type="hidden" class="obento-avatar-id" name="obento_avatar" value="<?php echo $has ? esc_attr( (string) obento_avatars_get_user_avatar_id( $user_id ) ) : ''; ?>">
		<?php wp_nonce_field( 'obento_avatar_' . $user_id, 'obento_avatar_nonce', false ); ?>
		<span class="hide-if-no-js">
			<button type="button" class="button obento-avatar-select"><?php echo esc_html( $has ? '画像を変更' : '画像を選ぶ' ); ?></button>
			<button type="button" class="button obento-avatar-remove<?php echo $has ? '' : ' hidden'; ?>">削除</button>
		</span>
		<span class="obento-avatar-error" role="alert" hidden></span>
	</span>
	<?php
	return (string) ob_get_clean();
}
add_filter( 'user_profile_picture_description', 'obento_avatars_profile_description', 10, 2 );

/**
 * プロフィールの保存でアバターを保存する（personal_options_update / edit_user_profile_update）
 *
 * 欄を出していない画面（nonceがない）と、nonceが合わないときは何もしない。送られた値が保存済みと同じなら何もしない
 * （管理者が設定した画像を、本人がプロフィールを保存しただけでedit_postの確認で弾かないため）。空なら消す（添付ファイルは消さない）。
 * 使えない画像は、user_profile_update_errorsでエラーにして、変えない。
 *
 * @param int $user_id 保存するユーザー。
 */
function obento_avatars_profile_save( $user_id ) {
	$user_id = (int) $user_id;
	if ( ! isset( $_POST['obento_avatar_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['obento_avatar_nonce'] ) ), 'obento_avatar_' . $user_id ) ) {
		return;
	}
	if ( ! obento_avatars_can_edit( $user_id ) ) {
		return;
	}
	$value = isset( $_POST['obento_avatar'] ) ? absint( $_POST['obento_avatar'] ) : 0;
	if ( obento_avatars_get_user_avatar_id( $user_id ) === $value ) {
		return;
	}
	if ( 0 === $value ) {
		delete_user_option( $user_id, 'obento_avatar' );
		return;
	}
	if ( ! obento_avatars_can_use_image( $value ) ) {
		add_action( 'user_profile_update_errors', 'obento_avatars_profile_error' );
		return;
	}
	update_user_option( $user_id, 'obento_avatar', $value );
}
add_action( 'personal_options_update', 'obento_avatars_profile_save' );
add_action( 'edit_user_profile_update', 'obento_avatars_profile_save' );

/**
 * プロフィールの保存のエラー（使えない画像）を足す
 *
 * @param WP_Error $errors コアのエラー。
 */
function obento_avatars_profile_error( $errors ) {
	$errors->add( 'obento_avatar', '選んだ画像はアバターに使えません。' );
}
