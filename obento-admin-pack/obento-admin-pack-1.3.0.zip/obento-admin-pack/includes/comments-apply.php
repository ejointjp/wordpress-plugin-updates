<?php
/**
 * コメントのフック（コメントを止める、自分のサイトへのピンバックを送らない）
 *
 * plugins_loadedで設定（option obento_comments）を1回読み、オンのものだけフックを登録する。
 * comments_openのように呼ばれる回数の多いフィルターの中で、毎回optionを読まないため。
 *
 * コメントを止めるのは実行時のフィルターだけ。DB（既存の投稿のcomment_status / ping_statusと既存のコメント）は変えない。
 * サポートを外すとコアは既存の投稿の保存でcomment_status / ping_statusをclosedにするので、止めているあいだは
 * wp_insert_post_data / wp_insert_attachment_dataで保存済みの値に戻す（チェックを外せば、既存の投稿は止める前の設定のまま）。
 * 止めているあいだに新しく作った投稿は、コアがclosedで保存し、やめても閉じたまま（タブの説明とreadmeで案内する）。
 * 既存のコメント（「概要」の件数、「アクティビティ」の「最近のコメント」、edit-comments.phpの一覧）と、
 * 送る側の通知（設定 > ディスカッション）、XML-RPCのほかのメソッド、ブロックエディターの「メモ」は触らない。
 *
 * is_admin()の外で読む（表側とcronで動く）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定を読んで、オンのもののフックを登録する（plugins_loaded）
 *
 * コメントを止める:
 * - wp_loadedで全投稿タイプのcomments / trackbacksのサポートを外す（新しい投稿はclosed。エディターのパネル、一覧の列、クイック編集の欄が消える）
 * - wp_insert_post_data / wp_insert_attachment_dataで、既存の投稿と添付ファイルのcomment_status / ping_statusを保存済みの値に戻す
 *   （欄が出ないので、コアがclosedで保存するのを防ぐ）
 * - comments_open / pings_openをfalse（既存の投稿も閉じる。X-Pingbackヘッダーはpings_open()に連動して消える）
 * - 表側: comments_arrayを空、get_comments_numberを0、comments_templateを空のファイル、「最近のコメント」ウィジェットの登録解除、
 *   「最新のコメント」ブロックを空、headのコメントフィードのリンクを出さない、コメントフィードを404
 * - 管理画面: 「コメント」メニューとツールバーの項目を消す
 * - API: RESTのコメントのルートを404にし（rest_pre_dispatch。ブロックエディターの「メモ」は通す）、XML-RPCのピンバックのメソッドを外す
 */
function obento_comments_register_hooks() {
	$settings = obento_comments_get_settings();
	if ( $settings['no_self_ping'] ) {
		add_action( 'pre_ping', 'obento_comments_pre_ping' );
	}
	if ( ! $settings['disable'] ) {
		return;
	}
	add_action( 'wp_loaded', 'obento_comments_remove_support' );
	add_filter( 'wp_insert_post_data', 'obento_comments_keep_discussion_status', PHP_INT_MAX, 4 );
	add_filter( 'wp_insert_attachment_data', 'obento_comments_keep_discussion_status', PHP_INT_MAX, 4 );
	add_filter( 'comments_open', '__return_false', PHP_INT_MAX );
	add_filter( 'pings_open', '__return_false', PHP_INT_MAX );
	add_filter( 'comments_array', '__return_empty_array', PHP_INT_MAX );
	add_filter( 'get_comments_number', '__return_zero', PHP_INT_MAX );
	add_filter( 'comments_template', 'obento_comments_empty_template', PHP_INT_MAX );
	add_action( 'widgets_init', 'obento_comments_unregister_widget' );
	add_filter( 'render_block_core/latest-comments', '__return_empty_string', PHP_INT_MAX );
	add_filter( 'feed_links_show_comments_feed', '__return_false' );
	add_action( 'template_redirect', 'obento_comments_block_comment_feed' );
	add_action( 'admin_menu', 'obento_comments_remove_menu' );
	add_action( 'add_admin_bar_menus', 'obento_comments_remove_toolbar_item' );
	add_filter( 'rest_pre_dispatch', 'obento_comments_block_rest', 10, 3 );
	add_filter( 'xmlrpc_methods', 'obento_comments_remove_xmlrpc_methods' );
}
add_action( 'plugins_loaded', 'obento_comments_register_hooks' );

/**
 * ピンバックの候補から、自分のサイトへのリンクを外す（pre_ping。候補は参照渡し）
 *
 * 自分のサイトはhome_url() / site_url()のホストだけ（外部リンクの「内部として扱うドメイン」と「サブドメインも内部として扱う」は見ない）。
 *
 * @param array $links 候補のURL（コアが参照で渡す）。
 */
function obento_comments_pre_ping( &$links ) {
	$links = obento_comments_remove_self_links( (array) $links, obento_external_hosts( array( 'internal_hosts' => array() ) ) );
}

/**
 * 全投稿タイプのcomments / trackbacksのサポートを外す（wp_loaded。プラグインのCPTの登録が済んだあと）
 */
function obento_comments_remove_support() {
	foreach ( get_post_types() as $post_type ) {
		remove_post_type_support( $post_type, 'comments' );
		remove_post_type_support( $post_type, 'trackbacks' );
	}
}

/**
 * 既存の投稿のcomment_status / ping_statusを、保存済みの値に戻す（wp_insert_post_data / wp_insert_attachment_data）
 *
 * サポートを外すと、クイック編集・クラシックエディター・旧来のメタボックス・添付ファイルの編集画面の保存では欄が送られず、
 * コア（wp_ajax_inline_save() / _wp_translate_postdata()）が既存の投稿をclosedにする。添付ファイル（attachmentは
 * commentsをサポートする）の保存はwp_insert_post_dataではなくwp_insert_attachment_dataを通るので、両方に付ける
 * （引数は同じ形）。止めているあいだは、既存の投稿と添付ファイルのこの2つを保存の前の値に戻してDBを変えない。
 * そのため、止めているあいだはRESTなどからこの2つを変えようとしても変わらない。
 * 新しい投稿（$updateが偽）はそのまま（サポートがないのでコアがclosedで保存する。タブの説明とreadmeで案内する）。
 *
 * @param array $data                保存する値（スラッシュ付き）。
 * @param array $postarr             wp_insert_post()に渡された値（sanitize済み）。
 * @param array $unsanitized_postarr wp_insert_post()に渡された値（sanitize前）。使わない。
 * @param bool  $update              既存の投稿の更新か。
 * @return array
 */
function obento_comments_keep_discussion_status( $data, $postarr, $unsanitized_postarr, $update ) {
	if ( ! $update || empty( $postarr['ID'] ) ) {
		return $data;
	}
	$post = get_post( (int) $postarr['ID'] );
	if ( ! $post ) {
		return $data;
	}
	$data['comment_status'] = $post->comment_status;
	$data['ping_status']    = $post->ping_status;
	return $data;
}

/**
 * コメントテンプレートを空のファイルに差し替える（comments_template）
 *
 * comments_open()を見ずにcomments_template()を呼ぶテーマでも、「コメントは受け付けていません。」などを出さない。
 *
 * @return string
 */
function obento_comments_empty_template() {
	return OBENTO_DIR . 'includes/comments-empty.php';
}

/**
 * 「最近のコメント」ウィジェットの登録を解除する（widgets_init）
 *
 * コアはwp_widgets_init()の中で登録してからwidgets_initを鳴らすので、どの優先度でも外せる。
 */
function obento_comments_unregister_widget() {
	unregister_widget( 'WP_Widget_Recent_Comments' );
}

/**
 * コメントフィードを404にする（template_redirect）
 *
 * /comments/feed/と投稿ごとの/…/feed/。set_404()はis_feedを残してis_comment_feedを落とすので、テンプレートの読み込みは
 * do_feed()のままで、404のステータスで投稿のフィード（クエリに残った投稿。コメントは含まない）を返す。
 */
function obento_comments_block_comment_feed() {
	if ( ! is_comment_feed() ) {
		return;
	}
	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();
}

/**
 * 管理メニューの「コメント」を消す（admin_menu）
 *
 * コアの画面なので、メニューから消しても権限判定に影響しない。edit-comments.phpをURLで開けば一覧が出て、既存のコメントを削除できる。
 * 管理メニューの編集（menu-apply.php）がremove_menu_page()を使わないのは、プラグインの画面を権限判定の前に消すと開けなくなるためで、ここには当たらない。
 */
function obento_comments_remove_menu() {
	remove_menu_page( 'edit-comments.php' );
}

/**
 * ツールバーの「コメント」を出さない（add_admin_bar_menus。コアが項目を足すフックを外す）
 */
function obento_comments_remove_toolbar_item() {
	remove_action( 'admin_bar_menu', 'wp_admin_bar_comments_menu', 60 );
}

/**
 * RESTのコメントのルートを404にする（rest_pre_dispatch）。ブロックエディターの「メモ」は通す
 *
 * /wp/v2/commentsと/wp/v2/comments/<ID>への要求に、ルートのハンドラーより先にエラーを返す。既存のコメントもRESTから取れなくなる
 * （投稿の_linksのrepliesは、サポートを外した時点で出なくなる）。
 *
 * WordPress 6.9以降のブロックエディターの「メモ」は、同じ/wp/v2/commentsをtype=noteで使う（一覧・追加・解決）。
 * メモは表に出ない編集用のもので、コアも閉じた投稿へのメモを許しているので、受け付けを止める範囲の外として通す。
 * IDのルートはそのコメントのcomment_typeがnote、一覧と作成はtypeの値が文字列のnoteなら通す。
 * ルートは、コアと同じく大文字小文字を見ずに照らす（コアは/wp/v2/Commentsでもコメントのハンドラーを呼ぶ）。
 *
 * @param mixed           $result  ほかのフィルターが決めた応答。nullでなければそのまま返す。
 * @param WP_REST_Server  $server  サーバー。使わない。
 * @param WP_REST_Request $request 要求。
 * @return mixed
 */
function obento_comments_block_rest( $result, $server, $request ) {
	if ( null !== $result ) {
		return $result;
	}
	if ( ! preg_match( '#^/wp/v2/comments(?:/(\d+))?$#i', $request->get_route(), $matches ) ) {
		return $result;
	}
	if ( isset( $matches[1] ) ) {
		$comment = get_comment( (int) $matches[1] );
		if ( $comment && 'note' === $comment->comment_type ) {
			return $result;
		}
	} elseif ( 'note' === $request->get_param( 'type' ) ) {
		return $result;
	}
	return new WP_Error( 'obento_comments_disabled', 'コメントは受け付けていません。', array( 'status' => 404 ) );
}

/**
 * XML-RPCのピンバックのメソッドを外す（xmlrpc_methods）
 *
 * ほかのメソッド（wp.newCommentなど）はcomments_open()を見て失敗するので触らない。
 *
 * @param array $methods メソッド名 => コールバック。
 * @return array
 */
function obento_comments_remove_xmlrpc_methods( $methods ) {
	unset( $methods['pingback.ping'], $methods['pingback.extensions.getPingbacks'] );
	return $methods;
}
