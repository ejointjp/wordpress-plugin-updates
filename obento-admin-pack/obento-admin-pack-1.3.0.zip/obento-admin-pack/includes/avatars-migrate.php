<?php
/**
 * アバター: WP User Avatarsからの引き継ぎ
 *
 * 本家（WP User Avatars）のユーザーメタwp_user_avatarsとoption wp_user_avatars_default_avatarを読み、アバターをObentoに写す。
 * 「アバター」タブのボタン（assets/avatars-migrate.js）が、AJAX obento_avatars_migrateをdoneになるまで繰り返し呼ぶ（1回に5人。
 * カーソルは処理済みの最後のユーザーIDで、状態はサーバーに持たない）。
 *
 * 画像はメディアから選んだものも含めてすべてコピーし、新しい添付ファイルにする。本家は、メディアから選んだ画像のサイズ違いを
 * 添付ファイルの横に作って本家の削除時に消し（名前がコアの中間サイズと重なると、コアの画像まで消える）、直接アップロードした画像は
 * 本家の削除時に原本ごと消すため。本家のデータとファイルには触らない。正方形でない画像は、本家の表示と同じく中央で正方形に切る。
 * 既定アバターは、本家がサイズ違いを作らず、本家の削除でもメディアの原本は消えないので、添付ファイルをそのまま使う
 * （Gravatarのd=が受け付けるJPEG・PNG・GIFの正方形だけ）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 本家のメタを持つ、このサイトのユーザーのID（昇順）
 *
 * @return int[]
 */
function obento_avatars_wua_user_ids() {
	$ids = get_users(
		array(
			'meta_key' => 'wp_user_avatars', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- 引き継ぐ対象を探す。引き継ぎのAJAXのときだけ
			'fields'   => 'ID',
			'orderby'  => 'ID',
			'order'    => 'ASC',
		)
	);
	return array_map( 'intval', $ids );
}

/**
 * 本家のデータが残っているか（このサイトのユーザーのメタか、本家の既定アバター）
 *
 * @return bool
 */
function obento_avatars_wua_has_data() {
	$users   = get_users(
		array(
			'meta_key' => 'wp_user_avatars', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- 引き継ぐ対象があるかを1件だけ見る
			'fields'   => 'ID',
			'number'   => 1,
		)
	);
	$default = get_option( 'wp_user_avatars_default_avatar', array() );
	return ! empty( $users ) || ( is_array( $default ) && ! empty( $default['media_id'] ) );
}

/**
 * 本家のメタから、元の画像のファイルのパスを決める
 *
 * メディアから選んだもの（media_id）は、その添付ファイル（マルチサイトで別のサイトのものは飛ばす）。直接アップロードしたものは、
 * fullのURLをこのサイトのアップロード先の中のパスに直す（http/httpsは問わない。アップロード先の外は飛ばす）。
 *
 * @param array $data 本家のメタ（full、media_id、site_id）。
 * @return string|WP_Error
 */
function obento_avatars_wua_source_path( $data ) {
	$missing = new WP_Error( 'obento_avatars_no_file', 'ファイルがありません' );
	if ( ! empty( $data['media_id'] ) ) {
		if ( is_multisite() && isset( $data['site_id'] ) && get_current_blog_id() !== (int) $data['site_id'] ) {
			return new WP_Error( 'obento_avatars_other_site', '別のサイトの画像です' );
		}
		$path = get_attached_file( (int) $data['media_id'] );
		return ( is_string( $path ) && is_file( $path ) ) ? $path : $missing;
	}
	$uploads = wp_upload_dir();
	$base    = preg_replace( '#^https?:#i', '', $uploads['baseurl'] ) . '/';
	$full    = preg_replace( '#^https?:#i', '', (string) $data['full'] );
	if ( 0 !== strpos( $full, $base ) ) {
		return $missing;
	}
	$root = realpath( $uploads['basedir'] );
	$real = realpath( $uploads['basedir'] . '/' . rawurldecode( substr( $full, strlen( $base ) ) ) );
	if ( false === $root || false === $real || 0 !== strpos( $real, $root . DIRECTORY_SEPARATOR ) || ! is_file( $real ) ) {
		return $missing;
	}
	return $real;
}

/**
 * 元の画像を、正方形の一時ファイルにする
 *
 * 一辺がobento_avatars_max_size()以下の正方形なら、そのままコピーする。正方形でなければ中央の最大の正方形を切り抜く。
 * どちらでも、一辺がobento_avatars_max_size()を超えるなら縮める（切り抜きの上限と同じ。大きな写真のままだと、サイズ違いを作る時間が
 * 延びて時間切れになり、添付ファイルだけが残ることがある）。
 * 一時ファイルは、コピーなら元と同じ拡張子で作る。切り抜き・縮小は画像エディターが保存するので、出力形式の変換で拡張子が変わることがある
 * （呼び出し側は、戻り値のパスの拡張子を使ってmedia_handle_sideload()に渡し、失敗したら消す）。
 *
 * @param string $path 元の画像。
 * @return string|WP_Error 一時ファイルのパス。
 */
function obento_avatars_make_square_copy( $path ) {
	$size = wp_getimagesize( $path );
	if ( ! $size ) {
		return new WP_Error( 'obento_avatars_not_image', '画像として読めません' );
	}
	$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	$dir = get_temp_dir();
	$tmp = $dir . wp_unique_filename( $dir, 'obento-avatar-' . wp_generate_password( 8, false ) . '.' . $ext );
	$w   = (int) $size[0];
	$h   = (int) $size[1];
	if ( $w === $h && $w <= obento_avatars_max_size() ) {
		return copy( $path, $tmp ) ? $tmp : new WP_Error( 'obento_avatars_copy', '画像をコピーできませんでした' );
	}
	$editor = wp_get_image_editor( $path );
	if ( is_wp_error( $editor ) ) {
		return $editor;
	}
	$side    = min( $w, $h );
	$dst     = min( $side, obento_avatars_max_size() );
	$cropped = $editor->crop( (int) floor( ( $w - $side ) / 2 ), (int) floor( ( $h - $side ) / 2 ), $side, $side, $dst, $dst );
	if ( is_wp_error( $cropped ) ) {
		return $cropped;
	}
	$saved = $editor->save( $tmp );
	if ( is_wp_error( $saved ) ) {
		return $saved;
	}
	return $saved['path'];
}

/**
 * 1人分を引き継ぐ
 *
 * Obentoのアバターがある人は飛ばす（上書きしない）。新しい添付ファイルの投稿者はそのユーザー、タイトルは「<表示名>のアバター」。
 * 本家のレーティングは見ない。
 *
 * @param int $user_id ユーザー。
 * @return int|WP_Error 新しい添付ファイルのID。飛ばすときは理由の文言を持つWP_Error。
 */
function obento_avatars_migrate_user( $user_id ) {
	$user = get_userdata( $user_id );
	if ( ! $user ) {
		return new WP_Error( 'obento_avatars_no_user', 'ユーザーがいません' );
	}
	if ( obento_avatars_get_user_avatar_id( $user->ID ) ) {
		return new WP_Error( 'obento_avatars_already', '設定済み' );
	}
	$data = get_user_meta( $user->ID, 'wp_user_avatars', true );
	if ( ! is_array( $data ) || empty( $data['full'] ) ) {
		return new WP_Error( 'obento_avatars_no_data', 'データがありません' );
	}
	$path = obento_avatars_wua_source_path( $data );
	if ( is_wp_error( $path ) ) {
		return $path;
	}
	$tmp = obento_avatars_make_square_copy( $path );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	$id = media_handle_sideload(
		array(
			'name'     => 'avatar-' . $user->ID . '.' . strtolower( pathinfo( $tmp, PATHINFO_EXTENSION ) ),
			'tmp_name' => $tmp,
		),
		0,
		null,
		array(
			'post_author' => $user->ID,
			'post_title'  => $user->display_name . 'のアバター',
		)
	);
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return $id;
	}
	update_user_option( $user->ID, 'obento_avatar', (int) $id );
	return (int) $id;
}

/**
 * 本家の既定アバターを引き継ぐ（Obentoのdefault_idが0で、本家の画像が正方形のJPEG・PNG・GIFのときだけ）
 *
 * 引き継ぐ条件は、update_option()より先に確かめる（sanitizeが対象外の画像を弾いても、そのあとのavatar_defaultの切り替えは
 * 止まらないため）。
 * コアのavatar_defaultが本家の画像（保存したURLか、いまのURL）なら、目印に切り替える。本家が有効なあいだは、本家の
 * option_avatar_defaultのフィルターが保存したURLをいまのURLに直して返すので、両方と比べる。
 */
function obento_avatars_migrate_default() {
	$wua = get_option( 'wp_user_avatars_default_avatar', array() );
	if ( ! is_array( $wua ) || empty( $wua['media_id'] ) ) {
		return;
	}
	$id = absint( $wua['media_id'] );
	if ( obento_avatars_get_settings()['default_id'] || ! obento_avatars_is_square_image( $id ) || ! obento_avatars_is_default_format( $id ) ) {
		return;
	}
	update_option( 'obento_avatars', array( 'default_id' => $id ) );
	$urls = array_filter( array( isset( $wua['url'] ) ? (string) $wua['url'] : '', (string) wp_get_attachment_url( $id ) ) );
	if ( in_array( get_option( 'avatar_default' ), $urls, true ) ) {
		update_option( 'avatar_default', obento_avatars_default_sentinel() );
	}
}

/**
 * AJAX: 1回分（5人）を引き継ぐ
 *
 * JSがdoneになるまで繰り返し呼ぶ。cursorが0のときは、ユーザーの前に既定アバターを引き継ぐ。
 * 失敗はwp_send_json_error( array( 'message' => … ) )で、画面にそのまま出せる文言を返す（nonceの不一致も、コアの`-1`ではなくこの形で返す）。
 */
function obento_ajax_avatars_migrate() {
	if ( ! check_ajax_referer( 'obento_avatars_migrate', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'ページの有効期限が切れました。ページを読み込み直して、もう一度お試しください。' ), 403 );
	}
	if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'upload_files' ) ) {
		wp_send_json_error( array( 'message' => 'アバターを引き継ぐ権限がありません。' ), 403 );
	}
	$cursor = isset( $_POST['cursor'] ) ? max( 0, (int) $_POST['cursor'] ) : 0;
	if ( 0 === $cursor ) {
		obento_avatars_migrate_default();
	}
	$ids      = obento_avatars_wua_user_ids();
	$rest     = array_values(
		array_filter(
			$ids,
			function ( $id ) use ( $cursor ) {
				return $id > $cursor;
			}
		)
	);
	$batch    = array_slice( $rest, 0, 5 );
	$migrated = 0;
	$skipped  = array();
	foreach ( $batch as $id ) {
		$result = obento_avatars_migrate_user( $id );
		if ( is_wp_error( $result ) ) {
			$user      = get_userdata( $id );
			$skipped[] = array(
				'user'   => $user ? $user->display_name : '#' . $id,
				'reason' => $result->get_error_message(),
			);
		} else {
			++$migrated;
		}
		$cursor = $id;
	}
	wp_send_json_success(
		array(
			'cursor'    => $cursor,
			'done'      => count( $rest ) <= count( $batch ),
			'total'     => count( $ids ),
			'processed' => count( $ids ) - count( $rest ) + count( $batch ),
			'migrated'  => $migrated,
			'skipped'   => $skipped,
		)
	);
}
add_action( 'wp_ajax_obento_avatars_migrate', 'obento_ajax_avatars_migrate' );

/**
 * 「アバター」タブの引き継ぎの節を描く（本家のデータが残っているときだけ）
 *
 * ボタンはJSが動くまでdisabledで、「JavaScriptが動いていない」の注意を出しておく（JSが消す）。
 */
function obento_avatars_render_migrate_section() {
	if ( ! obento_avatars_wua_has_data() ) {
		return;
	}
	?>
	<h2>WP User Avatarsから引き継ぐ</h2>
	<?php if ( function_exists( 'wp_user_avatars_get_plugin_url' ) ) : ?>
		<div class="notice notice-warning inline"><p>WP User Avatarsが有効です。有効のあいだは、WP User Avatarsの画像が優先されます。</p></div>
	<?php endif; ?>
	<p>WP User Avatarsで設定したアバターを、メディアライブラリにコピーして、このプラグインのアバターにします。すでにこのプラグインでアバターを設定しているユーザーは上書きしません。WP User Avatarsのデータとファイルは消しません。引き継いだら、WP User Avatarsを停止してください。</p>
	<div class="notice notice-warning inline obento-avatars-migrate-nojs"><p>JavaScriptが動いていないため引き継げません。</p></div>
	<p><button type="button" class="button" id="obento-avatars-migrate" disabled>引き継ぐ</button></p>
	<p id="obento-avatars-migrate-progress" aria-live="polite"></p>
	<ul id="obento-avatars-migrate-skipped"></ul>
	<?php
}

/**
 * 「アバター」タブに引き継ぎのスクリプトを読み込む（本家のデータが残っているときだけ）
 *
 * @param string $hook 管理画面のページ（settings_page_obento-admin-pack）。
 */
function obento_avatars_migrate_enqueue( $hook ) {
	if ( 'settings_page_obento-admin-pack' !== $hook || 'avatars' !== obento_get_settings_tab() || ! obento_avatars_wua_has_data() ) {
		return;
	}
	wp_enqueue_script( 'obento-avatars-migrate', OBENTO_URL . 'assets/avatars-migrate.js', array( 'jquery', 'wp-a11y' ), OBENTO_VERSION, true );
	$data = array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'obento_avatars_migrate' ),
		'action'  => 'obento_avatars_migrate',
	);
	wp_add_inline_script( 'obento-avatars-migrate', 'var obentoAvatarsMigrate = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', 'obento_avatars_migrate_enqueue' );
