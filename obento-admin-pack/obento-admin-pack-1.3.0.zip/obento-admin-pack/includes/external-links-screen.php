<?php
/**
 * 「外部リンク」タブ（設定 > Obento Admin Pack）
 *
 * option obento_external_linksの登録と、タブの描画。保存はSettings API。option groupはobento_external_links
 * （ほかのタブとは別。片方の保存でもう片方を消さない）。読み出しとsanitizeはincludes/external-links-common.phpの関数。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_external_setting() {
	register_setting(
		'obento_external_links',
		'obento_external_links',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_external_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_external_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知（捨てた行の警告を含む）は、「設定」メニュー配下なのでコアが出す。
 * 「このサイトのドメイン」には、home_url()とsite_url()のホスト（obento_external_hosts()に空の設定を渡したもの）を出す。
 */
function obento_render_external_tab() {
	$settings     = obento_external_get_settings();
	$descriptions = array(
		'noreferrer' => 'リンク先に、どのページから来たか（リファラー）を伝えません',
		'nofollow'   => '検索エンジンに、リンク先を評価に使わないよう伝えます',
		'external'   => '外部リンクの目印です。テーマのCSSで<code>a[rel~="external"]</code>として選べます',
	);
	$own_hosts    = array();
	foreach ( obento_external_hosts( array( 'internal_hosts' => array() ) ) as $host ) {
		$own_hosts[] = '<code>' . esc_html( $host ) . '</code>';
	}
	?>
	<p>サイトの表側のページ全体（本文・メニュー・ウィジェット・フッター）で、外部サイトへのリンクに属性を足します。管理画面・フィード・カスタマイザーのプレビューには効きません。<code>mailto:</code>・<code>tel:</code>・ページ内リンク（<code>#</code>）は触りません。保存した本文は変わりません。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_external_links' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row"><label for="obento-external-new-tab">新しいタブで開く</label></th>
				<td>
					<input type="checkbox" id="obento-external-new-tab" name="obento_external_links[new_tab]" value="1"<?php checked( $settings['new_tab'] ); ?>>
					<p class="description"><code>target="_blank"</code>と<code>rel="noopener"</code>を足します。すでに<code>target</code>のあるリンク（<code>target="_self"</code>など）の<code>target</code>は変えません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><code>rel</code>に足す値</th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">relに足す値</legend>
						<?php foreach ( obento_external_rel_values() as $value ) : ?>
							<label><input type="checkbox" name="obento_external_links[rel][]" value="<?php echo esc_attr( $value ); ?>"<?php checked( in_array( $value, $settings['rel'], true ) ); ?>> <code><?php echo esc_html( $value ); ?></code> — <?php echo wp_kses( $descriptions[ $value ], array( 'code' => array() ) ); ?></label><br>
						<?php endforeach; ?>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-external-icon">外部リンクの印</label></th>
				<td>
					<input type="checkbox" id="obento-external-icon" name="obento_external_links[icon]" value="1"<?php checked( $settings['icon'] ); ?>>
					<p class="description">リンクの文字の後ろに小さな矢印を出します（クラス<code>obento-external</code>と、プラグインの小さなCSS）。画像やSVGを含むリンクには出しません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-external-pdf">PDFへのリンクも新しいタブで開く</label></th>
				<td>
					<input type="checkbox" id="obento-external-pdf" name="obento_external_links[pdf_new_tab]" value="1"<?php checked( $settings['pdf_new_tab'] ); ?>>
					<p class="description">サイト内のPDFも含めて、URLの末尾が<code>.pdf</code>のリンクに<code>target="_blank"</code>と<code>rel="noopener"</code>を足します。WordやExcelのファイルはブラウザが表示せずダウンロードするので、対象にしません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-external-hosts">内部として扱うドメイン</label></th>
				<td>
					<textarea id="obento-external-hosts" name="obento_external_links[internal_hosts]" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", $settings['internal_hosts'] ) ); ?></textarea>
					<p class="description">1行に1つ。このサイトのドメイン（<?php echo wp_kses( implode( '・', $own_hosts ), array( 'code' => array() ) ); ?>）は書かなくても内部です。<code>www.</code>の有無は区別しません。ここに書いたドメインへのリンクは触りません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-external-subdomains">サブドメインも内部として扱う</label></th>
				<td>
					<input type="checkbox" id="obento-external-subdomains" name="obento_external_links[subdomains]" value="1"<?php checked( $settings['subdomains'] ); ?>>
					<p class="description"><code>shop.example.com</code>のように、内部のドメインのサブドメインへのリンクも触りません。</p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<?php
}
