<?php
/**
 * 外部リンクの表側
 *
 * template_redirectでob_start()し、最終のHTMLをobento_external_rewrite()で書き換える。印のCSSを読む。
 * 設定がすべてオフなら、ob_start()もCSSの読み込みもしない。
 *
 * is_admin()の外で読む（表側で動く）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 出力バッファを始める（template_redirect、優先度100）
 *
 * 優先度100は、コアのredirect_canonical()（10）やサイトマップの出力（10。出してexitする）より後。
 * ほかの出力バッファのプラグイン（minifyや圧縮）はinitやtemplate_redirectの早い優先度で始めるので、こちらが内側になり、
 * こちらのコールバックが先に動いて、その結果を外側が処理する。
 *
 * フィード・robots.txt・トラックバックはHTMLでない。カスタマイザーのプレビューは、リンクのクリックをJSが受けてプレビューの中で
 * 遷移するので、target="_blank"を足すとプレビューの外で開いてしまう。埋め込み・404・プレビューはHTMLなので対象。
 */
function obento_external_start_buffer() {
	if ( ! obento_external_is_active( obento_external_get_settings() ) ) {
		return;
	}
	if ( is_feed() || is_robots() || is_trackback() || is_customize_preview() || wp_doing_ajax() ) {
		return;
	}
	ob_start( 'obento_external_ob_callback' );
}
add_action( 'template_redirect', 'obento_external_start_buffer', 100 );

/**
 * バッファのコールバック（Content-Typeがtext/htmlのときだけ書き換える）
 *
 * テーマやプラグインがtemplate_redirectのあとでJSONやXMLを出すことがある。出力を始めたあとにheader()で変えたContent-Typeも、
 * バッファが流れるまでヘッダーは送られないのでheaders_list()で見える。Content-Typeがなければ、PHPの既定のtext/htmlなので進む。
 * <a（<abbr>や<article>にも当たるが、走査を省くための前置きの判定なので構わない）がなければ、そのまま返す。
 *
 * @param string $html バッファの中身。
 * @return string
 */
function obento_external_ob_callback( $html ) {
	if ( '' === $html ) {
		return $html;
	}
	foreach ( headers_list() as $header ) {
		if ( 0 === stripos( $header, 'Content-Type:' ) && false === stripos( $header, 'text/html' ) ) {
			return $html;
		}
	}
	if ( false === stripos( $html, '<a' ) ) {
		return $html;
	}
	$settings = obento_external_get_settings();
	return obento_external_rewrite( $html, $settings, obento_external_hosts( $settings ) );
}

/**
 * 印のCSSを読む（「外部リンクの印」がオンのとき）
 */
function obento_external_enqueue_style() {
	if ( ! obento_external_get_settings()['icon'] ) {
		return;
	}
	wp_enqueue_style( 'obento-external-links', OBENTO_URL . 'assets/external-links.css', array(), OBENTO_VERSION );
}
add_action( 'wp_enqueue_scripts', 'obento_external_enqueue_style' );
