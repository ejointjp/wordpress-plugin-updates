<?php
/**
 * SVGの共通部分（純粋な関数）
 *
 * 設定（option obento_svg）の読み出しとsanitize、選べるロール、アップロードできる人の判定、同梱のsvg-sanitizer
 * （lib/svg-sanitizer/）のオートローダー、サニタイズ、寸法の算出。フックは持たない（オートローダーの登録だけは、
 * このファイルを読んだときに行う）。フックの登録はincludes/svg-apply.php、設定画面はincludes/svg-screen.phpが持つ。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 同梱のsvg-sanitizerのクラスを読む（spl_autoload_register()に渡す）
 *
 * オートローダーは、クラスがまだないときだけ呼ばれる。Safe SVGなどが先に同じクラスを読んでいれば、そちらが使われる
 * （同じクラスを二重に定義する致命的エラーにならない）。
 *
 * @param string $class_name クラス名（名前空間付き）。
 */
function obento_svg_autoload( $class_name ) {
	$prefix = 'enshrined\\svgSanitize\\';
	if ( 0 !== strpos( $class_name, $prefix ) ) {
		return;
	}
	$file = OBENTO_DIR . 'lib/svg-sanitizer/src/' . str_replace( '\\', '/', substr( $class_name, strlen( $prefix ) ) ) . '.php';
	if ( is_readable( $file ) ) {
		require $file;
	}
}
spl_autoload_register( 'obento_svg_autoload' );

/**
 * 設定を返す
 *
 * optionがない・配列でないときは、オフで管理者だけ。rolesのキーがないときだけ管理者だけ（保存して空にしたら空）。
 * rolesは文字列だけを残す（ロールがあるかは見ない。実行時は、ユーザーのロールと重なるかだけを見る）。
 *
 * @return array{enabled: bool, roles: string[]}
 */
function obento_svg_get_settings() {
	$option = get_option( 'obento_svg', array() );
	$option = is_array( $option ) ? $option : array();
	$roles  = array_key_exists( 'roles', $option ) ? $option['roles'] : array( 'administrator' );
	return array(
		'enabled' => ! empty( $option['enabled'] ),
		'roles'   => array_values( array_filter( is_array( $roles ) ? $roles : array(), 'is_string' ) ),
	);
}

/**
 * アップロードできるロールとして選べるもの（upload_filesを持つロール。スラッグ => 表示名）
 *
 * get_editable_roles()はwp-admin/includes/user.phpにあり、表側やRESTでは読み込まれていないので、wp_roles()から取る。
 *
 * @return array<string, string>
 */
function obento_svg_upload_roles() {
	$roles = array();
	foreach ( wp_roles()->roles as $slug => $role ) {
		if ( ! empty( $role['capabilities']['upload_files'] ) ) {
			$roles[ $slug ] = translate_user_role( $role['name'] );
		}
	}
	return $roles;
}

/**
 * 設定のsanitize（配列でなければ空として扱う。rolesは選べるロールだけを、送られた順で重複なく残す。知らないキーは捨てる）
 *
 * 警告を出す入力はない。保存の通知は「設定」メニュー配下なのでコアが出す。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{enabled: bool, roles: string[]}
 */
function obento_svg_sanitize_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	$roles = isset( $input['roles'] ) && is_array( $input['roles'] ) ? $input['roles'] : array();
	$valid = obento_svg_upload_roles();
	$kept  = array();
	foreach ( $roles as $role ) {
		if ( is_string( $role ) && isset( $valid[ $role ] ) && ! in_array( $role, $kept, true ) ) {
			$kept[] = $role;
		}
	}
	return array(
		'enabled' => ! empty( $input['enabled'] ),
		'roles'   => $kept,
	);
}

/**
 * そのユーザーがSVGをアップロードできるか
 *
 * 設定がオンで、upload_filesを持ち、ロールが設定のrolesと重なる人。マルチサイトの特権管理者は、サイトにロールを
 * 持たないことがあるので、rolesに管理者があれば真にする。ロールに独自の権限は書き込まない（ロールの定義を変えない）。
 *
 * @param WP_User|int|null $user ユーザーかユーザーID。nullなら今のユーザー（upload_mimesは2つ目の引数で渡すことがある）。
 * @return bool
 */
function obento_svg_user_can_upload( $user = null ) {
	$settings = obento_svg_get_settings();
	if ( ! $settings['enabled'] ) {
		return false;
	}
	if ( null === $user ) {
		$user = wp_get_current_user();
	} elseif ( ! $user instanceof WP_User ) {
		$user = get_userdata( (int) $user );
	}
	if ( ! $user || ! $user->exists() || ! user_can( $user, 'upload_files' ) ) {
		return false;
	}
	if ( array_intersect( (array) $user->roles, $settings['roles'] ) ) {
		return true;
	}
	return is_multisite() && is_super_admin( $user->ID ) && in_array( 'administrator', $settings['roles'], true );
}

/**
 * ファイル名の拡張子がsvgか（大文字小文字は見ない。svgzは違う）
 *
 * @param string $filename ファイル名かパス。
 * @return bool
 */
function obento_svg_has_svg_extension( $filename ) {
	return 'svg' === strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) );
}

/**
 * 添付ファイルがSVGか（MIMEで見る）
 *
 * @param int $attachment_id 添付ファイルのID。
 * @return bool
 */
function obento_svg_is_svg_attachment( $attachment_id ) {
	return 'image/svg+xml' === get_post_mime_type( $attachment_id );
}

/**
 * SVGの文字列をサニタイズする
 *
 * 同梱のsvg-sanitizer（許可リスト、<use>の入れ子の制限、DTDの拒否）に、外部参照の除去を付けて通す。
 * minifyはしない。LIBXML_PARSEHUGEを付けないので、libxmlの既定の上限（1つのテキストが10MBまで、入れ子の深さなど）を超えるものは拒否する。
 *
 * @param mixed $dirty SVGの文字列。
 * @return string|false サニタイズしたSVG。空・文字列でない・サニタイズできないときはfalse。
 */
function obento_svg_sanitize( $dirty ) {
	if ( ! is_string( $dirty ) || '' === $dirty ) {
		return false;
	}
	$sanitizer = new \enshrined\svgSanitize\Sanitizer();
	$sanitizer->removeRemoteReferences( true );
	$clean = $sanitizer->sanitize( $dirty );
	return is_string( $clean ) && '' !== $clean ? $clean : false;
}

/**
 * ファイルをサニタイズし、中身が変わったときだけ書き戻す
 *
 * WP_FilesystemはFTPの資格情報を求めることがあり、アップロードの処理中には使えないので、PHPの関数で読み書きする。
 *
 * @param string $path ファイルのパス。
 * @return string|WP_Error サニタイズしたSVG。失敗は、画面に出せる文言を持つWP_Error。
 */
function obento_svg_sanitize_file( $path ) {
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- アップロード中のローカルのファイルを読む
	$dirty = is_readable( $path ) ? file_get_contents( $path ) : false;
	if ( false === $dirty ) {
		return new WP_Error( 'obento_svg_read', 'SVGファイルを読み込めませんでした。' );
	}
	$clean = obento_svg_sanitize( $dirty );
	if ( false === $clean ) {
		return new WP_Error( 'obento_svg_unsafe', 'SVGファイルを安全な形にできなかったため、アップロードしませんでした。' );
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- アップロード中のローカルのファイルへ書き戻す。WP_FilesystemはFTPの資格情報を求めることがある
	if ( $clean !== $dirty && false === file_put_contents( $path, $clean ) ) {
		return new WP_Error( 'obento_svg_write', 'SVGファイルを書き込めませんでした。' );
	}
	return $clean;
}

/**
 * サニタイズできなかったファイルを消し、画面に出す文言を返す
 *
 * uploadsへ移ったあとのファイルは、URLで開ける。消せなかったときは、文言にファイル名を足して、手で消すよう案内する。
 *
 * @param string $path    ファイルのパス。
 * @param string $message 失敗の文言。
 * @return string
 */
function obento_svg_delete_unsafe_file( $path, $message ) {
	wp_delete_file( $path );
	if ( file_exists( $path ) ) {
		$message .= 'アップロード先に残ったファイル（' . wp_basename( $path ) . '）を手で削除してください。';
	}
	return $message;
}

/**
 * SVGのwidth / heightの値を数値にする（単位なしかpxだけ。%やemなどは0）
 *
 * @param string $value 属性の値。
 * @return float
 */
function obento_svg_length( $value ) {
	if ( preg_match( '/^\s*(\d+(?:\.\d+)?|\.\d+)\s*(?:px)?\s*$/i', (string) $value, $matches ) ) {
		return (float) $matches[1];
	}
	return 0.0;
}

/**
 * SVGの文字列から、ルートのsvg要素の寸法を出す
 *
 * width / heightが両方とも数値（単位なしかpx）ならそれ、そうでなければviewBoxの3つ目と4つ目。四捨五入して整数にする（1未満は1）。
 * 外部実体は展開せず（LIBXML_NOENTを付けない）、ネットワークにも出ない（LIBXML_NONET）。
 *
 * @param mixed $svg SVGの文字列。
 * @return array{width: int, height: int}|false 出せなければfalse。
 */
function obento_svg_dimensions_from_markup( $svg ) {
	if ( ! is_string( $svg ) || '' === $svg ) {
		return false;
	}
	$dom      = new DOMDocument();
	$previous = libxml_use_internal_errors( true );
	$loaded   = $dom->loadXML( $svg, LIBXML_NONET );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous );
	$root = $loaded ? $dom->documentElement : null; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMのプロパティ
	if ( ! $root || 'svg' !== $root->localName ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMのプロパティ
		return false;
	}
	$width  = obento_svg_length( $root->getAttribute( 'width' ) );
	$height = obento_svg_length( $root->getAttribute( 'height' ) );
	if ( $width <= 0 || $height <= 0 ) {
		$box    = preg_split( '/[\s,]+/', trim( $root->getAttribute( 'viewBox' ) ) );
		$width  = isset( $box[2] ) && is_numeric( $box[2] ) ? (float) $box[2] : 0;
		$height = isset( $box[3] ) && is_numeric( $box[3] ) ? (float) $box[3] : 0;
	}
	if ( $width <= 0 || $height <= 0 ) {
		return false;
	}
	return array(
		'width'  => max( 1, (int) round( $width ) ),
		'height' => max( 1, (int) round( $height ) ),
	);
}

/**
 * SVGの添付ファイルの寸法
 *
 * メタデータのwidth / heightがあればそれ。なければファイルを読む（Haku2などで上げた既存のSVGは、メタデータに寸法がない）。
 * ファイルを読んだ結果だけを、リクエストのあいだ持つ（メディアのグリッドでは、1つの添付ファイルにサイズの数だけ呼ばれる）。
 * 読んだ結果をメタデータに書き戻すことはしない（表示のたびにDBを書かない）。
 *
 * @param int $attachment_id 添付ファイルのID。
 * @return array{width: int, height: int}|false
 */
function obento_svg_dimensions( $attachment_id ) {
	static $from_file = array();
	$attachment_id    = (int) $attachment_id;
	$meta             = wp_get_attachment_metadata( $attachment_id );
	if ( is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
		return array(
			'width'  => (int) $meta['width'],
			'height' => (int) $meta['height'],
		);
	}
	if ( ! array_key_exists( $attachment_id, $from_file ) ) {
		$file = get_attached_file( $attachment_id );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- 添付ファイルのローカルのファイルを読む
		$markup                      = $file && is_readable( $file ) ? file_get_contents( $file ) : false;
		$from_file[ $attachment_id ] = false === $markup ? false : obento_svg_dimensions_from_markup( $markup );
	}
	return $from_file[ $attachment_id ];
}

/**
 * SVGの寸法を、要求されたサイズの枠に縦横比を保って収める
 *
 * 拡大はしない（wp_constrain_dimensions()）。SVGは切り抜けないので、cropのサイズも収めるだけ。
 *
 * @param int          $width  幅。
 * @param int          $height 高さ。
 * @param string|int[] $size   サイズの名前か、array( 幅, 高さ )。
 * @return array{0: int, 1: int, 2: bool} 幅、高さ、is_intermediate（登録済みのサイズの名前のときだけ真。
 *                                       コアはis_intermediateが偽のサイズを、メディアのモーダルの「サイズ」から外す）。
 */
function obento_svg_fit_size( $width, $height, $size ) {
	if ( is_array( $size ) && isset( $size[0], $size[1] ) ) {
		list( $width, $height ) = wp_constrain_dimensions( $width, $height, (int) $size[0], (int) $size[1] );
		return array( $width, $height, false );
	}
	$sizes = wp_get_registered_image_subsizes();
	if ( is_string( $size ) && isset( $sizes[ $size ] ) ) {
		list( $width, $height ) = wp_constrain_dimensions( $width, $height, (int) $sizes[ $size ]['width'], (int) $sizes[ $size ]['height'] );
		return array( $width, $height, true );
	}
	return array( (int) $width, (int) $height, false );
}
