<?php
/**
 * アバター: 「アバター」タブ（設定 > Obento Admin Pack）と、「設定 > ディスカッション」の既定アバターの欄
 *
 * option obento_avatarsの登録とsanitize、タブの描画、ディスカッションの「アバター」節への欄の追加、スクリプトの読み込み。
 * 既定アバターの欄はタブとディスカッションで同じもの（obento_avatars_render_default_field()）。保存はSettings API。
 * option groupはobento_avatars（ほかのタブとは別）。allowed_optionsで、ディスカッションの保存（option_page=discussion）にも足す。
 * sanitizeはコアのavatar_defaultを書き換えるので、純粋な関数のincludes/avatars-common.phpではなく、ここに置く。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録し、ディスカッションの「アバター」節に既定アバターの欄を足す
 *
 * 欄の行は、コアのアバターの行と同じクラス（avatar-settings。「アバターを表示」がオフならhide-if-jsも）にして、一緒に出し入れさせる。
 */
function obento_register_avatars_setting() {
	register_setting(
		'obento_avatars',
		'obento_avatars',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_avatars_sanitize_settings',
			'default'           => array(),
		)
	);
	add_settings_field(
		'obento_avatars',
		'既定アバターの画像',
		'obento_avatars_render_default_field',
		'discussion',
		'avatars',
		array( 'class' => get_option( 'show_avatars' ) ? 'avatar-settings' : 'avatar-settings hide-if-js' )
	);
}
add_action( 'admin_init', 'obento_register_avatars_setting' );

/**
 * 既定アバターの設定のsanitize
 *
 * 配列でなければ保存済みの値を返す（ディスカッションの保存で欄が送られなかったときに消さない）。0なら、目印のavatar_defaultを戻して0。
 * 正方形の画像でなければ、またJPEG・PNG・GIFでなければ（Gravatarのd=がWebPなどを受け付けないため）、エラーにして保存済みの値を返す。
 * フォームのactivate（JSが新しく選んだときに1にする）があるときだけ、
 * avatar_defaultを目印に切り替える（コードからのupdate_option()では切り替わらない）。
 * ディスカッションでは、コアのavatar_defaultのあとにobento_avatarsが保存されるので、新しく選んだ画像がラジオに勝つ。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{default_id: int}
 */
function obento_avatars_sanitize_settings( $input ) {
	$saved = obento_avatars_get_settings();
	if ( ! is_array( $input ) ) {
		return $saved;
	}
	$id = isset( $input['default_id'] ) ? absint( $input['default_id'] ) : 0;
	if ( 0 === $id ) {
		obento_avatars_reset_avatar_default();
		return array( 'default_id' => 0 );
	}
	if ( ! obento_avatars_is_square_image( $id ) ) {
		add_settings_error( 'obento_avatars', 'obento_avatars_not_square', '既定アバターには正方形の画像を選んでください。' );
		return $saved;
	}
	if ( ! obento_avatars_is_default_format( $id ) ) {
		add_settings_error( 'obento_avatars', 'obento_avatars_bad_format', '既定アバターには、JPEG・PNG・GIFの画像を選んでください（GravatarがWebPなどを受け付けないため）。' );
		return $saved;
	}
	if ( ! empty( $input['activate'] ) ) {
		update_option( 'avatar_default', obento_avatars_default_sentinel() );
	}
	return array( 'default_id' => $id );
}

/**
 * ディスカッションの保存（option_page=discussion）でも、obento_avatarsを保存する
 *
 * @param array $allowed option group => option名の一覧。
 * @return array
 */
function obento_avatars_allowed_options( $allowed ) {
	$allowed['discussion'][] = 'obento_avatars';
	return $allowed;
}
add_filter( 'allowed_options', 'obento_avatars_allowed_options' );

/**
 * 既定アバターの欄を描く（タブとディスカッションで共通）
 *
 * hiddenのobento_avatars[activate]は0で出し、JS（assets/avatars.js）が新しく選んだときに1にする。
 * data-typesは、JSがモーダルの一覧を絞る形式（JPEG・PNG・GIF。プロフィールの欄にはない）。
 */
function obento_avatars_render_default_field() {
	$id     = obento_avatars_default_image_id();
	$url    = $id ? obento_avatars_image_url( $id, 96 ) : '';
	$active = obento_avatars_default_sentinel() === get_option( 'avatar_default' );
	?>
	<div class="obento-avatar-field" data-types="<?php echo esc_attr( implode( ',', obento_avatars_default_mime_types() ) ); ?>">
		<p><img class="obento-avatar-preview"<?php echo '' !== $url ? ' src="' . esc_url( $url ) . '"' : ' hidden'; ?> alt="" width="96" height="96"></p>
		<input type="hidden" class="obento-avatar-id" name="obento_avatars[default_id]" value="<?php echo $id ? esc_attr( (string) $id ) : ''; ?>">
		<input type="hidden" class="obento-avatar-activate" name="obento_avatars[activate]" value="0">
		<p class="hide-if-no-js">
			<button type="button" class="button obento-avatar-select"><?php echo esc_html( $id ? '画像を変更' : '画像を選ぶ' ); ?></button>
			<button type="button" class="button obento-avatar-remove<?php echo $id ? '' : ' hidden'; ?>">削除</button>
		</p>
		<p class="obento-avatar-error" role="alert" hidden></p>
		<?php if ( $id && ! $active ) : ?>
			<p class="obento-avatar-inactive">この画像は、いまは使われていません。「設定 &gt; ディスカッション」の「デフォルトアバター」で、別のものが選ばれています。</p>
		<?php endif; ?>
		<p class="description">アバターのない人（Gravatarに登録していない人など）に出す画像です。選んで保存すると、「設定 &gt; ディスカッション」の「デフォルトアバター」もこの画像に切り替わります。ディスカッションで別のものを選べば、そちらが使われます。JPEG・PNG・GIFの画像を選べます（GravatarがWebPなどを受け付けないため）。この画像はGravatarを通して配るため、インターネットから見えないサイト（ローカルやBasic認証付きのステージング）では、Gravatarの標準の画像が出ます。</p>
	</div>
	<?php
}

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_avatars_tab() {
	?>
	<?php if ( ! get_option( 'show_avatars' ) ) : ?>
		<div class="notice notice-warning inline"><p>「設定 &gt; ディスカッション」で「アバターを表示」がオフのため、アバターは表示されません。</p></div>
	<?php endif; ?>
	<p>ユーザーのアバターを、Gravatarではなくメディアライブラリの画像にできます。</p>
	<h2>既定アバター</h2>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_avatars' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row">既定アバターの画像</th>
				<td><?php obento_avatars_render_default_field(); ?></td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<h2>個人のアバター</h2>
	<p>各ユーザーのアバターは、プロフィールの「プロフィール写真」で設定します。メディアライブラリを使えるユーザー（投稿者以上）は、自分のアバターを設定できます。購読者と寄稿者のアバターは、管理者がそのユーザーの編集画面で設定します。</p>
	<p><a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>">自分のプロフィール</a> | <a href="<?php echo esc_url( admin_url( 'users.php' ) ); ?>">ユーザー一覧</a></p>
	<?php obento_avatars_render_migrate_section(); ?>
	<?php
}

/**
 * 「アバター」タブとディスカッションに、画像を選ぶ欄のスクリプトを読み込む
 *
 * @param string $hook 管理画面のページ（タブはsettings_page_obento-admin-pack）。
 */
function obento_avatars_screen_enqueue( $hook ) {
	$tab = 'settings_page_obento-admin-pack' === $hook && 'avatars' === obento_get_settings_tab();
	if ( ( $tab || 'options-discussion.php' === $hook ) && current_user_can( 'manage_options' ) ) {
		obento_avatars_enqueue_picker();
	}
}
add_action( 'admin_enqueue_scripts', 'obento_avatars_screen_enqueue' );
