<?php
/**
 * コメントの共通部分（純粋な関数）
 *
 * 設定（option obento_comments）の読み出しとsanitize、ピンバックの候補から自分のサイトへのリンクを外す関数。
 * フックは持たない。フックの登録はincludes/comments-apply.php、設定画面はincludes/comments-screen.phpが持つ。
 *
 * 「自分のサイト」はhome_url()とsite_url()のホスト（www.の有無とポートは見ない）。判定は外部リンクの
 * obento_external_classify()を再利用する（includes/external-links-common.php。先に読み込まれている）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定を返す（optionがない・壊れている・キーがないときは、どちらもオフ）
 *
 * @return array{disable: bool, no_self_ping: bool}
 */
function obento_comments_get_settings() {
	$option = get_option( 'obento_comments', array() );
	$option = is_array( $option ) ? $option : array();
	return array(
		'disable'      => ! empty( $option['disable'] ),
		'no_self_ping' => ! empty( $option['no_self_ping'] ),
	);
}

/**
 * 設定のsanitize（配列でなければ空として扱い、2つの値を真偽にする。知らないキーは捨てる）
 *
 * 警告を出す入力はない。保存の通知は「設定」メニュー配下なのでコアが出す。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{disable: bool, no_self_ping: bool}
 */
function obento_comments_sanitize_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	return array(
		'disable'      => ! empty( $input['disable'] ),
		'no_self_ping' => ! empty( $input['no_self_ping'] ),
	);
}

/**
 * ピンバックの候補から、自分のサイトへのリンクを外す
 *
 * コアのpingback()がwp_extract_urls()で集めたURL（http(s)://…・//…・ルート相対の/…など。同じ投稿へのリンクと
 * 添付ファイルは除いてある）を、外部リンクの判定（obento_external_classify()。サブドメインは内部にしない）に通し、
 * internalのものを外す。ルート相対の/…はinternalとして外れる。http(s)以外のスキーム（ftp://など）と壊れたURLはskip、
 * ほかのホストはexternalで、文字列でない値と一緒にそのまま残す。キーは詰め直す。
 *
 * @param string[] $links URL。
 * @param string[] $hosts 自分のサイトのホスト（obento_external_hosts( array( 'internal_hosts' => array() ) )。正規化済み）。
 * @return string[]
 */
function obento_comments_remove_self_links( $links, $hosts ) {
	$kept = array();
	foreach ( (array) $links as $link ) {
		if ( is_string( $link ) && 'internal' === obento_external_classify( $link, $hosts, false ) ) {
			continue;
		}
		$kept[] = $link;
	}
	return $kept;
}
