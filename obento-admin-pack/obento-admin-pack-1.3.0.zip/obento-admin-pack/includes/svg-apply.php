<?php
/**
 * SVGのフック（アップロードの許可、サニタイズ、表示の補正）
 *
 * アップロードの許可（upload_mimes / wp_check_filetype_and_ext）は、設定（option obento_svg）で選んだロールの人だけ。
 * サニタイズは権限を問わず、拡張子がsvgのファイルすべてにかける（ほかのプラグインがSVGを許していても通す）。
 * 時点は3つ: アップロード前の一時ファイル、uploadsへ移した後、メタデータの生成時（wp_upload_bits()で書く経路を拾う）。
 * 表示の補正（メタデータの寸法、image_downsize、メディアライブラリ）は、設定に関係なく常に効かせる。
 *
 * is_admin()の外で読む（RESTのメディアのアップロード、sideload、表側のwp_get_attachment_image()で効かせる）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 許可した人に、拡張子svgを許す（upload_mimes）
 *
 * 優先度は5。マルチサイトでコアが同じフィルターに付けるcheck_upload_mimes（優先度10。ネットワークの
 * 「アップロード可能なファイルの種類」で絞る）より先に足し、ネットワーク管理者が許していなければ、そこで外れるようにする。
 *
 * @param array<string, string> $mimes 拡張子 => MIME。
 * @param WP_User|int|null      $user  ユーザー（nullなら今のユーザー）。
 * @return array<string, string>
 */
function obento_svg_upload_mimes( $mimes, $user = null ) {
	if ( obento_svg_user_can_upload( $user ) ) {
		$mimes['svg'] = 'image/svg+xml';
	}
	return $mimes;
}
add_filter( 'upload_mimes', 'obento_svg_upload_mimes', 5, 2 );

/**
 * 許可した人のSVGを、中身の判定（finfo）に関係なくSVGとして通す（wp_check_filetype_and_ext）
 *
 * finfoはSVGを、XML宣言の有無やlibmagicの版によってtext/xmlなどと読み、コアは拡張子と違うと拒否する。
 * 中身がSVGとして読めるかは、アップロード前のサニタイズで確かめる（読めなければ拒否する）。
 *
 * @param array  $data     ext / type / proper_filename。
 * @param string $file     一時ファイルのパス（使わない）。
 * @param string $filename 元のファイル名。
 * @return array
 */
function obento_svg_fix_filetype( $data, $file, $filename ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundBeforeLastUsed -- フィルターの引数の順
	if ( obento_svg_has_svg_extension( $filename ) && obento_svg_user_can_upload() ) {
		$data['ext']  = 'svg';
		$data['type'] = 'image/svg+xml';
	}
	return $data;
}
add_filter( 'wp_check_filetype_and_ext', 'obento_svg_fix_filetype', 75, 3 );

/**
 * アップロード前の一時ファイルをサニタイズする（wp_handle_upload_prefilter / wp_handle_sideload_prefilter）
 *
 * 失敗したらerrorに文言を入れ、コアにアップロードを止めさせる。
 *
 * @param array $file $_FILESの1件と同じ形（sideloadではerrorとsizeがないことがある）。
 * @return array
 */
function obento_svg_prefilter( $file ) {
	if ( ! is_array( $file ) || ! empty( $file['error'] ) || empty( $file['tmp_name'] ) || ! isset( $file['name'] ) || ! obento_svg_has_svg_extension( $file['name'] ) ) {
		return $file;
	}
	$clean = obento_svg_sanitize_file( $file['tmp_name'] );
	if ( is_wp_error( $clean ) ) {
		$file['error'] = $clean->get_error_message();
	}
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'obento_svg_prefilter' );
add_filter( 'wp_handle_sideload_prefilter', 'obento_svg_prefilter' );

/**
 * uploadsへ移したSVGを、もう一度サニタイズする（wp_handle_upload。sideloadでも呼ばれる）
 *
 * あいだに別のプラグインが一時ファイルを差し替えても、未サニタイズのまま残さない。失敗したらファイルを消してエラーを返す。
 *
 * @param array $upload file / url / type。
 * @return array
 */
function obento_svg_after_upload( $upload ) {
	if ( ! is_array( $upload ) || isset( $upload['error'] ) || empty( $upload['file'] ) ) {
		return $upload;
	}
	$type = isset( $upload['type'] ) ? $upload['type'] : '';
	if ( 'image/svg+xml' !== $type && ! obento_svg_has_svg_extension( $upload['file'] ) ) {
		return $upload;
	}
	$clean = obento_svg_sanitize_file( $upload['file'] );
	if ( ! is_wp_error( $clean ) ) {
		return $upload;
	}
	return array( 'error' => obento_svg_delete_unsafe_file( $upload['file'], $clean->get_error_message() ) );
}
add_filter( 'wp_handle_upload', 'obento_svg_after_upload' );

/**
 * SVGのメタデータを作る（wp_generate_attachment_metadata）
 *
 * ファイルをもう一度サニタイズする（wp_upload_bits()で書く経路は、前の2つを通らない）。失敗したらファイルを消し、
 * 画面に出せないのでerror_logへ1行残す。サニタイズした内容から寸法を出し、width / height / fileを入れる。
 * sizesは作らない（srcsetを出さないため）。filesizeは、コアがサニタイズ前の大きさを入れているので入れ直す。
 *
 * @param array $metadata      メタデータ。
 * @param int   $attachment_id 添付ファイルのID。
 * @return array
 */
function obento_svg_generate_metadata( $metadata, $attachment_id ) {
	if ( ! obento_svg_is_svg_attachment( $attachment_id ) ) {
		return $metadata;
	}
	$file = get_attached_file( $attachment_id );
	if ( ! $file || ! file_exists( $file ) ) {
		return $metadata;
	}
	$clean = obento_svg_sanitize_file( $file );
	if ( is_wp_error( $clean ) ) {
		$message = obento_svg_delete_unsafe_file( $file, $clean->get_error_message() );
		error_log( sprintf( 'Obento Admin Pack: 添付ファイル%dのSVG: %s', $attachment_id, $message ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 画面に出せない文脈で、ファイルを消したことを黙って捨てないため
		return $metadata;
	}
	$metadata   = is_array( $metadata ) ? $metadata : array();
	$dimensions = obento_svg_dimensions_from_markup( $clean );
	if ( $dimensions ) {
		$metadata['width']  = $dimensions['width'];
		$metadata['height'] = $dimensions['height'];
	}
	$metadata['file']     = _wp_relative_upload_path( $file );
	$metadata['filesize'] = wp_filesize( $file );
	return $metadata;
}
add_filter( 'wp_generate_attachment_metadata', 'obento_svg_generate_metadata', 10, 2 );

/**
 * SVGの画像のURLと寸法を返す（image_downsize）
 *
 * コアのimage_downsize()は、SVGでも原本のURLを返すが、寸法はメタデータのwidth / heightだけを見る（Haku2などで上げた既存のSVGは0になり、
 * wp_get_attachment_image()がwidth / heightのないimgを出す）。中間サイズがないので、名前付きのサイズのis_intermediateは偽になり、
 * メディアのモーダルの「サイズ」に原寸しか出ない。ここでは、どのサイズでも原本のURLを返し、寸法はファイルからも出して、サイズの枠に収める。
 * 寸法が出せなければ0（wp_get_attachment_image()は0のwidth / heightを出さない）。
 *
 * @param array|false  $downsize      ほかのフィルターの結果。
 * @param int          $attachment_id 添付ファイルのID。
 * @param string|int[] $size          サイズの名前か、array( 幅, 高さ )。
 * @return array|false
 */
function obento_svg_image_downsize( $downsize, $attachment_id, $size ) {
	if ( $downsize || ! obento_svg_is_svg_attachment( $attachment_id ) ) {
		return $downsize;
	}
	$url = wp_get_attachment_url( $attachment_id );
	if ( ! $url ) {
		return $downsize;
	}
	$dimensions = obento_svg_dimensions( $attachment_id );
	if ( ! $dimensions ) {
		return array( $url, 0, 0, false );
	}
	list( $width, $height, $is_intermediate ) = obento_svg_fit_size( $dimensions['width'], $dimensions['height'], $size );
	list( $width, $height )                   = image_constrain_size_for_editor( $width, $height, $size );
	return array( $url, $width, $height, $is_intermediate );
}
add_filter( 'image_downsize', 'obento_svg_image_downsize', 10, 3 );

/**
 * メタデータに寸法のない既存のSVGを、メディアライブラリで寸法つきにする（wp_prepare_attachment_for_js）
 *
 * 新しく上げたSVGは、メタデータの寸法とimage_downsizeの補正で、コアが寸法とsizesを作るので触らない。
 *
 * @param array   $response   メディアライブラリに渡す値。
 * @param WP_Post $attachment 添付ファイル。
 * @return array
 */
function obento_svg_prepare_attachment_for_js( $response, $attachment ) {
	if ( ! isset( $response['mime'] ) || 'image/svg+xml' !== $response['mime'] || ! empty( $response['width'] ) ) {
		return $response;
	}
	$dimensions = obento_svg_dimensions( $attachment->ID );
	if ( ! $dimensions ) {
		return $response;
	}
	$full              = array(
		'url'         => $response['url'],
		'width'       => $dimensions['width'],
		'height'      => $dimensions['height'],
		'orientation' => $dimensions['height'] > $dimensions['width'] ? 'portrait' : 'landscape',
	);
	$response          = array_merge( $response, $full );
	$sizes             = isset( $response['sizes'] ) && is_array( $response['sizes'] ) ? $response['sizes'] : array();
	$sizes['full']     = $full;
	$response['sizes'] = $sizes;
	return $response;
}
add_filter( 'wp_prepare_attachment_for_js', 'obento_svg_prepare_attachment_for_js', 10, 2 );
