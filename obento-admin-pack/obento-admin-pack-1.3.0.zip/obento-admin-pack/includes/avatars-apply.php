<?php
/**
 * アバター: 表示のフック
 *
 * pre_get_avatar_dataで、個人のアバター（メディアライブラリの画像）のURLを先に決める（コアはGravatarのURLを作る前に止まる）。
 * 既定アバターは、コアのavatar_defaultに入れた目印（obento_avatar）を、表示のときに画像のURLに置き換える
 * （通常はGravatarのd=、force_default（ディスカッションの選択肢のプレビュー）ではurl）。
 * avatar_defaultsに「選んだ画像」を足し、添付ファイルの削除に追従する。is_admin()の外で読む（表側のコメント欄や著者の表示で動く）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * アバターのURLを先に決める（pre_get_avatar_data）
 *
 * ほかのプラグインがurlを決めていればそのまま。force_defaultと、引数obento_avatars_skip（プロフィールのプレビューの戻り先を
 * 求めるとき）では個人のアバターを使わない。既定が目印のときは、画像が有効なら置き換え、なければmm（ミステリーパーソン）にする。
 *
 * @param array $args        get_avatar_data()の引数（size、default、force_defaultなど）。
 * @param mixed $id_or_email get_avatar()の第1引数。
 * @return array
 */
function obento_avatars_pre_get_avatar_data( $args, $id_or_email ) {
	if ( isset( $args['url'] ) ) {
		return $args;
	}
	$size = isset( $args['size'] ) ? (int) $args['size'] : 96;
	if ( empty( $args['force_default'] ) && empty( $args['obento_avatars_skip'] ) ) {
		$url = obento_avatars_user_avatar_url( obento_avatars_resolve_user_id( $id_or_email ), $size );
		if ( '' !== $url ) {
			$args['url']          = $url;
			$args['found_avatar'] = true;
			return $args;
		}
	}
	if ( isset( $args['default'] ) && obento_avatars_default_sentinel() === $args['default'] ) {
		$default_id = obento_avatars_default_image_id();
		$url        = $default_id ? obento_avatars_image_url( $default_id, $size ) : '';
		if ( '' === $url ) {
			$args['default'] = 'mm';
		} elseif ( ! empty( $args['force_default'] ) ) {
			$args['url'] = $url;
		} else {
			$args['default'] = $url;
		}
	}
	return $args;
}
add_filter( 'pre_get_avatar_data', 'obento_avatars_pre_get_avatar_data', 10, 2 );

/**
 * デフォルトアバターの選択肢に「選んだ画像」を足す（既定アバターの画像が有効なとき、または目印が選ばれているあいだ）
 *
 * 画像が使えなくなった（メディアで正方形でなくした、形式が対象外になったなど）のにavatar_defaultが目印のまま残ると、
 * 選択肢を消してしまえばラジオのどれにもチェックが入らず、そのまま保存するとavatar_defaultが空で保存される。
 * 選択肢を残せば、表示は画像がなくてmm（ミステリーパーソン）のまま、ラジオは「選んだ画像」に入る。
 *
 * @param string[] $defaults 値 => 表示名。
 * @return string[]
 */
function obento_avatars_defaults( $defaults ) {
	if ( obento_avatars_default_image_id() || obento_avatars_default_sentinel() === get_option( 'avatar_default' ) ) {
		$defaults[ obento_avatars_default_sentinel() ] = '選んだ画像';
	}
	return $defaults;
}
add_filter( 'avatar_defaults', 'obento_avatars_defaults' );

/**
 * コアのavatar_defaultが目印ならmysteryに戻す（既定アバターの画像を外したとき、消えたとき、停止したとき）
 */
function obento_avatars_reset_avatar_default() {
	if ( obento_avatars_default_sentinel() === get_option( 'avatar_default' ) ) {
		update_option( 'avatar_default', 'mystery' );
	}
}

/**
 * 添付ファイルの削除に追従する（delete_attachment）
 *
 * その画像をアバターにしているユーザーのメタを消す。既定アバターの画像なら、default_idを0にして、目印のavatar_defaultを戻す。
 *
 * @param int $post_id 削除する添付ファイル。
 */
function obento_avatars_delete_attachment( $post_id ) {
	$post_id = (int) $post_id;
	delete_metadata( 'user', 0, obento_avatars_user_meta_key(), $post_id, true );
	if ( obento_avatars_get_settings()['default_id'] === $post_id ) {
		update_option( 'obento_avatars', array( 'default_id' => 0 ) );
		obento_avatars_reset_avatar_default();
	}
}
add_action( 'delete_attachment', 'obento_avatars_delete_attachment' );

/**
 * 停止したときの後始末（register_deactivation_hook。obento-admin-pack.phpで登録する）
 *
 * 目印のavatar_defaultをmysteryに戻す（戻さないと、停止中はGravatarにd=obento_avatarという意味のない値が渡る）。
 * 再び有効にしたら、ディスカッションで「選んだ画像」を選び直す。ネットワークで停止したときは全サイトを回す。
 *
 * @param bool $network_wide ネットワークで停止したか。
 */
function obento_avatars_deactivate( $network_wide ) {
	if ( is_multisite() && $network_wide ) {
		$site_ids = get_sites(
			array(
				'fields' => 'ids',
				'number' => 0,
			)
		);
		foreach ( $site_ids as $site_id ) {
			switch_to_blog( $site_id );
			obento_avatars_reset_avatar_default();
			restore_current_blog();
		}
		return;
	}
	obento_avatars_reset_avatar_default();
}
