<?php
/**
 * 「SVG」タブ（設定 > Obento Admin Pack）
 *
 * option obento_svgの登録と、タブの描画。保存はSettings API。option groupはobento_svg
 * （ほかのタブとは別。片方の保存でもう片方を消さない）。読み出しとsanitizeはincludes/svg-common.phpの関数。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_svg_setting() {
	register_setting(
		'obento_svg',
		'obento_svg',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_svg_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_svg_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_svg_tab() {
	$settings = obento_svg_get_settings();
	?>
	<p>メディアライブラリにSVGを上げられるようにします。上げるたびに、スクリプトや外部のファイルへの参照などを取り除いてから保存します。取り除けないファイルは受け付けません。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_svg' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row"><label for="obento-svg-enabled">SVGのアップロードを許可する</label></th>
				<td>
					<input type="checkbox" id="obento-svg-enabled" name="obento_svg[enabled]" value="1"<?php checked( $settings['enabled'] ); ?>>
					<p class="description">オフでも、すでにあるSVGは、メディアライブラリと表側で正しい大きさで出します。すでにあるSVGはサニタイズし直しません。<code>.svgz</code>は扱いません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row">アップロードできるロール</th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">アップロードできるロール</legend>
						<?php foreach ( obento_svg_upload_roles() as $slug => $name ) : ?>
							<label><input type="checkbox" name="obento_svg[roles][]" value="<?php echo esc_attr( $slug ); ?>"<?php checked( in_array( $slug, $settings['roles'], true ) ); ?>> <?php echo esc_html( $name ); ?></label><br>
						<?php endforeach; ?>
					</fieldset>
					<p class="description">メディアをアップロードできる（<code>upload_files</code>を持つ）ロールだけを並べています。</p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<?php
}
