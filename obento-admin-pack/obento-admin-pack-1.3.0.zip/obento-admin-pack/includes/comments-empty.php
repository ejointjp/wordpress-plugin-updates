<?php
/**
 * 空のコメントテンプレート
 *
 * 「コメントとピンバック・トラックバックを止める」がオンのとき、comments_templateフィルター（includes/comments-apply.php）が
 * テーマのcomments.phpの代わりに返す。何も出力しない。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
