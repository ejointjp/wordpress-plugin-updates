<?php
/**
 * 「コメント」タブ（設定 > Obento Admin Pack）
 *
 * option obento_commentsの登録と、タブの描画。保存はSettings API。option groupはobento_comments
 * （ほかのタブとは別。片方の保存でもう片方を消さない）。読み出しとsanitizeはincludes/comments-common.phpの関数。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_comments_setting() {
	register_setting(
		'obento_comments',
		'obento_comments',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_comments_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_comments_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_comments_tab() {
	$settings = obento_comments_get_settings();
	?>
	<p>コメントにまつわる設定です。すでにある投稿のコメントの設定と、すでにあるコメントは変えません。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_comments' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row"><label for="obento-comments-disable">コメントとピンバック・トラックバックを止める</label></th>
				<td>
					<input type="checkbox" id="obento-comments-disable" name="obento_comments[disable]" value="1"<?php checked( $settings['disable'] ); ?>>
					<p class="description">すべての投稿タイプで受け付けを止めます。表側のコメント欄と一覧、管理画面の「コメント」メニューとツールバーの項目、REST APIのコメント、コメントのフィード、XML-RPCのピンバックも止めます。</p>
					<p class="description">すでにあるコメントは消しません（<code>wp-admin/edit-comments.php</code>を開けば一覧が出て、削除できます）。止めているあいだに新しく作った投稿は、コメントを受け付けない設定で保存されます。止めるのをやめても、その投稿は閉じたままです（投稿の「ディスカッション」で開けます）。ほかのブログへの通知（リンク先にピンバックを送る）は止めません（「設定 &gt; ディスカッション」で切れます）。ブロックエディターの「メモ」は止めません。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-comments-no-self-ping">自分のサイトへのピンバックを送らない</label></th>
				<td>
					<input type="checkbox" id="obento-comments-no-self-ping" name="obento_comments[no_self_ping]" value="1"<?php checked( $settings['no_self_ping'] ); ?>>
					<p class="description">本文で自分のサイトの別のページにリンクしたとき、WordPressは自分自身にピンバックを送り、リンク先に「○○からリンクされました」というコメントが付きます。これを送らないようにします。<code>www.</code>の有無とポートは見ません。パスは見ないので、同じドメインのほかのサイトへも送りません。別のドメインの自分のサイトへは送ります。</p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<?php
}
