<?php
/**
 * 外部リンクの共通部分（純粋な関数）
 *
 * 設定（option obento_external_links）の読み出しとsanitize、内部として扱うホストの集合、hrefの判定、
 * HTMLの書き換え（WP_HTML_Tag_Processorで<a>の属性だけを変える）。
 * フックは持たない。表側のob_start()とCSSの読み込みはincludes/external-links-front.php、設定画面はincludes/external-links-screen.phpが持つ。
 *
 * 保存した本文は変えない。表示するときの最終のHTMLだけを書き換える。既存のtargetは上書きせず、relは既存の値に足す。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 外部リンクのrelに足せる値（この順に保存する）
 *
 * noopenerはここに入れない。「新しいタブで開く」とセットで付ける。
 *
 * @return string[]
 */
function obento_external_rel_values() {
	return array( 'noreferrer', 'nofollow', 'external' );
}

/**
 * 設定を返す（optionがない・壊れている・キーがないときは、すべてオフ・空）
 *
 * relは文字列の値のうちobento_external_rel_values()にあるものだけ（その順）。internal_hostsは空でない文字列の値だけ
 * （正規化はsanitizeの仕事なので、ここではしない）。
 *
 * @return array{new_tab: bool, rel: string[], icon: bool, pdf_new_tab: bool, internal_hosts: string[], subdomains: bool}
 */
function obento_external_get_settings() {
	$option = get_option( 'obento_external_links', array() );
	$option = is_array( $option ) ? $option : array();
	$rel    = isset( $option['rel'] ) && is_array( $option['rel'] ) ? array_filter( $option['rel'], 'is_string' ) : array();
	$hosts  = isset( $option['internal_hosts'] ) && is_array( $option['internal_hosts'] ) ? array_filter( $option['internal_hosts'], 'is_string' ) : array();
	return array(
		'new_tab'        => ! empty( $option['new_tab'] ),
		'rel'            => array_values( array_intersect( obento_external_rel_values(), $rel ) ),
		'icon'           => ! empty( $option['icon'] ),
		'pdf_new_tab'    => ! empty( $option['pdf_new_tab'] ),
		'internal_hosts' => array_values( array_filter( $hosts, 'strlen' ) ),
		'subdomains'     => ! empty( $option['subdomains'] ),
	);
}

/**
 * 設定のどれかがオンか（オフなら表側で何もしない）
 *
 * internal_hostsとsubdomainsは判定を変えるだけなので、これだけではオンにならない。
 *
 * @param array $settings obento_external_get_settings()の値。
 * @return bool
 */
function obento_external_is_active( $settings ) {
	return $settings['new_tab'] || ! empty( $settings['rel'] ) || $settings['icon'] || $settings['pdf_new_tab'];
}

/**
 * ホストを正規化する（小文字にし、末尾の「.」と先頭の「www.」を落とす）
 *
 * strtolower()はASCIIだけを変える。日本語ドメイン（Unicode）はそのまま。
 *
 * @param string $host ホスト。
 * @return string 空になれば''。
 */
function obento_external_normalize_host( $host ) {
	$host = rtrim( strtolower( trim( (string) $host ) ), '.' );
	if ( 0 === strpos( $host, 'www.' ) ) {
		$host = substr( $host, 4 );
	}
	return $host;
}

/**
 * 「内部として扱うドメイン」の入力を、正規化したホストの配列にする
 *
 * textareaの文字列は1行1つ。配列（初回の保存の2回目のsanitizeや、update_option()に配列を渡したとき）は、文字列の値を行として扱う。
 * 各行は、前後の空白（全角スペースとNBSPを含む。貼り付けで混ざる）を取り、「://」より後ろだけを使い、最初の/・?・#以降（パス・クエリ・フラグメント）と末尾の:数字（ポート）を落とし、
 * obento_external_normalize_host()で整える。文字・数字・.・-・_以外を含む行と、空になった行は捨てる。重複は1つにする。
 * 日本語ドメインはUnicodeのままでもPunycode（xn--）でも通すが、変換はしない（リンクのhrefと同じ書き方のときだけ一致する）。
 *
 * @param mixed $text    textareaの文字列か、文字列の配列。それ以外は空として扱う。
 * @param array $dropped 捨てた行（元の文字列）を受ける。
 * @return string[]
 */
function obento_external_sanitize_hosts( $text, &$dropped = array() ) {
	$dropped = array();
	if ( is_array( $text ) ) {
		$text = implode( "\n", array_filter( $text, 'is_string' ) );
	}
	$lines = is_string( $text ) ? preg_split( '/\r\n|\r|\n/', $text ) : array();
	$hosts = array();
	foreach ( $lines as $line ) {
		// UTF-8として読めない行はpreg_replace()がnullを返す。trim()に戻して、下の判定で捨てる
		$stripped = preg_replace( '/^[\s\x{3000}\x{00A0}]+|[\s\x{3000}\x{00A0}]+$/u', '', $line );
		$line     = null === $stripped ? trim( $line ) : $stripped;
		if ( '' === $line ) {
			continue;
		}
		$host = $line;
		$pos  = strpos( $host, '://' );
		if ( false !== $pos ) {
			$host = substr( $host, $pos + 3 );
		}
		$host = preg_replace( '/[\/?#].*$/s', '', $host );
		$host = preg_replace( '/:\d+$/', '', $host );
		$host = obento_external_normalize_host( $host );
		if ( '' === $host || ! preg_match( '/^[\p{L}\p{N}][\p{L}\p{N}._-]*$/u', $host ) ) {
			$dropped[] = $line;
			continue;
		}
		if ( ! in_array( $host, $hosts, true ) ) {
			$hosts[] = $host;
		}
	}
	return $hosts;
}

/**
 * 設定のsanitize
 *
 * 真偽の値は! empty()、relはobento_external_rel_values()にあるものだけ（その順）、internal_hostsはobento_external_sanitize_hosts()。
 * 捨てた行があれば警告の通知で知らせる（保存は通す）。コアのoptions.phpは、警告が1つでもあると「設定を保存しました。」を足さないので、
 * 警告を登録する前に、コアと同じ保存の通知を先に登録して、両方を出す。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{new_tab: bool, rel: string[], icon: bool, pdf_new_tab: bool, internal_hosts: string[], subdomains: bool}
 */
function obento_external_sanitize_settings( $input ) {
	$input   = is_array( $input ) ? $input : array();
	$dropped = array();
	$hosts   = obento_external_sanitize_hosts( isset( $input['internal_hosts'] ) ? $input['internal_hosts'] : '', $dropped );
	if ( $dropped ) {
		obento_cleanup_add_settings_error( 'general', 'settings_updated', '設定を保存しました。', 'success' );
		obento_cleanup_add_settings_error(
			'obento_external_links',
			'obento_external_hosts_dropped',
			'次の行はドメインとして読めないので、保存しませんでした: ' . implode( '、', $dropped ),
			'warning'
		);
	}
	return array(
		'new_tab'        => ! empty( $input['new_tab'] ),
		'rel'            => obento_sanitize_name_list( $input, 'rel', obento_external_rel_values() ),
		'icon'           => ! empty( $input['icon'] ),
		'pdf_new_tab'    => ! empty( $input['pdf_new_tab'] ),
		'internal_hosts' => $hosts,
		'subdomains'     => ! empty( $input['subdomains'] ),
	);
}

/**
 * 内部として扱うホストの集合（home_url()とsite_url()のホストと、設定のinternal_hosts。正規化済み、重複なし）
 *
 * ポートは見ない（localhost:8080のサイトで、localhostへのリンクは内部）。
 *
 * @param array $settings obento_external_get_settings()の値（internal_hostsだけ使う）。
 * @return string[]
 */
function obento_external_hosts( $settings ) {
	$hosts = array();
	foreach ( array( home_url(), site_url() ) as $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( is_string( $host ) ) {
			$hosts[] = obento_external_normalize_host( $host );
		}
	}
	foreach ( $settings['internal_hosts'] as $host ) {
		$hosts[] = obento_external_normalize_host( $host );
	}
	return array_values( array_unique( array_filter( $hosts, 'strlen' ) ) );
}

/**
 * hrefを判定する
 *
 * 1. 空、または#で始まる→skip
 * 2. スキームがあって、httpかhttpsでない（mailto: tel: javascript:など）→skip
 * 3. スキームがなく、//で始まらない→相対URL→internal
 * 4. ホストが取れない（http:fooのような壊れたURL）→skip
 * 5. 正規化したホストが$hostsのどれかと同じ→internal。$subdomainsなら、$hostsのどれかに.を付けたもので終わる（shop.example.com）→internal
 * 6. それ以外→external
 *
 * @param string   $href       hrefの値（実体参照は解決済み）。
 * @param string[] $hosts      内部として扱うホスト（obento_external_hosts()）。
 * @param bool     $subdomains 内部のホストのサブドメインも内部にするか。
 * @return string skip / internal / external。
 */
function obento_external_classify( $href, $hosts, $subdomains ) {
	$href = trim( (string) $href );
	if ( '' === $href || '#' === $href[0] ) {
		return 'skip';
	}
	if ( preg_match( '/^([a-z][a-z0-9+.\-]*):/i', $href, $m ) ) {
		if ( ! in_array( strtolower( $m[1] ), array( 'http', 'https' ), true ) ) {
			return 'skip';
		}
	} elseif ( 0 !== strpos( $href, '//' ) ) {
		return 'internal';
	}
	$host = wp_parse_url( $href, PHP_URL_HOST );
	if ( ! is_string( $host ) ) {
		return 'skip';
	}
	$host = obento_external_normalize_host( $host );
	if ( '' === $host ) {
		return 'skip';
	}
	foreach ( $hosts as $internal ) {
		if ( $host === $internal || ( $subdomains && substr( $host, -strlen( $internal ) - 1 ) === '.' . $internal ) ) {
			return 'internal';
		}
	}
	return 'external';
}

/**
 * PDFへのリンクか（パスの末尾が.pdf。大文字小文字は見ない。クエリと#は無視する）
 *
 * 相対URL（/files/a.pdf）も同じ。
 *
 * @param string $href hrefの値。
 * @return bool
 */
function obento_external_is_pdf( $href ) {
	$path = wp_parse_url( trim( (string) $href ), PHP_URL_PATH );
	return is_string( $path ) && (bool) preg_match( '/\.pdf$/i', $path );
}

/**
 * 止まっている<a>のrelに値を足す（既存の値は残し、ないものだけを後ろに足す。大文字小文字は見ない）
 *
 * 値なしのrel（get_attribute()がtrueを返す）は空として扱う。足すものがなければset_attribute()しない。
 *
 * @param WP_HTML_Tag_Processor $p   <a>に止まっているプロセッサー。
 * @param string[]              $add 足す値。
 */
function obento_external_merge_rel( $p, $add ) {
	$rel    = $p->get_attribute( 'rel' );
	$tokens = is_string( $rel ) ? preg_split( '/\s+/', trim( $rel ), -1, PREG_SPLIT_NO_EMPTY ) : array();
	$lower  = array_map( 'strtolower', $tokens );
	$added  = false;
	foreach ( $add as $value ) {
		if ( ! in_array( strtolower( $value ), $lower, true ) ) {
			$tokens[] = $value;
			$lower[]  = strtolower( $value );
			$added    = true;
		}
	}
	if ( $added ) {
		$p->set_attribute( 'rel', implode( ' ', $tokens ) );
	}
}

/**
 * HTMLの外部リンクとPDFへのリンクに属性を足す（WP_HTML_Tag_Processor）
 *
 * <a>ごとに:
 * 1. hrefが文字列でなければ（ない、値なし）飛ばす
 * 2. 判定がskipなら飛ばす
 * 3. 新しいタブで開く（外部でnew_tab、またはpdf_new_tabでPDF）なら、targetがなければ_blankを足す。
 *    targetが_blank（もともとでも、今足したものでも）ならrelにnoopenerを足す。target=""は「ある」として触らない
 * 4. 外部なら、設定のrelの値を足し、iconならクラスobento-externalを足す
 * 5. relは既存の値に、ないものだけを後ろに足す
 *
 * WP_HTML_Tag_Processorは<script>・コメント・<textarea>の中をタグとして読まない。
 *
 * @param string   $html     HTML。
 * @param array    $settings obento_external_get_settings()の値。
 * @param string[] $hosts    obento_external_hosts()の値。
 * @return string
 */
function obento_external_rewrite( $html, $settings, $hosts ) {
	$p = new WP_HTML_Tag_Processor( $html );
	while ( $p->next_tag( 'a' ) ) {
		$href = $p->get_attribute( 'href' );
		if ( ! is_string( $href ) ) {
			continue;
		}
		$kind = obento_external_classify( $href, $hosts, $settings['subdomains'] );
		if ( 'skip' === $kind ) {
			continue;
		}
		$add     = array();
		$new_tab = ( 'external' === $kind && $settings['new_tab'] ) || ( $settings['pdf_new_tab'] && obento_external_is_pdf( $href ) );
		if ( $new_tab ) {
			$target = $p->get_attribute( 'target' );
			if ( null === $target ) {
				$p->set_attribute( 'target', '_blank' );
				$target = '_blank';
			}
			if ( is_string( $target ) && '_blank' === strtolower( $target ) ) {
				$add[] = 'noopener';
			}
		}
		if ( 'external' === $kind ) {
			$add = array_merge( $add, $settings['rel'] );
			if ( $settings['icon'] ) {
				$p->add_class( 'obento-external' );
			}
		}
		if ( $add ) {
			obento_external_merge_rel( $p, $add );
		}
	}
	return $p->get_updated_html();
}
