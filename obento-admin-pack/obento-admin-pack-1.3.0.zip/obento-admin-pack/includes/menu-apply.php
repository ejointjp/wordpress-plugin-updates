<?php
/**
 * 管理メニューの編集を効かせる
 *
 * - 区切り線の足し引き: admin_menuの最後（PHP_INT_MAX）で、消した区切り線を$menuから除き、足した区切り線を末尾に足す
 *   （並びは下のmenu_orderで決まる）。区切り線はページではないので、ここで消しても権限の判定に関わらない
 * - 名前とサブの並び: 同じadmin_menuの最後で$menu / $submenuを書き換える
 * - トップの並び: custom_menu_order / menu_orderで、保存した並びに新しい項目を差し込んだ完全な並びを返す
 *   （コアのsort_menu()は、menu_orderにないslugを末尾へ送るので、保存した並びをそのまま返さない）
 * - 非表示: 描画の直前（parent_fileフィルター。menu-header.phpの先頭）で$menu / $submenuから消す。
 *   コアの権限判定（user_can_access_admin_page()）とフック名の決定はすでに終わっているので、隠したページをURLで直接開いても壊れない。
 *   remove_menu_page()は使わない（admin_menuの最後で消すと、コアの権限判定の前なので、隠したプラグインの画面が開けなくなる）
 * - 区切り線の片付け: 同じ描画の直前に、先頭・連続・末尾の区切り線を消して、先頭・末尾のクラスを付け直す。
 *   項目を隠したときに加えて、保存した並びがあるときは、何も隠さなくても走る。コアは並べ替えのあとの連続と末尾の区切り線は片付けるが、
 *   先頭の区切り線は片付けない。しかもadd_menu_classes()が先頭（キー0）をダッシュボードとして扱うので、先頭の区切り線にmenu-top-firstが付き、
 *   先頭の項目には付かない。何も消えなかったときは$menuに手を付けず、コアが付けたクラスをそのまま残す
 *
 * 設定画面に出す元のメニューは、区切り線を足し引きしたあと、名前と並びを書き換える直前に写し取る（設定画面を開いているときだけ）。
 * ネットワーク管理画面とユーザー管理画面には効かせない（admin_menuはそこでは発火しないが、menu_orderとparent_fileは走る）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * このプラグインの設定画面（設定 > Obento Admin Pack）を開いているか
 *
 * @return bool
 */
function obento_menu_is_settings_screen() {
	global $pagenow;
	if ( 'options-general.php' !== $pagenow || ! isset( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 開いている画面の判定に使うだけ
		return false;
	}
	return 'obento-admin-pack' === sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 同上
}

/**
 * 設定画面に出す元のメニュー（名前と並びを書き換える前の$menu / $submenu）
 *
 * @param array|null $store 保存する値。読むだけならnull。
 * @return array{menu: array, submenu: array}|null
 */
function obento_menu_snapshot( $store = null ) {
	static $snapshot = null;
	if ( null !== $store ) {
		$snapshot = $store;
	}
	return $snapshot;
}

/**
 * 区切り線の足し引きと、名前とサブの並びを効かせる（admin_menuの最後）
 *
 * 設定画面を開いているときは、区切り線を足し引きしたあと、名前とサブの並びを書き換える前の$menu / $submenuを写し取る
 * （表に、いまの区切り線をそのまま描くため）。
 */
function obento_menu_apply_on_admin_menu() {
	global $menu, $submenu;
	$settings = obento_get_menu_settings();
	if ( $settings['added_separators'] || $settings['removed_separators'] ) {
		$menu = obento_menu_apply_separators( (array) $menu, $settings ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 区切り線を足し引きするのがこの機能の目的。区切り線はページではないので、権限の判定に関わらない
	}
	if ( obento_menu_is_settings_screen() ) {
		obento_menu_snapshot(
			array(
				'menu'    => (array) $menu,
				'submenu' => (array) $submenu,
			)
		);
	}
	if ( ! $settings['labels']['top'] && ! $settings['labels']['sub'] && ! $settings['sub_order'] ) {
		return;
	}
	$result  = obento_menu_apply_titles_and_sub_order( (array) $menu, (array) $submenu, $settings );
	$menu    = $result['menu']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 管理メニューの名前とサブの並びを変えるのがこの機能の目的
	$submenu = $result['submenu']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 同上
}
add_action( 'admin_menu', 'obento_menu_apply_on_admin_menu', PHP_INT_MAX );

/**
 * トップの並びを変えるか（保存した並びがあるときだけ真にする）
 *
 * @param bool $custom ほかのプラグインの値。
 * @return bool
 */
function obento_menu_custom_menu_order( $custom ) {
	if ( is_network_admin() || is_user_admin() ) {
		return $custom;
	}
	$settings = obento_get_menu_settings();
	return $custom || ! empty( $settings['order'] );
}
add_filter( 'custom_menu_order', 'obento_menu_custom_menu_order' );

/**
 * トップの並び（保存した並びに新しい項目を差し込んだ完全な並び）
 *
 * @param array $menu_order コアの並び（slugの配列）。
 * @return array
 */
function obento_menu_menu_order( $menu_order ) {
	if ( is_network_admin() || is_user_admin() || ! is_array( $menu_order ) ) {
		return $menu_order;
	}
	$settings = obento_get_menu_settings();
	if ( empty( $settings['order'] ) ) {
		return $menu_order;
	}
	return obento_menu_merge_order( $settings['order'], $menu_order );
}
add_filter( 'menu_order', 'obento_menu_menu_order', PHP_INT_MAX );

/**
 * 非表示と区切り線の片付けを効かせる（描画の直前。parent_fileフィルター）
 *
 * - 保存した設定に並びも非表示もなければ、何もしない
 * - 利用者のロールで隠す項目があれば、$menu / $submenuから消す（消したときは、区切り線の片付けと先頭・末尾のクラスの付け直しも済む）
 * - 何も隠さなくても、保存した並びがあれば、区切り線を片付ける（並びの先頭に区切り線を置くと、コアは片付けないため）。
 *   何か消えたときだけ、先頭・末尾のクラスを付け直す
 * - 何も変わらなければ、$menu / $submenuは書き換えない（コアが付けたクラスをそのまま残す）
 *
 * 値（$parent_file）はそのまま返す。
 *
 * @param string $parent_file 親ファイル。
 * @return string
 */
function obento_menu_hide_on_render( $parent_file ) {
	global $menu, $submenu;
	if ( is_network_admin() || is_user_admin() ) {
		return $parent_file;
	}
	$settings = obento_get_menu_settings();
	if ( ! $settings['order'] && ! $settings['hidden'] ) {
		return $parent_file;
	}
	$new_menu    = (array) $menu;
	$new_submenu = (array) $submenu;
	$changed     = false;
	if ( $settings['hidden'] ) {
		$hidden = obento_menu_hidden_for_roles( $settings, obento_menu_current_user_roles() );
		if ( $hidden['top'] || $hidden['sub'] ) {
			$result      = obento_menu_remove_hidden( $new_menu, $new_submenu, $hidden );
			$new_menu    = $result['menu'];
			$new_submenu = $result['submenu'];
			$changed     = $result['changed'];
		}
	}
	if ( ! $changed && $settings['order'] ) {
		// 何も隠さなくても、保存した並びの先頭に区切り線があると残る。何か消えたときだけ差し替え、消えなければコアのクラスを残す
		$tidy = obento_menu_cleanup_separators( $new_menu );
		if ( count( $tidy ) !== count( $new_menu ) ) {
			$new_menu = obento_menu_reclass( $tidy );
			$changed  = true;
		}
	}
	if ( $changed ) {
		$menu    = $new_menu; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 管理メニューから項目を隠し、区切り線を片付けるのがこの機能の目的。権限判定のあとなので画面は開ける
		$submenu = $new_submenu; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 同上
	}
	return $parent_file;
}
add_filter( 'parent_file', 'obento_menu_hide_on_render', PHP_INT_MAX );
