<?php
/**
 * 「メンテナンス」タブ（設定 > Obento Admin Pack）
 *
 * option obento_maintenanceの登録と、タブの描画。保存はSettings API。option groupはobento_maintenance
 * （ほかのタブとは別。片方の保存でもう片方を消さない）。読み出しとsanitizeはincludes/maintenance-common.phpの関数。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_maintenance_setting() {
	register_setting(
		'obento_maintenance',
		'obento_maintenance',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_maintenance_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_maintenance_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 見られるロールには、manage_optionsを持たないロールだけを並べる（持つ人は常に見られる）。
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_maintenance_tab() {
	$settings = obento_maintenance_get_settings();
	$names    = wp_roles()->get_names();
	$roles    = array();
	foreach ( wp_roles()->role_objects as $slug => $role ) {
		if ( ! $role->has_cap( 'manage_options' ) && isset( $names[ $slug ] ) ) {
			$roles[ $slug ] = translate_user_role( $names[ $slug ] );
		}
	}
	?>
	<p>サイトの表側を、ログインしていない人には「メンテナンス中」の画面にします（HTTPステータス503）。管理画面とログイン画面はいつもどおり使えます。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_maintenance' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row">メンテナンスモード</th>
				<td>
					<label><input type="checkbox" name="obento_maintenance[enabled]" value="1"<?php checked( $settings['enabled'] ); ?>> 有効にする</label>
					<p class="description">有効にしているあいだは、ツールバーに「メンテナンス中」と出ます。止めるのはページ・フィード・サイトマップです。REST API・XML-RPC・cronは止めません。robots.txtと公開プレビューのリンクは開けます。</p>
					<p class="description">ページキャッシュのプラグインを使っているときは、切り替えたあとにキャッシュを削除してください。</p>
				</td>
			</tr>
			<tr>
				<th scope="row">サイトを見られるロール</th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">サイトを見られるロール</legend>
						<?php foreach ( $roles as $slug => $name ) : ?>
							<label><input type="checkbox" name="obento_maintenance[roles][]" value="<?php echo esc_attr( $slug ); ?>"<?php checked( in_array( $slug, $settings['roles'], true ) ); ?>> <?php echo esc_html( $name ); ?></label><br>
						<?php endforeach; ?>
					</fieldset>
					<p class="description">管理者（設定を変えられる人）は常に見られます。チェックしたロールでログインしている人は、いつもどおりサイトを見られます。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-maintenance-title">見出し</label></th>
				<td>
					<input type="text" id="obento-maintenance-title" class="regular-text" name="obento_maintenance[title]" value="<?php echo esc_attr( $settings['title'] ); ?>">
					<?php if ( '' !== obento_maintenance_dropin() ) : ?>
						<p class="description"><code>wp-content/maintenance.php</code>があるので、見出しと本文の代わりにそちらを表示します。</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-maintenance-message">本文</label></th>
				<td>
					<textarea id="obento-maintenance-message" class="large-text" rows="5" name="obento_maintenance[message]"><?php echo esc_textarea( $settings['message'] ); ?></textarea>
					<p class="description">改行は段落になります。リンクなどのHTMLも使えます。</p>
				</td>
			</tr>
			<tr>
				<th scope="row">画面の確認</th>
				<td>
					<a href="<?php echo esc_url( obento_maintenance_preview_url() ); ?>" target="_blank" rel="noopener">画面を確かめる<span class="screen-reader-text">（新しいタブで開く）</span></a>
					<p class="description">ログインしていない人に出る画面を、保存した内容で表示します。有効にする前でも確かめられます。</p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<?php
}
