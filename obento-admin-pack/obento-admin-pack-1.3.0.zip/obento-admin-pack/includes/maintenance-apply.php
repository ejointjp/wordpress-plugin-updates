<?php
/**
 * メンテナンスモードのフック（表側を止める、ツールバーの印）
 *
 * 止めるのは、表側のテンプレートの要求だけ（template_redirectを通るもの。ページ・フィード・サイトマップ・埋め込み・検索）。
 * 管理画面・ログイン画面・REST API・admin-ajax.php・wp-cron.php・xmlrpc.phpはtemplate_redirectを通らないので止まらない。
 *
 * フックは常に登録し、コールバックの中で設定（option obento_maintenance）を読む。どのフックも1回の要求で1回しか鳴らない。
 * 「画面を確かめる」（管理者だけ）は、無効のときも受け付ける。
 *
 * is_admin()の外で読む（表側で動く）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 表側を止める（template_redirect、優先度1）
 *
 * 優先度1は、コアのredirect_canonical()とサイトマップの出力（どちらも10）より前。
 * 1. 「画面を確かめる」（クエリobento_maintenance_preview）を管理者が開いたら、有効・無効を問わず画面を出す
 * 2. 無効なら何もしない
 * 3. 見られる人、robots.txtとfavicon、表示中の公開プレビュー（posts_resultsで決まるので、この時点で分かる）は通す
 * 4. 404なら、コアの/login・/adminの転送（wp_redirect_admin_locations()。当たれば転送して終わる）を先に通す。
 *    フックが外されていれば呼ばない（ログインのURLを隠すプラグインが外している）
 * 5. 画面を出す
 */
function obento_maintenance_template_redirect() {
	$settings = obento_maintenance_get_settings();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 画面を出すだけで、何も変えない
	if ( isset( $_GET['obento_maintenance_preview'] ) && current_user_can( 'manage_options' ) ) {
		obento_maintenance_render( $settings );
	}
	if ( ! $settings['enabled'] || obento_maintenance_can_view( $settings['roles'] ) ) {
		return;
	}
	if ( is_robots() || is_favicon() || 0 !== obento_preview_active_id() ) {
		return;
	}
	if ( is_404() && false !== has_action( 'template_redirect', 'wp_redirect_admin_locations' ) ) {
		wp_redirect_admin_locations();
	}
	obento_maintenance_render( $settings );
}
add_action( 'template_redirect', 'obento_maintenance_template_redirect', 1 );

/**
 * メンテナンスの画面を出して終わる（503）
 *
 * ページキャッシュのプラグインに保存させない（DONOTCACHEPAGE）。wp-content/maintenance.php（コアが更新中に読むドロップイン）が
 * あればそれを読み込み、なければwp_die()で、コアが更新中に出す画面と同じ見た目で出す。
 * wp_die()は<title>と本文をエスケープせずに出すので、ここでエスケープする（本文は保存のときにもksesを通しているが、
 * コードからupdate_option()で入れた値はsanitizeを通らないので、出すときにも通す）。
 *
 * @param array $settings obento_maintenance_get_settings()の値。
 */
function obento_maintenance_render( $settings ) {
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	if ( ! headers_sent() ) {
		status_header( 503 );
		header( 'Retry-After: 600' );
		nocache_headers();
	}
	$dropin = obento_maintenance_dropin();
	if ( '' !== $dropin ) {
		require $dropin;
		exit;
	}
	wp_die(
		'<h1>' . esc_html( $settings['title'] ) . '</h1>' . wp_kses_post( wpautop( $settings['message'] ) ),
		esc_html( $settings['title'] . ' – ' . get_bloginfo( 'name' ) ),
		array( 'response' => 503 )
	);
}

/**
 * ツールバーに「メンテナンス中」を足す（admin_bar_menu、優先度100。コアの項目のあと。有効なときだけ）
 *
 * 管理画面とサイト側の両方に出る。manage_optionsを持つ人には「メンテナンス」タブへのリンクにする。
 *
 * @param WP_Admin_Bar $wp_admin_bar ツールバー。
 */
function obento_maintenance_toolbar( $wp_admin_bar ) {
	if ( ! obento_maintenance_get_settings()['enabled'] ) {
		return;
	}
	$wp_admin_bar->add_node(
		array(
			'id'    => 'obento-maintenance',
			'title' => 'メンテナンス中',
			'href'  => current_user_can( 'manage_options' ) ? admin_url( 'options-general.php?page=obento-admin-pack&tab=maintenance' ) : false,
		)
	);
}
add_action( 'admin_bar_menu', 'obento_maintenance_toolbar', 100 );

/**
 * ツールバーの「メンテナンス中」を赤くする（admin_bar_init。有効なときだけ）
 *
 * admin_bar_initは、ツールバーのスタイル（admin-bar）を読み込んだ直後に鳴る。IDを2つ重ねて、コアと配色のホバーの指定より強くする。
 */
function obento_maintenance_toolbar_style() {
	if ( ! obento_maintenance_get_settings()['enabled'] ) {
		return;
	}
	wp_add_inline_style( 'admin-bar', '#wpadminbar #wp-admin-bar-obento-maintenance > .ab-item{background:#d63638;color:#fff}' );
}
add_action( 'admin_bar_init', 'obento_maintenance_toolbar_style' );
