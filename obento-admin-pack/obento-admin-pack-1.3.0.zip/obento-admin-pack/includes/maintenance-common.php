<?php
/**
 * メンテナンスモードの共通部分（純粋な関数）
 *
 * 既定の見出しと本文、既定のロール、設定（option obento_maintenance）の読み出しとsanitize、メンテナンス中もサイトを見られる人の判定、
 * コアのドロップイン（wp-content/maintenance.php）のパス、「画面を確かめる」のURL。
 * フックは持たない。フックはincludes/maintenance-apply.php、設定画面はincludes/maintenance-screen.phpが持つ。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 既定の見出し
 *
 * @return string
 */
function obento_maintenance_default_title() {
	return 'メンテナンス中';
}

/**
 * 既定の本文
 *
 * @return string
 */
function obento_maintenance_default_message() {
	return 'ただいまメンテナンス中です。しばらくしてから、もう一度お越しください。';
}

/**
 * 既定のサイトを見られるロール（edit_postsを持つもの。wp_roles()の順）
 *
 * 一度も保存していない（optionにrolesのキーがない）ときに使う。コアのロールならadministrator / editor / author / contributor。
 * administratorも入るが、manage_optionsで通るので害はない。
 *
 * @return string[]
 */
function obento_maintenance_default_roles() {
	$roles = array();
	foreach ( wp_roles()->role_objects as $slug => $role ) {
		if ( $role->has_cap( 'edit_posts' ) ) {
			$roles[] = $slug;
		}
	}
	return $roles;
}

/**
 * 設定を返す
 *
 * optionがない・壊れているときは空の配列として扱う。rolesは、キーがない（一度も保存していない）か配列でなければ既定のロール、
 * 配列なら文字列の値だけ（保存して空にしたら空。管理者だけが見られる）。見出しと本文は、前後の空白を取って空なら既定の文。
 *
 * @return array{enabled: bool, roles: string[], title: string, message: string}
 */
function obento_maintenance_get_settings() {
	$option = get_option( 'obento_maintenance', array() );
	$option = is_array( $option ) ? $option : array();
	if ( isset( $option['roles'] ) && is_array( $option['roles'] ) ) {
		$roles = array_values( array_filter( $option['roles'], 'is_string' ) );
	} else {
		$roles = obento_maintenance_default_roles();
	}
	return array(
		'enabled' => ! empty( $option['enabled'] ),
		'roles'   => $roles,
		'title'   => obento_maintenance_text( $option, 'title', obento_maintenance_default_title() ),
		'message' => obento_maintenance_text( $option, 'message', obento_maintenance_default_message() ),
	);
}

/**
 * optionの文の値（文字列でないか、前後の空白を取って空なら既定の文）
 *
 * @param array  $option   option。
 * @param string $key      キー。
 * @param string $fallback 既定の文。
 * @return string
 */
function obento_maintenance_text( $option, $key, $fallback ) {
	if ( ! isset( $option[ $key ] ) || ! is_string( $option[ $key ] ) ) {
		return $fallback;
	}
	$value = trim( $option[ $key ] );
	return '' === $value ? $fallback : $value;
}

/**
 * 設定のsanitize（配列でなければ空として扱う。知らないキーは捨てる）
 *
 * ロールは今あるものだけ（wp_roles()の順。チェックがひとつもなければ空の配列）。見出しはsanitize_text_field()、
 * 本文はwp_kses_post()。空の見出しと本文はそのまま保存し、読み出しで既定の文に戻す。
 * 警告を出す入力はない。保存の通知は「設定」メニュー配下なのでコアが出す。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{enabled: bool, roles: string[], title: string, message: string}
 */
function obento_maintenance_sanitize_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	return array(
		'enabled' => ! empty( $input['enabled'] ),
		'roles'   => obento_sanitize_name_list( $input, 'roles', array_keys( wp_roles()->get_names() ) ),
		'title'   => isset( $input['title'] ) && is_string( $input['title'] ) ? sanitize_text_field( $input['title'] ) : '',
		'message' => isset( $input['message'] ) && is_string( $input['message'] ) ? trim( wp_kses_post( $input['message'] ) ) : '',
	);
}

/**
 * いまの人が、メンテナンス中もサイトを見られるか
 *
 * manage_optionsを持つ人（マルチサイトの特権管理者も含む）は常に見られる。ほかは、ログインしていて、ロールのどれかが$rolesにあれば見られる。
 *
 * @param string[] $roles 見られるロール（obento_maintenance_get_settings()のroles）。
 * @return bool
 */
function obento_maintenance_can_view( $roles ) {
	if ( current_user_can( 'manage_options' ) ) {
		return true;
	}
	if ( ! is_user_logged_in() ) {
		return false;
	}
	return (bool) array_intersect( (array) wp_get_current_user()->roles, $roles );
}

/**
 * コアのドロップイン（wp-content/maintenance.php。コアが更新中に読む）のパス。なければ空
 *
 * @return string
 */
function obento_maintenance_dropin() {
	$path = WP_CONTENT_DIR . '/maintenance.php';
	return is_file( $path ) ? $path : '';
}

/**
 * 「画面を確かめる」のURL（管理者が開くと、有効・無効を問わずメンテナンスの画面を出す）
 *
 * @return string
 */
function obento_maintenance_preview_url() {
	return add_query_arg( 'obento_maintenance_preview', '1', home_url( '/' ) );
}
