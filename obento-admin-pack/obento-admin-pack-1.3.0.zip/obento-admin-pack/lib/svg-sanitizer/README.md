# svg-sanitizer（同梱）

SVGのサニタイズに使うライブラリ。Safe SVG（10up）と同じもの。

- 上流: https://github.com/darylldoyle/svg-sanitizer （Composerの名前は`enshrined/svg-sanitize`）
- 版: 1.1.1
- ライセンス: GPL-2.0-or-later（`LICENSE`）
- 置いているもの: 上流の`src/`（`svg-scanner.php`を除く）と`LICENSE`。中身は変えていない
- 読み込み: `includes/svg-common.php`の`obento_svg_autoload()`（Composerは使わない）

## 差し替え方

1. 上流のタグのアーカイブ（`https://github.com/darylldoyle/svg-sanitizer/archive/refs/tags/<版>.tar.gz`）を取得する
2. `src/`と`LICENSE`をここに置き直し、`src/svg-scanner.php`を消す
3. このファイルの版を書き換える
4. `tests/verify.sh`を回す（「SVG」の節がサニタイズの結果を確かめる）
