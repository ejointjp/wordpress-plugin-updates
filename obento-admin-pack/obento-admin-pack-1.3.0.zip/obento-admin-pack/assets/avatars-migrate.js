/**
 * WP User Avatarsからの引き継ぎ（設定画面の「アバター」タブ）
 *
 * 「引き継ぐ」を押したら確認し、AJAX（obento_avatars_migrate）をdoneになるまで繰り返し呼ぶ。進捗はaria-liveの要素に出し、
 * 終わったら管理画面の標準の通知（.notice）を見出しの直後に出して、同じ文言を進捗の要素にも残し、飛ばした人（表示名と理由）を
 * 一覧にする。実行中はボタンをdisabledにする。JSが動くまでボタンはdisabledで、「JavaScriptが動いていない」の注意が出ている。
 *
 * グローバル変数obentoAvatarsMigrateはPHP側（includes/avatars-migrate.php）がタブにだけ注入する。キー: ajaxUrl、nonce、action
 */

/* global jQuery, wp */

( function ( $ ) {
	'use strict';

	var data = window.obentoAvatarsMigrate || {};
	var INTERRUPTED = '引き継ぎを中断しました。ページを読み込み直して、もう一度お試しください。途中まで引き継いだ分はそのまま残ります。';

	// 管理画面の標準の通知を見出しの直後に出す（前の通知は消す）。閉じるボタンはcommon.jsがwp-notice-addedで付ける
	function showNotice( message, type ) {
		$( '.obento-avatars-notice' ).remove();
		var $notice = $( '<div class="notice is-dismissible obento-avatars-notice"></div>' )
			.addClass( 'notice-' + type )
			.append( $( '<p></p>' ).text( message ) );
		var $anchor = $( '.wrap > h1' ).first();
		if ( $anchor.length ) {
			$anchor.after( $notice );
		} else {
			$( '#wpbody-content' ).prepend( $notice );
		}
		$( document ).trigger( 'wp-notice-added' );
		wp.a11y.speak( message, 'error' === type ? 'assertive' : 'polite' );
	}

	// 失敗の理由。サーバーが返した文言を優先し、ないときはHTTPステータスと次にすることを書く（assets/revisions.jsと同じ判定）
	function failMessage( xhr ) {
		var json = xhr && xhr.responseJSON;
		var status = xhr ? xhr.status : 0;
		if ( json && json.data && json.data.message ) {
			return json.data.message;
		}
		if ( 403 === status && '-1' === String( xhr.responseText || '' ).trim() ) {
			return 'ページの有効期限が切れた可能性があります。読み込み直して、もう一度お試しください。途中まで引き継いだ分はそのまま残ります。';
		}
		if ( 400 === status && '0' === String( xhr.responseText || '' ).trim() ) {
			return 'ログインが切れています。もう一度ログインしてから、やり直してください。途中まで引き継いだ分はそのまま残ります。';
		}
		if ( status >= 400 ) {
			return '引き継ぎを中断しました（HTTP ' + status + '）。ページを読み込み直して、もう一度お試しください。途中まで引き継いだ分はそのまま残ります。';
		}
		if ( ! status ) {
			return '引き継ぎを中断しました。サーバーと通信できませんでした。接続を確かめて、もう一度お試しください。途中まで引き継いだ分はそのまま残ります。';
		}
		return INTERRUPTED;
	}

	$( function () {
		var $button = $( '#obento-avatars-migrate' );
		var $progress = $( '#obento-avatars-migrate-progress' );
		var $skipped = $( '#obento-avatars-migrate-skipped' );
		if ( ! $button.length ) {
			return;
		}
		$( '.obento-avatars-migrate-nojs' ).remove();
		$button.prop( 'disabled', false );

		// 終わったときの結果（成功も失敗も）を、通知と同じ文言で進捗の要素にも残す
		function report( message, type ) {
			$button.prop( 'disabled', false );
			$progress.text( message );
			showNotice( message, type );
		}

		$button.on( 'click', function () {
			var migrated = 0;
			var skipped = [];
			if ( ! window.confirm( 'WP User Avatarsのアバターを、メディアライブラリにコピーして引き継ぎます。よろしいですか？' ) ) {
				return;
			}
			$( '.obento-avatars-notice' ).remove();
			$skipped.empty();
			$button.prop( 'disabled', true );
			$progress.text( '引き継ぎ中…' );

			// doneになるまで繰り返す。カーソルは応答のものをそのまま返す（状態はサーバーに持たない）
			function step( cursor ) {
				$.post( data.ajaxUrl, { action: data.action, nonce: data.nonce, cursor: cursor } )
					.done( function ( response ) {
						var r;
						if ( ! response || ! response.success || ! response.data ) {
							report( ( response && response.data && response.data.message ) || INTERRUPTED, 'error' );
							return;
						}
						r = response.data;
						migrated += r.migrated;
						skipped = skipped.concat( r.skipped || [] );
						$progress.text( '引き継ぎ中… ' + r.total + '人中' + r.processed + '人' );
						if ( ! r.done ) {
							step( r.cursor );
							return;
						}
						$.each( skipped, function ( i, s ) {
							$skipped.append( $( '<li></li>' ).text( s.user + '（' + s.reason + '）' ) );
						} );
						if ( skipped.length ) {
							report( migrated + '人のアバターを引き継ぎました。' + skipped.length + '人は引き継ぎませんでした（下の一覧）。', 'warning' );
							return;
						}
						report( migrated + '人のアバターを引き継ぎました。', 'success' );
					} )
					.fail( function ( xhr ) {
						report( failMessage( xhr ), 'error' );
					} );
			}
			step( 0 );
		} );
	} );
} )( jQuery );
