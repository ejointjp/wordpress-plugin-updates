/**
 * アバターの画像を選ぶ欄（プロフィールの「プロフィール写真」の行、既定アバターの欄）
 *
 * 「画像を選ぶ」でメディアのモーダルを開く。正方形の画像はそのまま使い、正方形でない画像はコアの切り抜き画面
 * （wp.media.controller.Cropper。AJAXはcrop-image）で正方形にする。選んだら、hiddenの.obento-avatar-idにIDを入れ、
 * プレビューを差し替える。保存は、欄のあるフォームの送信（「プロフィールを更新」「変更を保存」）で行う。
 *
 * 欄（.obento-avatar-field）のdata属性:
 *   data-author    自分の画像だけをモーダルに出すときの、いまのユーザーのID（空なら絞らない）
 *   data-types     モーダルに出す画像のMIMEタイプのカンマ区切り（既定アバターの欄だけ。Gravatarが受け付けるJPEG・PNG・GIF。空なら絞らない）
 *   data-fallback  削除したときに戻すプレビューのURL（プロフィールだけ。2xはdata-fallback2x）
 * 既定アバターの欄には.obento-avatar-activateがあり、新しく選んだら1にする（sanitizeがコアのavatar_defaultを切り替える）。
 * プレビューは、欄の中の.obento-avatar-preview、なければ同じセルのコアのimg.avatar（プロフィール）。
 * ボタンを隠すのはクラスhidden（コアのbuttons.cssの.button.hidden）、それ以外はhidden属性。
 *
 * PHPはincludes/avatars-profile.php（プロフィール）とincludes/avatars-screen.php（既定アバター）。
 */

/* global jQuery, wp */

( function ( $ ) {
	'use strict';

	// 切り抜いた画像の一辺の最大（obento_avatars_max_size()と同じ）
	var MAX = 512;

	// 切り抜きの初期の選択範囲（中央の最大の正方形）。縦横比は1:1に固定し、小さく選びすぎないよう、最小を一辺と512の小さいほうにする
	function imgSelectOptions( attachment ) {
		var width = attachment.get( 'width' );
		var height = attachment.get( 'height' );
		var side = Math.min( width, height );
		var min = Math.min( side, MAX );
		var x1 = ( width - side ) / 2;
		var y1 = ( height - side ) / 2;
		return {
			aspectRatio: '1:1',
			handles: true,
			keys: true,
			instance: true,
			persistent: true,
			imageWidth: width,
			imageHeight: height,
			minWidth: min,
			minHeight: min,
			x1: x1,
			y1: y1,
			x2: x1 + side,
			y2: y1 + side,
		};
	}

	function preview( $field ) {
		var $img = $field.find( '.obento-avatar-preview' );
		return $img.length ? $img : $field.closest( 'td' ).find( 'img.avatar' ).first();
	}

	function showError( $field, message ) {
		$field.find( '.obento-avatar-error' ).text( message ).prop( 'hidden', '' === message );
	}

	// プロフィールの案内（Gravatarの案内と、選んだ画像の案内）を切り替える。既定アバターの欄にはない
	function toggleNotes( $field, has ) {
		var $cell = $field.closest( 'td' );
		$cell.find( '.obento-avatar-gravatar' ).prop( 'hidden', has );
		$cell.find( '.obento-avatar-local' ).prop( 'hidden', ! has );
	}

	// 選んだ（切り抜いた）画像を欄に入れる。attrsはwp_prepare_attachment_for_js()の形
	function setImage( $field, attrs ) {
		var sizes = attrs.sizes || {};
		var small = sizes.thumbnail ? sizes.thumbnail.url : attrs.url;
		var large = sizes.medium ? sizes.medium.url : attrs.url;
		$field.find( '.obento-avatar-id' ).val( attrs.id );
		$field.find( '.obento-avatar-activate' ).val( '1' );
		preview( $field ).attr( { src: small, srcset: large + ' 2x' } ).prop( 'hidden', false );
		$field.find( '.obento-avatar-select' ).text( '画像を変更' );
		$field.find( '.obento-avatar-remove' ).removeClass( 'hidden' );
		$field.find( '.obento-avatar-inactive' ).prop( 'hidden', true );
		toggleNotes( $field, true );
		showError( $field, '' );
	}

	function clearImage( $field ) {
		var $img = preview( $field );
		var fallback = $field.attr( 'data-fallback' );
		$field.find( '.obento-avatar-id' ).val( '' );
		$field.find( '.obento-avatar-activate' ).val( '0' );
		if ( fallback ) {
			$img.attr( { src: fallback, srcset: $field.attr( 'data-fallback2x' ) + ' 2x' } );
		} else {
			$img.prop( 'hidden', true ).removeAttr( 'src srcset' );
		}
		$field.find( '.obento-avatar-select' ).text( '画像を選ぶ' );
		$field.find( '.obento-avatar-remove' ).addClass( 'hidden' );
		toggleNotes( $field, false );
		showError( $field, '' );
	}

	$( function () {
		if ( ! window.wp || ! wp.media || ! wp.media.controller || ! wp.media.controller.Cropper ) {
			return;
		}

		// コアのCropperの既定の送り先（custom-header-crop）はテーマの権限が要るので、サイトアイコンと同じくcrop-imageへ送る。
		// 出力は選択範囲の一辺と512の小さいほう。コアは切り抜いた画像を新しい添付ファイルとして保存する
		var AvatarCropper = wp.media.controller.Cropper.extend( {
			doCrop: function ( attachment ) {
				var details = attachment.get( 'cropDetails' );
				var side = Math.min( Math.round( details.width ), MAX );
				details.dst_width = side;
				details.dst_height = side;
				return wp.ajax.post( 'crop-image', {
					nonce: attachment.get( 'nonces' ).edit,
					id: attachment.get( 'id' ),
					context: 'obento-avatar',
					cropDetails: details,
				} );
			},
		} );

		// モーダルは押すたびに作り直す（サイトアイコンと同じ。切り抜きのあとの状態を持ち越さない）
		function open( $field ) {
			var query = { type: 'image' };
			var author = parseInt( $field.attr( 'data-author' ), 10 );
			var types = $field.attr( 'data-types' );
			var frame;
			if ( author > 0 ) {
				query.author = author;
			}
			if ( types ) {
				query.type = types.split( ',' );
			}
			frame = wp.media( {
				button: { text: 'この画像を使う', close: false },
				states: [
					new wp.media.controller.Library( {
						title: 'アバターの画像を選ぶ',
						library: wp.media.query( query ),
						multiple: false,
						date: false,
						suggestedWidth: MAX,
						suggestedHeight: MAX,
					} ),
					new AvatarCropper( { imgSelectOptions: imgSelectOptions } ),
				],
			} );
			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first();
				var width = attachment.get( 'width' );
				// 幅も高さも未定義（メタデータのない画像）のときは正方形とみなさない
				if ( width > 0 && width === attachment.get( 'height' ) ) {
					setImage( $field, attachment.toJSON() );
					frame.close();
					return;
				}
				frame.setState( 'cropper' );
			} );
			frame.on( 'cropped', function ( attrs ) {
				setImage( $field, attrs );
			} );
			// コアはモーダルの中にも失敗を出す。閉じたあとも分かるよう、欄の下にも出す
			frame.on( 'content:error:crop', function () {
				showError( $field, '画像を切り抜けませんでした。' );
			} );
			frame.open();
		}

		$( document ).on( 'click', '.obento-avatar-select', function () {
			open( $( this ).closest( '.obento-avatar-field' ) );
		} );
		$( document ).on( 'click', '.obento-avatar-remove', function () {
			clearImage( $( this ).closest( '.obento-avatar-field' ) );
		} );
	} );
} )( jQuery );
