/**
 * 投稿一覧の列幅をドラッグで変える
 *
 * 見出し（thead th）の右端のハンドルは、その列と右隣の列の境界。ドラッグすると、その列が広がった分だけ右隣の列が狭まり、
 * ほかの列と表の幅は変わらない。ダブルクリックで、その一覧の列幅をすべて元に戻す。
 * 表はtable-layout: fixedで幅が100%なので、1列の幅だけを変えると、差をどの列で吸収するかはブラウザが決めてしまう
 * （幅の指定のない列や、%で指定した列が引きずられて動く）。そこで、ドラッグを始めるときに見えている列の幅をすべて固定し、2列だけを動かす。
 * 幅は、列のキー（thのid。コアが列のキーをそのまま入れる）ごとに、見えている列の幅の合計に対する割合でlocalStorageへ保存する。
 * 位置で覚えると表示オプションで列を出し入れしたときにずれ、pxで覚えると窓の幅が変わったときに合計が合わなくなるため。
 * 一覧が1列に積み重なる狭い画面（782px以下）では何もしない。
 */
( function () {
	'use strict';

	var config = window.obentoColumnWidth;
	var table = document.querySelector( '.wp-list-table' );
	if ( ! config || ! table ) {
		return;
	}
	var wide = window.matchMedia( '(min-width: 783px)' ); // 開いたあとに狭くしたときは、apply()で幅を外す
	if ( ! wide.matches ) {
		return;
	}

	var MIN_WIDTH = 40;
	var heads = Array.prototype.slice.call(
		table.querySelectorAll( 'thead th[id]' )
	);
	var handles = [];
	var ratios = load();

	function load() {
		var result = {};
		try {
			var saved = JSON.parse(
				window.localStorage.getItem( config.storeKey ) || '{}'
			);
			// 0.7.0までのpx（'120px'）は読まない（元の幅に戻る）
			Object.keys( saved && 'object' === typeof saved ? saved : {} ).forEach(
				function ( key ) {
					var value = saved[ key ];
					if (
						'number' === typeof value &&
						isFinite( value ) &&
						value > 0 &&
						value <= 1
					) {
						result[ key ] = value;
					}
				}
			);
		} catch ( e ) {
			// 読めない（壊れた値、プライベートブラウズなど）ときは、元の幅のまま
		}
		return result;
	}

	function store() {
		try {
			if ( Object.keys( ratios ).length ) {
				window.localStorage.setItem(
					config.storeKey,
					JSON.stringify( ratios )
				);
			} else {
				window.localStorage.removeItem( config.storeKey );
			}
		} catch ( e ) {
			// 保存できない（プライベートブラウズなど）ときは、この画面のあいだだけ効かせる
		}
	}

	function visibleHeads() {
		return heads.filter( function ( th ) {
			return ! th.classList.contains( 'hidden' );
		} );
	}

	// 枠の幅（余白と線を含む）
	function outerWidth( th ) {
		return th.getBoundingClientRect().width;
	}

	// 中身の幅（styleのwidthと同じく、余白と線を含まない）
	function contentWidth( th ) {
		return parseFloat( window.getComputedStyle( th ).width );
	}

	function sum( values ) {
		return values.reduce( function ( total, value ) {
			return total + value;
		}, 0 );
	}

	// 見えている列の幅の割合を保存する。隠れている列の割合は残す（出し直したときに、残りの列と按分する）
	function save() {
		var visible = visibleHeads();
		var widths = visible.map( outerWidth );
		var total = sum( widths );
		if ( total <= 0 ) {
			return;
		}
		visible.forEach( function ( th, index ) {
			ratios[ th.id ] = Math.round( ( widths[ index ] / total ) * 1e4 ) / 1e4;
		} );
		store();
	}

	// 保存した割合を、いまの表の幅に当てはめる。割合のない列（あとから出した列など）は、元の幅のまま固定する
	function apply() {
		var visible = visibleHeads();
		heads.forEach( function ( th ) {
			th.style.width = '';
		} );
		if ( ! wide.matches ) {
			return;
		}
		var hasRatio = visible.some( function ( th ) {
			return Object.prototype.hasOwnProperty.call( ratios, th.id );
		} );
		if ( ! hasRatio ) {
			return;
		}
		// 幅を書き換える前に、元の幅で測っておく
		var outers = visible.map( outerWidth );
		var paddings = visible.map( function ( th, index ) {
			return outers[ index ] - contentWidth( th );
		} );
		var rest = sum( outers );
		var ratioTotal = 0;
		visible.forEach( function ( th, index ) {
			if ( Object.prototype.hasOwnProperty.call( ratios, th.id ) ) {
				ratioTotal += ratios[ th.id ];
			} else {
				rest -= outers[ index ];
			}
		} );
		visible.forEach( function ( th, index ) {
			var outer = Object.prototype.hasOwnProperty.call( ratios, th.id )
				? ( rest * ratios[ th.id ] ) / ratioTotal
				: outers[ index ];
			th.style.width =
				Math.max( MIN_WIDTH, outer - paddings[ index ] ) + 'px';
		} );
	}

	// 見えている最後の列は表の右端で、右隣がないので、ハンドルを出さない
	function refreshHandles() {
		var visible = visibleHeads();
		var last = visible[ visible.length - 1 ];
		handles.forEach( function ( handle ) {
			handle.hidden = handle.parentNode === last;
		} );
	}

	function nextVisible( th ) {
		var visible = visibleHeads();
		var index = visible.indexOf( th );
		return index < 0 ? null : visible[ index + 1 ] || null;
	}

	heads.forEach( function ( th ) {
		var handle = document.createElement( 'span' );
		handle.className = 'obento-column-resizer';
		handle.setAttribute( 'aria-hidden', 'true' );
		th.appendChild( handle );
		handles.push( handle );

		// 並べ替えのリンクの上にあるので、クリックが見出しに伝わらないようにする
		handle.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			event.stopPropagation();
		} );

		handle.addEventListener( 'dblclick', function ( event ) {
			event.preventDefault();
			event.stopPropagation();
			ratios = {};
			store();
			apply();
		} );

		handle.addEventListener( 'pointerdown', function ( event ) {
			if ( 0 !== event.button ) {
				return;
			}
			var next = nextVisible( th );
			if ( ! next ) {
				return;
			}
			event.preventDefault();
			event.stopPropagation();

			// 見えている列の幅を、いまの幅で固定する（2列のほかが引きずられないように）。書き換える前に全部測る
			var visible = visibleHeads();
			var widths = visible.map( contentWidth );
			visible.forEach( function ( head, index ) {
				head.style.width = widths[ index ] + 'px';
			} );
			var startX = event.clientX;
			var startWidth = widths[ visible.indexOf( th ) ];
			var nextWidth = widths[ visible.indexOf( next ) ];
			// どちらの列もMIN_WIDTHより狭くしない。すでに狭いときは、その向きには動かさない
			var minDelta = Math.min( 0, MIN_WIDTH - startWidth );
			var maxDelta = Math.max( 0, nextWidth - MIN_WIDTH );
			handle.setPointerCapture( event.pointerId );
			document.body.classList.add( 'obento-column-resizing' );

			var moved = false;

			function onMove( moveEvent ) {
				var delta = Math.min(
					maxDelta,
					Math.max( minDelta, moveEvent.clientX - startX )
				);
				moved = moved || 0 !== delta;
				th.style.width = startWidth + delta + 'px';
				next.style.width = nextWidth - delta + 'px';
			}

			function onUp() {
				handle.removeEventListener( 'pointermove', onMove );
				handle.removeEventListener( 'pointerup', onUp );
				handle.removeEventListener( 'pointercancel', onUp );
				document.body.classList.remove( 'obento-column-resizing' );
				// 動かさなかった（クリックだけ、ダブルクリックの1回目）ときは保存せず、固定した幅を外す
				if ( moved ) {
					save();
				} else {
					apply();
				}
			}

			handle.addEventListener( 'pointermove', onMove );
			handle.addEventListener( 'pointerup', onUp );
			handle.addEventListener( 'pointercancel', onUp );
		} );
	} );

	refreshHandles();
	apply();

	// 表示オプションで列を出し入れしたとき（コアがhiddenのクラスを付け外ししたあと）
	document.addEventListener( 'change', function ( event ) {
		if (
			event.target.classList &&
			event.target.classList.contains( 'hide-column-tog' )
		) {
			refreshHandles();
			apply();
		}
	} );

	// 表の入れ物の幅が変わったら（窓の幅、左のメニューの開閉）、割合を当てはめ直す（固定したpxの合計が表の幅と合わなくなるため）。
	// 幅を変えると行の高さが変わって入れ物がまた通知されるので、当てはめは次の描画の前に回し、幅が変わったときだけにする
	var box = table.parentNode;
	var boxWidth = box.clientWidth;
	var pending = false;
	if ( window.ResizeObserver ) {
		new window.ResizeObserver( function () {
			if ( pending ) {
				return;
			}
			pending = true;
			window.requestAnimationFrame( function () {
				pending = false;
				if ( box.clientWidth === boxWidth ) {
					return;
				}
				boxWidth = box.clientWidth;
				apply();
			} );
		} ).observe( box );
	}
} )();
