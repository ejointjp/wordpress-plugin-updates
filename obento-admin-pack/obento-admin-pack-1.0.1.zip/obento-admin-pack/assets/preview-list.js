/**
 * 公開プレビュー（投稿一覧の行アクション「プレビューリンクをコピー」）
 *
 * クリックしたらリンクを開かず、hrefをクリップボードへコピーして、文字を2秒だけ「コピーしました」に変える。
 * Quick Editが描き直した行にも効くよう、documentでクリックを受ける（イベント委譲）。
 * Ctrl・Cmd・Shift・Altつきのクリックと主ボタン以外は横取りせず、ブラウザの標準の動き（リンクを開く）に任せる。
 * コピーできない環境では、失敗を読み上げて、リンクを新しいタブで開く（JSが効かないときと同じ動き）。
 */

/* global wp */

( function () {
	'use strict';

	function logError( error ) {
		if ( window.console ) {
			window.console.error( error );
		}
	}

	// 一時的なtextareaを選んでexecCommand('copy')でコピーする。選ぶとフォーカスがtextareaに移るので、終わったらリンクに戻す
	function copyWithTextarea( text, link ) {
		return new Promise( function ( resolve, reject ) {
			var area = document.createElement( 'textarea' );
			area.value = text;
			area.setAttribute( 'readonly', '' );
			area.style.position = 'fixed';
			area.style.left = '-9999px';
			document.body.appendChild( area );
			try {
				area.select();
				if ( document.execCommand( 'copy' ) ) {
					resolve();
				} else {
					var failure = new Error( 'copy failed' );
					logError( failure );
					reject( failure );
				}
			} catch ( e ) {
				logError( e );
				reject( e );
			} finally {
				document.body.removeChild( area );
				link.focus();
			}
		} );
	}

	// クリップボードへコピーする。navigator.clipboardが使えない環境（httpなど）や、拒否されたとき（権限・フォーカス）は、textareaを選んでコピーする
	function copyText( text, link ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( text ).catch( function () {
				return copyWithTextarea( text, link );
			} );
		}
		return copyWithTextarea( text, link );
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest ? event.target.closest( 'a.obento-preview-copy' ) : null;
		if ( ! link ) {
			return;
		}
		if ( 0 !== event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}
		event.preventDefault();
		var url = link.getAttribute( 'href' );
		// もとの文言は要素に1度だけ覚える。2秒以内にもう一度押すと、textContentはすでに「コピーしました」になっている
		if ( ! link.dataset.obentoLabel ) {
			link.dataset.obentoLabel = link.textContent;
		}
		copyText( url, link ).then(
			function () {
				link.textContent = 'コピーしました';
				wp.a11y.speak( 'プレビューリンクをコピーしました。' );
				clearTimeout( link.obentoTimer );
				link.obentoTimer = setTimeout( function () {
					link.textContent = link.dataset.obentoLabel;
				}, 2000 );
			},
			function () {
				wp.a11y.speak( 'コピーできませんでした。プレビューを新しいタブで開きます。', 'assertive' );
				window.open( url, '_blank', 'noopener' );
			}
		);
	} );
} )();
