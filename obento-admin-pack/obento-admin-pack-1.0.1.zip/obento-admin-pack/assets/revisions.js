/**
 * リビジョン管理（設定画面の「リビジョン」タブと、投稿一覧）
 *
 * 設定画面: 「上限を超えたリビジョンを削除」「すべてのリビジョンを削除」を押したら確認し、AJAX（obento_delete_revisions_site）を
 * doneになるまで繰り返し呼ぶ。進捗はaria-liveの要素に出し、終わったら管理画面の標準の通知（.notice）を見出しの直後に出して、
 * 同じ文言を進捗の要素にも残し（ボタンの近くに結果を残す。次の実行の開始時に上書きされる）、件数の表を書き換える。実行中は2つのボタンをdisabledにする。JSが動くまでボタンはdisabledで、「JavaScriptが動いていない」の注意が出ている。
 * 投稿一覧: 行アクション「リビジョンを削除」と、一括操作「リビジョンを削除」の送信を確認する。
 *
 * グローバル変数obentoRevisionsはPHP側（includes/revisions-screen.php）が設定画面にだけ注入する。キー: ajaxUrl、nonce、action
 */

/* global jQuery, wp */

( function ( $ ) {
	'use strict';

	var data = window.obentoRevisions || {};
	var INTERRUPTED = '削除を中断しました。ページを読み込み直して、もう一度お試しください。途中まで削除した分は戻りません。';

	// 3桁ごとにカンマ（number_format_i18n()の日本語と同じ見た目）
	function formatNumber( n ) {
		return String( n ).replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
	}

	// 管理画面の標準の通知を見出しの直後に出す（前の通知は消す）。閉じるボタンはcommon.jsがwp-notice-addedで付ける。
	// 目で見ていない人にもわかるよう、読み上げもする
	function showNotice( message, type ) {
		$( '.obento-revisions-notice' ).remove();
		var $notice = $( '<div class="notice is-dismissible obento-revisions-notice"></div>' )
			.addClass( 'notice-' + type )
			.append( $( '<p></p>' ).text( message ) );
		var $anchor = $( '.wrap > h1' ).first();
		if ( $anchor.length ) {
			$anchor.after( $notice );
		} else {
			$( '#wpbody-content' ).prepend( $notice );
		}
		$( document ).trigger( 'wp-notice-added' );
		wp.a11y.speak( message, 'error' === type ? 'assertive' : 'polite' );
	}

	// 失敗の理由。サーバーが返した文言を優先し、ないときはHTTPステータスと次にすることを書く。
	// admin-ajax.phpは、nonceの期限切れとログアウトをJSONではない本文で返す（assets/order.jsと同じ判定）
	function failMessage( xhr ) {
		var json = xhr && xhr.responseJSON;
		var status = xhr ? xhr.status : 0;
		if ( json && json.data && json.data.message ) {
			return json.data.message;
		}
		if ( 403 === status && '-1' === String( xhr.responseText || '' ).trim() ) {
			return 'ページの有効期限が切れた可能性があります。読み込み直して、もう一度お試しください。途中まで削除した分は戻りません。';
		}
		if ( 400 === status && '0' === String( xhr.responseText || '' ).trim() ) {
			return 'ログインが切れています。もう一度ログインしてから、やり直してください。途中まで削除した分は戻りません。';
		}
		if ( status >= 400 ) {
			return '削除を中断しました（HTTP ' + status + '）。ページを読み込み直して、もう一度お試しください。途中まで削除した分は戻りません。';
		}
		if ( ! status ) {
			return '削除を中断しました。サーバーと通信できませんでした。接続を確かめて、もう一度お試しください。途中まで削除した分は戻りません。';
		}
		return INTERRUPTED;
	}

	$( function () {
		// 設定画面
		var $progress = $( '#obento-revisions-progress' );
		var $buttons = $( '#obento-revisions-delete-excess, #obento-revisions-delete-all' );
		if ( $progress.length && $buttons.length ) {
			var confirmMessages = {
				excess: '保存した最大リビジョン数（空欄の投稿タイプはWordPressの既定）を超えた分のリビジョンを、サイト全体で削除します。元に戻せません。よろしいですか？',
				all: 'サイト全体のリビジョンをすべて削除します（保存していない編集を含む自動保存は残します）。元に戻せません。よろしいですか？',
			};

			// 件数の表の1行を書き換える。0件で隠す行（対象外、親なし）はhiddenを切り替える
			function setRow( key, pair, hideWhenZero ) {
				if ( ! pair ) {
					return;
				}
				$( '#obento-revisions-counts [data-count="' + key + '"]' ).text( formatNumber( pair.total ) );
				$( '#obento-revisions-counts [data-autosave="' + key + '"]' ).text( formatNumber( pair.autosave ) );
				if ( hideWhenZero ) {
					$( '#obento-revisions-counts tr[data-key="' + key + '"]' ).prop( 'hidden', 0 === pair.total );
				}
			}
			function updateCounts( counts ) {
				$.each( counts.types || {}, function ( key, pair ) {
					setRow( key, pair, false );
				} );
				setRow( 'other', counts.other, true );
				setRow( 'orphan', counts.orphan, true );
				setRow( 'total', counts.total, false );
			}

			// 進捗。allは消した件数、excessは見た投稿の件数を分子にする
			function progressText( mode, deleted, checked, total ) {
				var totalText = null === total ? '?' : formatNumber( total );
				if ( 'all' === mode ) {
					return '削除中… ' + formatNumber( deleted ) + ' / ' + totalText + '件';
				}
				return '確認中… 投稿' + formatNumber( checked ) + ' / ' + totalText + '件（削除' + formatNumber( deleted ) + '件）';
			}

			// 終わったときの結果（成功も失敗も）を、通知と同じ文言で進捗の要素にも残す。ボタンの近くから文字が消えないようにするため。
			// 次の実行の開始時に、進捗の表示で上書きされる
			function report( message, type ) {
				$buttons.prop( 'disabled', false );
				$progress.text( message );
				showNotice( message, type );
			}

			function finish( deleted, failed, counts ) {
				if ( counts ) {
					updateCounts( counts );
				}
				if ( failed > 0 ) {
					report( 'リビジョンを' + formatNumber( deleted ) + '件削除しました。' + formatNumber( failed ) + '件は削除できませんでした。もう一度お試しください。', 'warning' );
					return;
				}
				if ( 0 === deleted ) {
					report( '削除するリビジョンはありませんでした。', 'info' );
					return;
				}
				report( 'リビジョンを' + formatNumber( deleted ) + '件削除しました。', 'success' );
			}

			// doneになるまで繰り返す。カーソルは応答のものをそのまま返す（状態はサーバーに持たない）
			function run( mode ) {
				var total = null;
				var deleted = 0;
				var failed = 0;
				var checked = 0;
				$( '.obento-revisions-notice' ).remove();
				$buttons.prop( 'disabled', true );
				$progress.text( progressText( mode, 0, 0, null ) );
				function step( cursor ) {
					$.post( data.ajaxUrl, { action: data.action, nonce: data.nonce, mode: mode, cursor: cursor } )
						.done( function ( response ) {
							if ( ! response || ! response.success || ! response.data ) {
								report( ( response && response.data && response.data.message ) || INTERRUPTED, 'error' );
								return;
							}
							var r = response.data;
							if ( null === total && 'number' === typeof r.total ) {
								total = r.total;
							}
							deleted += r.deleted;
							failed += r.failed;
							checked += r.checked;
							$progress.text( progressText( mode, deleted, checked, total ) );
							if ( r.done ) {
								finish( deleted, failed, r.counts );
								return;
							}
							step( r.cursor );
						} )
						.fail( function ( xhr ) {
							report( failMessage( xhr ), 'error' );
						} );
				}
				step( 0 );
			}

			$buttons.on( 'click', function () {
				var mode = $( this ).attr( 'data-mode' );
				if ( ! confirmMessages[ mode ] || ! window.confirm( confirmMessages[ mode ] ) ) {
					return;
				}
				run( mode );
			} );

			// 初期化の最後に、「JavaScriptが動いていない」の注意を消して、ボタンを有効にする
			$( '.obento-revisions-nojs' ).remove();
			$buttons.prop( 'disabled', false );
		}

		// 投稿一覧: 行アクション「リビジョンを削除」の確認（取り消したら送らない）
		$( document ).on( 'click', '.obento-delete-revisions', function ( event ) {
			var title = $( this ).attr( 'data-title' ) || '';
			if ( ! window.confirm( '「' + title + '」のリビジョンを削除します。元に戻せません。よろしいですか？' ) ) {
				event.preventDefault();
			}
		} );

		// 投稿一覧: 一括操作「リビジョンを削除」の送信の確認。
		// コアのJS（5.7以降）が上下の選択を同じ値にそろえ、サーバーも上（action）しか読まないので、上だけを見る。
		// 確認を出すのは、コアが一括操作を実行する送信だけ。
		// 「絞り込み」ボタン（filter_action。自動で絞り込むときもこのボタンで送る）の送信は、コアが一括操作を無視するので出さない。
		// 投稿を1件も選んでいないときも、コアは何もせず戻すので出さない。検索の送信は、投稿を選んでいればコアが一括操作を実行するので、確認が唯一の歯止めになる。
		$( '#posts-filter' ).on( 'submit', function ( event ) {
			if ( 'obento_delete_revisions' !== $( '#bulk-action-selector-top' ).val() ) {
				return;
			}
			var submitter = event.originalEvent && event.originalEvent.submitter;
			if ( submitter && 'filter_action' === submitter.name ) {
				return;
			}
			if ( ! $( '#the-list input[name="post[]"]:checked' ).length ) {
				return;
			}
			if ( ! window.confirm( '選んだ投稿のリビジョンを削除します。元に戻せません。よろしいですか？' ) ) {
				event.preventDefault();
			}
		} );
	} );
} )( jQuery );
