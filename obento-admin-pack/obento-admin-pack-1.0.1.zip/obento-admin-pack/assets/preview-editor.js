/**
 * 公開プレビュー（ブロックエディターの「概要」パネル）
 *
 * チェック「公開プレビューを有効にする」、URLと「コピー」、期限、「延長」を描く。切り替えと延長は保存を待たずAJAX（obento_preview）で
 * 行い、応答の状態（includes/preview-common.phpのobento_preview_state()）で描き直す。
 * 投稿が公開済み・非公開なら描かない。未保存（auto-draft）ならチェックを無効にして「下書きを保存すると使えます」を出す。
 * ビルドなしなので、JSXではなくwp.element.createElementで書く。
 *
 * グローバル変数obentoPreviewはPHP側（includes/preview-editor.php）が編集画面にだけ注入する。
 * キー: ajaxUrl、nonce、action、days（設定の日数。0は無期限）、state（初期状態）
 */

/* global jQuery, wp */

( function ( $ ) {
	'use strict';

	var data = window.obentoPreview || {};
	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useRef = wp.element.useRef;
	var useEffect = wp.element.useEffect;
	var useSelect = wp.data.useSelect;
	var components = wp.components;
	var EMPTY = { enabled: false, expired: false, url: '', expires: '', remain: '' };

	// 失敗の理由。サーバーが返した文言を優先し、ないときはHTTPステータスと次にすることを書く。
	// admin-ajax.phpは、nonceの期限切れとログアウトをJSONではない本文で返す（assets/revisions.jsと同じ判定）
	function failMessage( xhr ) {
		var json = xhr && xhr.responseJSON;
		var status = xhr ? xhr.status : 0;
		if ( json && json.data && json.data.message ) {
			return json.data.message;
		}
		if ( 403 === status && '-1' === String( xhr.responseText || '' ).trim() ) {
			return 'ページの有効期限が切れた可能性があります。読み込み直して、もう一度お試しください。';
		}
		if ( 400 === status && '0' === String( xhr.responseText || '' ).trim() ) {
			return 'ログインが切れています。もう一度ログインしてから、やり直してください。';
		}
		if ( status >= 400 ) {
			return '公開プレビューを変更できませんでした（HTTP ' + status + '）。ページを読み込み直して、もう一度お試しください。';
		}
		return '公開プレビューを変更できませんでした。サーバーと通信できませんでした。接続を確かめて、もう一度お試しください。';
	}

	// 欄の文字を選んでexecCommand('copy')でコピーする
	function copyWithSelection( input ) {
		return new Promise( function ( resolve, reject ) {
			try {
				if ( input ) {
					input.focus();
					input.select();
				}
				if ( document.execCommand( 'copy' ) ) {
					resolve();
				} else {
					reject( new Error( 'copy failed' ) );
				}
			} catch ( e ) {
				reject( e );
			}
		} );
	}

	// クリップボードへコピーする。navigator.clipboardが使えない環境（httpなど）や、拒否されたとき（権限・フォーカス）は、欄の文字を選んでコピーする
	function copyText( text, input ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( text ).catch( function () {
				return copyWithSelection( input );
			} );
		}
		return copyWithSelection( input );
	}

	function Panel() {
		var post = useSelect( function ( select ) {
			var editor = select( 'core/editor' );
			return {
				id: editor.getCurrentPostId(),
				// 保存済みのステータス（編集中の値ではない）。公開を押して保存が終わるとpublishになる
				status: editor.getCurrentPost().status,
			};
		}, [] );
		var stateHook = useState( data.state || EMPTY );
		var state = stateHook[ 0 ];
		var setState = stateHook[ 1 ];
		var busyHook = useState( false );
		var busy = busyHook[ 0 ];
		var setBusy = busyHook[ 1 ];
		var errorHook = useState( '' );
		var error = errorHook[ 0 ];
		var setError = errorHook[ 1 ];
		var copiedHook = useState( false );
		var copied = copiedHook[ 0 ];
		var setCopied = copiedHook[ 1 ];
		var inputRef = useRef( null );
		// 「コピーしました」を戻すタイマーのID。2回押したときに前のタイマーを止めて、後の表示が早く戻らないようにする
		var copyTimer = useRef( null );
		var published = 'publish' === post.status || 'private' === post.status;

		// 公開すると、サーバーはメタを消す（obento_preview_on_transition）。パネルは描かなくてもマウントされたままなので、
		// 状態を空に戻す。戻さないと、下書きに戻したときに、消えたURLと残り日数が出てしまう。フックはすべて、次のreturnより前で呼ぶ
		useEffect( function () {
			if ( published ) {
				setState( EMPTY );
				setError( '' );
			}
		}, [ post.status ] );

		if ( published ) {
			return null;
		}
		var unsaved = 'auto-draft' === post.status;

		function run( op ) {
			setBusy( true );
			setError( '' );
			$.post( data.ajaxUrl, { action: data.action, nonce: data.nonce, post_id: post.id, op: op } )
				.done( function ( res ) {
					if ( res && res.success && res.data ) {
						setState( res.data );
					} else {
						setError( failMessage( { responseJSON: res, status: 200 } ) );
					}
				} )
				.fail( function ( xhr ) {
					setError( failMessage( xhr ) );
				} )
				.always( function () {
					setBusy( false );
				} );
		}

		function copy() {
			copyText( state.url, inputRef.current ).then(
				function () {
					setError( '' );
					setCopied( true );
					wp.a11y.speak( 'プレビューリンクをコピーしました。' );
					clearTimeout( copyTimer.current );
					copyTimer.current = setTimeout( function () {
						setCopied( false );
					}, 2000 );
				},
				function () {
					setError( 'コピーできませんでした。URLの欄を選んでコピーしてください。' );
				}
			);
		}

		var children = [];
		children.push(
			el( components.CheckboxControl, {
				key: 'toggle',
				__nextHasNoMarginBottom: true,
				label: '公開プレビューを有効にする',
				help: unsaved ? '下書きを保存すると使えます。' : undefined,
				checked: state.enabled,
				disabled: busy || unsaved,
				onChange: function ( checked ) {
					run( checked ? 'enable' : 'disable' );
				},
			} )
		);
		if ( state.enabled ) {
			children.push(
				el(
					'div',
					{ key: 'url', className: 'obento-preview-url', style: { display: 'flex', gap: '8px', alignItems: 'flex-end', marginTop: '8px' } },
					el(
						'div',
						{ style: { flex: '1 1 auto' } },
						el( components.TextControl, {
							__nextHasNoMarginBottom: true,
							__next40pxDefaultSize: true,
							label: 'プレビューのURL',
							hideLabelFromVision: true,
							value: state.url,
							readOnly: true,
							ref: inputRef,
							onChange: function () {},
						} )
					),
					el( components.Button, { variant: 'secondary', __next40pxDefaultSize: true, onClick: copy, disabled: busy }, copied ? 'コピーしました' : 'コピー' )
				)
			);
			var expiry;
			if ( state.expired ) {
				expiry = el( 'span', { style: { color: '#b32d2e' } }, '期限切れ（' + state.expires + '）' );
			} else if ( state.expires ) {
				expiry = state.expires + 'まで（残り' + state.remain + '）';
			} else {
				expiry = '期限なし';
			}
			children.push( el( 'p', { key: 'expiry', className: 'obento-preview-expiry', style: { margin: '8px 0 0' } }, expiry ) );
			if ( data.days > 0 ) {
				children.push(
					el(
						components.Button,
						{ key: 'extend', variant: 'link', onClick: function () { run( 'extend' ); }, disabled: busy },
						'延長（今日から' + data.days + '日）'
					)
				);
			}
		}
		if ( error ) {
			children.push( el( components.Notice, { key: 'error', status: 'error', isDismissible: false }, error ) );
		}

		return el(
			wp.editor.PluginPostStatusInfo,
			{ className: 'obento-preview' },
			el( 'div', { style: { width: '100%' } }, children )
		);
	}

	wp.plugins.registerPlugin( 'obento-preview', { render: Panel } );
} )( jQuery );
