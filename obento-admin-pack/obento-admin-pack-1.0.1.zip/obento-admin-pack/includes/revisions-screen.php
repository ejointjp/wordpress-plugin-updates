<?php
/**
 * 「リビジョン」タブ（設定 > Obento Admin Pack）
 *
 * option obento_revisionsの登録、タブの描画（最大リビジョン数のフォーム、件数の表、削除のボタン）、サイト全体の削除のAJAX、
 * スクリプトの読み込み。削除の中身と集計はincludes/revisions-common.phpの関数を使う。
 *
 * 保存はSettings API。option groupはobento_revisions（ほかのタブとは別。片方の保存でもう片方を消さない）。
 * 削除のボタンはフォームの外に置き、JS（assets/revisions.js）がAJAXを繰り返し呼ぶ。JSが動くまでボタンはdisabled。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_revisions_setting() {
	register_setting(
		'obento_revisions',
		'obento_revisions',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_sanitize_revisions_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_revisions_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_revisions_tab() {
	$types = obento_get_revision_post_types();
	$keep  = obento_get_revisions_settings()['keep'];
	?>
	<p>リビジョンは、投稿を保存するたびに残る以前の版です。ここで決めた上限は、その投稿を次に保存したときから効きます。すでにある分を減らすには、下の「リビジョンの削除」を使ってください。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_revisions' ); ?>
		<h2>最大リビジョン数</h2>
		<p>空欄はWordPressの既定（いまは<?php echo esc_html( obento_revisions_default_label() ); ?>）のままにします。0にすると、その投稿タイプではリビジョンを保存しません。テーマやプラグインが投稿タイプ別に上限を決めているときは、そちらが優先されます。</p>
		<table class="form-table" role="presentation">
			<tbody>
			<?php foreach ( $types as $name => $type ) : ?>
				<tr>
					<th scope="row"><label for="obento-revisions-keep-<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $type->labels->name ); ?> <code><?php echo esc_html( $name ); ?></code></label></th>
					<td><input type="number" min="0" step="1" class="small-text" id="obento-revisions-keep-<?php echo esc_attr( $name ); ?>" name="obento_revisions[keep][<?php echo esc_attr( $name ); ?>]" value="<?php echo isset( $keep[ $name ] ) ? (int) $keep[ $name ] : ''; ?>" placeholder="既定"></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<h2>リビジョンの件数</h2>
	<?php obento_render_revisions_counts_table( obento_count_revisions() ); ?>
	<h2>リビジョンの削除</h2>
	<div class="notice notice-warning inline obento-revisions-nojs"><p>JavaScriptが動いていないため削除できません。</p></div>
	<p><button type="button" class="button" id="obento-revisions-delete-excess" data-mode="excess" disabled>上限を超えたリビジョンを削除</button></p>
	<p class="description">保存した最大リビジョン数（空欄の投稿タイプはWordPressの既定）を超えた分を、サイト全体で削除します。テーマやプラグインが投稿タイプ別に上限を決めているときは、その値を使います。上の欄に入力しただけで保存していない値は使いません。先に「変更を保存」を押してください。</p>
	<p><button type="button" class="button" id="obento-revisions-delete-all" data-mode="all" disabled>すべてのリビジョンを削除</button></p>
	<p class="description">サイト全体のリビジョンをすべて削除します。保存していない編集を含む自動保存は残します。</p>
	<p id="obento-revisions-progress" aria-live="polite"></p>
	<?php
}

/**
 * 件数の表を描く
 *
 * 行は対象の投稿タイプ（0件でも出す）、対象外の投稿タイプ（1件以上のとき）、親のないリビジョン（1件以上のとき）、合計。
 * セルにdata-count / data-autosaveを付け、削除が終わったときにJSが書き換える。
 *
 * @param array $counts obento_count_revisions()の値。
 */
function obento_render_revisions_counts_table( $counts ) {
	echo '<table class="widefat striped" id="obento-revisions-counts"><thead><tr><th scope="col">投稿タイプ</th><th scope="col">リビジョン</th><th scope="col">うち自動保存</th></tr></thead><tbody>' . "\n";
	foreach ( obento_get_revision_post_types() as $name => $type ) {
		$pair = isset( $counts['types'][ $name ] ) ? $counts['types'][ $name ] : obento_revisions_empty_pair();
		obento_render_revisions_counts_row( $name, $type->labels->name, $name, $pair, false );
	}
	obento_render_revisions_counts_row( 'other', '対象外の投稿タイプ', '', $counts['other'], true );
	obento_render_revisions_counts_row( 'orphan', '親のないリビジョン', '', $counts['orphan'], true );
	obento_render_revisions_counts_row( 'total', '合計', '', $counts['total'], false );
	echo '</tbody></table>' . "\n";
}

/**
 * 件数の表の1行を描く（1行に出す。検証がgrepで1行ずつ見るため）
 *
 * @param string $key            行のキー（投稿タイプ名 / other / orphan / total）。
 * @param string $label          表示名。
 * @param string $code           投稿タイプ名（<code>で添える。空なら添えない）。
 * @param array  $pair           total / autosave。
 * @param bool   $hide_when_zero 0件のときhiddenにするか。
 */
function obento_render_revisions_counts_row( $key, $label, $code, $pair, $hide_when_zero ) {
	printf(
		'<tr data-key="%1$s"%2$s><th scope="row">%3$s%4$s</th><td data-count="%1$s">%5$s</td><td data-autosave="%1$s">%6$s</td></tr>' . "\n",
		esc_attr( $key ),
		$hide_when_zero && 0 === (int) $pair['total'] ? ' hidden' : '',
		esc_html( $label ),
		'' !== $code ? ' <code>' . esc_html( $code ) . '</code>' : '',
		esc_html( number_format_i18n( (int) $pair['total'] ) ),
		esc_html( number_format_i18n( (int) $pair['autosave'] ) )
	);
}

/**
 * 「リビジョン」タブにスクリプトを読み込む
 *
 * @param string $hook 管理画面のページ（add_options_page()の戻り。settings_page_obento-admin-pack）。
 */
function obento_revisions_enqueue( $hook ) {
	if ( 'settings_page_obento-admin-pack' !== $hook || 'revisions' !== obento_get_settings_tab() ) {
		return;
	}
	wp_enqueue_script( 'obento-revisions', OBENTO_URL . 'assets/revisions.js', array( 'jquery', 'wp-a11y' ), OBENTO_VERSION, true );
	$data = array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'obento_delete_revisions_site' ),
		'action'  => 'obento_delete_revisions_site',
	);
	wp_add_inline_script( 'obento-revisions', 'var obentoRevisions = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', 'obento_revisions_enqueue' );

/**
 * AJAX: サイト全体のリビジョンを1回分消す
 *
 * JSがdoneになるまで繰り返し呼ぶ。初回（cursorが0）の応答には進捗の分母（total）を、doneの応答には件数の表の値（counts）を添える。
 * totalは消す前に数える。
 * 失敗はwp_send_json_error( array( 'message' => … ) )で、画面にそのまま出せる文言を返す（nonceの不一致も、コアの`-1`ではなくこの形で返す）。
 */
function obento_ajax_delete_revisions_site() {
	if ( ! check_ajax_referer( 'obento_delete_revisions_site', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'ページの有効期限が切れました。ページを読み込み直して、もう一度お試しください。' ), 403 );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'リビジョンを削除する権限がありません。' ), 403 );
	}
	$mode   = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : '';
	$cursor = isset( $_POST['cursor'] ) ? (int) $_POST['cursor'] : 0;
	if ( ! in_array( $mode, array( 'all', 'excess' ), true ) ) {
		wp_send_json_error( array( 'message' => '削除の種類が不正です。ページを読み込み直して、もう一度お試しください。' ), 400 );
	}
	$total  = 0 === $cursor ? obento_count_revisions_batch_total( $mode ) : null;
	$result = obento_delete_revisions_batch( $mode, $cursor );
	if ( null !== $total ) {
		$result['total'] = $total;
	}
	if ( $result['done'] ) {
		$result['counts'] = obento_count_revisions();
	}
	wp_send_json_success( $result );
}
add_action( 'wp_ajax_obento_delete_revisions_site', 'obento_ajax_delete_revisions_site' );
