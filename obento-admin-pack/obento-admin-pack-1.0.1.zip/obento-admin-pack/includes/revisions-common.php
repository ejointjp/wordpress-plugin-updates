<?php
/**
 * リビジョン管理の共通部分（純粋な関数）
 *
 * 対象の投稿タイプ、設定（obento_revisions。keep: 投稿タイプ => 最大リビジョン数）の読み出しとsanitize、
 * wp_revisions_to_keepへの適用、残す自動保存の判定、消すリビジョンの選別、1つの投稿の削除、
 * 件数の集計、サイト全体の1回分の削除。
 * フックはwp_revisions_to_keepのフィルターだけ。画面と一覧のフックはincludes/revisions-screen.php / revisions-list.phpが持つ。
 *
 * 削除はwp_delete_post_revision()に任せる（メタ・キャッシュ・他プラグインのフックをコアに任せるため）。
 * $wpdbを使うのは、件数の集計と消す候補の選別だけ。どのクエリもpost_status = 'inherit'のリビジョンだけを見る
 * （コアのwp_get_post_revisions()と同じ。承認待ちの変更をrevisionのpending / futureで持つプラグインの、未公開の編集を数えず、消さない）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 対象の投稿タイプ（obento_get_post_types()のうち、リビジョンをサポートするもの）
 *
 * @return WP_Post_Type[] 投稿タイプ名 => オブジェクト。
 */
function obento_get_revision_post_types() {
	$types = array();
	foreach ( obento_get_post_types() as $name => $type ) {
		if ( post_type_supports( $name, 'revisions' ) ) {
			$types[ $name ] = $type;
		}
	}
	return $types;
}

/**
 * 設定を返す（keep: 投稿タイプ => 0以上の整数）
 *
 * 読めないoption、整数でない値、負の値は捨てる。投稿タイプが登録されているかは見ない（sanitizeの仕事）。
 *
 * @return array{keep: array<string, int>}
 */
function obento_get_revisions_settings() {
	$settings = get_option( 'obento_revisions', array() );
	$keep     = array();
	if ( is_array( $settings ) && isset( $settings['keep'] ) && is_array( $settings['keep'] ) ) {
		foreach ( $settings['keep'] as $post_type => $value ) {
			if ( is_string( $post_type ) && is_int( $value ) && $value >= 0 ) {
				$keep[ $post_type ] = $value;
			}
		}
	}
	return array( 'keep' => $keep );
}

/**
 * 投稿タイプの最大リビジョン数（設定がなければnull。WordPressの既定のまま）
 *
 * @param string $post_type 投稿タイプ名。
 * @return int|null
 */
function obento_get_revision_keep( $post_type ) {
	$keep = obento_get_revisions_settings()['keep'];
	return isset( $keep[ $post_type ] ) ? $keep[ $post_type ] : null;
}

/**
 * WordPressの既定の最大リビジョン数（WP_POST_REVISIONS）の表示
 *
 * コアのwp_revisions_to_keep()と同じく、trueは無制限（-1）、それ以外は整数にする。
 *
 * @return string 無制限 / N件 / 保存しない。
 */
function obento_revisions_default_label() {
	$num = WP_POST_REVISIONS;
	$num = true === $num ? -1 : (int) $num;
	if ( $num < 0 ) {
		return '無制限';
	}
	return 0 === $num ? '保存しない' : number_format_i18n( $num ) . '件';
}

/**
 * 設定のsanitize
 *
 * 対象の投稿タイプごとに、送られてきた値を見る。
 * - 空（空文字、送られていない）: 値を持たない（WordPressの既定）
 * - 0以上の整数（前後の空白を除いてctype_digit()が真）: その値
 * - それ以外: 通知を出し、保存済みの値（なければ持たない）
 * 登録されていない投稿タイプと、リビジョンをサポートしない投稿タイプの値は捨てる。
 * update_option()に配列を渡したとき（初回の保存の2回目、検証）は値がintで届くので、文字列にしてから見る。
 * 通知はobento_cleanup_add_settings_error()（cleanup-common.php。obento-admin-pack.phpで先に読み込む）で登録する。
 * 同じコードは1回だけ登録し、文言をエスケープし、add_settings_error()が使えない文脈（WP-CLIなど）ではerror_logへ1行残す。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{keep: array<string, int>}
 */
function obento_sanitize_revisions_settings( $input ) {
	$previous = obento_get_revisions_settings()['keep'];
	$input    = is_array( $input ) ? $input : array();
	$sent     = isset( $input['keep'] ) && is_array( $input['keep'] ) ? $input['keep'] : array();
	$keep     = array();
	foreach ( obento_get_revision_post_types() as $name => $type ) {
		$raw = isset( $sent[ $name ] ) ? $sent[ $name ] : '';
		if ( is_int( $raw ) ) {
			$raw = (string) $raw;
		}
		$raw = is_string( $raw ) ? trim( $raw ) : 'invalid';
		if ( '' === $raw ) {
			continue;
		}
		if ( ctype_digit( $raw ) ) {
			$keep[ $name ] = (int) $raw;
			continue;
		}
		obento_cleanup_add_settings_error(
			'obento_revisions',
			'obento_revisions_invalid_' . $name,
			sprintf( '「%s」の最大リビジョン数は、0以上の整数にしてください。前の値を残しました。', $type->labels->name )
		);
		if ( isset( $previous[ $name ] ) ) {
			$keep[ $name ] = $previous[ $name ];
		}
	}
	return array( 'keep' => $keep );
}

/**
 * 設定の最大リビジョン数をコアに効かせる（wp_revisions_to_keepフィルター）
 *
 * WP_POST_REVISIONSより優先される。投稿タイプ別のフィルター（wp_{post_type}_revisions_to_keep）はこのあとに走るので、
 * テーマやプラグインがそれを使っていればそちらが勝つ。
 * リビジョンをサポートしない投稿タイプは触らない（sanitizeで捨てるのと二重）。
 *
 * @param int     $num  コアが決めた件数（-1は無制限）。
 * @param WP_Post $post 投稿。
 * @return int
 */
function obento_apply_revisions_to_keep( $num, $post ) {
	if ( ! $post instanceof WP_Post || ! post_type_supports( $post->post_type, 'revisions' ) ) {
		return $num;
	}
	$keep = obento_get_revision_keep( $post->post_type );
	return null === $keep ? $num : $keep;
}
add_filter( 'wp_revisions_to_keep', 'obento_apply_revisions_to_keep', 10, 2 );

/**
 * 残す自動保存か（自動保存で、親の更新日より新しいもの = 保存していない編集を含む）
 *
 * コアが編集画面で「より新しい自動保存があります」を出す判定（wp_get_post_autosave()の結果と親の更新日の比較）と同じ。
 *
 * @param WP_Post $revision    リビジョン。
 * @param WP_Post $parent_post 親の投稿。
 * @return bool
 */
function obento_is_autosave_to_keep( $revision, $parent_post ) {
	if ( false === strpos( $revision->post_name, 'autosave' ) ) {
		return false;
	}
	return mysql2date( 'U', $revision->post_modified_gmt, false ) > mysql2date( 'U', $parent_post->post_modified_gmt, false );
}

/**
 * 消すリビジョンを選ぶ
 *
 * 全件を古い順に取る。check_enabledを切るのは、上限を0にした投稿タイプの既存のリビジョンも消せるようにするため。
 * - all: 残す自動保存を除いて、すべて
 * - excess: コアのwp_save_post_revision()の間引きと同じ。wp_revisions_to_keep()が負なら何もしない。
 *   自動保存を含めた全件のうち古い順にcount - keep件を候補にし、候補の中の自動保存は飛ばす
 *   （間引いたあとの状態が、コアが次の保存で作る状態と同じになる）。
 *   リビジョンを保護するプラグインが、コアの間引き（6.2以降）のフィルターwp_save_post_revision_revisions_before_deletionで
 *   配列（リビジョンIDがキー）から外したものは、候補に入れない。コアと同じく、数える前に通す
 * 知らないmodeは、元に戻せないallとして扱わず、空を返す。
 *
 * @param WP_Post $post 親の投稿。
 * @param string  $mode all / excess。
 * @return WP_Post[] 古い順。
 */
function obento_select_revisions_to_delete( $post, $mode ) {
	$out = array();
	if ( 'all' !== $mode && 'excess' !== $mode ) {
		return $out;
	}
	$keep = 0;
	if ( 'excess' === $mode ) {
		$keep = wp_revisions_to_keep( $post );
		if ( $keep < 0 ) {
			return $out;
		}
	}
	$revisions = wp_get_post_revisions(
		$post->ID,
		array(
			'check_enabled' => false,
			'order'         => 'ASC',
			'orderby'       => 'date ID',
		)
	);
	if ( 'excess' === $mode ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- コアのフィルター。コアの間引きと同じ規則にして、リビジョンを保護するプラグインを尊重するために通す
		$revisions = array_values( (array) apply_filters( 'wp_save_post_revision_revisions_before_deletion', $revisions, $post->ID ) );
		$delete    = count( $revisions ) - $keep;
		if ( $delete < 1 ) {
			return $out;
		}
		foreach ( array_slice( $revisions, 0, $delete ) as $revision ) {
			if ( false === strpos( $revision->post_name, 'autosave' ) ) {
				$out[] = $revision;
			}
		}
		return $out;
	}
	foreach ( $revisions as $revision ) {
		if ( ! obento_is_autosave_to_keep( $revision, $post ) ) {
			$out[] = $revision;
		}
	}
	return $out;
}

/**
 * 1つの投稿のリビジョンを消す
 *
 * wp_delete_post_revision()で1件ずつ消す。1件でも消せたらobento_revisions_deletedを鳴らす（キャッシュの連携用）。
 * 投稿IDが0以下（get_post( 0 )はグローバルの$postを拾う）、リビジョン自身のID、ない投稿のID、知らないmodeには何もしない。
 * excessは、リビジョンをサポートしない投稿タイプではwp_revisions_to_keep()が0になり、自動保存以外をすべて消す。
 * 呼ぶ側（サイト全体の1回分）が対象の投稿タイプに絞る。
 *
 * @param int    $post_id 親の投稿ID。
 * @param string $mode    all / excess。
 * @return array{deleted: int[], failed: int[]} 消したIDと、消せなかったID。
 */
function obento_delete_post_revisions( $post_id, $mode = 'all' ) {
	$result  = array(
		'deleted' => array(),
		'failed'  => array(),
	);
	$post_id = (int) $post_id;
	if ( $post_id < 1 ) {
		return $result;
	}
	$post = get_post( $post_id );
	if ( ! $post || 'revision' === $post->post_type ) {
		return $result;
	}
	foreach ( obento_select_revisions_to_delete( $post, $mode ) as $revision ) {
		if ( wp_delete_post_revision( $revision->ID ) ) {
			$result['deleted'][] = $revision->ID;
		} else {
			$result['failed'][] = $revision->ID;
		}
	}
	if ( $result['deleted'] ) {
		/**
		 * リビジョンを消したあとに鳴る
		 *
		 * 1つの投稿で消したぶんを1回で渡す。ただし、サイト全体の削除は1回分ごとに区切るので、同じ親で複数回鳴ることがある。
		 * サイト全体の「すべて」が消す、親のないリビジョン（親の投稿が削除されて残ったもの）では、存在しない投稿IDで鳴る。
		 *
		 * @param int   $post_id     親の投稿ID。
		 * @param int[] $deleted_ids 消したリビジョンのID。
		 */
		do_action( 'obento_revisions_deleted', $post->ID, $result['deleted'] );
	}
	return $result;
}

/**
 * 自動保存を数えるLIKEのパターン（post_nameに「autosave」を含む。コアのstr_contains( post_name, 'autosave' )と同じ）
 *
 * @return string
 */
function obento_revisions_autosave_like() {
	global $wpdb;
	return '%' . $wpdb->esc_like( 'autosave' ) . '%';
}

/**
 * 空の件数の組
 *
 * @return array{total: int, autosave: int}
 */
function obento_revisions_empty_pair() {
	return array(
		'total'    => 0,
		'autosave' => 0,
	);
}

/**
 * サイト全体のリビジョンの件数（クエリ1本）
 *
 * wp_postsを自己結合し、親のpost_typeでまとめる。post_status = 'inherit'のものだけ数える（コアのリビジョンの件数と同じ）。親がない（LEFT JOINでNULL）ものは親なし、
 * 対象の投稿タイプでない（サポートしない、登録されていない）ものは「対象外」に入れる。対象の投稿タイプは0件でも行を持つ。
 *
 * @return array{types: array<string, array{total: int, autosave: int}>, other: array{total: int, autosave: int}, orphan: array{total: int, autosave: int}, total: array{total: int, autosave: int}}
 */
function obento_count_revisions() {
	global $wpdb;
	$rows    = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 親の投稿タイプごとの集計。コアにこの集計の関数はなく、削除のたびに変わるのでキャッシュしない
		$wpdb->prepare(
			"SELECT p.post_type AS parent_type, COUNT(*) AS total, SUM( r.post_name LIKE %s ) AS autosave
			FROM {$wpdb->posts} r
			LEFT JOIN {$wpdb->posts} p ON p.ID = r.post_parent
			WHERE r.post_type = 'revision' AND r.post_status = 'inherit'
			GROUP BY p.post_type",
			obento_revisions_autosave_like()
		)
	);
	$targets = array_keys( obento_get_revision_post_types() );
	$counts  = array(
		'types'  => array(),
		'other'  => obento_revisions_empty_pair(),
		'orphan' => obento_revisions_empty_pair(),
		'total'  => obento_revisions_empty_pair(),
	);
	foreach ( $targets as $name ) {
		$counts['types'][ $name ] = obento_revisions_empty_pair();
	}
	foreach ( (array) $rows as $row ) {
		$total    = (int) $row->total;
		$autosave = (int) $row->autosave;
		if ( null === $row->parent_type ) {
			$slot = &$counts['orphan'];
		} elseif ( in_array( $row->parent_type, $targets, true ) ) {
			$slot = &$counts['types'][ $row->parent_type ];
		} else {
			$slot = &$counts['other'];
		}
		$slot['total']    += $total;
		$slot['autosave'] += $autosave;
		unset( $slot );
		$counts['total']['total']    += $total;
		$counts['total']['autosave'] += $autosave;
	}
	return $counts;
}

/**
 * 投稿ごとのリビジョンの件数と、IDが最大のリビジョン（一覧のページぶんをクエリ1本で取る）
 *
 * post_status = 'inherit'のものだけ数える（エディターの「リビジョン N」と同じ数え方）。
 *
 * @param int[] $ids 投稿ID。
 * @return array<int, array{count: int, latest: int}> 頼んだIDはすべて入る（リビジョンがなければ0|0）。
 */
function obento_count_revisions_for_posts( $ids ) {
	global $wpdb;
	$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );
	$out = array();
	if ( ! $ids ) {
		return $out;
	}
	foreach ( $ids as $id ) {
		$out[ $id ] = array(
			'count'  => 0,
			'latest' => 0,
		);
	}
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$rows         = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 一覧のページぶんをまとめて数える（投稿ごとにwp_get_post_revisions()を呼ぶと1行1クエリになる）
		$wpdb->prepare(
			"SELECT post_parent, COUNT(*) AS total, MAX(ID) AS latest FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_status = 'inherit' AND post_parent IN ($placeholders) GROUP BY post_parent", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- プレースホルダーの並びだけを埋め込む
			$ids
		)
	);
	foreach ( (array) $rows as $row ) {
		$out[ (int) $row->post_parent ] = array(
			'count'  => (int) $row->total,
			'latest' => (int) $row->latest,
		);
	}
	return $out;
}

/**
 * サイト全体の削除の総数（進捗の分母。初回の呼び出しで取る）
 *
 * - all: 消す候補（残す自動保存を除いたリビジョン）の件数
 * - excess: リビジョンを持つ、対象の投稿タイプの投稿の件数
 * 知らないmodeは0。
 *
 * @param string $mode all / excess。
 * @return int
 */
function obento_count_revisions_batch_total( $mode ) {
	global $wpdb;
	if ( 'all' !== $mode && 'excess' !== $mode ) {
		return 0;
	}
	if ( 'excess' === $mode ) {
		$types = array_keys( obento_get_revision_post_types() );
		if ( ! $types ) {
			return 0;
		}
		$placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 進捗の分母。削除のたびに変わる
			$wpdb->prepare(
				"SELECT COUNT( DISTINCT r.post_parent ) FROM {$wpdb->posts} r INNER JOIN {$wpdb->posts} p ON p.ID = r.post_parent WHERE r.post_type = 'revision' AND r.post_status = 'inherit' AND p.post_type IN ($placeholders)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- プレースホルダーの並びだけを埋め込む
				$types
			)
		);
	}
	return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 進捗の分母。削除のたびに変わる
		$wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} r LEFT JOIN {$wpdb->posts} p ON p.ID = r.post_parent
			WHERE r.post_type = 'revision' AND r.post_status = 'inherit'
			AND NOT ( r.post_name LIKE %s AND p.ID IS NOT NULL AND r.post_modified_gmt > p.post_modified_gmt )",
			obento_revisions_autosave_like()
		)
	);
}

/**
 * サイト全体の削除の1回分
 *
 * 状態をサーバーに持たない。カーソルは「どこまで見たか」で、消せなかった行で止まらない
 * （wp_delete_post_revision()がfalseを返しても次へ進む）。
 * - all: ID > cursorのリビジョンを、残す自動保存を除いてID順に$limit件取り、消す。親なしと対象外の投稿タイプも消す。カーソルは最後に見たリビジョンのID。
 *   親ごとにobento_revisions_deletedを鳴らす
 * - excess: リビジョンを持つ対象の投稿タイプの親のうち、ID > cursorのものをID順に$limit件取り、それぞれobento_delete_post_revisions( …, 'excess' )する。
 *   カーソルは最後に見た親のID。1回に消す件数（消した+消せなかった）が$max_deletedに達したら、残りの親を見ずに、その親をカーソルにしてdone = falseで返す
 *   （上限を無制限から下げた長年のブログで、1回のリクエストが数千件の削除になってタイムアウトしないため）。
 *   親の途中では切らない。次の呼び出しはカーソルより大きい親から始まるので、途中で切るとその親の残りは消えないまま残る
 * 知らないmodeは何もせずdone。
 *
 * @param string $mode        all / excess。
 * @param int    $cursor      前回の応答のcursor。初回は0。
 * @param int    $limit       1回で見る件数。0なら既定（allは100件、excessは50件）。
 * @param int    $max_deleted excessで1回に消す件数の上限。0なら既定（100件）。1つの親の超過分がこれを超えるときは、その親の分を消し切ってから返す。allは$limitで決まるので使わない。
 * @return array{deleted: int, failed: int, checked: int, cursor: int, done: bool}
 */
function obento_delete_revisions_batch( $mode, $cursor, $limit = 0, $max_deleted = 0 ) {
	global $wpdb;
	$cursor = max( 0, (int) $cursor );
	$limit  = (int) $limit;
	$result = array(
		'deleted' => 0,
		'failed'  => 0,
		'checked' => 0,
		'cursor'  => $cursor,
		'done'    => true,
	);
	if ( 'excess' === $mode ) {
		$limit       = $limit > 0 ? $limit : 50;
		$max_deleted = (int) $max_deleted > 0 ? (int) $max_deleted : 100;
		$types       = array_keys( obento_get_revision_post_types() );
		if ( ! $types ) {
			return $result;
		}
		$placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$args         = array_merge( $types, array( $cursor, $limit ) );
		$parents      = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 消す候補の親をカーソルから順に取る。削除のたびに変わる
			$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- プレースホルダーの数は対象の投稿タイプの数+2。配列で渡すので数えられない
				"SELECT DISTINCT r.post_parent FROM {$wpdb->posts} r INNER JOIN {$wpdb->posts} p ON p.ID = r.post_parent WHERE r.post_type = 'revision' AND r.post_status = 'inherit' AND p.post_type IN ($placeholders) AND r.post_parent > %d ORDER BY r.post_parent ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- プレースホルダーの並びだけを埋め込む
				$args
			)
		);

		$last_index = count( $parents ) - 1;
		foreach ( $parents as $index => $parent_id ) {
			$deleted            = obento_delete_post_revisions( (int) $parent_id, 'excess' );
			$result['deleted'] += count( $deleted['deleted'] );
			$result['failed']  += count( $deleted['failed'] );
			++$result['checked'];
			$result['cursor'] = (int) $parent_id;
			if ( $index < $last_index && $result['deleted'] + $result['failed'] >= $max_deleted ) {
				// まだ親が残っている。ここで返し、続きは次の呼び出し（カーソルより大きい親）に回す
				$result['done'] = false;
				return $result;
			}
		}
		$result['done'] = count( $parents ) < $limit;
		return $result;
	}
	if ( 'all' !== $mode ) {
		return $result;
	}
	$limit     = $limit > 0 ? $limit : 100;
	$rows      = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- 消す候補をカーソルから順に取る。削除のたびに変わる
		$wpdb->prepare(
			"SELECT r.ID, r.post_parent FROM {$wpdb->posts} r LEFT JOIN {$wpdb->posts} p ON p.ID = r.post_parent
			WHERE r.post_type = 'revision' AND r.post_status = 'inherit' AND r.ID > %d
			AND NOT ( r.post_name LIKE %s AND p.ID IS NOT NULL AND r.post_modified_gmt > p.post_modified_gmt )
			ORDER BY r.ID ASC LIMIT %d",
			$cursor,
			obento_revisions_autosave_like(),
			$limit
		)
	);
	$by_parent = array();
	foreach ( (array) $rows as $row ) {
		++$result['checked'];
		$result['cursor'] = (int) $row->ID;
		if ( wp_delete_post_revision( (int) $row->ID ) ) {
			++$result['deleted'];
			$by_parent[ (int) $row->post_parent ][] = (int) $row->ID;
		} else {
			++$result['failed'];
		}
	}
	foreach ( $by_parent as $parent_id => $ids ) {
		/** This action is documented in includes/revisions-common.php */
		do_action( 'obento_revisions_deleted', $parent_id, $ids );
	}
	$result['done'] = count( $rows ) < $limit;
	return $result;
}
