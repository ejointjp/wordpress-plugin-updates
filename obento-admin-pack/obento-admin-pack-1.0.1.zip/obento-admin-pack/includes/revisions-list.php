<?php
/**
 * 投稿一覧のリビジョン（列、行アクション、一括操作、admin-postの受け口、通知）
 *
 * 対象の投稿タイプ（リビジョンをサポートするもの）の一覧（edit.php）に足す。
 * 列のフックは、Quick Edit（admin-ajax.phpのinline-save）が返す行にも要るので、admin_initで投稿タイプごとに登録する（load-edit.phpは走らない）。
 * 利用者のデータを書く処理と、一覧の画面だけに要るフック（通知、スクリプトの読み込みなど）は、load-edit.phpのときに足す。
 * - 列「リビジョン」: 件数（自動保存を含む。エディターの「リビジョン N」と同じ数え方）。初期状態は非表示
 * - 行アクション「リビジョンを削除」: admin-post.phpへのGET＋nonce（コアの「ゴミ箱」と同じ形）
 * - 一括操作「リビジョンを削除」
 * 件数は、ページに出ている投稿のぶんをクエリ1本でまとめて取る（includes/revisions-common.phpのobento_count_revisions_for_posts()）。
 * 削除の中身は同じファイルのobento_delete_post_revisions()。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 列のフックを登録する（投稿タイプが登録されたあとに走らせる）
 *
 * 一覧の表示（edit.php）だけでなく、Quick Edit（admin-ajax.phpのinline-save）が行を描き直すときも同じ列が要る。
 * load-edit.phpはinline-saveでは走らないので、ここで（admin_initで）登録する。ID列（includes/id-column.php）と同じ形。
 * 初期状態で非表示にするdefault_hidden_columnsはファイルの読み込みのときに足す（コールバックが画面を見て、対象の一覧だけに効かせる）。
 */
function obento_revisions_columns_init() {
	foreach ( array_keys( obento_get_revision_post_types() ) as $post_type ) {
		add_filter( "manage_{$post_type}_posts_columns", 'obento_add_revisions_column' );
	}
}
add_action( 'admin_init', 'obento_revisions_columns_init' );
add_filter( 'default_hidden_columns', 'obento_revisions_default_hidden', 10, 2 );

/**
 * 対象の投稿一覧でだけ要るフックを足す（load-edit.php）
 *
 * ここは、実際に一覧を開いたときだけ走る。ユーザーのデータを書く処理（初回の非表示）と、一覧の画面だけに要るフック
 * （一括操作、通知、スクリプトの読み込み）をここに足す。
 * 列と行アクションは、Quick Editが返す行にも要るので、ここでは足さない（列はobento_revisions_columns_init()でadmin_initのときに、
 * 行アクションはobento_revisions_row_action()の直後にファイルの読み込みのときに、常時登録する。コールバックが投稿タイプを見て絞る）。
 * admin-post.phpの受け口と、通知のクエリ引数の後始末はこの外（ファイルの末尾）で登録する（画面がないため）。
 */
function obento_revisions_list_setup() {
	$screen = get_current_screen();
	if ( ! $screen || 'edit' !== $screen->base || ! isset( obento_get_revision_post_types()[ $screen->post_type ] ) ) {
		return;
	}
	obento_revisions_hide_column_once( $screen );
	add_action( 'admin_notices', 'obento_revisions_list_notice' );
	add_action( 'admin_enqueue_scripts', 'obento_revisions_list_enqueue' );
	add_filter( "bulk_actions-{$screen->id}", 'obento_revisions_bulk_action' );
	add_filter( "handle_bulk_actions-{$screen->id}", 'obento_handle_revisions_bulk', 10, 3 );
}
add_action( 'load-edit.php', 'obento_revisions_list_setup' );

/**
 * 表示オプションを保存済みのユーザーに、初回だけ列を非表示にする
 *
 * default_hidden_columnsは、user option（manage{screen->id}columnshidden）がないユーザーにしか効かない。
 * 保存済みのユーザーには、一度だけ非表示リストへ足す。処理したことはユーザーメタ（画面IDの配列）に残し、
 * user optionがなかったときも残す（あとでユーザーが表示オプションを保存したときに、もう一度隠してしまわないため）。
 *
 * @param WP_Screen $screen 画面。
 */
function obento_revisions_hide_column_once( $screen ) {
	$user_id = get_current_user_id();
	if ( ! $user_id ) {
		return;
	}
	$seen = get_user_meta( $user_id, 'obento_revisions_column_seen', true );
	$seen = is_array( $seen ) ? $seen : array();
	if ( in_array( $screen->id, $seen, true ) ) {
		return;
	}
	$option = 'manage' . $screen->id . 'columnshidden';
	$hidden = get_user_option( $option );
	if ( is_array( $hidden ) && ! in_array( 'obento_revisions', $hidden, true ) ) {
		$hidden[] = 'obento_revisions';
		update_user_option( $user_id, $option, $hidden, true );
	}
	$seen[] = $screen->id;
	update_user_meta( $user_id, 'obento_revisions_column_seen', $seen );
}

/**
 * 列の一覧に「リビジョン」を足す（「日付」の前。「日付」がなければ末尾）
 *
 * @param array $columns 列のキー => 見出し。
 * @return array
 */
function obento_add_revisions_column( $columns ) {
	$columns = is_array( $columns ) ? $columns : array();
	if ( isset( $columns['obento_revisions'] ) ) {
		return $columns;
	}
	$out = array();
	foreach ( $columns as $key => $label ) {
		if ( 'date' === $key ) {
			$out['obento_revisions'] = 'リビジョン';
		}
		$out[ $key ] = $label;
	}
	if ( ! isset( $out['obento_revisions'] ) ) {
		$out['obento_revisions'] = 'リビジョン';
	}
	return $out;
}

/**
 * 列を初期状態で非表示にする（default_hidden_columns）
 *
 * ファイルの読み込みのときに登録する。対象の投稿タイプの一覧の画面（edit）のときだけ足す（Quick Editが行を描き直すときの画面も同じ）。
 *
 * @param string[]  $hidden 非表示の列。
 * @param WP_Screen $screen 画面。
 * @return string[]
 */
function obento_revisions_default_hidden( $hidden, $screen ) {
	$hidden = is_array( $hidden ) ? $hidden : array();
	if ( ! $screen instanceof WP_Screen || 'edit' !== $screen->base || ! isset( obento_get_revision_post_types()[ $screen->post_type ] ) ) {
		return $hidden;
	}
	if ( ! in_array( 'obento_revisions', $hidden, true ) ) {
		$hidden[] = 'obento_revisions';
	}
	return $hidden;
}

/**
 * 投稿のリビジョンの件数と、IDが最大のリビジョン（一覧のページぶんをまとめて取る）
 *
 * 列を描くときと行アクションを作るときのどちらが先でも、最初の呼び出しで$wp_query->postsのIDを集めて1回だけ問い合わせ、staticに持つ。
 * 階層ありの投稿タイプ（固定ページなど）の一覧は、コアがfields=id=>parentでメインクエリを引くので、postsの中身はWP_Postではなく
 * IDを持つstdClass。どちらでも集める。postsが空のうちは「集めた」ことにせず、あとの呼び出しでもう一度集める。
 * 持っていないIDを求められたら、その1件だけ問い合わせる。
 *
 * @param int $post_id 投稿ID。
 * @return array{count: int, latest: int}
 */
function obento_revisions_list_count( $post_id ) {
	static $cache  = array();
	static $loaded = false;

	$post_id = (int) $post_id;
	if ( ! isset( $cache[ $post_id ] ) ) {
		$ids = array( $post_id );
		if ( ! $loaded && isset( $GLOBALS['wp_query'] ) && $GLOBALS['wp_query'] instanceof WP_Query ) {
			foreach ( (array) $GLOBALS['wp_query']->posts as $post ) {
				if ( is_object( $post ) && isset( $post->ID ) ) {
					$ids[]  = (int) $post->ID;
					$loaded = true;
				}
			}
		}
		$cache += obento_count_revisions_for_posts( $ids );
	}
	return $cache[ $post_id ];
}

/**
 * 列「リビジョン」の中身
 *
 * 0件は「—」。件数は、編集できて（edit_post）リビジョンが有効なら（wp_revisions_enabled()。上限0の投稿タイプではリビジョン画面を開いても何も出ない）、
 * IDが最大のリビジョンの画面（revision.php）へのリンクにする。
 *
 * @param string $column  列のキー。
 * @param int    $post_id 投稿ID。
 */
function obento_render_revisions_column( $column, $post_id ) {
	if ( 'obento_revisions' !== $column ) {
		return;
	}
	$info = obento_revisions_list_count( $post_id );
	if ( $info['count'] < 1 ) {
		echo '—';
		return;
	}
	$text = number_format_i18n( $info['count'] );
	$post = get_post( $post_id );
	if ( $post && $info['latest'] && current_user_can( 'edit_post', $post_id ) && wp_revisions_enabled( $post ) ) {
		printf( '<a href="%s">%s</a>', esc_url( admin_url( 'revision.php?revision=' . $info['latest'] ) ), esc_html( $text ) );
		return;
	}
	echo esc_html( $text );
}
add_action( 'manage_posts_custom_column', 'obento_render_revisions_column', 10, 2 );
add_action( 'manage_pages_custom_column', 'obento_render_revisions_column', 10, 2 );

/**
 * 行アクション「リビジョンを削除（N件）」
 *
 * 件数が1以上で、親のdelete_postがあり、ゴミ箱の中でないときだけ出す。
 * admin-post.phpへのGET＋nonce（コアの「ゴミ箱」と同じ形）。JSがdata-titleで確認を出す。
 * 権限は親のdelete_post（コアはリビジョン単体のdelete_postを常に拒否するが、親を完全に削除できる人はリビジョンも消せる）。
 *
 * @param string[] $actions 行アクション。
 * @param WP_Post  $post    投稿。
 * @return string[]
 */
function obento_revisions_row_action( $actions, $post ) {
	if ( ! post_type_supports( $post->post_type, 'revisions' ) || 'trash' === $post->post_status || ! current_user_can( 'delete_post', $post->ID ) ) {
		return $actions;
	}
	$count = obento_revisions_list_count( $post->ID )['count'];
	if ( $count < 1 ) {
		return $actions;
	}
	$title                              = _draft_or_post_title( $post );
	$url                                = wp_nonce_url( admin_url( 'admin-post.php?action=obento_delete_revisions&post=' . $post->ID ), 'obento_delete_revisions_' . $post->ID );
	$actions['obento_delete_revisions'] = sprintf(
		'<a href="%1$s" class="obento-delete-revisions" data-title="%2$s" aria-label="%3$s">リビジョンを削除（%4$s件）</a>',
		esc_url( $url ),
		esc_attr( $title ),
		esc_attr( '「' . $title . '」のリビジョンを削除' ),
		esc_html( number_format_i18n( $count ) )
	);
	return $actions;
}
// Quick Edit（admin-ajax.phpのinline-save）が返す行にも要る（load-edit.phpは走らない）ので、ファイルの読み込みのときに常時登録する。
add_filter( 'post_row_actions', 'obento_revisions_row_action', 10, 2 );
add_filter( 'page_row_actions', 'obento_revisions_row_action', 10, 2 );

/**
 * admin-post.php: 1つの投稿のリビジョンを消して、一覧へ戻す
 *
 * nonce、投稿があること、親のdelete_postを確かめ、ダメならwp_die()（403）。
 * 戻り先はReferer（なければその投稿タイプの一覧）。件数をobento_revisions_deletedに付け、一覧の通知で出す。
 */
function obento_handle_delete_revisions() {
	// 投稿IDは、直後のcheck_admin_referer()のアクション名に使う（整数にしてから渡す）。
	$post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
	check_admin_referer( 'obento_delete_revisions_' . $post_id );
	$post = get_post( $post_id );
	if ( ! $post || 'revision' === $post->post_type || ! current_user_can( 'delete_post', $post_id ) ) {
		wp_die( 'この投稿のリビジョンを削除する権限がありません。', 403 );
	}
	$result = obento_delete_post_revisions( $post_id, 'all' );
	$back   = wp_get_referer();
	if ( ! $back ) {
		$back = admin_url( 'edit.php?post_type=' . $post->post_type );
	}
	wp_safe_redirect( add_query_arg( 'obento_revisions_deleted', count( $result['deleted'] ), remove_query_arg( 'obento_revisions_deleted', $back ) ) );
	exit;
}
add_action( 'admin_post_obento_delete_revisions', 'obento_handle_delete_revisions' );

/**
 * 一覧の通知（削除の件数）
 *
 * obento_revisions_list_setup()で対象の一覧にだけ登録される。
 */
function obento_revisions_list_notice() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示の切り替えにだけ使う
	if ( ! isset( $_GET['obento_revisions_deleted'] ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 同上
	$count = (int) $_GET['obento_revisions_deleted'];
	if ( $count > 0 ) {
		wp_admin_notice(
			esc_html( 'リビジョンを' . number_format_i18n( $count ) . '件削除しました。' ),
			array(
				'type'        => 'success',
				'dismissible' => true,
			)
		);
		return;
	}
	wp_admin_notice(
		'削除できるリビジョンはありませんでした。保存していない編集を含む自動保存は残します。',
		array(
			'type'        => 'info',
			'dismissible' => true,
		)
	);
}

/**
 * 通知のクエリ引数を、表示したらアドレスバーから消す（再読み込みで同じ通知を出さないため）
 *
 * @param string[] $args コアが消す引数。
 * @return string[]
 */
function obento_revisions_removable_args( $args ) {
	$args[] = 'obento_revisions_deleted';
	return $args;
}
add_filter( 'removable_query_args', 'obento_revisions_removable_args' );

/**
 * 対象の一覧にスクリプトを読み込む（行アクションと一括操作の確認）
 *
 * obento_revisions_list_setup()で対象の一覧にだけ登録される。設定画面と同じファイルで、グローバル変数は注入しない。
 *
 * @param string $hook 管理画面のページ。
 */
function obento_revisions_list_enqueue( $hook ) {
	if ( 'edit.php' !== $hook ) {
		return;
	}
	wp_enqueue_script( 'obento-revisions', OBENTO_URL . 'assets/revisions.js', array( 'jquery', 'wp-a11y' ), OBENTO_VERSION, true );
}

/**
 * 一括操作に「リビジョンを削除」を足す
 *
 * ゴミ箱のビュー（post_status=trash）には足さない（行アクションをゴミ箱で出さないのとそろえる）。
 *
 * @param string[] $actions 一括操作（キー => 表示名）。
 * @return string[]
 */
function obento_revisions_bulk_action( $actions ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示の切り替えにだけ使う
	if ( isset( $_GET['post_status'] ) && 'trash' === sanitize_key( wp_unslash( $_GET['post_status'] ) ) ) {
		return $actions;
	}
	$actions['obento_delete_revisions'] = 'リビジョンを削除';
	return $actions;
}

/**
 * 一括操作「リビジョンを削除」の処理
 *
 * 先に選んだ投稿すべてのdelete_postを確かめ、1つでもなければwp_die()（403。コアの一括のゴミ箱と同じ）。消す前に確かめるので、途中まで消えない。
 * 戻り先のURLに合計の件数（obento_revisions_deleted）を付け、一覧の通知で出す。
 *
 * @param string $sendback 戻り先のURL。
 * @param string $action   一括操作のキー。
 * @param int[]  $ids      選んだ投稿ID。
 * @return string
 */
function obento_handle_revisions_bulk( $sendback, $action, $ids ) {
	if ( 'obento_delete_revisions' !== $action ) {
		return $sendback;
	}
	$ids = array_map( 'intval', (array) $ids );
	foreach ( $ids as $id ) {
		if ( ! current_user_can( 'delete_post', $id ) ) {
			wp_die( 'この投稿のリビジョンを削除する権限がありません。', 403 );
		}
	}
	$deleted = 0;
	foreach ( $ids as $id ) {
		$deleted += count( obento_delete_post_revisions( $id, 'all' )['deleted'] );
	}
	return add_query_arg( 'obento_revisions_deleted', $deleted, remove_query_arg( 'obento_revisions_deleted', $sendback ) );
}
