<?php
/**
 * 「公開プレビュー」タブ（設定 > Obento Admin Pack）
 *
 * option obento_previewの登録と、タブの描画（対象の投稿タイプのチェックボックス、有効期限の日数）。
 * 保存はSettings API。option groupはobento_preview（ほかのタブとは別。片方の保存でもう片方を消さない）。
 * 読み出しとsanitizeはincludes/preview-common.phpの関数。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * optionを登録する
 */
function obento_register_preview_setting() {
	register_setting(
		'obento_preview',
		'obento_preview',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obento_sanitize_preview_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'obento_register_preview_setting' );

/**
 * タブを描く（settings.phpのobento_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。
 */
function obento_render_preview_tab() {
	$settings = obento_get_preview_settings();
	?>
	<p>公開前の投稿（下書き・レビュー待ち・予約済み）を、ログインしていない人に見せるリンクを作ります。投稿の編集画面の「概要」パネルで有効にします。リンクを知っている人は誰でも見られます。</p>
	<form action="options.php" method="post">
		<?php settings_fields( 'obento_preview' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
			<tr>
				<th scope="row">対象の投稿タイプ</th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">対象の投稿タイプ</legend>
						<?php foreach ( obento_get_preview_post_types() as $name => $type ) : ?>
							<label><input type="checkbox" name="obento_preview[post_types][]" value="<?php echo esc_attr( $name ); ?>"<?php checked( in_array( $name, $settings['post_types'], true ) ); ?>> <?php echo esc_html( $type->labels->name ); ?> <code><?php echo esc_html( $name ); ?></code></label><br>
						<?php endforeach; ?>
					</fieldset>
					<p class="description">選んだ投稿タイプの編集画面と一覧にだけ、公開プレビューの操作が出ます。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="obento-preview-days">有効期限（日）</label></th>
				<td>
					<input type="number" min="0" max="365" step="1" class="small-text" id="obento-preview-days" name="obento_preview[days]" value="<?php echo (int) $settings['days']; ?>">
					<p class="description">有効にした時刻から数えます。0で無期限。変えると、すでに有効にしているリンクの期限にもすぐ効きます。</p>
				</td>
			</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
	</form>
	<?php
}
