<?php
/**
 * 公開プレビューの投稿一覧（印と行アクション）
 *
 * タイトルの横の状態ラベル（「下書き」と同じ場所）に「公開プレビュー中」「公開プレビュー（期限切れ）」を足し、
 * 期限内なら行アクション「プレビューリンクをコピー」を出す。どちらも、その投稿を編集できる人（edit_post）にだけ出す。列は増やさない。
 * 行アクションのhrefはプレビューのURL（JSが効かない環境では新しいタブで開く）。assets/preview-list.jsがクリックでコピーに変える。
 * Quick Edit（admin-ajax.phpのinline-save）が返す行にも要る（load-edit.phpは走らない）ので、フィルターはファイルの読み込みのときに常時登録する。
 * 一覧からの有効化・取り消しはしない（エディターで足りる）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 状態ラベルに公開プレビューの印を足す（display_post_states）
 *
 * メタがあり、投稿タイプが設定で選ばれ、ステータスが対象で、現在のユーザーがその投稿を編集できる（edit_post）ときだけ。
 * コアの投稿一覧は、edit_others_postsを持たない人（寄稿者・投稿者）にも他人の下書きの行（タイトル）を出す。コアのプレビューの行アクションは
 * 編集権限で隠れるが、印と行アクションが権限を見ないと、他人の下書きの秘密のURLを一覧のHTMLから取れてしまうので、編集できない人には出さない。
 *
 * @param string[] $states 状態ラベル（キー => 表示名）。
 * @param WP_Post  $post   投稿。
 * @return string[]
 */
function obento_preview_post_states( $states, $post ) {
	if ( ! obento_preview_is_target_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $states;
	}
	$meta = obento_preview_get( $post->ID );
	if ( null === $meta ) {
		return $states;
	}
	$states['obento_preview'] = obento_preview_is_expired( $meta ) ? '公開プレビュー（期限切れ）' : '公開プレビュー中';
	return $states;
}
add_filter( 'display_post_states', 'obento_preview_post_states', 10, 2 );

/**
 * 行アクション「プレビューリンクをコピー」を足す（印と同じ条件（編集できる人だけ）のうち、期限内のとき）
 *
 * 編集できない人に出さない理由は、obento_preview_post_states()と同じ（hrefに秘密のURLが入る）。
 *
 * @param string[] $actions 行アクション。
 * @param WP_Post  $post    投稿。
 * @return string[]
 */
function obento_preview_row_action( $actions, $post ) {
	if ( ! obento_preview_is_target_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $actions;
	}
	$meta = obento_preview_get( $post->ID );
	if ( null === $meta || obento_preview_is_expired( $meta ) ) {
		return $actions;
	}
	$title                          = _draft_or_post_title( $post );
	$actions['obento_preview_copy'] = sprintf(
		'<a href="%1$s" class="obento-preview-copy" target="_blank" rel="noopener" aria-label="%2$s">プレビューリンクをコピー</a>',
		esc_url( obento_preview_url( $post ) ),
		esc_attr( '「' . $title . '」のプレビューリンクをコピー' )
	);
	return $actions;
}
add_filter( 'post_row_actions', 'obento_preview_row_action', 10, 2 );
add_filter( 'page_row_actions', 'obento_preview_row_action', 10, 2 );

/**
 * 設定で選んだ投稿タイプの一覧にスクリプトを読み込む
 *
 * @param string $hook 管理画面のページ。
 */
function obento_preview_list_enqueue( $hook ) {
	if ( 'edit.php' !== $hook ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! obento_preview_is_post_type_enabled( $screen->post_type ) ) {
		return;
	}
	wp_enqueue_script( 'obento-preview-list', OBENTO_URL . 'assets/preview-list.js', array( 'wp-a11y' ), OBENTO_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'obento_preview_list_enqueue' );
