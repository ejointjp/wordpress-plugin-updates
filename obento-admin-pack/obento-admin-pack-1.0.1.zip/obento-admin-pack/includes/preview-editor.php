<?php
/**
 * 公開プレビューのエディター（ブロックエディターの「概要」パネルとAJAX）
 *
 * 設定で選んだ投稿タイプの編集画面（post.php / post-new.php）にだけassets/preview-editor.jsを読み込み、初期状態とnonceを渡す。
 * 切り替え（有効・取り消し）と延長はAJAX（obento_preview）で、保存を待たずに効く（有効にした直後からリンクを共有できる）。
 * トークンはサーバーで作る。クラシックエディターには出ない。
 * リンクは、ログインしていない人にも下書きを見せるので、作る・延ばすのは、その投稿タイプの投稿を公開できる人（publish_posts）だけ。
 * 取り消しは、投稿を編集できる人なら誰でもできる（見せたくなくなったときに止められるように）。投稿タイプが設定から外れていても通す。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 現在のユーザーが、その投稿タイプの投稿を公開できるか（publish_posts）
 *
 * 公開プレビューのリンクを作る・延ばす権限の判定に使う。登録されていない投稿タイプはfalse。
 *
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obento_preview_user_can_publish( $post_type ) {
	$object = get_post_type_object( $post_type );
	return $object && current_user_can( $object->cap->publish_posts );
}

/**
 * 編集画面にスクリプトを読み込む（enqueue_block_editor_assets）
 *
 * サイトエディターやウィジェットの画面でも鳴るので、画面のbaseがpostのときだけ。
 * 投稿を公開できない人（寄稿者など。publish_posts）にはパネルを出さないので、読み込まない。
 */
function obento_preview_editor_enqueue() {
	$screen = get_current_screen();
	if ( ! $screen || 'post' !== $screen->base || ! obento_preview_is_post_type_enabled( $screen->post_type ) || ! obento_preview_user_can_publish( $screen->post_type ) ) {
		return;
	}
	wp_enqueue_script(
		'obento-preview-editor',
		OBENTO_URL . 'assets/preview-editor.js',
		array( 'wp-plugins', 'wp-editor', 'wp-element', 'wp-components', 'wp-data', 'wp-a11y', 'jquery' ),
		OBENTO_VERSION,
		true
	);
	$post = get_post();
	$data = array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'obento_preview' ),
		'action'  => 'obento_preview',
		'days'    => obento_get_preview_settings()['days'],
		'state'   => obento_preview_state( $post ? $post->ID : 0 ),
	);
	wp_add_inline_script( 'obento-preview-editor', 'var obentoPreview = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'obento_preview_editor_enqueue' );

/**
 * AJAX: 公開プレビューを有効にする・取り消す・延長する
 *
 * 引数: post_id、op（enable / disable / extend）、nonce（obento_preview）。
 * nonce、投稿があること、edit_postを確かめる。disableはここまでだけでよい（編集できる人なら誰でも取り消せる。投稿タイプが設定から外れていても通す。
 * 外したあとも、すでに出したリンクを止められるように）。enableとextendはさらに、投稿タイプが設定で選ばれていること、
 * その投稿タイプの投稿を公開できること（publish_posts）、ステータスが対象であることを確かめる。
 * 失敗はwp_send_json_error( array( 'message' => … ) )で、画面にそのまま出せる文言を返す（nonceの不一致も、コアの`-1`ではなくこの形で返す）。
 * 成功はobento_preview_state()を返す。
 */
function obento_ajax_preview() {
	if ( ! check_ajax_referer( 'obento_preview', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'ページの有効期限が切れました。ページを読み込み直して、もう一度お試しください。' ), 403 );
	}
	$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
	$op      = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
	$post    = get_post( $post_id );
	if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( array( 'message' => 'この投稿を編集する権限がありません。' ), 403 );
	}
	// 取り消しは、投稿タイプの設定を問わない（設定から外したあとも、出したリンクを止められるように）
	if ( 'disable' === $op ) {
		obento_preview_disable( $post_id );
		wp_send_json_success( obento_preview_state( $post_id ) );
	}
	if ( ! obento_preview_is_post_type_enabled( $post->post_type ) ) {
		wp_send_json_error( array( 'message' => 'この投稿タイプは公開プレビューの対象ではありません。設定 > Obento Admin Packの「公開プレビュー」タブで選んでください。' ), 400 );
	}
	switch ( $op ) {
		case 'enable':
		case 'extend':
			if ( ! obento_preview_user_can_publish( $post->post_type ) ) {
				wp_send_json_error( array( 'message' => 'この投稿の公開プレビューを有効にする権限がありません。公開できる人に依頼してください。' ), 403 );
			}
			if ( ! in_array( $post->post_status, obento_preview_statuses(), true ) ) {
				wp_send_json_error( array( 'message' => '公開プレビューは、下書き・レビュー待ち・予約済みの投稿で使えます。' ), 400 );
			}
			if ( 'enable' === $op ) {
				obento_preview_enable( $post_id );
			} elseif ( null === obento_preview_extend( $post_id ) ) {
				wp_send_json_error( array( 'message' => 'この投稿の公開プレビューは有効になっていません。ページを読み込み直してください。' ), 400 );
			}
			break;
		default:
			wp_send_json_error( array( 'message' => '操作が不正です。ページを読み込み直して、もう一度お試しください。' ), 400 );
	}
	wp_send_json_success( obento_preview_state( $post_id ) );
}
add_action( 'wp_ajax_obento_preview', 'obento_ajax_preview' );
