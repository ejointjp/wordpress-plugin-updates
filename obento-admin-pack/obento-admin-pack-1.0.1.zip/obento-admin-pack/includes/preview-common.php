<?php
/**
 * 公開プレビューの共通部分（純粋な関数）
 *
 * 対象の投稿タイプ、設定（obento_preview。post_types: 対象の投稿タイプ、days: 有効期限の日数。0は無期限）の読み出しとsanitize、
 * 投稿メタ（_obento_preview。token: 32文字の英数字、started: 有効にした時刻、post_id: 有効にした投稿のID）の読み書き（有効・取り消し・延長）、期限、URL、
 * エディターと一覧とAJAXの応答で共有する状態の配列。
 * フックはtransition_post_status（公開か非公開になるか、ゴミ箱に入れたらメタを消す）だけ。表側・エディター・一覧・設定画面のフックは
 * includes/preview-front.php / preview-editor.php / preview-list.php / preview-screen.phpが持つ。
 *
 * 期限は実行時に「started + days日」で計算する（設定の日数を変えると、すでに有効にしているリンクにもすぐ効く）。
 * 取り消しはメタを消すだけなので、再び有効にすると新しいトークンになり、古いリンクは使えなくなる。延長はトークンを変えない。
 * トークンは投稿IDと結び付く。メタのpost_idが読んでいる投稿のIDと違えば無効（複製プラグインがメタを写しても、写した先では使えない）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 対象にできる投稿タイプ（obento_get_post_types()のうち、表側で見られるもの）
 *
 * 表側で見られない投稿タイプは、プレビューの意味がない。
 *
 * @return WP_Post_Type[] 投稿タイプ名 => オブジェクト。
 */
function obento_get_preview_post_types() {
	$types = array();
	foreach ( obento_get_post_types() as $name => $type ) {
		if ( is_post_type_viewable( $type ) ) {
			$types[ $name ] = $type;
		}
	}
	return $types;
}

/**
 * 公開プレビューを有効にできるステータス
 *
 * @return string[]
 */
function obento_preview_statuses() {
	return array( 'draft', 'pending', 'future' );
}

/**
 * 設定を返す（post_types: 投稿タイプ名の配列、days: 0以上の整数。0は無期限）
 *
 * 読めないoption、文字列でない投稿タイプ名、整数でない・負の日数は捨てる。日数がなければ30。
 * 投稿タイプのキーがなければ（一度も保存していなければ）投稿と固定ページ。保存して空にしたものは空のまま。
 * 投稿タイプが登録されているかは見ない（sanitizeの仕事）。
 *
 * @return array{post_types: string[], days: int}
 */
function obento_get_preview_settings() {
	$option     = get_option( 'obento_preview', array() );
	$option     = is_array( $option ) ? $option : array();
	$post_types = array_key_exists( 'post_types', $option ) ? array() : array( 'post', 'page' );
	if ( isset( $option['post_types'] ) && is_array( $option['post_types'] ) ) {
		$post_types = array_values( array_filter( $option['post_types'], 'is_string' ) );
	}
	$days = isset( $option['days'] ) && is_int( $option['days'] ) && $option['days'] >= 0 ? $option['days'] : 30;
	return array(
		'post_types' => $post_types,
		'days'       => $days,
	);
}

/**
 * 投稿タイプが設定で選ばれているか
 *
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obento_preview_is_post_type_enabled( $post_type ) {
	return in_array( $post_type, obento_get_preview_settings()['post_types'], true );
}

/**
 * 投稿が公開プレビューの対象か（WP_Postで、投稿タイプが設定で選ばれ、ステータスが対象）
 *
 * @param mixed $post 投稿。
 * @return bool
 */
function obento_preview_is_target_post( $post ) {
	return $post instanceof WP_Post
		&& obento_preview_is_post_type_enabled( $post->post_type )
		&& in_array( $post->post_status, obento_preview_statuses(), true );
}

/**
 * 設定のsanitize
 *
 * post_typesは対象にできる投稿タイプだけ残す（停止中のプラグインの投稿タイプは落ちる）。
 * daysは数字だけの文字列なら整数にして0〜365に収め、空欄と数字でない値（負の数・小数を含む）は30にする。
 *
 * @param mixed $input 送られてきた設定。
 * @return array{post_types: string[], days: int}
 */
function obento_sanitize_preview_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	$days  = isset( $input['days'] ) && is_scalar( $input['days'] ) ? trim( (string) $input['days'] ) : '';
	return array(
		'post_types' => obento_sanitize_name_list( $input, 'post_types', array_keys( obento_get_preview_post_types() ) ),
		'days'       => ctype_digit( $days ) ? min( 365, (int) $days ) : 30,
	);
}

/**
 * 投稿のメタを返す（なければ、壊れていれば、投稿IDと結び付いていなければnull）
 *
 * メタのpost_idが整数で、引数の投稿IDと同じときだけ有効。複製プラグインなどが投稿のメタをそのまま別の投稿へ写しても、
 * 写した先ではpost_idが合わないのでnullになる（エディター・一覧・表側のどこでも無効として扱われ、元のトークンで写した先は開けない）。
 *
 * @param int $post_id 投稿ID。
 * @return array{token: string, started: int, post_id: int}|null
 */
function obento_preview_get( $post_id ) {
	$post_id = (int) $post_id;
	$meta    = get_post_meta( $post_id, '_obento_preview', true );
	if (
		! is_array( $meta )
		|| ! isset( $meta['token'], $meta['started'], $meta['post_id'] )
		|| ! is_string( $meta['token'] ) || '' === $meta['token']
		|| ! is_int( $meta['started'] )
		|| ! is_int( $meta['post_id'] ) || $post_id !== $meta['post_id']
	) {
		return null;
	}
	return array(
		'token'   => $meta['token'],
		'started' => $meta['started'],
		'post_id' => $meta['post_id'],
	);
}

/**
 * 公開プレビューを有効にする（新しいトークンと今の時刻でメタを書く）
 *
 * ステータスや投稿タイプは見ない（呼ぶ側の仕事。AJAXが確かめる）。
 *
 * @param int $post_id 投稿ID。
 * @return array{token: string, started: int, post_id: int} 書いたメタ。
 */
function obento_preview_enable( $post_id ) {
	$post_id = (int) $post_id;
	$meta    = array(
		'token'   => wp_generate_password( 32, false ),
		'started' => time(),
		'post_id' => $post_id,
	);
	update_post_meta( $post_id, '_obento_preview', $meta );
	return $meta;
}

/**
 * 公開プレビューを取り消す（メタを消す）
 *
 * @param int $post_id 投稿ID。
 */
function obento_preview_disable( $post_id ) {
	delete_post_meta( (int) $post_id, '_obento_preview' );
}

/**
 * 公開プレビューを延長する（トークンとpost_idを変えず、startedを今にする）
 *
 * @param int $post_id 投稿ID。
 * @return array{token: string, started: int, post_id: int}|null 書いたメタ。有効でなければnull。
 */
function obento_preview_extend( $post_id ) {
	$meta = obento_preview_get( $post_id );
	if ( null === $meta ) {
		return null;
	}
	$meta['started'] = time();
	update_post_meta( (int) $post_id, '_obento_preview', $meta );
	return $meta;
}

/**
 * 期限のUNIX時刻（設定の日数が0なら無期限で0）
 *
 * @param array{token: string, started: int, post_id: int} $meta メタ。
 * @return int
 */
function obento_preview_expires( $meta ) {
	$days = obento_get_preview_settings()['days'];
	return $days > 0 ? $meta['started'] + $days * DAY_IN_SECONDS : 0;
}

/**
 * 期限が切れているか
 *
 * @param array{token: string, started: int, post_id: int} $meta メタ。
 * @return bool
 */
function obento_preview_is_expired( $meta ) {
	$expires = obento_preview_expires( $meta );
	return $expires > 0 && $expires <= time();
}

/**
 * プレビューのURL（下書きのパーマリンクにpreview=trueとpreview_token=トークンを足す）
 *
 * preview=trueはis_preview()を立てる。コアのredirect_canonical()はis_preview()なら何もしないので、
 * ?p=IDの形のURLが別の形へ転送されない。
 *
 * @param int|WP_Post $post 投稿。
 * @return string メタがなければ''。
 */
function obento_preview_url( $post ) {
	$post = get_post( $post );
	$meta = $post ? obento_preview_get( $post->ID ) : null;
	if ( null === $meta ) {
		return '';
	}
	return add_query_arg(
		array(
			'preview'       => 'true',
			'preview_token' => $meta['token'],
		),
		get_permalink( $post )
	);
}

/**
 * エディターと一覧とAJAXの応答で共有する状態
 *
 * expiresはサイトのタイムゾーンの「Y年n月j日 H:i」（無期限は''）、remainは残りの日数を切り上げた「N日」（無期限と期限切れは''）。
 *
 * @param int|WP_Post $post 投稿。
 * @return array{enabled: bool, expired: bool, url: string, expires: string, remain: string}
 */
function obento_preview_state( $post ) {
	$post  = get_post( $post );
	$meta  = $post ? obento_preview_get( $post->ID ) : null;
	$state = array(
		'enabled' => false,
		'expired' => false,
		'url'     => '',
		'expires' => '',
		'remain'  => '',
	);
	if ( null === $meta ) {
		return $state;
	}
	$expires          = obento_preview_expires( $meta );
	$expired          = obento_preview_is_expired( $meta );
	$state['enabled'] = true;
	$state['expired'] = $expired;
	$state['url']     = obento_preview_url( $post );
	if ( $expires > 0 ) {
		$state['expires'] = wp_date( 'Y年n月j日 H:i', $expires );
		if ( ! $expired ) {
			$state['remain'] = (int) ceil( ( $expires - time() ) / DAY_IN_SECONDS ) . '日';
		}
	}
	return $state;
}

/**
 * 公開か非公開になるか、ゴミ箱に入れたらメタを消す（transition_post_status）
 *
 * 公開済みの投稿はトークンに関わらずパーマリンクへ転送するので、メタを残す意味がない。公開を取り下げて下書きに戻したら、改めて有効にする。
 * ゴミ箱に入れたときも消す。残すと、ゴミ箱から戻した（下書きに戻る）ときに、古いリンクが生き返ってしまう。
 * メタのない投稿（ほとんどの公開）ではDBに書かない。
 *
 * @param string  $new_status 新しいステータス。
 * @param string  $old_status 前のステータス。
 * @param WP_Post $post       投稿。
 */
function obento_preview_on_transition( $new_status, $old_status, $post ) {
	if ( $new_status === $old_status || ! in_array( $new_status, array( 'publish', 'private', 'trash' ), true ) ) {
		return;
	}
	if ( null !== obento_preview_get( $post->ID ) ) {
		obento_preview_disable( $post->ID );
	}
}
add_action( 'transition_post_status', 'obento_preview_on_transition', 10, 3 );
