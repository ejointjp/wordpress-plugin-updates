<?php
/**
 * 削除時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * 投稿のmenu_orderはコアの列なので触らない。
 *
 * マルチサイトでは、ネットワーク管理画面から削除したときにメインサイトの文脈で1回だけ走る。
 * 設定と順序と公開プレビューと外部リンクとコメントとアバターとメンテナンスとSVGのデータはサイトごとのテーブルにあるので、サイトを切り替えて全サイトから消す（アバターのユーザーメタはusermetaにあるが、キーにサイトの接頭辞が付くので、サイトごとに消す）。
 * 既定アバターの目印（avatar_default）はmysteryに戻す。切り抜きや引き継ぎで作った添付ファイルは、メディアライブラリの画像として残す。
 * 更新情報のキャッシュ（site transient）と、リビジョンの列の記録（ユーザーメタ。usermetaはネットワークで共通のテーブル）も、
 * ループの外で1回だけ消す。
 *
 * ユーザーオプションのmanage…columnshiddenに残るobento_revisionsは、コアが知らない列名を無視するので触らない。
 *
 * @package Obento
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * いまのサイトの設定と順序のデータを消す
 */
function obento_uninstall_site() {
	delete_option( 'obento_settings' );
	delete_option( 'obento_order_state' );
	delete_option( 'obento_menu' );
	delete_option( 'obento_dashboard' );
	delete_option( 'obento_toolbar' );
	delete_option( 'obento_dashboard_seen' );
	delete_option( 'obento_toolbar_seen' );
	delete_option( 'obento_revisions' );
	delete_option( 'obento_preview' );
	delete_option( 'obento_external_links' );
	delete_option( 'obento_comments' );
	delete_option( 'obento_avatars' );
	delete_option( 'obento_maintenance' );
	delete_option( 'obento_svg' );
	delete_metadata( 'user', 0, $GLOBALS['wpdb']->get_blog_prefix() . 'obento_avatar', '', true );
	if ( 'obento_avatar' === get_option( 'avatar_default' ) ) {
		update_option( 'avatar_default', 'mystery' );
	}
	delete_metadata( 'post', 0, '_obento_preview', '', true );
	delete_metadata( 'term', 0, '_obento_order', '', true );
}

if ( is_multisite() ) {
	$obento_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);
	foreach ( $obento_site_ids as $obento_site_id ) {
		switch_to_blog( $obento_site_id );
		obento_uninstall_site();
		restore_current_blog();
	}
} else {
	obento_uninstall_site();
}
delete_site_transient( 'obento_update_info' );
delete_metadata( 'user', 0, 'obento_revisions_column_seen', '', true );
