<?php
/**
 * 公開プレビューの投稿一覧（印、行アクション、列）
 *
 * タイトルの横の状態ラベル（「下書き」と同じ場所）に「公開プレビュー中」「公開プレビュー（期限切れ）」を足し、
 * 期限内なら行アクション「プレビューリンクをコピー」を出す。「公開プレビュー」列には、期限内なら「開く」と「コピー」を出す。
 * どれも、その投稿を編集できる人（edit_post）にだけ出す。
 * 行アクションと列の「コピー」のhrefはプレビューのURL（JSが効かない環境では新しいタブで開く）。assets/preview-list.jsがクリックでコピーに変える。
 * Quick Edit（admin-ajax.phpのinline-save）が返す行にも要る（load-edit.phpは走らない）ので、フィルターはファイルの読み込みのときに常時登録する
 * （列の見出しは、投稿タイプごとのフィルターなのでadmin_initで登録する）。
 * 一覧からの有効化・取り消しはしない（エディターで足りる）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 状態ラベルに公開プレビューの印を足す（display_post_states）
 *
 * メタがあり、投稿タイプが設定で選ばれ、ステータスが対象で、現在のユーザーがその投稿を編集できる（edit_post）ときだけ。
 * コアの投稿一覧は、edit_others_postsを持たない人（寄稿者・投稿者）にも他人の下書きの行（タイトル）を出す。コアのプレビューの行アクションは
 * 編集権限で隠れるが、印と行アクションが権限を見ないと、他人の下書きの秘密のURLを一覧のHTMLから取れてしまうので、編集できない人には出さない。
 *
 * @param string[] $states 状態ラベル（キー => 表示名）。
 * @param WP_Post  $post   投稿。
 * @return string[]
 */
function obento_preview_post_states( $states, $post ) {
	if ( ! obento_preview_is_target_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $states;
	}
	$meta = obento_preview_get( $post->ID );
	if ( null === $meta ) {
		return $states;
	}
	$states['obento_preview'] = obento_preview_is_expired( $meta ) ? '公開プレビュー（期限切れ）' : '公開プレビュー中';
	return $states;
}
add_filter( 'display_post_states', 'obento_preview_post_states', 10, 2 );

/**
 * 行アクション「プレビューリンクをコピー」を足す（印と同じ条件（編集できる人だけ）のうち、期限内のとき）
 *
 * 編集できない人に出さない理由は、obento_preview_post_states()と同じ（hrefに秘密のURLが入る）。
 *
 * @param string[] $actions 行アクション。
 * @param WP_Post  $post    投稿。
 * @return string[]
 */
function obento_preview_row_action( $actions, $post ) {
	if ( ! obento_preview_is_target_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $actions;
	}
	$meta = obento_preview_get( $post->ID );
	if ( null === $meta || obento_preview_is_expired( $meta ) ) {
		return $actions;
	}
	$title                          = _draft_or_post_title( $post );
	$actions['obento_preview_copy'] = sprintf(
		'<a href="%1$s" class="obento-preview-copy" target="_blank" rel="noopener" aria-label="%2$s">プレビューリンクをコピー</a>',
		esc_url( obento_preview_url( $post ) ),
		esc_attr( '「' . $title . '」のプレビューリンクをコピー' )
	);
	return $actions;
}
add_filter( 'post_row_actions', 'obento_preview_row_action', 10, 2 );
add_filter( 'page_row_actions', 'obento_preview_row_action', 10, 2 );

/**
 * 列のフックを登録する（設定で選んだ投稿タイプ。リビジョンの列（includes/revisions-list.php）と同じ形）
 */
function obento_preview_columns_init() {
	foreach ( obento_get_preview_settings()['post_types'] as $post_type ) {
		add_filter( "manage_{$post_type}_posts_columns", 'obento_add_preview_column' );
	}
}
add_action( 'admin_init', 'obento_preview_columns_init' );

/**
 * 列の一覧に「公開プレビュー」を足す（「日付」の前。「日付」がなければ末尾）
 *
 * @param array $columns 列のキー => 見出し。
 * @return array
 */
function obento_add_preview_column( $columns ) {
	$columns = is_array( $columns ) ? $columns : array();
	if ( isset( $columns['obento_preview'] ) ) {
		return $columns;
	}
	$out = array();
	foreach ( $columns as $key => $label ) {
		if ( 'date' === $key ) {
			$out['obento_preview'] = '公開プレビュー';
		}
		$out[ $key ] = $label;
	}
	if ( ! isset( $out['obento_preview'] ) ) {
		$out['obento_preview'] = '公開プレビュー';
	}
	return $out;
}

/**
 * 列「公開プレビュー」の中身（期限内は「開く」と「コピー」、期限切れは「期限切れ」、それ以外は「—」）
 *
 * 編集できない人には、有効でも「—」を出す。理由はobento_preview_post_states()と同じ（hrefに秘密のURLが入る）。
 * 「コピー」は行アクションと同じクラス（obento-preview-copy）で、assets/preview-list.jsが受ける。
 *
 * @param string $column  列のキー。
 * @param int    $post_id 投稿ID。
 */
function obento_render_preview_column( $column, $post_id ) {
	if ( 'obento_preview' !== $column ) {
		return;
	}
	$post = get_post( $post_id );
	$meta = obento_preview_is_target_post( $post ) && current_user_can( 'edit_post', $post->ID ) ? obento_preview_get( $post->ID ) : null;
	if ( null === $meta ) {
		echo '—';
		return;
	}
	if ( obento_preview_is_expired( $meta ) ) {
		echo '期限切れ';
		return;
	}
	$title = _draft_or_post_title( $post );
	printf(
		'<a href="%1$s" target="_blank" rel="noopener" aria-label="%2$s">開く</a> | <a href="%1$s" class="obento-preview-copy" target="_blank" rel="noopener" aria-label="%3$s">コピー</a>',
		esc_url( obento_preview_url( $post ) ),
		esc_attr( '「' . $title . '」の公開プレビューを開く（新しいタブ）' ),
		esc_attr( '「' . $title . '」のプレビューリンクをコピー' )
	);
}
add_action( 'manage_posts_custom_column', 'obento_render_preview_column', 10, 2 );
add_action( 'manage_pages_custom_column', 'obento_render_preview_column', 10, 2 );

/**
 * 設定で選んだ投稿タイプの一覧に、スクリプトと列の幅のスタイルを読み込む
 *
 * 一覧は初期状態でtable-layout: fixedなので、幅を決めないと列がタイトルと同じ幅になる。幅は見出し（7文字）が1行に収まる大きさ。
 * リンクを途中で折り返さないのは、「コピー」が「コピーしました」に変わるあいだ、文字の途中で折れないようにするため。
 *
 * @param string $hook 管理画面のページ。
 */
function obento_preview_list_enqueue( $hook ) {
	if ( 'edit.php' !== $hook ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! obento_preview_is_post_type_enabled( $screen->post_type ) ) {
		return;
	}
	wp_enqueue_script( 'obento-preview-list', OBENTO_URL . 'assets/preview-list.js', array( 'wp-a11y' ), OBENTO_VERSION, true );
	wp_add_inline_style( 'list-tables', '.wp-list-table .column-obento_preview { width: 100px; } .wp-list-table .column-obento_preview a { white-space: nowrap; }' );
}
add_action( 'admin_enqueue_scripts', 'obento_preview_list_enqueue' );
