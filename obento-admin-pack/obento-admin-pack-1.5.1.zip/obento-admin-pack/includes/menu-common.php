<?php
/**
 * 管理メニュー編集の共通部分（純粋な関数）
 *
 * option（obento_menu）の読み出しと形の正規化、鍵（隠せない項目）の判定、ロールの一覧、
 * 名前の文字の部分と差し替え、新しいメニューの差し込み、区切り線の足し引き、区切り線の片付けと先頭・末尾のクラス、
 * $menu / $submenuへの名前・サブの並び・非表示の適用。
 * ここにはフックを書かない。フックはincludes/menu-apply.phpにあり、ここの関数はtests/helper.phpから直接確かめる。
 *
 * optionの形:
 *   order     トップのslugの並び
 *   sub_order 親のslug => サブのslugの並び
 *   labels    top: slug => 名前、sub: 親のslug => ( slug => 名前 )
 *   hidden    ロールのslug => ( top: slugの配列, sub: 親のslug => slugの配列 )
 *   added_separators   足した区切り線のslug（separator-obento-<N>）。位置はorderに入る
 *   removed_separators 消したコア・プラグインの区切り線のslug
 * 空の配列は「設定なし」。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定の空の形（設定なし）
 *
 * @return array{order: string[], sub_order: array<string, string[]>, labels: array{top: array<string, string>, sub: array<string, array<string, string>>}, hidden: array<string, array{top: string[], sub: array<string, string[]>}>, added_separators: string[], removed_separators: string[]}
 */
function obento_menu_empty_settings() {
	return array(
		'order'              => array(),
		'sub_order'          => array(),
		'labels'             => array(
			'top' => array(),
			'sub' => array(),
		),
		'hidden'             => array(),
		'added_separators'   => array(),
		'removed_separators' => array(),
	);
}

/**
 * 文字列の配列に整える（文字列でない値を捨て、重複を除く）
 *
 * @param mixed $value 値。
 * @return string[]
 */
function obento_menu_string_list( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}
	return array_values( array_unique( array_filter( $value, 'is_string' ) ) );
}

/**
 * 親のslug => 文字列の配列、の形に整える（空の親は捨てる）
 *
 * @param mixed $value 値。
 * @return array<string, string[]>
 */
function obento_menu_grouped_string_list( $value ) {
	$result = array();
	if ( ! is_array( $value ) ) {
		return $result;
	}
	foreach ( $value as $parent => $list ) {
		$list = obento_menu_string_list( $list );
		if ( $list ) {
			$result[ (string) $parent ] = $list;
		}
	}
	return $result;
}

/**
 * slug => 名前、の形に整える（名前のタグを除き、空の名前と文字列でない名前を捨てる）
 *
 * @param mixed $value 値。
 * @return array<string, string>
 */
function obento_menu_label_map( $value ) {
	$result = array();
	if ( ! is_array( $value ) ) {
		return $result;
	}
	foreach ( $value as $slug => $label ) {
		if ( ! is_string( $label ) ) {
			continue;
		}
		$label = trim( wp_strip_all_tags( $label ) );
		if ( '' !== $label ) {
			$result[ (string) $slug ] = $label;
		}
	}
	return $result;
}

/**
 * optionの値を設定の形に整える
 *
 * 読めない部分は捨てる。配列でない、またはorder / sub_order / labels / hidden / added_separators / removed_separatorsや
 * ロールの中身が配列でない壊れ方は、brokenで知らせる（設定画面で通知するため。普通の画面では何も出さない）。
 * 足した区切り線は形（separator-obento-<N>）の合うslugだけを残し、消した区切り線からは足した区切り線の形のslugを捨てる
 * （足した区切り線は、added_separatorsから抜けば消える）。
 * ロールが実在するか、鍵の項目を隠していないかは見ない（それは保存のsanitizeの仕事。適用時は鍵を別に守る）。
 *
 * @param mixed $raw get_option( 'obento_menu', array() )の値。
 * @return array{settings: array, broken: bool}
 */
function obento_menu_normalize( $raw ) {
	$settings = obento_menu_empty_settings();
	if ( ! is_array( $raw ) ) {
		return array(
			'settings' => $settings,
			'broken'   => true,
		);
	}
	$broken = false;
	foreach ( array( 'order', 'sub_order', 'labels', 'hidden', 'added_separators', 'removed_separators' ) as $key ) {
		if ( isset( $raw[ $key ] ) && ! is_array( $raw[ $key ] ) ) {
			$broken = true;
		}
	}
	$settings['order']     = isset( $raw['order'] ) ? obento_menu_string_list( $raw['order'] ) : array();
	$settings['sub_order'] = isset( $raw['sub_order'] ) ? obento_menu_grouped_string_list( $raw['sub_order'] ) : array();
	if ( isset( $raw['labels'] ) && is_array( $raw['labels'] ) ) {
		$settings['labels']['top'] = isset( $raw['labels']['top'] ) ? obento_menu_label_map( $raw['labels']['top'] ) : array();
		if ( isset( $raw['labels']['sub'] ) && is_array( $raw['labels']['sub'] ) ) {
			foreach ( $raw['labels']['sub'] as $parent => $labels ) {
				$labels = obento_menu_label_map( $labels );
				if ( $labels ) {
					$settings['labels']['sub'][ (string) $parent ] = $labels;
				}
			}
		}
	}
	if ( isset( $raw['hidden'] ) && is_array( $raw['hidden'] ) ) {
		foreach ( $raw['hidden'] as $role => $hidden ) {
			if ( ! is_array( $hidden ) ) {
				$broken = true;
				continue;
			}
			$top = isset( $hidden['top'] ) ? obento_menu_string_list( $hidden['top'] ) : array();
			$sub = isset( $hidden['sub'] ) ? obento_menu_grouped_string_list( $hidden['sub'] ) : array();
			if ( $top || $sub ) {
				$settings['hidden'][ (string) $role ] = array(
					'top' => $top,
					'sub' => $sub,
				);
			}
		}
	}
	$added                          = isset( $raw['added_separators'] ) ? obento_menu_string_list( $raw['added_separators'] ) : array();
	$settings['added_separators']   = array_values( array_filter( $added, 'obento_menu_is_added_separator' ) );
	$removed                        = isset( $raw['removed_separators'] ) ? obento_menu_string_list( $raw['removed_separators'] ) : array();
	$settings['removed_separators'] = array_values(
		array_filter(
			$removed,
			function ( $slug ) {
				return ! obento_menu_is_added_separator( $slug );
			}
		)
	);
	return array(
		'settings' => $settings,
		'broken'   => $broken,
	);
}

/**
 * 設定を返す（形を整えたもの。設定がなければ空の形）
 *
 * @return array
 */
function obento_get_menu_settings() {
	$read = obento_menu_normalize( get_option( 'obento_menu', array() ) );
	return $read['settings'];
}

/**
 * 保存されている設定が壊れているか（設定画面の通知に使う）
 *
 * @return bool
 */
function obento_menu_settings_broken() {
	$read = obento_menu_normalize( get_option( 'obento_menu', array() ) );
	return $read['broken'];
}

/**
 * ロールのslugの一覧（wp_rolesの順。独自のロールも含む）
 *
 * @return string[]
 */
function obento_menu_role_slugs() {
	return array_keys( wp_roles()->get_names() );
}

/**
 * 利用者のロール。ロールを持たない利用者（サイトのメンバーでない特権管理者など）は管理者として扱う
 *
 * @return string[]
 */
function obento_menu_current_user_roles() {
	$roles = array_values( array_filter( (array) wp_get_current_user()->roles, 'is_string' ) );
	return $roles ? $roles : array( 'administrator' );
}

/**
 * 隠せない項目か（隠すと、このプラグインの設定画面へ行けなくなるため）
 *
 * トップの「設定」（options-general.php）と、その下の「Obento Admin Pack」（obento-admin-pack）。
 *
 * @param string $slug        メニューのslug。
 * @param string $parent_slug サブのときは親のslug。トップは空。
 * @return bool
 */
function obento_menu_is_locked( $slug, $parent_slug = '' ) {
	if ( '' === $parent_slug ) {
		return 'options-general.php' === $slug;
	}
	return 'options-general.php' === $parent_slug && 'obento-admin-pack' === $slug;
}

/**
 * 区切り線の項目か
 *
 * @param array $item $menuの1項目。
 * @return bool
 */
function obento_menu_is_separator( $item ) {
	return isset( $item[4] ) && is_string( $item[4] ) && false !== strpos( $item[4], 'wp-menu-separator' );
}

/**
 * このプラグインで足した区切り線のslugか（separator-obento-<N>。Nは1以上の整数）
 *
 * separatorで始めるのは、コアのadd_menu_classes()がslugの先頭のseparatorで区切り線を見分けて、
 * 直前の項目にmenu-top-last、直後の項目にmenu-top-firstを付けるため。
 *
 * @param mixed $slug slug。
 * @return bool
 */
function obento_menu_is_added_separator( $slug ) {
	return is_string( $slug ) && 1 === preg_match( '/^separator-obento-[1-9][0-9]*\z/', $slug );
}

/**
 * メニューの名前の文字の部分（最初のタグより前）
 *
 * コアはコメントや更新の件数をタグで名前に足す（「コメント <span class='awaiting-mod'>…」）。
 * 設定画面に出す名前と、名前を変えるときに差し替える範囲は、この文字の部分。
 * 文字の部分がない（タグで始まる）名前は空を返す。
 *
 * @param string $title $menu / $submenuの名前（[0]）。
 * @return string
 */
function obento_menu_label_text( $title ) {
	$title = (string) $title;
	$pos   = strpos( $title, '<' );
	return trim( false === $pos ? $title : substr( $title, 0, $pos ) );
}

/**
 * メニューの名前の文字の部分を差し替える（件数のバッジなどのタグは残す）
 *
 * 文字の部分がない名前は変えない。文字とタグのあいだの空白は残す。
 * コアは$menu / $submenuの名前をエスケープせずに出すので、新しい名前はここでesc_html()する（後ろに残すバッジなどのタグはそのまま）。
 *
 * @param string $title 元の名前。
 * @param string $label 新しい名前。
 * @return string
 */
function obento_menu_apply_label( $title, $label ) {
	$title = (string) $title;
	$label = esc_html( $label );
	$pos   = strpos( $title, '<' );
	if ( false === $pos ) {
		return '' === trim( $title ) ? $title : $label;
	}
	$text = rtrim( substr( $title, 0, $pos ) );
	if ( '' === trim( $text ) ) {
		return $title;
	}
	return $label . substr( $title, strlen( $text ) );
}

/**
 * 保存した並びに、新しい項目（保存した並びにないslug）を差し込んだ完全な並びを返す
 *
 * 新しい項目は、いまの並び（コアの並び）で直前にある「保存した並びに含まれる項目」の直後に入れる。
 * 直前にそれがなければ先頭。連続する新しい項目どうしは、いまの並びの順を保つ。
 * 保存した並びにあって、いまはない項目（消えたプラグインのメニューなど）は除く。
 *
 * @param string[] $saved   保存した並び。
 * @param string[] $current いまの並び。
 * @return string[]
 */
function obento_menu_merge_order( $saved, $current ) {
	$current = array_values( array_unique( $current ) );
	$result  = array_values( array_intersect( $saved, $current ) );
	$pos     = 0;
	foreach ( $current as $slug ) {
		$index = array_search( $slug, $result, true );
		if ( false !== $index ) {
			$pos = $index + 1;
			continue;
		}
		array_splice( $result, $pos, 0, array( $slug ) );
		++$pos;
	}
	return $result;
}

/**
 * サブメニューを保存した並びに並べ直す（新しいサブは差し込み、配列は0から詰め直す）
 *
 * コアも描画の前にarray_values()で詰め直すので、キーの番号に意味はない。
 *
 * @param array    $subs  $submenu[ $parent ]。
 * @param string[] $saved 保存した並び。
 * @return array
 */
function obento_menu_sort_subs( $subs, $saved ) {
	$current = array();
	$by_slug = array();
	foreach ( $subs as $sub ) {
		$slug = (string) $sub[2];
		if ( ! isset( $by_slug[ $slug ] ) ) {
			$current[]        = $slug;
			$by_slug[ $slug ] = array();
		}
		$by_slug[ $slug ][] = $sub;
	}
	$sorted = array();
	foreach ( obento_menu_merge_order( $saved, $current ) as $slug ) {
		foreach ( $by_slug[ $slug ] as $sub ) {
			$sorted[] = $sub;
		}
	}
	return $sorted;
}

/**
 * 利用者のロールから、隠す項目の集合を作る
 *
 * 持っているロールのどれか1つで表示なら出す（すべてのロールで隠しているものだけを隠す）。
 * 設定のないロールは何も隠さない。鍵の項目は、どう保存されていても隠さない。
 *
 * @param array    $settings obento_get_menu_settings()の値。
 * @param string[] $roles    利用者のロール。
 * @return array{top: array<string, true>, sub: array<string, array<string, true>>}
 */
function obento_menu_hidden_for_roles( $settings, $roles ) {
	$top = null;
	$sub = null;
	foreach ( $roles as $role ) {
		$hidden   = isset( $settings['hidden'][ $role ] ) ? $settings['hidden'][ $role ] : array(
			'top' => array(),
			'sub' => array(),
		);
		$role_top = array_fill_keys( $hidden['top'], true );
		$role_sub = array();
		foreach ( $hidden['sub'] as $parent => $slugs ) {
			$role_sub[ $parent ] = array_fill_keys( $slugs, true );
		}
		if ( null === $top ) {
			$top = $role_top;
			$sub = $role_sub;
			continue;
		}
		$top = array_intersect_key( $top, $role_top );
		foreach ( $sub as $parent => $slugs ) {
			$sub[ $parent ] = isset( $role_sub[ $parent ] ) ? array_intersect_key( $slugs, $role_sub[ $parent ] ) : array();
		}
	}
	$top = (array) $top;
	$sub = (array) $sub;
	unset( $top['options-general.php'] );
	if ( isset( $sub['options-general.php'] ) ) {
		unset( $sub['options-general.php']['obento-admin-pack'] );
	}
	return array(
		'top' => $top,
		'sub' => array_filter( $sub ),
	);
}

/**
 * クラスの文字列にクラスを足す（すでにあれば足さない）
 *
 * @param string $classes    空白区切りのクラス。
 * @param string $class_name 足すクラス。
 * @return string
 */
function obento_menu_add_class( $classes, $class_name ) {
	$list = preg_split( '/\s+/', trim( (string) $classes ), -1, PREG_SPLIT_NO_EMPTY );
	if ( ! in_array( $class_name, $list, true ) ) {
		$list[] = $class_name;
	}
	return implode( ' ', $list );
}

/**
 * 区切り線を片付ける（先頭・連続・末尾の区切り線を消す。キーは保つ）
 *
 * コアは連続と末尾だけを消すが、先頭の項目を隠すと区切り線が先頭に残るので、先頭も消す。
 *
 * @param array $menu $menu。
 * @return array
 */
function obento_menu_cleanup_separators( $menu ) {
	$result   = array();
	$prev_sep = true;
	foreach ( $menu as $key => $item ) {
		$is_sep = obento_menu_is_separator( $item );
		if ( $is_sep && $prev_sep ) {
			continue;
		}
		$result[ $key ] = $item;
		$prev_sep       = $is_sep;
	}
	$keys = array_keys( $result );
	while ( $keys && obento_menu_is_separator( $result[ end( $keys ) ] ) ) {
		unset( $result[ array_pop( $keys ) ] );
	}
	return $result;
}

/**
 * 先頭・末尾のクラス（menu-top-first / menu-top-last）を付け直す
 *
 * コアのadd_menu_classes()と同じ規則（区切り線の直後がfirst、直前がlast、全体の最後がlast）。
 * add_menu_classes()を呼ばないのは、add_menu_classesフィルターに乗った他のプラグインの処理を2回走らせないため。
 *
 * @param array $menu $menu。
 * @return array
 */
function obento_menu_reclass( $menu ) {
	foreach ( $menu as $key => $item ) {
		$classes         = isset( $item[4] ) ? (string) $item[4] : '';
		$menu[ $key ][4] = trim( preg_replace( '/\s*\bmenu-top-(?:first|last)\b/', '', $classes ) );
	}
	$first_pending = true;
	$last_item_key = null;
	foreach ( $menu as $key => $item ) {
		if ( obento_menu_is_separator( $item ) ) {
			if ( null !== $last_item_key ) {
				$menu[ $last_item_key ][4] = obento_menu_add_class( $menu[ $last_item_key ][4], 'menu-top-last' );
			}
			$first_pending = true;
			continue;
		}
		if ( $first_pending ) {
			$menu[ $key ][4] = obento_menu_add_class( $menu[ $key ][4], 'menu-top-first' );
			$first_pending   = false;
		}
		$last_item_key = $key;
	}
	if ( null !== $last_item_key ) {
		$menu[ $last_item_key ][4] = obento_menu_add_class( $menu[ $last_item_key ][4], 'menu-top-last' );
	}
	return $menu;
}

/**
 * 区切り線を足し引きする（消した区切り線を除き、足した区切り線を末尾に足す。キーは保つ）
 *
 * 消すのは、removed_separatorsにあるslugの区切り線の項目だけ（区切り線でない項目は、slugが入っていても消さない）。
 * 足した区切り線は$menu[]で末尾に入れる。並びは、menu_orderフィルターが保存した並びに合わせる。同じslugの項目がすでにあれば足さない。
 * 区切り線はページではないので、admin_menuで消しても権限の判定に関わらない。
 *
 * @param array $menu     $menu。
 * @param array $settings obento_get_menu_settings()の値。
 * @return array
 */
function obento_menu_apply_separators( $menu, $settings ) {
	$removed = array_fill_keys( $settings['removed_separators'], true );
	$slugs   = array();
	foreach ( $menu as $key => $item ) {
		$slug = (string) $item[2];
		if ( isset( $removed[ $slug ] ) && obento_menu_is_separator( $item ) ) {
			unset( $menu[ $key ] );
			continue;
		}
		$slugs[ $slug ] = true;
	}
	foreach ( $settings['added_separators'] as $slug ) {
		if ( isset( $slugs[ $slug ] ) ) {
			continue;
		}
		$menu[]         = array( '', 'read', $slug, '', 'wp-menu-separator' );
		$slugs[ $slug ] = true;
	}
	return $menu;
}

/**
 * 名前とサブの並びを$menuと$submenuに効かせる
 *
 * @param array $menu     $menu。
 * @param array $submenu  $submenu。
 * @param array $settings obento_get_menu_settings()の値。
 * @return array{menu: array, submenu: array}
 */
function obento_menu_apply_titles_and_sub_order( $menu, $submenu, $settings ) {
	foreach ( $menu as $key => $item ) {
		$slug = (string) $item[2];
		if ( isset( $settings['labels']['top'][ $slug ] ) ) {
			$menu[ $key ][0] = obento_menu_apply_label( $item[0], $settings['labels']['top'][ $slug ] );
		}
	}
	foreach ( $submenu as $parent => $subs ) {
		$parent = (string) $parent;
		if ( isset( $settings['labels']['sub'][ $parent ] ) ) {
			foreach ( $subs as $index => $sub ) {
				$slug = (string) $sub[2];
				if ( isset( $settings['labels']['sub'][ $parent ][ $slug ] ) ) {
					$submenu[ $parent ][ $index ][0] = obento_menu_apply_label( $sub[0], $settings['labels']['sub'][ $parent ][ $slug ] );
				}
			}
		}
		if ( ! empty( $settings['sub_order'][ $parent ] ) ) {
			$submenu[ $parent ] = obento_menu_sort_subs( $submenu[ $parent ], $settings['sub_order'][ $parent ] );
		}
	}
	return array(
		'menu'    => $menu,
		'submenu' => $submenu,
	);
}

/**
 * 隠す項目を$menuと$submenuから消し、後始末をする
 *
 * サブをすべて隠した親も消す（親のslugに画面がないプラグインのメニューを、空のリンクとして残さないため）。
 * 何か消したときだけ、区切り線を片付けて先頭・末尾のクラスを付け直す。
 *
 * @param array $menu    $menu。
 * @param array $submenu $submenu。
 * @param array $hidden  obento_menu_hidden_for_roles()の値。
 * @return array{menu: array, submenu: array, changed: bool}
 */
function obento_menu_remove_hidden( $menu, $submenu, $hidden ) {
	$changed = false;
	foreach ( $menu as $key => $item ) {
		$slug = (string) $item[2];
		if ( isset( $hidden['top'][ $slug ] ) ) {
			unset( $menu[ $key ], $submenu[ $slug ] );
			$changed = true;
			continue;
		}
		if ( empty( $submenu[ $slug ] ) || empty( $hidden['sub'][ $slug ] ) ) {
			continue;
		}
		foreach ( $submenu[ $slug ] as $index => $sub ) {
			if ( isset( $hidden['sub'][ $slug ][ (string) $sub[2] ] ) ) {
				unset( $submenu[ $slug ][ $index ] );
				$changed = true;
			}
		}
		if ( empty( $submenu[ $slug ] ) ) {
			unset( $submenu[ $slug ], $menu[ $key ] );
		}
	}
	if ( $changed ) {
		$menu = obento_menu_reclass( obento_menu_cleanup_separators( $menu ) );
	}
	return array(
		'menu'    => $menu,
		'submenu' => $submenu,
		'changed' => $changed,
	);
}
