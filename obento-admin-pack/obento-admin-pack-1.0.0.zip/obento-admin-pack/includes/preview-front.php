<?php
/**
 * 公開プレビューの表側
 *
 * クエリ変数obento_previewを足し、メインクエリのposts_resultsで、トークンの合う公開前の投稿だけをメモリ上でpublish扱いにする
 * （コアはposts_resultsの直後に「公開でない投稿はログインしていないと見せない」判定をするので、ここで差し替えれば通る。
 * Public Post Previewと同じ方式）。DBの状態は変えない。
 * 公開済みならパーマリンクへ301、期限切れなら案内（403）、トークン違いや取り消し済みは何もしない（コアが404にする）。
 *
 * is_admin()の外で読む（表側で動く）。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * クエリ変数obento_previewを足す（メインクエリから$query->get()で読めるようにする）
 *
 * @param string[] $vars 公開のクエリ変数。
 * @return string[]
 */
function obento_preview_query_vars( $vars ) {
	$vars[] = 'obento_preview';
	return $vars;
}
add_filter( 'query_vars', 'obento_preview_query_vars' );

/**
 * メインクエリの結果を見て、トークンの合う公開前の投稿をpublish扱いにする
 *
 * メインクエリで、単一の投稿（フィードと埋め込みを除く）で、obento_previewがあり、結果が1件のときだけ動く。
 * 1. 公開済み→パーマリンクへ301（トークンは問わない）
 * 2. 投稿タイプが設定で選ばれていない、ステータスが対象外、メタがない、トークンが違う→何もしない（コアが404にする）
 * 3. 期限切れ→案内（403。本文は出さない）
 * 4. 一致して期限内→post_statusをpublishにして返す。キャッシュさせず、noindex, nofollowにし、コメントとピンバックを閉じ、canonicalを出さない。
 *    複数ページの投稿のページ送りのリンクにはトークンを付ける
 *
 * ログインの有無は問わない（編集できる人はコアが元から下書きを見せるので、差し替えても害はない）。
 *
 * @param WP_Post[] $posts 結果。
 * @param WP_Query  $query クエリ。
 * @return WP_Post[]
 */
function obento_preview_posts_results( $posts, $query ) {
	if ( ! $query->is_main_query() || ! $query->is_singular() || $query->is_feed() || $query->is_embed() ) {
		return $posts;
	}
	$token = $query->get( 'obento_preview' );
	if ( ! is_string( $token ) || '' === $token || 1 !== count( $posts ) || ! ( $posts[0] instanceof WP_Post ) ) {
		return $posts;
	}
	$post = $posts[0];
	if ( 'publish' === $post->post_status ) {
		wp_safe_redirect( get_permalink( $post ), 301 );
		exit;
	}
	if ( ! obento_preview_is_target_post( $post ) ) {
		return $posts;
	}
	$meta = obento_preview_get( $post->ID );
	if ( null === $meta || ! hash_equals( $meta['token'], $token ) ) {
		return $posts;
	}
	if ( obento_preview_is_expired( $meta ) ) {
		nocache_headers();
		wp_die(
			'このプレビューの有効期限が切れています。送った人に新しいリンクを依頼してください。',
			'公開プレビュー',
			array( 'response' => 403 )
		);
	}
	if ( ! headers_sent() ) {
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	// ほかのフィルターがfollowやindexを足しても上書きできるよう、最後に動かす
	add_filter( 'wp_robots', 'obento_preview_wp_robots', PHP_INT_MAX );
	add_filter( 'comments_open', '__return_false' );
	add_filter( 'pings_open', '__return_false' );
	// 公開前の投稿のURLをcanonicalとして出さない（$postの差し替えでget_permalink()が整形したURLを返すため）
	remove_action( 'wp_head', 'rel_canonical' );
	obento_preview_active_id( $post->ID );
	add_filter( 'wp_link_pages_link', 'obento_preview_link_pages_link', 10, 2 );
	$posts[0]->post_status = 'publish';
	return $posts;
}
add_filter( 'posts_results', 'obento_preview_posts_results', 10, 2 );

/**
 * いま公開プレビューとして表示している投稿のID（posts_resultsで表示を許したときだけ入る。それ以外は0）
 *
 * @param int|null $post_id 入れるID。nullなら読むだけ。
 * @return int
 */
function obento_preview_active_id( $post_id = null ) {
	static $active = 0;
	if ( null !== $post_id ) {
		$active = (int) $post_id;
	}
	return $active;
}

/**
 * プレビューの表示の検索エンジン向けの指示を、X-Robots-Tagのヘッダーとそろえる（noindex, nofollow）
 *
 * コアのwp_robots_no_robots()は、検索エンジンに公開しているサイトではfollowを付ける。
 * wp_robots()は同じ意味の指示を排他にしないので、followとindexは外す。
 *
 * @param array $robots 指示（キーが名前）。
 * @return array
 */
function obento_preview_wp_robots( $robots ) {
	unset( $robots['follow'], $robots['index'] );
	$robots['noindex']  = true;
	$robots['nofollow'] = true;
	return $robots;
}

/**
 * 複数ページの投稿（<!--nextpage-->）のページ送りのリンクを、公開プレビューのURLにする（wp_link_pages_link）
 *
 * コアの_wp_link_page()は、publish扱いにした投稿のリンクを整形したURL（下書きではスラッグが空のこともある）で、
 * トークンを付けずに作るので、2ページ目以降が開けない。プレビュー中の投稿のリンクだけ、下書きのURLの形
 * （?p=ID、固定ページは?page_id=ID、ほかの投稿タイプは?post_type=…&p=ID）にpreview=true、トークン、page=Nを付けたURLに差し替える。
 * いまのページ（リンクではなくspan）はhrefがないので、そのまま返す。トークンは、posts_resultsで確かめたクエリ変数を使う。
 *
 * @param string $link ページ番号のリンクのHTML。
 * @param int    $i    ページ番号。
 * @return string
 */
function obento_preview_link_pages_link( $link, $i ) {
	$post = get_post();
	if ( ! $post || obento_preview_active_id() !== $post->ID ) {
		return $link;
	}
	if ( 'page' === $post->post_type ) {
		$args = array( 'page_id' => $post->ID );
	} elseif ( 'post' === $post->post_type ) {
		$args = array( 'p' => $post->ID );
	} else {
		$args = array(
			'post_type' => $post->post_type,
			'p'         => $post->ID,
		);
	}
	$args['preview']        = 'true';
	$args['obento_preview'] = (string) get_query_var( 'obento_preview' );
	if ( 1 < (int) $i ) {
		$args['page'] = (int) $i;
	}
	$url = add_query_arg( $args, home_url( '/' ) );
	return (string) preg_replace( '/href="[^"]*"/', 'href="' . esc_url( $url ) . '"', $link, 1 );
}
