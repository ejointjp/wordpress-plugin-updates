<?php
/**
 * Plugin Name:       Obento Admin Pack
 * Description:       管理画面の一覧にID列・絞り込み・ドラッグ＆ドロップの並び替え・列幅の変更を足し、左の管理メニュー・ダッシュボードのウィジェット・ツールバーをロール別に片付けられる、小さな便利機能の詰め合わせ。
 * Version:           0.6.1
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * Update URI:        https://yuiami.jp/wp-plugins/obento-admin-pack
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       obento-admin-pack
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OBENTO_VERSION', '0.6.1' );
define( 'OBENTO_FILE', __FILE__ );
define( 'OBENTO_DIR', plugin_dir_path( __FILE__ ) );
define( 'OBENTO_URL', plugin_dir_url( __FILE__ ) );

// 自己ホストの更新チェック。定期の更新チェックはwp-cronで動くので、is_admin()の中に入れない。
require_once OBENTO_DIR . 'includes/update-checker.php';
// 旧名（Obentou Admin Pack）からの引き継ぎ。有効化のフックなので、is_admin()の中に入れない（WP-CLIの有効化でも走らせる）。
require_once OBENTO_DIR . 'includes/migrate.php';
require_once OBENTO_DIR . 'includes/settings.php';
require_once OBENTO_DIR . 'includes/id-column.php';
require_once OBENTO_DIR . 'includes/list-filters.php';
require_once OBENTO_DIR . 'includes/auto-filter.php';
require_once OBENTO_DIR . 'includes/column-width.php';
require_once OBENTO_DIR . 'includes/order-common.php';
require_once OBENTO_DIR . 'includes/order-posts.php';
require_once OBENTO_DIR . 'includes/order-terms.php';
require_once OBENTO_DIR . 'includes/menu-common.php';
require_once OBENTO_DIR . 'includes/menu-apply.php';
require_once OBENTO_DIR . 'includes/menu-screen.php';
require_once OBENTO_DIR . 'includes/cleanup-common.php';
require_once OBENTO_DIR . 'includes/cleanup-dashboard.php';
require_once OBENTO_DIR . 'includes/cleanup-toolbar.php';
require_once OBENTO_DIR . 'includes/cleanup-screen.php';
