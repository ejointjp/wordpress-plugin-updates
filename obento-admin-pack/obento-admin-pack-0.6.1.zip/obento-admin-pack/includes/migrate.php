<?php
/**
 * 旧名（Obentou Admin Pack）からの引き継ぎ
 *
 * 0.6.0で名前とslugをobentouからobento-admin-packに変え、optionとterm metaの接頭辞もobentou_からobento_にした。
 * 旧版からは更新として届かないので、新しい版を別のプラグインとして入れ、旧版を停止してから有効にする。
 * その有効化のときに、旧版のデータを新しい名前へ写す。
 *
 * - optionは、新しい名前のものがまだないときだけ写す。新しい版で保存した設定は上書きしない
 * - タームの順序（term meta）は、新しい名前の順序がまだないタームだけ写す。有効化をやり直しても重ならない
 * - 管理メニューの設定は、設定画面のslugをobentouからobento-admin-packに読み替える（サブメニューの並び順と名前）
 * - 旧データは消さない。写したあとも旧版に戻せるようにするため。旧版を削除すると、旧版のuninstall.phpが消す
 * - マルチサイトのネットワーク有効化では、全サイトを回して写す
 *
 * 旧版を使っていたサイトの入れ替えがすべて済んだら、このファイルは消してよい。
 *
 * @package Obento
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 有効化のときに、旧版のデータを写す
 *
 * @param bool $network_wide ネットワーク有効化ならtrue。
 */
function obento_migrate_legacy( $network_wide ) {
	if ( is_multisite() && $network_wide ) {
		$site_ids = get_sites(
			array(
				'fields' => 'ids',
				'number' => 0,
			)
		);
		foreach ( $site_ids as $site_id ) {
			switch_to_blog( $site_id );
			obento_migrate_legacy_site();
			restore_current_blog();
		}
		return;
	}
	obento_migrate_legacy_site();
}
register_activation_hook( OBENTO_FILE, 'obento_migrate_legacy' );

/**
 * いまのサイトの、旧版のoptionとタームの順序を写す
 */
function obento_migrate_legacy_site() {
	foreach ( array( 'settings', 'order_state', 'menu', 'dashboard', 'toolbar', 'dashboard_seen', 'toolbar_seen' ) as $key ) {
		$legacy = get_option( 'obentou_' . $key, null );
		if ( null === $legacy || null !== get_option( 'obento_' . $key, null ) ) {
			continue;
		}
		if ( 'menu' === $key ) {
			$legacy = obento_migrate_legacy_menu( $legacy );
		}
		if ( ! add_option( 'obento_' . $key, $legacy ) ) {
			error_log( sprintf( 'Obento Admin Pack: 旧版の設定（obentou_%s）を引き継げませんでした。', $key ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 失敗を運用側が気付けるように残す
		}
	}

	global $wpdb;
	// 有効化のときに一度だけ読む。メタの値はタームごとに読み直さず、この結果から写す
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT term_id, meta_value FROM {$wpdb->termmeta} WHERE meta_key = %s", '_obentou_order' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 旧版のメタを持つタームを一度に拾う手段がほかにない
	foreach ( $rows as $row ) {
		$term_id = (int) $row->term_id;
		if ( metadata_exists( 'term', $term_id, '_obento_order' ) ) {
			continue;
		}
		if ( ! add_term_meta( $term_id, '_obento_order', maybe_unserialize( $row->meta_value ), true ) ) {
			error_log( sprintf( 'Obento Admin Pack: ターム%dの順序を引き継げませんでした。', $term_id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 失敗を運用側が気付けるように残す
		}
	}
}

/**
 * 管理メニューの設定の中の、設定画面のslugを新しいものに読み替える
 *
 * 旧版の設定画面（設定 > Obentou Admin Pack）のslugはobentouだった。サブメニューの並び順と名前に、そのslugで入っている。
 *
 * @param mixed $menu 旧版の管理メニューの設定（obentou_menu）。
 * @return mixed 読み替えた設定。配列でなければそのまま返す。
 */
function obento_migrate_legacy_menu( $menu ) {
	if ( ! is_array( $menu ) ) {
		return $menu;
	}
	if ( isset( $menu['sub_order']['options-general.php'] ) && is_array( $menu['sub_order']['options-general.php'] ) ) {
		foreach ( $menu['sub_order']['options-general.php'] as $i => $slug ) {
			if ( 'obentou' === $slug ) {
				$menu['sub_order']['options-general.php'][ $i ] = 'obento-admin-pack';
			}
		}
	}
	if ( isset( $menu['labels']['sub']['options-general.php'] ) && is_array( $menu['labels']['sub']['options-general.php'] )
		&& array_key_exists( 'obentou', $menu['labels']['sub']['options-general.php'] ) ) {
		$menu['labels']['sub']['options-general.php']['obento-admin-pack'] = $menu['labels']['sub']['options-general.php']['obentou'];
		unset( $menu['labels']['sub']['options-general.php']['obentou'] );
	}
	return $menu;
}
