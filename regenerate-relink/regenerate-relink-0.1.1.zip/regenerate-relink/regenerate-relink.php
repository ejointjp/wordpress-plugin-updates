<?php
/**
 * Plugin Name:       Regenerate & Relink – Thumbnails, Image URLs & Media Cleanup
 * Description:       Regenerate thumbnails, update image references in post content to match, and clean up unused image sizes — with dry-run preview and quarantine.
 * Version:           0.1.1
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       regenerate-relink
 * Domain Path:       /languages
 * Update URI:        https://yuiami.jp/wp-plugins/regenerate-relink
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RGRL_VERSION', '0.1.1' );
define( 'RGRL_DB_VERSION', '3' );
define( 'RGRL_FILE', __FILE__ );
define( 'RGRL_DIR', plugin_dir_path( __FILE__ ) );
define( 'RGRL_URL', plugin_dir_url( __FILE__ ) );

/*
 * オートローダ: Regenerate_Relink\Foo_Bar → includes/class-foo-bar.php
 * サブ名前空間を切ったらマッピングを拡張すること。
 */
spl_autoload_register(
	function ( $class_name ) {
		if ( 0 !== strpos( $class_name, __NAMESPACE__ . '\\' ) ) {
			return;
		}

		$relative = substr( $class_name, strlen( __NAMESPACE__ ) + 1 );
		$file     = RGRL_DIR . 'includes/class-' . str_replace( '_', '-', strtolower( $relative ) ) . '.php';

		if ( is_readable( $file ) ) {
			require $file;
		}
	}
);

/**
 * 翻訳を読み込む
 *
 * WordPress 6.7 以降、init より前に翻訳関数を呼ぶと
 * _load_textdomain_just_in_time の警告が出る。必ず init 以降に載せること。
 */
function load_textdomain(): void {
	load_plugin_textdomain(
		'regenerate-relink',
		false,
		dirname( plugin_basename( RGRL_FILE ) ) . '/languages'
	);
}
add_action( 'init', __NAMESPACE__ . '\\load_textdomain' );

register_activation_hook( __FILE__, array( __NAMESPACE__ . '\\Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( __NAMESPACE__ . '\\Plugin', 'deactivate' ) );

Plugin::boot();
