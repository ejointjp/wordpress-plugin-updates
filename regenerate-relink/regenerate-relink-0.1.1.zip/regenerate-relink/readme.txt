=== Regenerate & Relink – Thumbnails, Image URLs & Media Cleanup ===
Contributors: ejointjp
Tags: regenerate thumbnails, thumbnail, image sizes, media cleanup, broken images
Requires at least: 6.6
Tested up to: 7.1
Stable tag: 0.1.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Regenerate thumbnails, update image URLs in your posts to match, and clean up unused files — with dry-run preview and quarantine.

== Description ==

WordPress bakes image size file names into your post content the moment you insert an image. When a size definition changes later — a new theme, new media settings — regenerating thumbnails is not enough: the URLs in your content still point to the old files, leaving broken images or outdated dimensions. Unused thumbnails pile up and waste disk space.

Regenerate & Relink fixes the whole chain, safely:

* **Diagnose** – list every registered image size with file counts, disk usage, how often it is used in content, and which files need regeneration.
* **Regenerate** – rebuild intermediate sizes from the original images. Never from `-scaled` copies.
* **Relink** – update image URLs, `width` / `height` attributes and `[caption]` widths in post content to match the current definitions. Only the file name part of the URL is touched — your CDN and site structure are preserved.
* **Clean up** – quarantine files that are no longer referenced anywhere, instead of deleting them. Restore anytime; auto-purge after 30 days (configurable).
* **Dry-run first** – every stage shows a full preview before touching anything. Skipped items are reported with reasons and links.
* **WP-CLI** – scan, review reports and apply from the command line.

The plugin never changes your image size definitions. It detects what was changed elsewhere — Settings > Media, your theme's `add_image_size()` — and brings files and content back in sync.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/regenerate-relink` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.

== Frequently Asked Questions ==

= Does this plugin change my image size settings? =

No. Sizes are defined in Settings > Media, by your theme, or by other plugins. Regenerate & Relink only detects those definitions and brings your files and post content in line with them.

= Is it safe to run? =

Every stage runs behind a dry-run preview, deletions go to a quarantine area instead of being removed immediately, and content updates can be reverted. When in doubt, the plugin reports instead of touching.

= Can I run it from WP-CLI? =

Yes. The command line covers the same stages as the admin screen:

`
wp regenerate-relink sizes        # size diagnostics
wp regenerate-relink scan         # create the dry-run preview
wp regenerate-relink report       # read it (--section=summary|skips|refs|cleanup, --format=table|csv|json)
wp regenerate-relink regenerate   # create missing and outdated thumbnails
wp regenerate-relink apply        # update image references in post content
wp regenerate-relink cleanup      # quarantine obsolete files
wp regenerate-relink run          # all three stages, in order
wp regenerate-relink quarantine   # show the state of the quarantine area
wp regenerate-relink restore      # restore every quarantined file
wp regenerate-relink purge        # empty the quarantine area permanently
`

Commands that change anything ask for confirmation first; pass `--yes` to skip the prompt.

== Screenshots ==

1. Main screen with size list, preview and run button.

== Changelog ==

= 0.1.1 =
* Added an update checker. New versions now appear on the Plugins screen and can be installed from there.

= 0.1.0 =
* Initial release.
