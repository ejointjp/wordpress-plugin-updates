<?php
/**
 * 不要ファイルの隔離（FR-5）
 *
 * 4つの操作を束ねる実行制御。
 *
 * - plan:    削除候補の算出（プレビュー）。FR-5.1 の全条件を満たすファイル
 *            だけを candidate、ひとつでも欠けるものは report として
 *            rgrl_quarantine に記録する。実データは一切変更しない（FR-6.1）
 * - run:     candidate を隔離領域へ移動する（FR-5.3）。plan の結果を
 *            そのまま適用し、再算出しない（FR-6.3）。実行時に前提が
 *            変わっていた候補はスキップして記録する（FR-6.4）
 * - restore: 隔離済みファイルを元の場所へ戻す（FR-5.4）
 * - empty:   隔離領域を手動で空にする（FR-5.7）
 *
 * 削除対象の条件（FR-5.1。すべて必須、欠けたら報告のみ）:
 *
 * 1. uploads 配下にある — 移動直前に実パス解決で検証（NFR-1.4）
 * 2. 中間サイズ命名規則（原画名-幅x高さ.拡張子）に一致する
 * 3. 現在のメタデータに含まれない、または停止したサイズのものである
 * 4. 本文のどこからも参照されていない — 参照グラフで照合（FR-5.1.4）。
 *    さらに他の添付・画像編集バックアップが同名を使っていないことを
 *    postmeta 横断で確認する（同名別添付の巻き込み防止）
 * 5. 原画本体ではない — 本体・原画・有効サイズのファイル名は最初から
 *    列挙対象に入れない
 *
 * -scaled 本体の隔離（FR-5.2）は明示的なオプトイン設定があるときだけ
 * 候補にし、メタデータの向き先を原画へ付け替える。復元時は書き戻す。
 *
 * 実行順のガード（FR-7.5）: 本文更新（FR-4 apply）が完了していない
 * （= 更新予定の参照が残っている）状態では run を開始しない。旧 URL が
 * 本文に残ったまま旧ファイルを動かすことが、このプラグインで唯一の
 * 致命的操作だから。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 隔離の実行制御
 */
class Cleanup {

	/**
	 * 1バッチの実行時間の上限（秒）
	 */
	const TIME_BUDGET = 15;

	/**
	 * restore / empty 1リクエストの時間予算（秒）と件数上限
	 */
	const LOOP_TIME_BUDGET = 10;
	const LOOP_BATCH       = 50;

	/*
	 * ---------------------------------------------------------------------
	 * plan: 削除候補の算出（FR-5.1 / FR-6.1）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 候補算出ジョブを開始する。進行中のものがあればそれを返す（再開）
	 *
	 * @param bool     $restart          true なら進行中のジョブを破棄して新規に始める。
	 * @param int|null $expected_scan_id プレビューに表示したスキャンID。指定時、最新の
	 *                                   完了スキャンと一致しなければ開始しない（FR-6.3）。
	 *                                   null = 照合しない（CLI 等、独自に確認する経路用）。
	 * @return array 進捗形式。開始できない場合は error キーを持つ。
	 */
	public static function start_plan( bool $restart = false, ?int $expected_scan_id = null ): array {
		$running = Jobs::latest_job( Jobs::TYPE_CLEANUP_PLAN, Jobs::JOB_RUNNING );

		if ( $running && ! $restart ) {
			return self::plan_progress( $running, 0, false );
		}

		$scan = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );

		if ( ! $scan ) {
			return array( 'error' => 'no_scan' );
		}

		// 新規開始の前提チェック。restart 時も、破棄より先に検証する
		if ( null !== $expected_scan_id && (int) $scan->scan_id !== $expected_scan_id ) {
			return array( 'error' => 'stale_preview' );
		}

		if ( $running ) {
			Jobs::update_job(
				(int) $running->job_id,
				array(
					'status'      => Jobs::JOB_ABORTED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}

		// 古いプレビュー行が新しい集計へ混ざらないよう先に払う
		Quarantine::clear_plan_rows();

		$totals = self::normalize_plan_totals( array( 'scan_id' => (int) $scan->scan_id ) );
		$total  = Size_Registry::count_image_attachments();
		$job_id = Jobs::create_job( Jobs::TYPE_CLEANUP_PLAN, $total, $totals );

		return self::plan_progress( Jobs::get_job( $job_id ), 0, false );
	}

	/**
	 * 候補算出を1バッチ進める
	 *
	 * @param int $job_id 対象ジョブ。running であること。
	 * @return array|null 進捗。null = ジョブが存在しないか running でない。
	 */
	public static function step_plan( int $job_id ) {
		$job = Jobs::get_job( $job_id );

		if ( ! $job || Jobs::TYPE_CLEANUP_PLAN !== $job->job_type || Jobs::JOB_RUNNING !== $job->status ) {
			return null;
		}

		$totals = self::normalize_plan_totals( Jobs::decode_totals( $job ) );

		/**
		 * 候補算出1バッチで走査する添付数
		 *
		 * @param int $batch_size 既定 25。TIME_BUDGET 秒を超えた時点でも打ち切る。
		 */
		$batch_size = max( 1, (int) apply_filters( 'rgrl_cleanup_plan_batch_size', 25 ) );

		$ids = self::next_attachment_ids( (int) $job->last_item_id, $batch_size );

		if ( empty( $ids ) ) {
			Jobs::update_job(
				$job_id,
				array(
					'status'      => Jobs::JOB_COMPLETE,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);

			return self::plan_progress( Jobs::get_job( $job_id ), 0, true );
		}

		update_meta_cache( 'post', $ids );

		$delete_scaled = Quarantine::settings()['delete_scaled'];
		$scan_id       = (int) $totals['scan_id'];
		$started       = microtime( true );
		$processed     = 0;
		$last_id       = (int) $job->last_item_id;
		$rows          = array();

		foreach ( $ids as $attachment_id ) {
			$rows    = array_merge( $rows, self::plan_attachment( $attachment_id, $scan_id, $delete_scaled, $totals ) );
			$last_id = $attachment_id;
			++$processed;

			if ( microtime( true ) - $started > self::TIME_BUDGET ) {
				break;
			}
		}

		if ( ! empty( $rows ) ) {
			Quarantine::add_rows( $rows );
		}

		Jobs::update_job(
			$job_id,
			array(
				'items_done'   => (int) $job->items_done + $processed,
				'last_item_id' => $last_id,
				'totals'       => $totals,
			)
		);

		return array(
			'job_id'            => $job_id,
			'attachments_total' => (int) $job->items_total,
			'attachments_done'  => (int) $job->items_done + $processed,
			'processed'         => $processed,
			'done'              => false,
			'totals'            => $totals,
		);
	}

	/**
	 * 添付1件の削除候補・報告行を算出する
	 *
	 * CLI（FR-8.2）もこのメソッドを使う。ここに UI 依存を持ち込まないこと。
	 * ファイルには一切触れない（FR-6.1）。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param int   $scan_id       参照の照合に使う完了スキャン。
	 * @param bool  $delete_scaled -scaled 本体を候補に含めるか（FR-5.2）。
	 * @param array $totals        集計の加算先（参照渡し）。
	 * @return array Quarantine::add_rows() に渡せる行の配列。
	 */
	public static function plan_attachment( int $attachment_id, int $scan_id, bool $delete_scaled, array &$totals ): array {
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) || empty( $meta['file'] ) || ! is_string( $meta['file'] ) ) {
			return array();
		}

		$upload_dir = wp_get_upload_dir();
		$rel_dir    = dirname( $meta['file'] );
		$dir_prefix = '.' === $rel_dir ? '' : trailingslashit( $rel_dir );
		$dir_path   = trailingslashit( $upload_dir['basedir'] ) . $dir_prefix;

		if ( ! is_dir( $dir_path ) ) {
			// メディアオフロード等でローカルにファイルが無い添付は扱わない
			return array();
		}

		$file_name = wp_basename( $meta['file'] );
		$original  = isset( $meta['original_image'] ) && is_string( $meta['original_image'] ) ? $meta['original_image'] : '';

		// 中間サイズの命名は生成元（原画）のファイル名が基準。-scaled 添付でも
		// 中間サイズは「原画名-幅x高さ」で保存される
		$source_name = '' !== $original ? $original : $file_name;
		$dot         = strrpos( $source_name, '.' );

		if ( false === $dot || 0 === $dot ) {
			return array();
		}

		$stem = substr( $source_name, 0, $dot );
		$ext  = substr( $source_name, $dot + 1 );

		$disabled   = Size_Registry::disabled_sizes();
		$meta_sizes = isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ? $meta['sizes'] : array();

		// ファイル名 => それを使うサイズ名。寸法が同じだと複数サイズが同一ファイルを指す
		$sizes_by_file = array();

		foreach ( $meta_sizes as $name => $size_meta ) {
			if ( is_array( $size_meta ) && ! empty( $size_meta['file'] ) && is_string( $size_meta['file'] ) ) {
				$sizes_by_file[ wp_basename( $size_meta['file'] ) ][] = (string) $name;
			}
		}

		// この添付の正規ファイル（FR-5.1.5: 本体・原画と、有効なサイズが使うファイル）
		$protected = array( $file_name => true );

		if ( '' !== $original ) {
			$protected[ $original ] = true;
		}

		foreach ( $sizes_by_file as $used_name => $names ) {
			if ( array_diff( $names, $disabled ) ) {
				$protected[ $used_name ] = true;
			}
		}

		$pattern = '/^' . preg_quote( $stem, '/' ) . '-\d+x\d+\.' . preg_quote( $ext, '/' ) . '$/';
		$entries = scandir( $dir_path );
		$found   = array();

		foreach ( is_array( $entries ) ? $entries : array() as $entry ) {
			if ( ! preg_match( $pattern, $entry ) || isset( $protected[ $entry ] ) ) {
				continue;
			}

			if ( isset( $sizes_by_file[ $entry ] ) ) {
				// メタデータに載っているが、使う全サイズが停止中（FR-5.1.3 後段）。
				// 有効なサイズがひとつでもあれば $protected で除外済み
				$found[] = array(
					'name'   => $entry,
					'reason' => Quarantine::REASON_DISABLED,
					'sizes'  => $sizes_by_file[ $entry ],
				);
			} else {
				// 現在のメタデータに含まれない（FR-5.1.3 前段）
				$found[] = array(
					'name'   => $entry,
					'reason' => Quarantine::REASON_ORPHANED,
					'sizes'  => array(),
				);
			}
		}

		// -scaled 本体（FR-5.2）: 原画が別に実在するときだけ扱う
		if ( '' !== $original && preg_match( '/-scaled\.[^.]+$/', $file_name ) ) {
			$scaled_size = is_file( $dir_path . $file_name ) ? (int) filesize( $dir_path . $file_name ) : 0;

			if ( ! $delete_scaled ) {
				// 既定では削除しない。存在量だけ集計して知らせる
				if ( $scaled_size > 0 ) {
					++$totals['scaled_files'];
					$totals['scaled_bytes'] += $scaled_size;
				}
			} elseif ( $scaled_size > 0 && is_file( $dir_path . $original ) ) {
				$found[] = array(
					'name'   => $file_name,
					'reason' => Quarantine::REASON_SCALED,
					'sizes'  => array(),
				);
			}
		}

		if ( empty( $found ) ) {
			return array();
		}

		// 参照チェック（FR-5.1.4）: この添付への参照から「本文に実在する URL」の
		// ファイル名集合を作る。状態と列の対応は Reference_Graph::mentions_filename と同じ
		$referenced = array();

		foreach ( Reference_Graph::refs_for_attachment( $scan_id, $attachment_id ) as $ref ) {
			$status = (string) $ref->status;

			if ( in_array( $status, array( Reference_Graph::REF_FOUND, Reference_Graph::REF_UPDATE, Reference_Graph::REF_SKIP, Reference_Graph::REF_FAILED ), true ) ) {
				$referenced[ wp_basename( (string) $ref->url ) ] = true;
			}

			if ( '' !== (string) $ref->new_url && in_array( $status, array( Reference_Graph::REF_UPDATE, Reference_Graph::REF_APPLIED ), true ) ) {
				$referenced[ wp_basename( (string) $ref->new_url ) ] = true;
			}
		}

		$rows = array();

		foreach ( $found as $item ) {
			$name = $item['name'];
			$path = $dir_path . $name;

			clearstatcache( true, $path );

			if ( ! is_file( $path ) ) {
				continue;
			}

			$size  = (int) filesize( $path );
			$mtime = (int) filemtime( $path );

			$row = array(
				'scan_id'       => $scan_id,
				'attachment_id' => $attachment_id,
				'size_name'     => empty( $item['sizes'] ) ? '' : (string) $item['sizes'][0],
				'rel_path'      => $dir_prefix . $name,
				'bytes'         => $size,
				'details'       => array(
					// run 時の前提照合（FR-6.4）に使う plan 時点のファイル状態
					'stat'  => array(
						'size'  => $size,
						'mtime' => $mtime,
					),
					'sizes' => $item['sizes'],
				),
			);

			if ( isset( $referenced[ $name ] ) || Reference_Graph::mentions_filename( $scan_id, $name ) ) {
				// 本文のどこかから参照されている（FR-5.1.4 欠落 → 報告のみ）
				$row['status'] = Quarantine::ST_REPORT;
				$row['reason'] = Quarantine::REASON_REFERENCED;
			} elseif ( self::claimed_elsewhere( $attachment_id, $name ) ) {
				// 他の添付・画像編集バックアップが同名を使っている → 報告のみ
				$row['status'] = Quarantine::ST_REPORT;
				$row['reason'] = Quarantine::REASON_CLAIMED;
			} else {
				$row['status'] = Quarantine::ST_CANDIDATE;
				$row['reason'] = $item['reason'];

				++$totals['candidates'];
				$totals['candidate_bytes'] += $size;
			}

			$rows[] = $row;
		}

		return $rows;
	}

	/**
	 * 他の添付・編集バックアップがこのファイル名を使っていないか（FR-5.1.5 の横断確認)
	 *
	 * 同名ファイルを原画として持つ別添付（例: foo-150x150.jpg という名前の
	 * 画像を別途アップロードした場合）や、画像エディタの「元に戻す」用
	 * バックアップ（_wp_attachment_backup_sizes。自添付分も含む）を守る。
	 * 部分一致の過剰ヒットは「保護しすぎ」の方向なので安全側（NFR-1.1）。
	 *
	 * @param int    $attachment_id 判定中の添付ID（自身のメタは除外する）。
	 * @param string $filename      ファイル名（basename）。
	 * @return bool 使われていれば true。
	 */
	private static function claimed_elsewhere( int $attachment_id, string $filename ): bool {
		global $wpdb;

		$quoted_like = '%' . $wpdb->esc_like( '"' . $filename . '"' ) . '%';
		$tail_like   = '%' . $wpdb->esc_like( $filename );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- 添付横断のファイル名照合。meta_key インデックスで絞った上での LIKE で、WP_Query では表現できない。
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta}
				WHERE ( meta_key = '_wp_attached_file' AND post_id <> %d AND meta_value LIKE %s )
				OR ( meta_key = '_wp_attachment_metadata' AND post_id <> %d AND meta_value LIKE %s )
				OR ( meta_key = '_wp_attachment_backup_sizes' AND meta_value LIKE %s )",
				$attachment_id,
				$tail_like,
				$attachment_id,
				$quoted_like,
				$quoted_like
			)
		);

		return (int) $count > 0;
	}

	/*
	 * ---------------------------------------------------------------------
	 * run: 隔離の実行（FR-5.3 / FR-7.5）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 隔離ジョブを開始する。進行中のものがあればそれを返す（再開）
	 *
	 * @param bool     $restart          true なら進行中のジョブを破棄して新規に始める。
	 * @param int|null $expected_scan_id プレビューに表示したスキャンID。null = 照合しない
	 *                                   （CLI 等、独自に確認する経路用。FR-7.5 のガードは
	 *                                   null でも掛かる）。
	 * @return array 進捗形式。開始できない場合は error キーを持つ。
	 */
	public static function start_run( bool $restart = false, ?int $expected_scan_id = null ): array {
		$running = Jobs::latest_job( Jobs::TYPE_QUARANTINE, Jobs::JOB_RUNNING );

		if ( $running && ! $restart ) {
			return self::run_progress( $running, 0, false );
		}

		$scan = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );

		if ( ! $scan ) {
			return array( 'error' => 'no_scan' );
		}

		$scan_id = (int) $scan->scan_id;

		if ( null !== $expected_scan_id && $scan_id !== $expected_scan_id ) {
			return array( 'error' => 'stale_preview' );
		}

		// plan（プレビュー）の候補が、この完了スキャンを根拠にしていること（FR-6.3）
		$plan_scan_id = Quarantine::plan_scan_id();

		if ( 0 === $plan_scan_id ) {
			return array( 'error' => 'no_plan' );
		}

		if ( $plan_scan_id !== $scan_id ) {
			return array( 'error' => 'stale_preview' );
		}

		// FR-7.5: 本文更新が完了していない（更新予定の参照が残っている）間は
		// 実行しない。旧 URL が本文に残ったまま旧ファイルを動かさない
		$pending = Reference_Graph::status_breakdown( $scan_id, Reference_Graph::REF_UPDATE );

		if ( $pending['refs'] > 0 ) {
			return array(
				'error'   => 'apply_incomplete',
				'pending' => $pending['refs'],
			);
		}

		if ( null === Quarantine::ensure_dir() ) {
			return array( 'error' => 'dir_failed' );
		}

		if ( $running ) {
			Jobs::update_job(
				(int) $running->job_id,
				array(
					'status'      => Jobs::JOB_ABORTED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}

		$totals = self::normalize_run_totals( array( 'scan_id' => $scan_id ) );
		$total  = Quarantine::count_status( Quarantine::ST_CANDIDATE );
		$job_id = Jobs::create_job( Jobs::TYPE_QUARANTINE, $total, $totals );

		return self::run_progress( Jobs::get_job( $job_id ), 0, false );
	}

	/**
	 * 隔離を1バッチ進める
	 *
	 * @param int $job_id 対象ジョブ。running であること。
	 * @return array|null 進捗。null = ジョブが存在しないか running でない。
	 */
	public static function step_run( int $job_id ) {
		$job = Jobs::get_job( $job_id );

		if ( ! $job || Jobs::TYPE_QUARANTINE !== $job->job_type || Jobs::JOB_RUNNING !== $job->status ) {
			return null;
		}

		$totals = self::normalize_run_totals( Jobs::decode_totals( $job ) );

		/**
		 * 隔離1バッチで処理する候補数
		 *
		 * @param int $batch_size 既定 25。TIME_BUDGET 秒を超えた時点でも打ち切る。
		 */
		$batch_size = max( 1, (int) apply_filters( 'rgrl_quarantine_batch_size', 25 ) );

		$rows = Quarantine::rows_batch( Quarantine::ST_CANDIDATE, (int) $job->last_item_id, $batch_size );

		if ( empty( $rows ) ) {
			Jobs::update_job(
				$job_id,
				array(
					'status'      => Jobs::JOB_COMPLETE,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);

			return self::run_progress( Jobs::get_job( $job_id ), 0, true );
		}

		$qdir = Quarantine::ensure_dir();

		if ( null === $qdir ) {
			return array( 'error' => 'dir_failed' );
		}

		$settings  = Quarantine::settings();
		$started   = microtime( true );
		$processed = 0;
		$last_id   = (int) $job->last_item_id;

		foreach ( $rows as $row ) {
			$result  = self::run_row( $row, $qdir, $settings );
			$last_id = (int) $row->file_id;
			++$processed;

			if ( 'quarantined' === $result ) {
				++$totals['quarantined'];
				$totals['bytes'] += (int) $row->bytes;
			} else {
				$totals['skipped'][ $result ] = ( $totals['skipped'][ $result ] ?? 0 ) + 1;
			}

			// ファイル移動と行の記録は1件ずつ完結しているため、どこで
			// 打ち切っても完了分は失われない（FR-7.7 / NFR-1.6）
			if ( microtime( true ) - $started > self::TIME_BUDGET ) {
				break;
			}
		}

		Jobs::update_job(
			$job_id,
			array(
				'items_done'   => (int) $job->items_done + $processed,
				'last_item_id' => $last_id,
				'totals'       => $totals,
			)
		);

		return array(
			'job_id'      => $job_id,
			'files_total' => (int) $job->items_total,
			'files_done'  => (int) $job->items_done + $processed,
			'processed'   => $processed,
			'done'        => false,
			'totals'      => $totals,
		);
	}

	/**
	 * 候補1件を隔離する
	 *
	 * @param object $row      candidate 状態の行。
	 * @param string $qdir     隔離ディレクトリの絶対パス。
	 * @param array  $settings Quarantine::settings() の値。
	 * @return string 'quarantined' またはスキップ理由（REASON_* の値）。
	 */
	private static function run_row( $row, string $qdir, array $settings ): string {
		$file_id  = (int) $row->file_id;
		$details  = Quarantine::decode_details( $row );
		$basename = wp_basename( (string) $row->rel_path );
		$stored   = $file_id . '-' . $basename;
		$dest     = trailingslashit( $qdir ) . $stored;

		// FR-5.1.1 / NFR-1.4: uploads 配下であることを実パス解決の上で検証する
		$path = self::resolve_uploads_path( (string) $row->rel_path );

		if ( null === $path ) {
			return self::skip_row( $file_id, Quarantine::REASON_PATH_INVALID );
		}

		clearstatcache( true, $path );

		if ( ! is_file( $path ) ) {
			// 前回の実行が移動直後に落ちていた場合はメタ処理から再開して
			// 隔離済みへ倒す（再実行で整合が回復する。NFR-1.6）
			if ( is_file( $dest ) ) {
				return self::finish_quarantine( $row, $stored, $details );
			}

			return self::skip_row( $file_id, Quarantine::REASON_FILE_MISSING );
		}

		// plan 時点とファイルが変わっていないこと（FR-6.4）
		$stat = isset( $details['stat'] ) && is_array( $details['stat'] ) ? $details['stat'] : array();

		if ( (int) filesize( $path ) !== (int) ( $stat['size'] ?? -1 )
			|| (int) filemtime( $path ) !== (int) ( $stat['mtime'] ?? -1 ) ) {
			return self::skip_row( $file_id, Quarantine::REASON_PRECONDITION );
		}

		// plan 時点とメタデータ・設定が変わっていないこと（FR-6.4）
		if ( ! self::verify_meta_precondition( $row, $details, $settings ) ) {
			return self::skip_row( $file_id, Quarantine::REASON_PRECONDITION );
		}

		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.rename_rename -- 移動失敗は戻り値で検出して記録する。並行削除等の TOCTOU があるため事前チェックでは警告を防ぎ切れない。WP_Filesystem の資格情報要求は REST/cron 文脈では使えない。
		if ( ! @rename( $path, $dest ) ) {
			// uploads が複数デバイスにまたがる構成へのフォールバック
			// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink -- 上と同じ。
			if ( ! @copy( $path, $dest ) || ! @unlink( $path ) ) {
				// 原本（$path）は必ず残っている。中途半端な複製だけ消して仕切り直す
				if ( is_file( $dest ) ) {
					wp_delete_file( $dest );
				}

				return self::skip_row( $file_id, Quarantine::REASON_MOVE_FAILED );
			}
		}

		return self::finish_quarantine( $row, $stored, $details );
	}

	/**
	 * 移動済みファイルのメタ処理と行の確定
	 *
	 * 再実行されても安全なように、メタ操作はすべて「対象がまだその状態の
	 * ときだけ」動く冪等な実装にしてある。
	 *
	 * @param object $row     行。
	 * @param string $stored  隔離領域内の保存名。
	 * @param array  $details 行の details。
	 * @return string 'quarantined'。
	 */
	private static function finish_quarantine( $row, string $stored, array $details ): string {
		$attachment_id = (int) $row->attachment_id;
		$reason        = (string) $row->reason;

		if ( Quarantine::REASON_DISABLED === $reason ) {
			$removed = self::detach_size_meta(
				$attachment_id,
				isset( $details['sizes'] ) && is_array( $details['sizes'] ) ? $details['sizes'] : array(),
				wp_basename( (string) $row->rel_path )
			);

			if ( ! empty( $removed ) ) {
				$details['removed_sizes'] = $removed;
			}
		} elseif ( Quarantine::REASON_SCALED === $reason ) {
			$patch = self::detach_scaled_meta( $attachment_id );

			if ( null !== $patch ) {
				$details['meta_patch'] = $patch;
			}
		}

		Quarantine::update_row(
			(int) $row->file_id,
			array(
				'status'         => Quarantine::ST_QUARANTINED,
				'stored_name'    => $stored,
				'quarantined_at' => gmdate( 'Y-m-d H:i:s' ),
				'details'        => $details,
			)
		);

		return 'quarantined';
	}

	/**
	 * 行をスキップとして記録する
	 *
	 * @param int    $file_id 行ID。
	 * @param string $reason  スキップ理由（REASON_* 定数）。
	 * @return string 記録した理由（step_run の集計キー）。
	 */
	private static function skip_row( int $file_id, string $reason ): string {
		Quarantine::update_row(
			$file_id,
			array(
				'status' => Quarantine::ST_SKIPPED,
				'reason' => $reason,
			)
		);

		return $reason;
	}

	/**
	 * plan 時点のメタデータ・設定の前提がまだ成り立つか（FR-6.4）
	 *
	 * @param object $row      行。
	 * @param array  $details  行の details。
	 * @param array  $settings Quarantine::settings() の値。
	 */
	private static function verify_meta_precondition( $row, array $details, array $settings ): bool {
		$attachment_id = (int) $row->attachment_id;
		$reason        = (string) $row->reason;
		$basename      = wp_basename( (string) $row->rel_path );

		$meta       = wp_get_attachment_metadata( $attachment_id );
		$meta       = is_array( $meta ) ? $meta : array();
		$meta_sizes = isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ? $meta['sizes'] : array();

		if ( Quarantine::REASON_ORPHANED === $reason ) {
			// plan 後の再生成などで正規ファイルへ戻っていないこと
			if ( wp_basename( (string) ( $meta['file'] ?? '' ) ) === $basename ) {
				return false;
			}

			if ( (string) ( $meta['original_image'] ?? '' ) === $basename ) {
				return false;
			}

			foreach ( $meta_sizes as $size_meta ) {
				if ( is_array( $size_meta ) && wp_basename( (string) ( $size_meta['file'] ?? '' ) ) === $basename ) {
					return false;
				}
			}

			return true;
		}

		if ( Quarantine::REASON_DISABLED === $reason ) {
			$names = isset( $details['sizes'] ) && is_array( $details['sizes'] ) ? $details['sizes'] : array();

			if ( empty( $names ) ) {
				return false;
			}

			$disabled = Size_Registry::disabled_sizes();

			foreach ( $names as $name ) {
				if ( ! in_array( (string) $name, $disabled, true ) ) {
					return false;
				}

				$size_meta = $meta_sizes[ $name ] ?? null;

				if ( ! is_array( $size_meta ) || wp_basename( (string) ( $size_meta['file'] ?? '' ) ) !== $basename ) {
					return false;
				}
			}

			return true;
		}

		if ( Quarantine::REASON_SCALED === $reason ) {
			if ( empty( $settings['delete_scaled'] ) ) {
				return false;
			}

			if ( wp_basename( (string) ( $meta['file'] ?? '' ) ) !== $basename || empty( $meta['original_image'] ) ) {
				return false;
			}

			$original = wp_get_original_image_path( $attachment_id );

			return is_string( $original ) && '' !== $original && is_file( $original );
		}

		return false;
	}

	/**
	 * 停止サイズのエントリをメタデータから外す（復元用に退避を返す）
	 *
	 * @param int      $attachment_id 添付ID。
	 * @param string[] $names         外すサイズ名。
	 * @param string   $basename      対象ファイル名（このファイルを指すエントリだけ外す）。
	 * @return array<string, array> 外したエントリ。復元（FR-5.4）で書き戻す。
	 */
	private static function detach_size_meta( int $attachment_id, array $names, string $basename ): array {
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) || ! isset( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
			return array();
		}

		$removed = array();

		foreach ( $names as $name ) {
			$name      = (string) $name;
			$size_meta = $meta['sizes'][ $name ] ?? null;

			if ( is_array( $size_meta ) && wp_basename( (string) ( $size_meta['file'] ?? '' ) ) === $basename ) {
				$removed[ $name ] = $size_meta;
				unset( $meta['sizes'][ $name ] );
			}
		}

		if ( ! empty( $removed ) ) {
			wp_update_attachment_metadata( $attachment_id, $meta );
		}

		return $removed;
	}

	/**
	 * -scaled 本体の隔離に伴い、添付の向き先を原画へ付け替える（FR-5.2）
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array|null 書き換え前の断片（復元用）。既に処理済みなら null。
	 */
	private static function detach_scaled_meta( int $attachment_id ): ?array {
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) || empty( $meta['original_image'] ) || empty( $meta['file'] ) ) {
			return null;
		}

		// 付け替え前に原画の実寸法を取る（EXIF の向きも考慮される）
		list( $width, $height ) = Size_Registry::source_dimensions( $attachment_id, $meta );

		$original_path = wp_get_original_image_path( $attachment_id );

		$patch = array(
			'file'           => (string) $meta['file'],
			'width'          => (int) ( $meta['width'] ?? 0 ),
			'height'         => (int) ( $meta['height'] ?? 0 ),
			'original_image' => (string) $meta['original_image'],
			'filesize'       => $meta['filesize'] ?? null,
		);

		$rel_dir  = dirname( $meta['file'] );
		$new_file = ( '.' === $rel_dir ? '' : trailingslashit( $rel_dir ) ) . $meta['original_image'];

		$meta['file']   = $new_file;
		$meta['width']  = $width;
		$meta['height'] = $height;
		unset( $meta['original_image'] );

		$size = is_string( $original_path ) && is_file( $original_path ) ? filesize( $original_path ) : false;

		if ( false === $size ) {
			unset( $meta['filesize'] );
		} else {
			$meta['filesize'] = (int) $size;
		}

		update_attached_file( $attachment_id, $new_file );
		wp_update_attachment_metadata( $attachment_id, $meta );

		return $patch;
	}

	/*
	 * ---------------------------------------------------------------------
	 * restore: 復元（FR-5.4）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 隔離済みファイルの復元を1バッチ進める
	 *
	 * ジョブは使わず、行の状態遷移そのものを進捗として繰り返し呼ばれる。
	 * 復元できなかった行は quarantined のまま details に理由を記録し、
	 * カーソルで先へ進む（無限ループしない）。
	 *
	 * @param int $after_file_id この行IDより大きいものから。初回は 0。
	 * @return array { processed, restored, failed, next_cursor, remaining, done }
	 */
	public static function restore_batch( int $after_file_id ): array {
		$qdir = Quarantine::dir();
		$rows = null === $qdir
			? array()
			: Quarantine::rows_batch( Quarantine::ST_QUARANTINED, $after_file_id, self::LOOP_BATCH );

		$started   = microtime( true );
		$processed = 0;
		$restored  = 0;
		$failed    = 0;
		$cursor    = $after_file_id;

		foreach ( $rows as $row ) {
			$ok     = self::restore_row( $row, $qdir );
			$cursor = (int) $row->file_id;
			++$processed;

			if ( $ok ) {
				++$restored;
			} else {
				++$failed;
			}

			if ( microtime( true ) - $started > self::LOOP_TIME_BUDGET ) {
				break;
			}
		}

		return array(
			'processed'   => $processed,
			'restored'    => $restored,
			'failed'      => $failed,
			'next_cursor' => $cursor,
			'remaining'   => Quarantine::count_status( Quarantine::ST_QUARANTINED ),
			'done'        => count( $rows ) === $processed && count( $rows ) < self::LOOP_BATCH,
		);
	}

	/**
	 * 隔離済み1件を元の場所へ戻す
	 *
	 * @param object $row  quarantined 状態の行。
	 * @param string $qdir 隔離ディレクトリの絶対パス。
	 * @return bool 復元できたか。
	 */
	private static function restore_row( $row, string $qdir ): bool {
		$file_id = (int) $row->file_id;
		$src     = trailingslashit( $qdir ) . (string) $row->stored_name;

		if ( '' === (string) $row->stored_name || ! is_file( $src ) ) {
			return self::record_restore_failure( $row, 'source_missing' );
		}

		$dest = self::resolve_restore_path( (string) $row->rel_path );

		if ( null === $dest ) {
			return self::record_restore_failure( $row, 'path_invalid' );
		}

		if ( is_file( $dest ) ) {
			// 再生成などで同名ファイルができている。上書きしない（NFR-1.1）
			return self::record_restore_failure( $row, Quarantine::REASON_CONFLICT );
		}

		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.rename_rename -- 移動失敗は戻り値で検出して記録する。WP_Filesystem の資格情報要求は REST/cron 文脈では使えない。
		if ( ! @rename( $src, $dest ) ) {
			// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink -- 上と同じ。
			if ( ! @copy( $src, $dest ) || ! @unlink( $src ) ) {
				if ( is_file( $dest ) && is_file( $src ) ) {
					wp_delete_file( $dest );
				}

				return self::record_restore_failure( $row, 'move_failed' );
			}
		}

		$details = Quarantine::decode_details( $row );

		if ( isset( $details['removed_sizes'] ) && is_array( $details['removed_sizes'] ) ) {
			self::reattach_size_meta( (int) $row->attachment_id, $details['removed_sizes'] );
		}

		if ( isset( $details['meta_patch'] ) && is_array( $details['meta_patch'] ) ) {
			self::reattach_scaled_meta( (int) $row->attachment_id, $details['meta_patch'] );
		}

		unset( $details['restore_error'] );

		Quarantine::update_row(
			$file_id,
			array(
				'status'  => Quarantine::ST_RESTORED,
				'details' => $details,
			)
		);

		return true;
	}

	/**
	 * 復元失敗を details に記録する（状態は quarantined のまま）
	 *
	 * reason 列は「なぜ隔離候補になったか」の記録なので触らない。
	 *
	 * @param object $row   行。
	 * @param string $error 失敗理由。
	 * @return bool 常に false（restore_row の戻り値として使う）。
	 */
	private static function record_restore_failure( $row, string $error ): bool {
		$details                  = Quarantine::decode_details( $row );
		$details['restore_error'] = $error;

		Quarantine::update_row( (int) $row->file_id, array( 'details' => $details ) );

		return false;
	}

	/**
	 * 停止サイズのエントリをメタデータへ書き戻す（FR-5.4）
	 *
	 * 現在のメタに同名サイズが既にある場合（復元までの間に再生成された等）は
	 * 触らない。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param array $removed       隔離時に退避したエントリ。
	 */
	private static function reattach_size_meta( int $attachment_id, array $removed ): void {
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) ) {
			return;
		}

		if ( ! isset( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
			$meta['sizes'] = array();
		}

		$changed = false;

		foreach ( $removed as $name => $size_meta ) {
			if ( is_array( $size_meta ) && ! isset( $meta['sizes'][ $name ] ) ) {
				$meta['sizes'][ $name ] = $size_meta;
				$changed                = true;
			}
		}

		if ( $changed ) {
			wp_update_attachment_metadata( $attachment_id, $meta );
		}
	}

	/**
	 * -scaled の向き先をメタデータへ書き戻す（FR-5.4）
	 *
	 * 隔離時に付け替えた「原画向き」のままのときだけ戻す。その後に
	 * 画像編集などでメタが変わっていたら触らない（NFR-1.1）。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param array $patch         隔離時に退避した断片。
	 */
	private static function reattach_scaled_meta( int $attachment_id, array $patch ): void {
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) || empty( $patch['file'] ) || empty( $patch['original_image'] ) ) {
			return;
		}

		$rel_dir  = dirname( (string) $patch['file'] );
		$expected = ( '.' === $rel_dir ? '' : trailingslashit( $rel_dir ) ) . (string) $patch['original_image'];

		if ( (string) ( $meta['file'] ?? '' ) !== $expected || ! empty( $meta['original_image'] ) ) {
			return;
		}

		$meta['file']           = (string) $patch['file'];
		$meta['width']          = (int) $patch['width'];
		$meta['height']         = (int) $patch['height'];
		$meta['original_image'] = (string) $patch['original_image'];

		if ( isset( $patch['filesize'] ) && null !== $patch['filesize'] ) {
			$meta['filesize'] = (int) $patch['filesize'];
		} else {
			unset( $meta['filesize'] );
		}

		update_attached_file( $attachment_id, (string) $patch['file'] );
		wp_update_attachment_metadata( $attachment_id, $meta );
	}

	/*
	 * ---------------------------------------------------------------------
	 * empty: 隔離領域を手動で空にする（FR-5.7）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 隔離領域の完全削除を1バッチ進める
	 *
	 * @param int $after_file_id この行IDより大きいものから。初回は 0。
	 * @return array { processed, purged, next_cursor, remaining, done }
	 */
	public static function empty_batch( int $after_file_id ): array {
		$rows = Quarantine::rows_batch( Quarantine::ST_QUARANTINED, $after_file_id, self::LOOP_BATCH );

		$started   = microtime( true );
		$processed = 0;
		$purged    = 0;
		$cursor    = $after_file_id;

		foreach ( $rows as $row ) {
			if ( Quarantine::purge_row( $row ) ) {
				++$purged;
			}

			$cursor = (int) $row->file_id;
			++$processed;

			if ( microtime( true ) - $started > self::LOOP_TIME_BUDGET ) {
				break;
			}
		}

		return array(
			'processed'   => $processed,
			'purged'      => $purged,
			'next_cursor' => $cursor,
			'remaining'   => Quarantine::count_status( Quarantine::ST_QUARANTINED ),
			'done'        => count( $rows ) === $processed && count( $rows ) < self::LOOP_BATCH,
		);
	}

	/*
	 * ---------------------------------------------------------------------
	 * 共通ヘルパー
	 * ---------------------------------------------------------------------
	 */

	/**
	 * uploads 相対パスを検証済みの絶対パスへ解決する（NFR-1.4 / NFR-5.5）
	 *
	 * 実在するファイル用。文字列としての遮断（.. / 絶対パス / NUL）と、
	 * 実パス解決後の uploads 配下確認の二段で検証する。
	 *
	 * @param string $rel_path uploads 相対パス。
	 * @return string|null 検証済み絶対パス。不正なら null。
	 */
	private static function resolve_uploads_path( string $rel_path ): ?string {
		if ( ! self::rel_path_shape_ok( $rel_path ) ) {
			return null;
		}

		$upload_dir = wp_get_upload_dir();
		$basedir    = realpath( $upload_dir['basedir'] );
		$dir_real   = realpath( dirname( trailingslashit( $upload_dir['basedir'] ) . $rel_path ) );

		if ( false === $basedir || false === $dir_real ) {
			return null;
		}

		if ( $dir_real !== $basedir && 0 !== strpos( $dir_real, $basedir . DIRECTORY_SEPARATOR ) ) {
			return null;
		}

		return trailingslashit( $dir_real ) . wp_basename( $rel_path );
	}

	/**
	 * 復元先の uploads 相対パスを検証済みの絶対パスへ解決する
	 *
	 * 復元先ファイルはまだ存在しないため、親ディレクトリを（必要なら
	 * 作成してから）実パスで検証する。
	 *
	 * @param string $rel_path uploads 相対パス。
	 * @return string|null 検証済み絶対パス。不正なら null。
	 */
	private static function resolve_restore_path( string $rel_path ): ?string {
		if ( ! self::rel_path_shape_ok( $rel_path ) ) {
			return null;
		}

		$upload_dir = wp_get_upload_dir();
		$parent     = dirname( trailingslashit( $upload_dir['basedir'] ) . $rel_path );

		// 形状検証済みのパスなので、この mkdir は uploads 配下にしか掘れない
		if ( ! is_dir( $parent ) && ! wp_mkdir_p( $parent ) ) {
			return null;
		}

		$basedir  = realpath( $upload_dir['basedir'] );
		$dir_real = realpath( $parent );

		if ( false === $basedir || false === $dir_real ) {
			return null;
		}

		if ( $dir_real !== $basedir && 0 !== strpos( $dir_real, $basedir . DIRECTORY_SEPARATOR ) ) {
			return null;
		}

		return trailingslashit( $dir_real ) . wp_basename( $rel_path );
	}

	/**
	 * uploads 相対パスとして許される形か（文字列としての遮断）
	 *
	 * @param string $rel_path 検査対象。
	 */
	private static function rel_path_shape_ok( string $rel_path ): bool {
		if ( '' === $rel_path || false !== strpos( $rel_path, "\0" ) ) {
			return false;
		}

		if ( preg_match( '#(^|[/\\\\])\.\.([/\\\\]|$)#', $rel_path ) ) {
			return false;
		}

		if ( path_is_absolute( $rel_path ) ) {
			return false;
		}

		return true;
	}

	/**
	 * plan の累積値を正規の構造に丸める
	 *
	 * @param mixed $totals ジョブ行の totals（JSON 復号後）。
	 * @return array 正規化済みの累積値。
	 */
	public static function normalize_plan_totals( $totals ): array {
		$totals = is_array( $totals ) ? $totals : array();

		return array(
			'scan_id'         => absint( $totals['scan_id'] ?? 0 ),
			'candidates'      => absint( $totals['candidates'] ?? 0 ),
			'candidate_bytes' => absint( $totals['candidate_bytes'] ?? 0 ),
			'scaled_files'    => absint( $totals['scaled_files'] ?? 0 ),
			'scaled_bytes'    => absint( $totals['scaled_bytes'] ?? 0 ),
		);
	}

	/**
	 * run の累積値を正規の構造に丸める
	 *
	 * @param mixed $totals ジョブ行の totals（JSON 復号後）。
	 * @return array 正規化済みの累積値。
	 */
	public static function normalize_run_totals( $totals ): array {
		$totals = is_array( $totals ) ? $totals : array();

		$out = array(
			'scan_id'     => absint( $totals['scan_id'] ?? 0 ),
			'quarantined' => absint( $totals['quarantined'] ?? 0 ),
			'bytes'       => absint( $totals['bytes'] ?? 0 ),
			'skipped'     => array(),
		);

		$skipped = isset( $totals['skipped'] ) && is_array( $totals['skipped'] ) ? $totals['skipped'] : array();

		foreach ( $skipped as $reason => $count ) {
			$out['skipped'][ sanitize_key( (string) $reason ) ] = absint( $count );
		}

		return $out;
	}

	/**
	 * plan ジョブの進捗を応答形式に整える
	 *
	 * @param object|null $job       ジョブ行。
	 * @param int         $processed このリクエストで処理した件数。
	 * @param bool        $done      完了したか。
	 */
	private static function plan_progress( $job, int $processed, bool $done ): array {
		if ( ! $job ) {
			return array(
				'job_id'            => 0,
				'attachments_total' => 0,
				'attachments_done'  => 0,
				'processed'         => 0,
				'done'              => $done,
				'totals'            => self::normalize_plan_totals( array() ),
			);
		}

		return array(
			'job_id'            => (int) $job->job_id,
			'attachments_total' => (int) $job->items_total,
			'attachments_done'  => (int) $job->items_done,
			'processed'         => $processed,
			'done'              => $done,
			'totals'            => self::normalize_plan_totals( Jobs::decode_totals( $job ) ),
		);
	}

	/**
	 * run ジョブの進捗を応答形式に整える
	 *
	 * @param object|null $job       ジョブ行。
	 * @param int         $processed このリクエストで処理した件数。
	 * @param bool        $done      完了したか。
	 */
	private static function run_progress( $job, int $processed, bool $done ): array {
		if ( ! $job ) {
			return array(
				'job_id'      => 0,
				'files_total' => 0,
				'files_done'  => 0,
				'processed'   => 0,
				'done'        => $done,
				'totals'      => self::normalize_run_totals( array() ),
			);
		}

		return array(
			'job_id'      => (int) $job->job_id,
			'files_total' => (int) $job->items_total,
			'files_done'  => (int) $job->items_done,
			'processed'   => $processed,
			'done'        => $done,
			'totals'      => self::normalize_run_totals( Jobs::decode_totals( $job ) ),
		);
	}

	/**
	 * カーソル以降の画像添付IDを取得する
	 *
	 * @param int $after_id   このIDより大きい添付から。
	 * @param int $batch_size 件数。
	 * @return int[]
	 */
	private static function next_attachment_ids( int $after_id, int $batch_size ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- カーソル式ページングのため ID 直接取得が必要。WP_Query の OFFSET ページングは大規模サイトで劣化する。
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment' AND post_mime_type LIKE %s AND ID > %d
				ORDER BY ID LIMIT %d",
				$wpdb->esc_like( 'image/' ) . '%',
				$after_id,
				$batch_size
			)
		);

		return array_map( 'intval', $ids );
	}
}
