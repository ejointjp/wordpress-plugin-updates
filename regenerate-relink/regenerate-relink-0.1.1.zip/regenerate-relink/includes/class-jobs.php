<?php
/**
 * 長時間バッチジョブのデータ層
 *
 * 再生成（FR-3）をはじめ、タイムアウト・接続断があっても再開できる
 * 必要がある処理（FR-3.5 / FR-7.7）の実行状態を rgrl_jobs で管理する。
 * 進捗の主単位（items_total / items_done）と再開カーソル（last_item_id）は
 * カラムで持ち、ジョブ種別ごとの詳細カウンタは totals（JSON）に格納する。
 *
 * 本クラスは格納と照会に徹する。処理の実装は各実行クラス
 * （Regenerator 等）が持つ。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- カスタムテーブルのデータ層のため $wpdb 直接クエリが本務。結果の再利用は呼び出し側の責務とする。

/**
 * ジョブの格納・照会
 */
class Jobs {
	/*
	 * ジョブの状態
	 */
	const JOB_RUNNING  = 'running';
	const JOB_COMPLETE = 'complete';
	const JOB_ABORTED  = 'aborted';

	/*
	 * ジョブ種別
	 *
	 * 種別を増やすときは値の追加のみで済ませ、既存値の意味を変えないこと。
	 */
	const TYPE_REGENERATE   = 'regenerate';
	const TYPE_APPLY        = 'apply';
	const TYPE_CLEANUP_PLAN = 'cleanup_plan';
	const TYPE_QUARANTINE   = 'quarantine';

	/**
	 * ジョブを開始する
	 *
	 * @param string $job_type    ジョブ種別（TYPE_* 定数）。
	 * @param int    $items_total 処理予定の項目数。
	 * @param array  $totals      詳細カウンタの初期値。
	 * @return int 新しい job_id。失敗時は 0。
	 */
	public static function create_job( string $job_type, int $items_total = 0, array $totals = array() ): int {
		global $wpdb;

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'rgrl_jobs',
			array(
				'job_type'    => $job_type,
				'status'      => self::JOB_RUNNING,
				'started_at'  => gmdate( 'Y-m-d H:i:s' ),
				'items_total' => $items_total,
				'totals'      => (string) wp_json_encode( $totals ),
			),
			array( '%s', '%s', '%s', '%d', '%s' )
		);

		return $inserted ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * ジョブを1件取得する
	 *
	 * @param int $job_id ジョブID。
	 * @return object|null
	 */
	public static function get_job( int $job_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_jobs WHERE job_id = %d",
				$job_id
			)
		);
	}

	/**
	 * 種別ごとの最新ジョブを取得する
	 *
	 * @param string      $job_type ジョブ種別（TYPE_* 定数）。
	 * @param string|null $status   状態で絞る場合に指定（JOB_* 定数）。
	 * @return object|null
	 */
	public static function latest_job( string $job_type, ?string $status = null ) {
		global $wpdb;

		if ( null === $status ) {
			return $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}rgrl_jobs WHERE job_type = %s ORDER BY job_id DESC LIMIT 1",
					$job_type
				)
			);
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_jobs WHERE job_type = %s AND status = %s ORDER BY job_id DESC LIMIT 1",
				$job_type,
				$status
			)
		);
	}

	/**
	 * ジョブの進捗・状態を更新する
	 *
	 * @param int   $job_id ジョブID。
	 * @param array $fields 更新するカラム。totals は配列で渡す（JSON 化はここで行う）。
	 *                      許可外のキーは無視する。
	 * @return bool 1行更新できたか。
	 */
	public static function update_job( int $job_id, array $fields ): bool {
		global $wpdb;

		$allowed = array(
			'status'       => '%s',
			'finished_at'  => '%s',
			'items_total'  => '%d',
			'items_done'   => '%d',
			'last_item_id' => '%d',
			'totals'       => '%s',
		);

		if ( isset( $fields['totals'] ) && is_array( $fields['totals'] ) ) {
			$fields['totals'] = (string) wp_json_encode( $fields['totals'] );
		}

		$data    = array();
		$formats = array();

		foreach ( $allowed as $key => $format ) {
			if ( array_key_exists( $key, $fields ) ) {
				$data[ $key ] = $fields[ $key ];
				$formats[]    = $format;
			}
		}

		if ( empty( $data ) ) {
			return false;
		}

		$updated = $wpdb->update(
			$wpdb->prefix . 'rgrl_jobs',
			$data,
			array( 'job_id' => $job_id ),
			$formats,
			array( '%d' )
		);

		return 1 === $updated;
	}

	/**
	 * ジョブ行の totals（JSON）を配列に戻す
	 *
	 * @param object|null $job get_job() / latest_job() の戻り値。
	 * @return array 壊れている場合は空配列。
	 */
	public static function decode_totals( $job ): array {
		if ( ! $job || empty( $job->totals ) ) {
			return array();
		}

		$totals = json_decode( (string) $job->totals, true );

		return is_array( $totals ) ? $totals : array();
	}
}
