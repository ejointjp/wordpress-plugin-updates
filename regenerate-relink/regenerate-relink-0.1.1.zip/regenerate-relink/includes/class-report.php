<?php
/**
 * dry-run レポート（FR-6）
 *
 * スキャン（FR-4 の scan 側）と診断集計（FR-1）の保存済み結果から、
 * 実行前プレビュー（FR-6.1 / FR-6.2）と実行後の結果参照（FR-6.6）を
 * 1つのレポートに組み立てる。ここでは新たな走査・算出を行わない。
 *
 * 「プレビューした内容がそのまま適用される」（FR-6.3）の担保:
 *
 * - 更新ステージ: スキャンが算出・記録した new_url を Applier がそのまま
 *   適用する。加えて、レポートに表示したスキャンと適用対象のスキャンが
 *   ズレていないかを開始時に照合する（Applier::start の expected_scan_id）
 * - 生成ステージ: 診断（FR-1）と再生成（FR-3）が同一の判定関数を共有する
 *   ことに加えて、集計時点のサイズ定義フィンガープリントを開始時に照合する
 *   （Regenerator::start の expected_fingerprint）。ズレていたら実行せず
 *   再プレビューを促す（FR-6.4）
 *
 * - 削除ステージ: plan（Cleanup::start_plan）が算出して rgrl_quarantine に
 *   記録した候補を Cleanup::start_run がそのまま隔離する。レポートは
 *   その候補の集計を cleanup 区画として読むだけで、再算出しない
 *
 * CSV エクスポート（FR-6.7）は admin-post.php 経由のダウンロードで提供する。
 * 参照一覧（EXPORT_ACTION）と削除候補・隔離マニフェスト一覧
 * （EXPORT_CLEANUP_ACTION）の2種。行の整形（csv_headers / csv_row）は
 * WP-CLI のレポート出力（FR-8.4）からも使う前提で public にしてある。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * レポートの組み立てと CSV エクスポート
 */
class Report {

	/**
	 * CSV エクスポートの admin-post アクション名
	 */
	const EXPORT_ACTION = 'rgrl_export_report';

	/**
	 * 削除候補・隔離マニフェスト CSV の admin-post アクション名
	 */
	const EXPORT_CLEANUP_ACTION = 'rgrl_export_cleanup';

	/**
	 * CSV を1バッチで読む参照の行数
	 */
	const CSV_BATCH = 500;

	/**
	 * レポートを組み立てる
	 *
	 * @param int|null $scan_id 対象スキャン。null = 最新の完了スキャン。
	 * @return array scan / update / statuses / skips / generation / cleanup /
	 *               capacity / export_url。
	 */
	public static function build( ?int $scan_id = null ): array {
		$scan = null === $scan_id
			? Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE )
			: Reference_Graph::get_scan( $scan_id );

		$report = array(
			'scan'       => null,
			'update'     => null,
			'statuses'   => null,
			'skips'      => null,
			'generation' => self::generation_forecast(),
			'cleanup'    => null,
			'quarantine' => array(
				'usage'    => Quarantine::usage(),
				'settings' => Quarantine::settings(),
			),
			'capacity'   => null,
			'export_url' => '',
		);

		if ( $scan ) {
			$id = (int) $scan->scan_id;

			$report['scan'] = array(
				'scan_id'       => $id,
				'status'        => (string) $scan->status,
				'started_at'    => $scan->started_at,
				'finished_at'   => $scan->finished_at,
				'posts_total'   => (int) $scan->posts_total,
				'posts_scanned' => (int) $scan->posts_scanned,
			);

			$report['update']   = Reference_Graph::status_breakdown( $id, Reference_Graph::REF_UPDATE );
			$report['statuses'] = Reference_Graph::counts_by_status( $id );
			$report['skips']    = self::skip_details( $id );
			$report['cleanup']  = self::cleanup_forecast( $id );

			$report['export_url'] = add_query_arg(
				array(
					'action'   => self::EXPORT_ACTION,
					'scan_id'  => $id,
					'_wpnonce' => wp_create_nonce( self::EXPORT_ACTION . '_' . $id ),
				),
				admin_url( 'admin-post.php' )
			);
		}

		$est    = $report['generation'] ? $report['generation']['est_add_bytes'] : null;
		$remove = $report['cleanup'] ? $report['cleanup']['bytes'] : null;

		// FR-6.2: 生成の増加見込みと隔離候補の削減量から容量の差引を出す。
		// どちらも未算出なら差引も出せない
		$report['capacity'] = array(
			'add_est_bytes' => $est,
			'remove_bytes'  => $remove,
			'net_est_bytes' => ( null === $est && null === $remove )
				? null
				: (int) $est - (int) $remove,
		);

		return $report;
	}

	/**
	 * 削除ステージの見込みを plan の保存済み結果から組み立てる（FR-6.2）
	 *
	 * ここでは新たな走査を行わない。plan（Cleanup::start_plan）が
	 * rgrl_quarantine に記録した行の集計だけを読む。
	 *
	 * @param int $scan_id 表示中のスキャンID。
	 * @return array|null このスキャンに対する完了済み plan が無ければ null。
	 */
	private static function cleanup_forecast( int $scan_id ): ?array {
		$job = Jobs::latest_job( Jobs::TYPE_CLEANUP_PLAN, Jobs::JOB_COMPLETE );

		if ( ! $job ) {
			return null;
		}

		$totals = Cleanup::normalize_plan_totals( Jobs::decode_totals( $job ) );

		if ( $totals['scan_id'] !== $scan_id ) {
			// 別のスキャンを根拠にした古い plan は表示しない（FR-6.3）
			return null;
		}

		$breakdown  = Quarantine::breakdown( $scan_id );
		$candidates = $breakdown[ Quarantine::ST_CANDIDATE ] ?? array();

		$files = 0;
		$bytes = 0;

		foreach ( $candidates as $bucket ) {
			$files += $bucket['files'];
			$bytes += $bucket['bytes'];
		}

		// FR-7.5 の状態表示: 本文更新が済んでいない間は実行できない
		$pending = Reference_Graph::status_breakdown( $scan_id, Reference_Graph::REF_UPDATE );

		return array(
			'planned_at'      => $job->finished_at,
			'files'           => $files,
			'bytes'           => $bytes,
			'by_reason'       => $candidates,
			'reported'        => $breakdown[ Quarantine::ST_REPORT ] ?? array(),
			'scaled_files'    => $totals['scaled_files'],
			'scaled_bytes'    => $totals['scaled_bytes'],
			'pending_updates' => $pending['refs'],
			'export_url'      => add_query_arg(
				array(
					'action'   => self::EXPORT_CLEANUP_ACTION,
					'scan_id'  => $scan_id,
					'_wpnonce' => wp_create_nonce( self::EXPORT_CLEANUP_ACTION . '_' . $scan_id ),
				),
				admin_url( 'admin-post.php' )
			),
		);
	}

	/**
	 * 生成ステージの見込みを保存済み集計から組み立てる
	 *
	 * @return array|null 未集計なら null。
	 */
	private static function generation_forecast(): ?array {
		$stats = Size_Registry::get_cached_stats();

		if ( ! is_array( $stats ) || empty( $stats['generated_at'] ) ) {
			return null;
		}

		$missing = 0;
		$stale   = 0;
		$est     = 0;

		foreach ( $stats['sizes'] as $bucket ) {
			$missing += $bucket['missing'];
			$stale   += $bucket['stale'];
			$est     += $bucket['est_add_bytes'];
		}

		return array(
			'missing'       => $missing,
			'stale'         => $stale,
			'files'         => $missing + $stale,
			'est_add_bytes' => $est,
			'generated_at'  => (int) $stats['generated_at'],
			'fingerprint'   => (string) $stats['fingerprint'],
		);
	}

	/**
	 * スキップ内訳（理由別の件数・記事数・記事リンク数件）を組み立てる
	 *
	 * FR-6.2 の区分表に合わせ、apply が失敗として記録した行（status=failed）も
	 * 「失敗」区分としてここに含める。
	 *
	 * @param int $scan_id スキャンID。
	 * @return array<string, array{refs: int, posts: int, samples: array}>
	 */
	private static function skip_details( int $scan_id ): array {
		$skips = array();

		foreach ( Reference_Graph::skip_breakdown( $scan_id ) as $reason => $counts ) {
			$skips[ $reason ] = $counts + array(
				'samples' => self::format_posts(
					Reference_Graph::sample_post_ids( $scan_id, Reference_Graph::REF_SKIP, $reason )
				),
			);
		}

		$failed = Reference_Graph::status_breakdown( $scan_id, Reference_Graph::REF_FAILED );

		if ( $failed['refs'] > 0 ) {
			$skips[ Reference_Graph::SKIP_FAILED ] = $failed + array(
				'samples' => self::format_posts(
					Reference_Graph::sample_post_ids( $scan_id, Reference_Graph::REF_FAILED )
				),
			);
		}

		return $skips;
	}

	/**
	 * 記事IDの一覧を表示用（タイトル・編集リンク付き）へ整形する（FR-6.5）
	 *
	 * @param int[] $post_ids 記事ID。
	 * @return array<int, array{post_id: int, title: string, edit_url: string}>
	 */
	private static function format_posts( array $post_ids ): array {
		if ( empty( $post_ids ) ) {
			return array();
		}

		_prime_post_caches( $post_ids, false, false );

		$out = array();

		foreach ( $post_ids as $post_id ) {
			$edit_url = get_edit_post_link( $post_id, 'raw' );

			$out[] = array(
				'post_id'  => $post_id,
				'title'    => (string) get_the_title( $post_id ),
				'edit_url' => is_string( $edit_url ) ? $edit_url : '',
			);
		}

		return $out;
	}

	/**
	 * スキップ理由コードの表示ラベル（FR-6.2 の区分）
	 *
	 * src/lib/labels.js の skipLabels() と対で保守すること。
	 *
	 * @return array<string, string>
	 */
	public static function skip_reason_labels(): array {
		return array(
			Reference_Graph::SKIP_SIZE_UNKNOWN         => __( 'Size name unknown', 'regenerate-relink' ),
			Reference_Graph::SKIP_ATTACHMENT_MISSING   => __( 'Attachment missing', 'regenerate-relink' ),
			Reference_Graph::SKIP_NO_INTERMEDIATE      => __( 'Intermediate file missing', 'regenerate-relink' ),
			Reference_Graph::SKIP_FILENAME_MISMATCH    => __( 'Filename mismatch', 'regenerate-relink' ),
			Reference_Graph::SKIP_OUT_OF_SCOPE         => __( 'Out of scope', 'regenerate-relink' ),
			Reference_Graph::SKIP_BUILDER              => __( 'Page builder content', 'regenerate-relink' ),
			Reference_Graph::SKIP_POSTMETA             => __( 'Custom field reference', 'regenerate-relink' ),
			Reference_Graph::SKIP_PRECONDITION_CHANGED => __( 'Content changed after scan', 'regenerate-relink' ),
			Reference_Graph::SKIP_NO_CHANGE            => __( 'Already up to date', 'regenerate-relink' ),
			Reference_Graph::SKIP_FAILED               => __( 'Failed', 'regenerate-relink' ),
		);
	}

	/**
	 * 再生成のスキップ理由コードの表示ラベル（FR-3.6）
	 *
	 * src/lib/labels.js の regenSkipLabels() と対で保守すること。
	 *
	 * @return array<string, string>
	 */
	public static function regenerate_skip_labels(): array {
		return array(
			Regenerator::SKIP_TOO_SMALL        => __( 'Original image smaller than the size definition', 'regenerate-relink' ),
			Regenerator::SKIP_ORIGINAL_MISSING => __( 'Original image file missing', 'regenerate-relink' ),
		);
	}

	/**
	 * 参照状態コードの表示ラベル
	 *
	 * @return array<string, string>
	 */
	public static function status_labels(): array {
		return array(
			Reference_Graph::REF_FOUND   => __( 'Found', 'regenerate-relink' ),
			Reference_Graph::REF_UPDATE  => __( 'Will update', 'regenerate-relink' ),
			Reference_Graph::REF_SKIP    => __( 'Skipped', 'regenerate-relink' ),
			Reference_Graph::REF_APPLIED => __( 'Applied', 'regenerate-relink' ),
			Reference_Graph::REF_FAILED  => __( 'Failed', 'regenerate-relink' ),
		);
	}

	/**
	 * CSV エクスポートを処理する（FR-6.7）
	 *
	 * admin_post_{EXPORT_ACTION} フックから呼ばれる。権限と nonce を検証して
	 * スキャンの全参照を CSV でストリーム出力する。
	 */
	public static function handle_export(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to access this page.', 'regenerate-relink' ),
				'',
				array( 'response' => 403 )
			);
		}

		$scan_id = isset( $_GET['scan_id'] ) ? absint( $_GET['scan_id'] ) : 0;

		check_admin_referer( self::EXPORT_ACTION . '_' . $scan_id );

		$scan = $scan_id > 0 ? Reference_Graph::get_scan( $scan_id ) : null;

		if ( ! $scan ) {
			wp_die(
				esc_html__( 'The requested scan was not found.', 'regenerate-relink' ),
				'',
				array( 'response' => 404 )
			);
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="regenerate-relink-report-scan' . $scan_id . '.csv"' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Excel に UTF-8 と認識させる BOM。マークアップ文脈ではない。
		echo "\xEF\xBB\xBF";

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- 出力ストリームへの書き込み。WP_Filesystem の対象外。
		$output = fopen( 'php://output', 'w' );

		self::write_csv( $output, $scan_id );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- 上と同じ。
		fclose( $output );
		exit;
	}

	/**
	 * スキャンの全参照を CSV としてストリームへ書き出す
	 *
	 * @param resource $stream  書き込み先。
	 * @param int      $scan_id スキャンID。
	 */
	public static function write_csv( $stream, int $scan_id ): void {
		self::put_csv( $stream, self::csv_headers() );

		$after = 0;

		for ( ;; ) {
			$refs = Reference_Graph::refs_batch( $scan_id, $after, self::CSV_BATCH );

			if ( empty( $refs ) ) {
				break;
			}

			self::prime_caches( $refs );

			foreach ( $refs as $ref ) {
				self::put_csv( $stream, self::csv_row( $ref ) );
				$after = (int) $ref->ref_id;
			}
		}
	}

	/**
	 * 参照1行の列キーを返す（WP-CLI の一覧出力用。FR-8.4）
	 *
	 * csv_headers() が翻訳済みの見出しを返すのに対し、こちらは翻訳しない
	 * 安定した列名を返す。**csv_headers() / csv_row() と同じ並びを保つこと。**
	 *
	 * @return string[]
	 */
	public static function csv_field_keys(): array {
		return array(
			'ref_id',
			'post_id',
			'post_title',
			'post_edit_url',
			'route',
			'position',
			'attachment_id',
			'attachment_title',
			'size_name',
			'status',
			'status_label',
			'skip_reason',
			'skip_reason_label',
			'url',
			'new_url',
			'details',
		);
	}

	/**
	 * CSV のヘッダ行を返す
	 *
	 * csv_field_keys() / csv_row() と並びをそろえること。
	 *
	 * @return string[]
	 */
	public static function csv_headers(): array {
		return array(
			__( 'Reference ID', 'regenerate-relink' ),
			__( 'Post ID', 'regenerate-relink' ),
			__( 'Post title', 'regenerate-relink' ),
			__( 'Post edit URL', 'regenerate-relink' ),
			__( 'Route', 'regenerate-relink' ),
			__( 'Position', 'regenerate-relink' ),
			__( 'Attachment ID', 'regenerate-relink' ),
			__( 'Attachment title', 'regenerate-relink' ),
			__( 'Size name', 'regenerate-relink' ),
			__( 'Status', 'regenerate-relink' ),
			__( 'Status label', 'regenerate-relink' ),
			__( 'Skip reason', 'regenerate-relink' ),
			__( 'Skip reason label', 'regenerate-relink' ),
			__( 'Current URL', 'regenerate-relink' ),
			__( 'New URL', 'regenerate-relink' ),
			__( 'Details', 'regenerate-relink' ),
		);
	}

	/**
	 * 参照1行を CSV の1行へ整形する
	 *
	 * 状態・理由はコード（安定した語彙）とラベル（翻訳済み）の両方を出す。
	 * 該当記事・添付への編集リンクを含める（FR-6.5）。
	 *
	 * @param object $ref rgrl_refs の1行。
	 * @return array
	 */
	public static function csv_row( $ref ): array {
		$status_labels = self::status_labels();
		$skip_labels   = self::skip_reason_labels();

		$details = json_decode( (string) $ref->details, true );
		$details = is_array( $details ) ? $details : array();

		// 手作業の手がかりになる付帯情報だけを1列に集約する
		$note = (string) ( $details['message'] ?? '' );

		if ( '' === $note && isset( $details['builder'] ) ) {
			$note = (string) $details['builder'];
		}

		if ( '' === $note && isset( $details['meta_key'] ) ) {
			$note = (string) $details['meta_key'];
		}

		$post_id       = (int) $ref->post_id;
		$attachment_id = (int) $ref->attachment_id;

		$post_edit = $post_id > 0 ? get_edit_post_link( $post_id, 'raw' ) : '';

		return array(
			(int) $ref->ref_id,
			$post_id,
			self::csv_text( $post_id > 0 ? (string) get_the_title( $post_id ) : '' ),
			is_string( $post_edit ) ? $post_edit : '',
			(string) $ref->route,
			self::csv_text( (string) $ref->position ),
			$attachment_id,
			self::csv_text( $attachment_id > 0 ? (string) get_the_title( $attachment_id ) : '' ),
			(string) $ref->size_name,
			(string) $ref->status,
			(string) ( $status_labels[ $ref->status ] ?? $ref->status ),
			(string) $ref->skip_reason,
			'' === (string) $ref->skip_reason ? '' : (string) ( $skip_labels[ $ref->skip_reason ] ?? $ref->skip_reason ),
			self::csv_text( (string) $ref->url ),
			self::csv_text( (string) $ref->new_url ),
			self::csv_text( $note ),
		);
	}

	/**
	 * 隔離行の状態コードの表示ラベル
	 *
	 * CSV エクスポート専用。管理画面（JS）側に対応するラベル表はない。
	 *
	 * @return array<string, string>
	 */
	public static function cleanup_status_labels(): array {
		return array(
			Quarantine::ST_CANDIDATE   => __( 'Will quarantine', 'regenerate-relink' ),
			Quarantine::ST_REPORT      => __( 'Report only', 'regenerate-relink' ),
			Quarantine::ST_QUARANTINED => __( 'Quarantined', 'regenerate-relink' ),
			Quarantine::ST_RESTORED    => __( 'Restored', 'regenerate-relink' ),
			Quarantine::ST_PURGED      => __( 'Deleted permanently', 'regenerate-relink' ),
			Quarantine::ST_SKIPPED     => __( 'Skipped', 'regenerate-relink' ),
		);
	}

	/**
	 * 隔離行の理由コードの表示ラベル
	 *
	 * src/lib/labels.js の cleanupReasonLabels() と対で保守すること。
	 *
	 * @return array<string, string>
	 */
	public static function cleanup_reason_labels(): array {
		return array(
			Quarantine::REASON_ORPHANED       => __( 'Not in current attachment data', 'regenerate-relink' ),
			Quarantine::REASON_DISABLED       => __( 'Size generation is turned off', 'regenerate-relink' ),
			Quarantine::REASON_SCALED         => __( 'Scaled copy (-scaled)', 'regenerate-relink' ),
			Quarantine::REASON_REFERENCED     => __( 'Still referenced in content', 'regenerate-relink' ),
			Quarantine::REASON_CLAIMED        => __( 'Used by another attachment', 'regenerate-relink' ),
			Quarantine::REASON_PRECONDITION   => __( 'Changed after the preview', 'regenerate-relink' ),
			Quarantine::REASON_FILE_MISSING   => __( 'File not found', 'regenerate-relink' ),
			Quarantine::REASON_PATH_INVALID   => __( 'Path failed validation', 'regenerate-relink' ),
			Quarantine::REASON_MOVE_FAILED    => __( 'Could not be moved', 'regenerate-relink' ),
			Quarantine::REASON_CONFLICT       => __( 'A file with the same name exists', 'regenerate-relink' ),
			Quarantine::REASON_RESTORE_FAILED => __( 'Could not be restored', 'regenerate-relink' ),
		);
	}

	/**
	 * 削除候補・隔離マニフェストの CSV エクスポートを処理する（FR-6.7）
	 *
	 * admin_post_{EXPORT_CLEANUP_ACTION} フックから呼ばれる。
	 */
	public static function handle_cleanup_export(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to access this page.', 'regenerate-relink' ),
				'',
				array( 'response' => 403 )
			);
		}

		$scan_id = isset( $_GET['scan_id'] ) ? absint( $_GET['scan_id'] ) : 0;

		check_admin_referer( self::EXPORT_CLEANUP_ACTION . '_' . $scan_id );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="regenerate-relink-cleanup-scan' . $scan_id . '.csv"' );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Excel に UTF-8 と認識させる BOM。マークアップ文脈ではない。
		echo "\xEF\xBB\xBF";

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- 出力ストリームへの書き込み。WP_Filesystem の対象外。
		$output = fopen( 'php://output', 'w' );

		self::write_cleanup_csv( $output, $scan_id );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- 上と同じ。
		fclose( $output );
		exit;
	}

	/**
	 * 削除候補・隔離マニフェストを CSV としてストリームへ書き出す
	 *
	 * @param resource $stream  書き込み先。
	 * @param int      $scan_id スキャンID。
	 */
	public static function write_cleanup_csv( $stream, int $scan_id ): void {
		self::put_csv( $stream, self::cleanup_csv_headers() );

		$after = 0;

		for ( ;; ) {
			$rows = Quarantine::export_batch( $scan_id, $after, self::CSV_BATCH );

			if ( empty( $rows ) ) {
				break;
			}

			$ids = array();

			foreach ( $rows as $row ) {
				if ( (int) $row->attachment_id > 0 ) {
					$ids[ (int) $row->attachment_id ] = true;
				}
			}

			if ( ! empty( $ids ) ) {
				_prime_post_caches( array_keys( $ids ), false, false );
			}

			foreach ( $rows as $row ) {
				self::put_csv( $stream, self::cleanup_csv_row( $row ) );
				$after = (int) $row->file_id;
			}
		}
	}

	/**
	 * 隔離行1件の列キーを返す（WP-CLI の一覧出力用。FR-8.4）
	 *
	 * **cleanup_csv_headers() / cleanup_csv_row() と同じ並びを保つこと。**
	 *
	 * @return string[]
	 */
	public static function cleanup_csv_field_keys(): array {
		return array(
			'file_id',
			'status',
			'status_label',
			'reason',
			'reason_label',
			'attachment_id',
			'attachment_title',
			'attachment_edit_url',
			'size_name',
			'file_path',
			'bytes',
			'quarantined_at',
			'details',
		);
	}

	/**
	 * 削除候補・隔離マニフェスト CSV のヘッダ行を返す
	 *
	 * cleanup_csv_field_keys() / cleanup_csv_row() と並びをそろえること。
	 *
	 * @return string[]
	 */
	public static function cleanup_csv_headers(): array {
		return array(
			__( 'File ID', 'regenerate-relink' ),
			__( 'Status', 'regenerate-relink' ),
			__( 'Status label', 'regenerate-relink' ),
			__( 'Reason', 'regenerate-relink' ),
			__( 'Reason label', 'regenerate-relink' ),
			__( 'Attachment ID', 'regenerate-relink' ),
			__( 'Attachment title', 'regenerate-relink' ),
			__( 'Attachment edit URL', 'regenerate-relink' ),
			__( 'Size name', 'regenerate-relink' ),
			__( 'File path', 'regenerate-relink' ),
			__( 'Bytes', 'regenerate-relink' ),
			__( 'Quarantined at', 'regenerate-relink' ),
			__( 'Details', 'regenerate-relink' ),
		);
	}

	/**
	 * 隔離行1件を CSV の1行へ整形する
	 *
	 * 該当添付への編集リンクを含める（FR-6.5）。
	 *
	 * @param object $row rgrl_quarantine の1行。
	 * @return array
	 */
	public static function cleanup_csv_row( $row ): array {
		$status_labels = self::cleanup_status_labels();
		$reason_labels = self::cleanup_reason_labels();

		$details = json_decode( (string) $row->details, true );
		$details = is_array( $details ) ? $details : array();

		$note = (string) ( $details['restore_error'] ?? '' );

		$attachment_id = (int) $row->attachment_id;
		$edit_url      = $attachment_id > 0 ? get_edit_post_link( $attachment_id, 'raw' ) : '';

		return array(
			(int) $row->file_id,
			(string) $row->status,
			(string) ( $status_labels[ $row->status ] ?? $row->status ),
			(string) $row->reason,
			'' === (string) $row->reason ? '' : (string) ( $reason_labels[ $row->reason ] ?? $row->reason ),
			$attachment_id,
			self::csv_text( $attachment_id > 0 ? (string) get_the_title( $attachment_id ) : '' ),
			is_string( $edit_url ) ? $edit_url : '',
			(string) $row->size_name,
			self::csv_text( (string) $row->rel_path ),
			(int) $row->bytes,
			(string) ( $row->quarantined_at ?? '' ),
			self::csv_text( $note ),
		);
	}

	/**
	 * CSV バッチ内の記事・添付情報をまとめてロードする（N+1 回避）
	 *
	 * @param object[] $refs rgrl_refs の行。
	 */
	private static function prime_caches( array $refs ): void {
		$ids = array();

		foreach ( $refs as $ref ) {
			if ( (int) $ref->post_id > 0 ) {
				$ids[ (int) $ref->post_id ] = true;
			}
			if ( (int) $ref->attachment_id > 0 ) {
				$ids[ (int) $ref->attachment_id ] = true;
			}
		}

		if ( ! empty( $ids ) ) {
			_prime_post_caches( array_keys( $ids ), false, false );
		}
	}

	/**
	 * 表計算ソフトが数式として解釈しうるセル値を無害化する
	 *
	 * 記事タイトル等のユーザー由来文字列が = + - @ で始まると、Excel 等が
	 * 数式として実行する（CSVインジェクション）。先頭にアポストロフィを
	 * 付けてテキスト扱いに固定する。
	 *
	 * @param string $value セル値。
	 */
	private static function csv_text( string $value ): string {
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}

	/**
	 * 1行を CSV として書き出す
	 *
	 * エスケープ文字は空文字を明示する（PHP 独自のバックスラッシュ
	 * エスケープを無効にした RFC 4180 準拠の出力。PHP 8.4 以降は
	 * 省略すると deprecation が出る）。
	 *
	 * @param resource $stream 書き込み先。
	 * @param array    $row    セル値の配列。
	 */
	private static function put_csv( $stream, array $row ): void {
		fputcsv( $stream, $row, ',', '"', '' );
	}
}
