<?php
/**
 * 起動処理
 *
 * サービスのフック登録をここで束ねる。個々のクラスは自分では
 * add_action しない（起動順を1箇所で見渡せるようにするため）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * プラグインの起動を束ねるクラス
 */
class Plugin {

	/**
	 * アクティベーション時の処理
	 */
	public static function activate(): void {
		Schema::activate();
		Quarantine::schedule_purge();
	}

	/**
	 * 停止時の処理
	 *
	 * cron イベントだけを解除する。設定・テーブル・隔離ファイルは
	 * 保持し（FR-2.2 と同じ方針）、削除はアンインストール時に行う。
	 */
	public static function deactivate(): void {
		Quarantine::unschedule_purge();
	}

	/**
	 * フックを登録する
	 */
	public static function boot(): void {
		// プラグイン更新時は activation フックが走らないため、版ズレをここで検出する。
		add_action( 'plugins_loaded', array( Schema::class, 'maybe_upgrade' ) );

		add_action( 'rest_api_init', array( Rest_Controller::class, 'register_routes' ) );

		// FR-2.1: 停止設定されたサイズはアップロード時に生成しない。
		// アップロードは REST / async-upload / WP-CLI からも来るため admin 判定の外に置く。
		add_filter( 'intermediate_image_sizes_advanced', array( Generation_Control::class, 'filter_intermediate_sizes' ) );

		// FR-2.3: 大画像の自動縮小（-scaled 生成）の無効化。ユーザーの明示設定を
		// 確実に効かせるため優先度を遅らせる（無効時は素通しなので他へ干渉しない）。
		add_filter( 'big_image_size_threshold', array( Generation_Control::class, 'filter_big_image_threshold' ), 100 );

		// FR-5.5: 隔離ファイルの保持期限切れを日次で片付ける
		add_action( Quarantine::PURGE_HOOK, array( Quarantine::class, 'purge_expired' ) );

		// 自己ホストの更新チェック。定期の更新チェックは wp-cron で動くため admin 判定の外に置く。
		add_filter( 'update_plugins_yuiami.jp', array( Update_Checker::class, 'filter_update' ), 10, 3 );
		add_filter( 'plugins_api', array( Update_Checker::class, 'filter_plugin_information' ), 10, 3 );

		// FR-8: WP-CLI。管理画面と同じロジックを呼ぶ薄い層（FR-8.2）
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'regenerate-relink', CLI::class );
		}

		if ( is_admin() ) {
			add_action( 'admin_menu', array( Admin_Page::class, 'add_menu' ) );
			add_action( 'admin_enqueue_scripts', array( Admin_Page::class, 'enqueue_assets' ) );

			// FR-6.7: dry-run レポートの CSV エクスポート（admin-post 経由のダウンロード）
			add_action( 'admin_post_' . Report::EXPORT_ACTION, array( Report::class, 'handle_export' ) );
			add_action( 'admin_post_' . Report::EXPORT_CLEANUP_ACTION, array( Report::class, 'handle_cleanup_export' ) );

			// プラグイン更新で activation を経ずに新機能が入った場合の穴埋め
			add_action( 'admin_init', array( Quarantine::class, 'schedule_purge' ) );
		}
	}
}
