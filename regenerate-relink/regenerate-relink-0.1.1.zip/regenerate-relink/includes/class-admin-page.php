<?php
/**
 * 管理画面（FR-7）
 *
 * ツール配下の単一ページ。画面の中身は React（src/）が描画し、ここは殻と
 * 初期状態（サイズ定義・設定・定義フィンガープリント・初期タブ）を出す
 * だけにとどめる。処理は REST（Rest_Controller）経由で行い、ここに処理を
 * 書かない（FR-8.2）。
 *
 * 初期状態を inline script で渡すのは、サイズ一覧の初期描画を REST の
 * 応答待ちにしないため（FR-1.4 / NFR-2.2）。統計は React 側が非同期に埋める。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 管理画面の描画とアセット読み込み
 */
class Admin_Page {

	const MENU_SLUG = 'regenerate-relink';

	/**
	 * タブ名の許可リスト（URL の ?tab=）
	 */
	const TABS = array( 'run', 'sizes', 'quarantine', 'settings' );

	/**
	 * 停止しても警告しないサイズ（FR-2.4）
	 */
	const NO_WARN_SIZES = array( 'thumbnail', 'medium', 'large' );

	/**
	 * add_management_page が返すフックサフィックス
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * ツールメニューに追加する
	 */
	public static function add_menu(): void {
		self::$hook_suffix = add_management_page(
			__( 'Regenerate & Relink', 'regenerate-relink' ),
			__( 'Regenerate & Relink', 'regenerate-relink' ),
			'manage_options',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * 画面の殻を描画する
	 *
	 * 中身は #rgrl-app に React がマウントする。
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'regenerate-relink' ) );
		}
		?>
		<div class="wrap rgrl-admin">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<div id="rgrl-app"></div>
			<noscript>
				<p><?php esc_html_e( 'Regenerate & Relink needs JavaScript. Enable it in your browser and reload this page.', 'regenerate-relink' ); ?></p>
			</noscript>
		</div>
		<?php
	}

	/**
	 * React に渡す初期状態を組み立てる
	 *
	 * @return array window.rgrlInitial の内容。
	 */
	public static function initial_state(): array {
		$disabled = Size_Registry::disabled_sizes();
		$sizes    = array();

		foreach ( Size_Registry::get_sizes() as $size ) {
			$sizes[] = array(
				'name'          => $size['name'],
				'width'         => (int) $size['width'],
				'height'        => (int) $size['height'],
				'crop'          => (bool) $size['crop'],
				'source'        => $size['source'],
				'enabled'       => ! in_array( $size['name'], $disabled, true ),
				'warnOnDisable' => ! in_array( $size['name'], self::NO_WARN_SIZES, true ),
			);
		}

		$quarantine = Quarantine::settings();

		return array(
			'tab'                    => self::current_tab(),
			'sizes'                  => $sizes,
			'definitionsFingerprint' => Size_Registry::definitions_fingerprint(),
			'settings'               => array(
				'thresholdDisabled' => Generation_Control::big_image_threshold_disabled(),
				'deleteScaled'      => (bool) $quarantine['delete_scaled'],
				'retentionDays'     => (int) $quarantine['retention_days'],
				'retentionOptions'  => self::retention_options( (int) $quarantine['retention_days'] ),
			),
		);
	}

	/**
	 * 保持期間の選択肢を返す（FR-5.5）
	 *
	 * 設定値が既定の選択肢にない場合（フィルタや CLI で変更された等）も
	 * 表示が現状を偽らないよう選択肢に足す。
	 *
	 * @param int $current 現在の保持日数。
	 * @return array { value: int, label: string } の配列。
	 */
	private static function retention_options( int $current ): array {
		$options = array(
			7  => __( '7 days', 'regenerate-relink' ),
			30 => __( '30 days', 'regenerate-relink' ),
			90 => __( '90 days', 'regenerate-relink' ),
			0  => __( 'Keep until manually deleted', 'regenerate-relink' ),
		);

		if ( ! isset( $options[ $current ] ) ) {
			$options[ $current ] = sprintf(
				/* translators: %s: 日数 */
				__( '%s days', 'regenerate-relink' ),
				number_format_i18n( $current )
			);
		}

		$list = array();

		foreach ( $options as $days => $label ) {
			$list[] = array(
				'value' => (int) $days,
				'label' => $label,
			);
		}

		return $list;
	}

	/**
	 * URL の ?tab= から初期タブを決める
	 *
	 * @return string 許可リストにある値。なければ run。
	 */
	private static function current_tab(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示するタブを選ぶだけの読み取り専用パラメータ。状態を変更しない。
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';

		return in_array( $tab, self::TABS, true ) ? $tab : 'run';
	}

	/**
	 * スクリプト・スタイルを読み込む
	 *
	 * 依存と版は build/admin.asset.php から受け取る。
	 * **ファイルがないときに黙って return しないこと**（ビルド漏れに気付けなくなる）。
	 *
	 * @param string $hook_suffix 現在の管理画面。
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( '' === self::$hook_suffix || self::$hook_suffix !== $hook_suffix ) {
			return;
		}

		$asset_file = RGRL_DIR . 'build/admin.asset.php';

		if ( ! file_exists( $asset_file ) ) {
			_doing_it_wrong(
				__METHOD__,
				'build/admin.asset.php が見つかりません。pnpm build を実行してください。',
				'0.1.0'
			);
			return;
		}

		$asset = require $asset_file;

		wp_enqueue_script(
			'regenerate-relink-admin',
			RGRL_URL . 'build/admin.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		wp_add_inline_script(
			'regenerate-relink-admin',
			'window.rgrlInitial = ' . wp_json_encode( self::initial_state(), JSON_HEX_TAG | JSON_HEX_AMP ) . ';',
			'before'
		);

		wp_set_script_translations(
			'regenerate-relink-admin',
			'regenerate-relink',
			RGRL_DIR . 'languages'
		);

		// @wordpress/components のスタイルはコアが登録済みだが、編集画面以外では
		// 自動で読み込まれないため明示する
		wp_enqueue_style( 'wp-components' );

		wp_enqueue_style(
			'regenerate-relink-admin',
			RGRL_URL . 'build/admin.css',
			array( 'wp-components' ),
			$asset['version']
		);
	}
}
