<?php
/**
 * 本文の参照更新（FR-4 の apply 側）
 *
 * スキャン（FR-4 の scan 側）が算出した更新対象（status=update）を、
 * 記録された new_url・寸法のまま本文へ適用する。適用時に再算出は
 * 一切行わない（FR-6.3）。スキャン後に本文が変わった記事は
 * content_hash の不一致で検出し、適用せず記録する（FR-6.4）。
 *
 * 書き換えは本文全体を WP_HTML_Tag_Processor で1パスし、src が
 * 更新対象 URL に一致する img の属性だけを変更する（NFR-1.2）。
 * parse_blocks → serialize_blocks の往復はしない: ブロックコメントは
 * タグ処理で素通しされ原文が保たれるため、属性 JSON の再エンコードで
 * 無関係な差分が出る余地を構造的に断つ。[caption] の width だけは
 * ショートコード構文（コアの正規表現）で属性を置換する（FR-4.7）。
 *
 * 保存は更新前リビジョンを明示確保（FR-4.10）し、post_modified を
 * 維持（FR-4.11）、kses を一時解除して自分が触っていない本文が
 * 変質しないようにする。処理は記事単位のバッチで、途中で切れても
 * ジョブのカーソルから再開できる（FR-7.7）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_HTML_Tag_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 参照更新の実行制御
 */
class Applier {

	/**
	 * 1バッチの実行時間の上限（秒）
	 */
	const TIME_BUDGET = 15;

	/**
	 * ジョブに記録する問題詳細の最大件数（カウンタは全件正確に保つ）
	 */
	const MAX_ISSUES = 100;

	/**
	 * 参照更新ジョブを開始する。進行中のものがあればそれを返す（再開）
	 *
	 * @param bool     $restart          true なら進行中のジョブを破棄して新規に始める。
	 * @param int|null $expected_scan_id プレビューに表示したスキャンID。指定時、適用対象
	 *                                   （最新の完了スキャン）と一致しなければ開始しない
	 *                                   （FR-6.3: プレビューした内容だけを適用する）。
	 *                                   null = 照合しない（CLI 等、独自に確認する経路用）。
	 * @return array 進捗形式。開始できない場合は error キーを持つ。
	 */
	public static function start( bool $restart = false, ?int $expected_scan_id = null ) {
		$running = Jobs::latest_job( Jobs::TYPE_APPLY, Jobs::JOB_RUNNING );

		if ( $running && ! $restart ) {
			return self::progress( $running, 0, false );
		}

		$scan = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );

		if ( ! $scan ) {
			return array( 'error' => 'no_scan' );
		}

		// 新規開始の前提チェック。restart 時も、破棄より先に検証する
		// （ズレていた場合に進行中ジョブへ副作用を残さない）
		if ( null !== $expected_scan_id && (int) $scan->scan_id !== $expected_scan_id ) {
			return array( 'error' => 'stale_preview' );
		}

		if ( $running ) {
			Jobs::update_job(
				(int) $running->job_id,
				array(
					'status'      => Jobs::JOB_ABORTED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}

		$scan_id = (int) $scan->scan_id;
		$totals  = self::normalize_totals( array( 'scan_id' => $scan_id ) );
		$total   = Reference_Graph::count_posts_with_updates( $scan_id );
		$job_id  = Jobs::create_job( Jobs::TYPE_APPLY, $total, $totals );

		return self::progress( Jobs::get_job( $job_id ), 0, false );
	}

	/**
	 * 参照更新を1バッチ進める
	 *
	 * @param int $job_id 対象ジョブ。running であること。
	 * @return array|null 進捗。null = ジョブが存在しないか running でない。
	 */
	public static function step( int $job_id ) {
		$job = Jobs::get_job( $job_id );

		if ( ! $job || Jobs::TYPE_APPLY !== $job->job_type || Jobs::JOB_RUNNING !== $job->status ) {
			return null;
		}

		$totals  = self::normalize_totals( Jobs::decode_totals( $job ) );
		$scan_id = (int) $totals['scan_id'];

		/**
		 * 1バッチで処理する記事数
		 *
		 * @param int $batch_size 既定 10。TIME_BUDGET 秒を超えた時点でも打ち切る。
		 */
		$batch_size = max( 1, (int) apply_filters( 'rgrl_apply_batch_size', 10 ) );

		$post_ids = Reference_Graph::posts_with_updates( $scan_id, (int) $job->last_item_id, $batch_size );

		if ( empty( $post_ids ) ) {
			Jobs::update_job(
				$job_id,
				array(
					'status'      => Jobs::JOB_COMPLETE,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);

			return self::progress( Jobs::get_job( $job_id ), 0, true );
		}

		$started   = microtime( true );
		$processed = 0;
		$last_id   = (int) $job->last_item_id;

		foreach ( $post_ids as $post_id ) {
			self::apply_post( $post_id, $scan_id, $totals );
			$last_id = $post_id;
			++$processed;

			// 記事単位で本文保存と参照の記録まで済ませているため、
			// どこで打ち切っても完了分は失われない（FR-7.7）
			if ( microtime( true ) - $started > self::TIME_BUDGET ) {
				break;
			}
		}

		Jobs::update_job(
			$job_id,
			array(
				'items_done'   => (int) $job->items_done + $processed,
				'last_item_id' => $last_id,
				'totals'       => $totals,
			)
		);

		$job = Jobs::get_job( $job_id );

		return self::progress( $job, $processed, false );
	}

	/**
	 * 記事1件へ参照更新を適用する
	 *
	 * CLI（FR-8.2）もこのメソッドを使う。ここに UI 依存を持ち込まないこと。
	 *
	 * @param int   $post_id 記事ID。
	 * @param int   $scan_id 対象スキャン。
	 * @param array $totals  累積カウンタ（参照渡し）。
	 */
	public static function apply_post( int $post_id, int $scan_id, array &$totals ): void {
		$refs = array();

		foreach ( Reference_Graph::refs_for_post( $scan_id, $post_id ) as $ref ) {
			if ( Reference_Graph::REF_UPDATE === $ref->status ) {
				$refs[] = $ref;
			}
		}

		if ( empty( $refs ) ) {
			return;
		}

		$post = get_post( $post_id );

		if ( ! $post ) {
			self::record_failure( $refs, $totals, __( 'The post no longer exists.', 'regenerate-relink' ) );
			return;
		}

		// FR-6.4: スキャン時と本文が変わっていたら適用せず記録する。
		// ハッシュが記録されていない行が混ざる場合も検証不能として同扱い（NFR-1.1）
		$content = (string) $post->post_content;

		if ( ! self::content_hash_matches( $refs, $content ) ) {
			self::record_skip( $refs, $totals, Reference_Graph::SKIP_PRECONDITION_CHANGED );
			self::add_issue(
				$totals,
				$post_id,
				__( 'The content changed after the scan. Run a new scan and apply again.', 'regenerate-relink' )
			);
			return;
		}

		// src → 適用内容のマップを作る。同一 URL に異なる new_url が算出されて
		// いる場合は判定が信用できないため、その URL の全行を適用しない（NFR-1.1）
		list( $map, $conflicted ) = self::build_url_map( $refs );

		if ( ! empty( $conflicted ) ) {
			self::record_failure( $conflicted, $totals, __( 'Conflicting update targets were calculated for the same source URL.', 'regenerate-relink' ) );
			self::add_issue(
				$totals,
				$post_id,
				__( 'Conflicting update targets were calculated for the same source URL.', 'regenerate-relink' )
			);
		}

		// 適用先ファイルの実在を確認する（再算出ではなく安全確認。
		// スキャン後に再生成のやり直し等でファイルが消えた場合に備える）
		$map = self::drop_missing_targets( $map, $totals, $post_id );

		if ( empty( $map ) ) {
			return;
		}

		// [caption] の width をショートコード構文で更新する（FR-4.7）
		$new_content = self::update_caption_widths( $content, $map );

		// img の src / width / height を差し替え、固定 srcset / sizes を
		// 除去する（FR-4.5 / FR-4.6）。対象外の img には一切触れない
		$new_content = self::update_img_tags( $new_content, $map );

		if ( $new_content === $content ) {
			// content_hash が一致していれば起こらないはずの防御的分岐
			self::record_failure( self::map_refs( $map ), $totals, __( 'The reference was not found in the content.', 'regenerate-relink' ) );
			self::add_issue(
				$totals,
				$post_id,
				__( 'The reference was not found in the content.', 'regenerate-relink' )
			);
			return;
		}

		$saved = self::save_content( $post, $new_content );

		if ( is_wp_error( $saved ) ) {
			self::record_failure( self::map_refs( $map ), $totals, $saved->get_error_message() );
			self::add_issue( $totals, $post_id, $saved->get_error_message() );
			return;
		}

		$applied_refs = self::map_refs( $map );
		Reference_Graph::update_refs_status(
			array_map(
				static function ( $ref ) {
					return (int) $ref->ref_id;
				},
				$applied_refs
			),
			Reference_Graph::REF_APPLIED
		);

		$totals['applied'] += count( $applied_refs );
		++$totals['posts_updated'];
	}

	/**
	 * 全行の content_hash が現在の本文と一致するか（FR-6.4）
	 *
	 * @param object[] $refs    update 行。
	 * @param string   $content 現在の本文。
	 */
	private static function content_hash_matches( array $refs, string $content ): bool {
		$hash = md5( $content );

		foreach ( $refs as $ref ) {
			$details = json_decode( (string) $ref->details, true );

			if ( ! is_array( $details ) || ( $details['content_hash'] ?? '' ) !== $hash ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * src URL → 適用内容のマップを組み立てる
	 *
	 * @param object[] $refs update 行。
	 * @return array{0: array, 1: object[]} マップと、衝突していた行。
	 */
	private static function build_url_map( array $refs ): array {
		$map        = array();
		$conflicted = array();

		foreach ( $refs as $ref ) {
			$url     = (string) $ref->url;
			$new_url = (string) $ref->new_url;

			if ( '' === $url || '' === $new_url ) {
				continue;
			}

			if ( isset( $map[ $url ] ) && $map[ $url ]['new_url'] !== $new_url ) {
				$map[ $url ]['conflict'] = true;
				continue;
			}

			if ( ! isset( $map[ $url ] ) ) {
				$details = json_decode( (string) $ref->details, true );
				$details = is_array( $details ) ? $details : array();

				$map[ $url ] = array(
					'new_url'       => $new_url,
					'new_width'     => (int) ( $details['new_width'] ?? 0 ),
					'new_height'    => (int) ( $details['new_height'] ?? 0 ),
					'caption_width' => isset( $details['caption_width'] ) ? (int) $details['caption_width'] : null,
					'old_dims'      => self::filename_dimensions( $url ),
					'attachment_id' => (int) $ref->attachment_id,
					'conflict'      => false,
					'refs'          => array(),
				);
			}

			$map[ $url ]['refs'][] = $ref;

			// caption_width は route=caption の行にのみ入る。同一 URL の
			// 別行（本文中の他の場所）から補完されても正しい値になる
			if ( null === $map[ $url ]['caption_width'] ) {
				$details = json_decode( (string) $ref->details, true );

				if ( is_array( $details ) && isset( $details['caption_width'] ) ) {
					$map[ $url ]['caption_width'] = (int) $details['caption_width'];
				}
			}
		}

		foreach ( $map as $url => $entry ) {
			if ( $entry['conflict'] ) {
				$conflicted = array_merge( $conflicted, $entry['refs'] );
				unset( $map[ $url ] );
			}
		}

		return array( $map, $conflicted );
	}

	/**
	 * 適用先ファイルが実在しない URL をマップから外し、failed として記録する
	 *
	 * @param array $map     build_url_map のマップ。
	 * @param array $totals  累積カウンタ（参照渡し）。
	 * @param int   $post_id 記事ID（issue 記録用）。
	 * @return array 実在確認済みのマップ。
	 */
	private static function drop_missing_targets( array $map, array &$totals, int $post_id ): array {
		foreach ( $map as $url => $entry ) {
			$file = get_attached_file( $entry['attachment_id'] );

			if ( ! is_string( $file ) || '' === $file ) {
				continue;
			}

			$new_name = rawurldecode( self::url_basename( $entry['new_url'] ) );
			$path     = dirname( $file ) . '/' . $new_name;

			if ( ! is_file( $path ) ) {
				self::record_failure( $entry['refs'], $totals, __( 'The target file no longer exists. Regenerate thumbnails and scan again.', 'regenerate-relink' ) );
				self::add_issue(
					$totals,
					$post_id,
					sprintf(
						/* translators: %s: ファイル名 */
						__( 'The target file “%s” no longer exists. Regenerate thumbnails and scan again.', 'regenerate-relink' ),
						$new_name
					)
				);
				unset( $map[ $url ] );
			}
		}

		return $map;
	}

	/**
	 * [caption] ショートコードの width 属性を更新する（FR-4.7）
	 *
	 * ショートコード構文の解析にはコアの正規表現を用いる（HTML の解析では
	 * ない）。対象は、コンテンツ内の img の src が更新対象 URL に一致し、
	 * スキャンが caption_width を記録している caption のみ。属性部分の
	 * width=数値 だけを置換し、それ以外は原文のまま返す。
	 *
	 * @param string $content 本文。
	 * @param array  $map     build_url_map のマップ。
	 */
	private static function update_caption_widths( string $content, array $map ): string {
		if ( false === strpos( $content, '[caption' ) ) {
			return $content;
		}

		$pattern = get_shortcode_regex( array( 'caption' ) );

		$result = preg_replace_callback(
			'/' . $pattern . '/',
			static function ( $m ) use ( $map ) {
				// [[caption]] はエスケープ表記（コアの仕様）。触らない
				if ( '[' === $m[1] && ']' === $m[6] ) {
					return $m[0];
				}

				$entry = null;

				foreach ( Html_Img_Scanner::scan( $m[5] ) as $img ) {
					if ( isset( $map[ $img['url'] ] ) ) {
						$entry = $map[ $img['url'] ];
						break;
					}
				}

				if ( null === $entry || null === $entry['caption_width'] || $entry['new_width'] < 1 ) {
					return $m[0];
				}

				$new_attrs = preg_replace(
					'/(\bwidth=)(["\']?)\d+\2/',
					'${1}${2}' . $entry['new_width'] . '${2}',
					$m[3],
					1
				);

				if ( ! is_string( $new_attrs ) || $new_attrs === $m[3] ) {
					return $m[0];
				}

				// 開始タグ内の属性部分（最初の出現）だけを差し替える
				$pos = strpos( $m[0], $m[3] );

				return false === $pos ? $m[0] : substr_replace( $m[0], $new_attrs, $pos, strlen( $m[3] ) );
			},
			$content
		);

		return is_string( $result ) ? $result : $content;
	}

	/**
	 * img タグの src / width / height / srcset / sizes を更新する
	 *
	 * WP_HTML_Tag_Processor による属性単位の書き換えのため、記述順・
	 * 大文字小文字・自己終了の差異に依存しない（NFR-1.2）。ブロック
	 * コメントを含むタグ以外の本文は一切変更されない。
	 *
	 * width / height は、現在の属性値が参照ファイル名の寸法と一致する
	 * 場合（= サイズの自然寸法）のみ新寸法へ更新する。ユーザーが手動で
	 * 指定した表示幅は変更しない（FR-4.5 の安全側解釈）。
	 *
	 * 本文に固定の srcset / sizes が書かれている場合は除去する。
	 * WordPress が描画時に再生成するため（FR-4.6）。
	 *
	 * @param string $content 本文。
	 * @param array  $map     build_url_map のマップ。
	 */
	private static function update_img_tags( string $content, array $map ): string {
		$processor = new WP_HTML_Tag_Processor( $content );

		while ( $processor->next_tag( 'img' ) ) {
			$src = (string) $processor->get_attribute( 'src' );

			if ( ! isset( $map[ $src ] ) ) {
				continue;
			}

			$entry = $map[ $src ];

			$processor->set_attribute( 'src', $entry['new_url'] );

			$width  = $processor->get_attribute( 'width' );
			$height = $processor->get_attribute( 'height' );

			if (
				null !== $entry['old_dims']
				&& $entry['new_width'] > 0 && $entry['new_height'] > 0
				&& is_string( $width ) && (int) $width === $entry['old_dims'][0]
				&& is_string( $height ) && (int) $height === $entry['old_dims'][1]
			) {
				$processor->set_attribute( 'width', (string) $entry['new_width'] );
				$processor->set_attribute( 'height', (string) $entry['new_height'] );
			}

			$processor->remove_attribute( 'srcset' );
			$processor->remove_attribute( 'sizes' );
		}

		return $processor->get_updated_html();
	}

	/**
	 * 本文を保存する
	 *
	 * 更新前の状態をリビジョンとして明示確保する（FR-4.10。直近リビジョンと
	 * 同一内容なら重複は作られない）。post_modified は維持する（FR-4.11。
	 * コアは更新時に現在時刻で上書きするため、wp_insert_post_data フィルタで
	 * 保存直前に差し戻す）。kses を一時解除し、自分が触っていない本文
	 * （unfiltered_html の無い環境での iframe 等）が保存で変質しないようにする。
	 *
	 * @param \WP_Post $post        記事。
	 * @param string   $new_content 新しい本文。
	 * @return true|\WP_Error
	 */
	private static function save_content( $post, string $new_content ) {
		wp_save_post_revision( $post->ID );

		$keep_modified = static function ( $data ) use ( $post ) {
			$data['post_modified']     = $post->post_modified;
			$data['post_modified_gmt'] = $post->post_modified_gmt;

			return $data;
		};

		kses_remove_filters();
		add_filter( 'wp_insert_post_data', $keep_modified );

		$result = wp_update_post(
			wp_slash(
				array(
					'ID'           => $post->ID,
					'post_content' => $new_content,
				)
			),
			true
		);

		remove_filter( 'wp_insert_post_data', $keep_modified );
		// 権限に応じた標準状態へ戻す
		kses_init();

		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * マップに残っている全行を平坦化して返す
	 *
	 * @param array $map build_url_map のマップ。
	 * @return object[]
	 */
	private static function map_refs( array $map ): array {
		$refs = array();

		foreach ( $map as $entry ) {
			$refs = array_merge( $refs, $entry['refs'] );
		}

		return $refs;
	}

	/**
	 * 行をスキップとして記録する
	 *
	 * @param object[] $refs   対象行。
	 * @param array    $totals 累積カウンタ（参照渡し）。
	 * @param string   $reason スキップ理由。
	 */
	private static function record_skip( array $refs, array &$totals, string $reason ): void {
		Reference_Graph::update_refs_status(
			array_map(
				static function ( $ref ) {
					return (int) $ref->ref_id;
				},
				$refs
			),
			Reference_Graph::REF_SKIP,
			$reason
		);

		$totals['skipped'][ $reason ] = ( $totals['skipped'][ $reason ] ?? 0 ) + count( $refs );
	}

	/**
	 * 行を失敗として記録する
	 *
	 * @param object[] $refs    対象行。
	 * @param array    $totals  累積カウンタ（参照渡し）。
	 * @param string   $message 失敗理由。
	 */
	private static function record_failure( array $refs, array &$totals, string $message ): void {
		foreach ( $refs as $ref ) {
			Reference_Graph::merge_ref_details( (int) $ref->ref_id, array( 'message' => $message ) );
		}

		Reference_Graph::update_refs_status(
			array_map(
				static function ( $ref ) {
					return (int) $ref->ref_id;
				},
				$refs
			),
			Reference_Graph::REF_FAILED
		);

		$totals['failed'] += count( $refs );
	}

	/**
	 * 問題詳細を記録する（FR-6.5: 記事へのリンク付き）
	 *
	 * @param array  $totals  累積カウンタ（参照渡し）。
	 * @param int    $post_id 記事ID。
	 * @param string $message 内容。
	 */
	private static function add_issue( array &$totals, int $post_id, string $message ): void {
		if ( count( $totals['issues'] ) >= self::MAX_ISSUES ) {
			return;
		}

		$totals['issues'][] = array(
			'post_id'  => $post_id,
			'title'    => get_the_title( $post_id ),
			'edit_url' => (string) get_edit_post_link( $post_id, 'raw' ),
			'message'  => $message,
		);
	}

	/**
	 * URL 末尾のファイル名部分を返す
	 *
	 * @param string $url URL。
	 */
	private static function url_basename( string $url ): string {
		foreach ( array( '#', '?' ) as $sep ) {
			$pos = strpos( $url, $sep );

			if ( false !== $pos ) {
				$url = substr( $url, 0, $pos );
			}
		}

		$pos = strrpos( $url, '/' );

		return false === $pos ? $url : substr( $url, $pos + 1 );
	}

	/**
	 * 参照 URL のファイル名から中間サイズの寸法を取り出す
	 *
	 * @param string $url 参照 URL。
	 * @return array{0: int, 1: int}|null 幅と高さ。命名規則に一致しなければ null。
	 */
	private static function filename_dimensions( string $url ) {
		$name = rawurldecode( self::url_basename( $url ) );

		if ( preg_match( '/-(\d+)x(\d+)\.[a-z0-9]+$/i', $name, $m ) ) {
			return array( (int) $m[1], (int) $m[2] );
		}

		return null;
	}

	/**
	 * 進捗レスポンスを組み立てる
	 *
	 * @param object|null $job       ジョブ行。
	 * @param int         $processed このバッチで処理した記事数。
	 * @param bool        $done      完了したか。
	 */
	private static function progress( $job, int $processed, bool $done ): array {
		if ( ! $job ) {
			return array( 'error' => 'job_missing' );
		}

		return array(
			'job_id'      => (int) $job->job_id,
			'posts_total' => (int) $job->items_total,
			'posts_done'  => (int) $job->items_done,
			'processed'   => $processed,
			'done'        => $done || Jobs::JOB_COMPLETE === $job->status,
			'totals'      => self::normalize_totals( Jobs::decode_totals( $job ) ),
		);
	}

	/**
	 * 累積カウンタを正規の構造に丸める
	 *
	 * @param mixed $totals 入力。
	 * @return array 正規化済みの累積カウンタ。
	 */
	public static function normalize_totals( $totals ): array {
		$out = array(
			'scan_id'       => 0,
			'applied'       => 0,
			'posts_updated' => 0,
			'failed'        => 0,
			'skipped'       => array(),
			'issues'        => array(),
		);

		if ( ! is_array( $totals ) ) {
			return $out;
		}

		$out['scan_id']       = absint( $totals['scan_id'] ?? 0 );
		$out['applied']       = absint( $totals['applied'] ?? 0 );
		$out['posts_updated'] = absint( $totals['posts_updated'] ?? 0 );
		$out['failed']        = absint( $totals['failed'] ?? 0 );

		$skipped = isset( $totals['skipped'] ) && is_array( $totals['skipped'] ) ? $totals['skipped'] : array();
		foreach ( $skipped as $reason => $count ) {
			$out['skipped'][ sanitize_text_field( (string) $reason ) ] = absint( $count );
		}

		$issues = isset( $totals['issues'] ) && is_array( $totals['issues'] ) ? $totals['issues'] : array();
		foreach ( array_slice( $issues, 0, self::MAX_ISSUES ) as $issue ) {
			if ( ! is_array( $issue ) ) {
				continue;
			}

			$out['issues'][] = array(
				'post_id'  => absint( $issue['post_id'] ?? 0 ),
				'title'    => sanitize_text_field( (string) ( $issue['title'] ?? '' ) ),
				'edit_url' => esc_url_raw( (string) ( $issue['edit_url'] ?? '' ) ),
				'message'  => sanitize_text_field( (string) ( $issue['message'] ?? '' ) ),
			);
		}

		return $out;
	}
}
