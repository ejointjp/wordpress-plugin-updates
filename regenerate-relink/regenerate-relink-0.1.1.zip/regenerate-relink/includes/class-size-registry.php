<?php
/**
 * サイズ一覧と診断（FR-1）
 *
 * 現在のサイズ定義（wp_get_registered_image_subsizes）と、各添付の
 * _wp_attachment_metadata に記録された実寸法を突き合わせて診断する。
 *
 * 集計は添付IDをカーソルにしたバッチ方式（FR-1.4）。1リクエストで
 * 全添付を走査せず、クライアントが完了までバッチを繰り返し呼ぶ。
 * 累積値はクライアントが持ち回り、完了時にオプションへ保存する。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * サイズ定義の取得と診断集計
 */
class Size_Registry {

	const STATS_OPTION = 'rgrl_size_stats';

	const DISABLED_OPTION = 'rgrl_disabled_sizes';

	/**
	 * コア由来のサイズ名（FR-1.5 のソース表示用）
	 *
	 * @var string[]
	 */
	const CORE_SIZES = array( 'thumbnail', 'medium', 'medium_large', 'large', '1536x1536', '2048x2048' );

	/**
	 * 登録されている全サイズの定義を返す（FR-1.1 / FR-1.5）
	 *
	 * @return array<string, array> name => { name, width, height, crop, source }。
	 */
	public static function get_sizes(): array {
		$sizes = array();

		foreach ( wp_get_registered_image_subsizes() as $name => $def ) {
			$sizes[ $name ] = array(
				'name'   => $name,
				'width'  => (int) $def['width'],
				'height' => (int) $def['height'],
				'crop'   => ! empty( $def['crop'] ),
				'source' => in_array( $name, self::CORE_SIZES, true ) ? 'core' : 'custom',
			);
		}

		return $sizes;
	}

	/**
	 * 生成を停止しているサイズ名の一覧を返す（FR-2.1 / FR-3.2）
	 *
	 * 設定の書き込み UI とアップロード時の生成停止は FR-2 で実装する。
	 * 再生成（FR-3.2）はここに載っているサイズを生成しない。
	 *
	 * @return string[]
	 */
	public static function disabled_sizes(): array {
		$disabled = get_option( self::DISABLED_OPTION, array() );

		if ( ! is_array( $disabled ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'strval', $disabled ) ) );
	}

	/**
	 * サイズ定義と停止設定のフィンガープリントを返す（FR-6.3 / FR-6.4）
	 *
	 * 診断集計（= 生成ステージのプレビュー）の完了時に保存し、再生成の開始時に
	 * 現在値と照合する。一致しない場合、プレビューに表示した内容と異なる生成が
	 * 起きるため、実行せず再プレビューを促す。
	 *
	 * @return string
	 */
	public static function definitions_fingerprint(): string {
		$disabled = self::disabled_sizes();
		sort( $disabled );

		return md5( (string) wp_json_encode( array( wp_get_registered_image_subsizes(), $disabled ) ) );
	}

	/**
	 * 画像添付の総数を返す（進捗表示の分母）
	 */
	public static function count_image_attachments(): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- COUNT のみの軽量クエリ。WP_Query を通す利点が無い。
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts}
				WHERE post_type = 'attachment' AND post_mime_type LIKE %s",
				$wpdb->esc_like( 'image/' ) . '%'
			)
		);
	}

	/**
	 * 診断集計を1バッチ進める（FR-1.2 / FR-1.3 / FR-1.4）
	 *
	 * サイズごとに次を数える。
	 *
	 * - files:   生成済みファイル数
	 * - bytes:   合計容量（metadata の filesize が無い古い添付はファイル stat）
	 * - stale:   要再生成。記録された実寸法が、現在の定義から算出した期待寸法と不一致
	 * - missing: 生成可能なのに未生成
	 * - excess:  生成不要（原画が定義より小さい等）なのにファイルが存在する
	 * - est_add_bytes: missing / stale を生成した場合の増加容量の推定（FR-6.2）。
	 *   その添付の既存ファイルの実測 bytes/px × 期待画素数で見積もる
	 *
	 * 期待寸法は image_resize_dimensions() を生成元（原画）の寸法に適用して
	 * 求める。WordPress 本体が生成時に使う計算・入力と同一のため、
	 * 「いま再生成したらどうなるか」と診断が一致する。
	 *
	 * @param int   $cursor     前バッチ最後の添付ID。初回は 0。
	 * @param array $totals     前バッチまでの累積値。初回は空配列。
	 * @param int   $batch_size 1バッチの添付数。
	 * @return array { cursor, done, processed, totals }。
	 */
	public static function aggregate_batch( int $cursor, array $totals, int $batch_size = 500 ): array {
		global $wpdb;

		$totals   = self::normalize_totals( $totals );
		$sizes    = wp_get_registered_image_subsizes();
		$disabled = self::disabled_sizes();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- カーソル式ページングのため ID 直接取得が必要。WP_Query の OFFSET ページングは大規模サイトで劣化する。
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment' AND post_mime_type LIKE %s AND ID > %d
				ORDER BY ID LIMIT %d",
				$wpdb->esc_like( 'image/' ) . '%',
				$cursor,
				$batch_size
			)
		);

		if ( empty( $ids ) ) {
			update_option(
				self::STATS_OPTION,
				array_merge(
					$totals,
					array(
						'generated_at' => time(),
						// この集計をプレビューとして再生成を実行してよいかの照合値（FR-6.3）
						'fingerprint'  => self::definitions_fingerprint(),
					)
				),
				false
			);

			return array(
				'cursor'    => $cursor,
				'done'      => true,
				'processed' => 0,
				'totals'    => $totals,
			);
		}

		$ids = array_map( 'intval', $ids );
		update_meta_cache( 'post', $ids );

		$upload_dir = wp_get_upload_dir();
		$basedir    = trailingslashit( $upload_dir['basedir'] );

		foreach ( $ids as $id ) {
			$cursor = $id;
			$meta   = wp_get_attachment_metadata( $id );

			if ( ! is_array( $meta ) || empty( $meta['width'] ) || empty( $meta['height'] ) || empty( $meta['file'] ) ) {
				// SVG 等、寸法を持たない画像添付は診断対象外
				++$totals['skipped'];
				continue;
			}

			++$totals['attachments'];

			$meta_sizes = isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ? $meta['sizes'] : array();
			$dir        = dirname( $meta['file'] );
			$dir_path   = $basedir . ( '.' === $dir ? '' : trailingslashit( $dir ) );

			list( $src_w, $src_h ) = self::source_dimensions( $id, $meta );

			// 増加容量の推定に使う bytes/px。必要になった添付だけ算出する
			$bpp = null;

			foreach ( $sizes as $name => $def ) {
				self::ensure_size_bucket( $totals['sizes'], $name );

				$has_file = isset( $meta_sizes[ $name ] ) && is_array( $meta_sizes[ $name ] );

				if ( $has_file ) {
					++$totals['sizes'][ $name ]['files'];
					$totals['sizes'][ $name ]['bytes'] += self::size_bytes( $meta_sizes[ $name ], $dir_path );
				}

				// 停止中のサイズ（FR-2.1）は生成対象でない。missing / stale に
				// 数えると再生成（FR-3.2 でスキップ）しても消えない表示になる
				// ため数えず、実在ファイルだけ excess（FR-5 の削除候補）へ回す。
				if ( in_array( $name, $disabled, true ) ) {
					if ( $has_file ) {
						++$totals['sizes'][ $name ]['excess'];
					}
					continue;
				}

				$expected = image_resize_dimensions(
					$src_w,
					$src_h,
					(int) $def['width'],
					(int) $def['height'],
					$def['crop']
				);

				if ( ! $expected ) {
					if ( $has_file ) {
						++$totals['sizes'][ $name ]['excess'];
					}
					continue;
				}

				if ( ! $has_file ) {
					++$totals['sizes'][ $name ]['missing'];

					$bpp = null === $bpp ? self::bytes_per_pixel( $meta, $meta_sizes, $basedir ) : $bpp;

					$totals['sizes'][ $name ]['est_add_bytes'] += (int) round( (int) $expected[4] * (int) $expected[5] * $bpp );
					continue;
				}

				$actual_w = (int) ( $meta_sizes[ $name ]['width'] ?? 0 );
				$actual_h = (int) ( $meta_sizes[ $name ]['height'] ?? 0 );

				if ( $actual_w !== (int) $expected[4] || $actual_h !== (int) $expected[5] ) {
					++$totals['sizes'][ $name ]['stale'];

					$bpp = null === $bpp ? self::bytes_per_pixel( $meta, $meta_sizes, $basedir ) : $bpp;

					// 旧ファイルは隔離（FR-5）まで残るため、増加分は新ファイルの容量
					$totals['sizes'][ $name ]['est_add_bytes'] += (int) round( (int) $expected[4] * (int) $expected[5] * $bpp );
				}
			}

			// 定義に無いサイズのファイル（テーマ変更等の残存）も容量把握のため数える
			foreach ( $meta_sizes as $name => $size_meta ) {
				if ( isset( $sizes[ $name ] ) || ! is_array( $size_meta ) ) {
					continue;
				}

				if ( ! isset( $totals['unregistered'][ $name ] ) ) {
					$totals['unregistered'][ $name ] = array(
						'files' => 0,
						'bytes' => 0,
					);
				}

				++$totals['unregistered'][ $name ]['files'];
				$totals['unregistered'][ $name ]['bytes'] += self::size_bytes( $size_meta, $dir_path );
			}
		}

		return array(
			'cursor'    => $cursor,
			'done'      => false,
			'processed' => count( $ids ),
			'totals'    => $totals,
		);
	}

	/**
	 * 生成元（リサイズ元）画像の寸法を返す
	 *
	 * 中間サイズの生成は常に原画から行う（FR-3.3）。-scaled / -rotated 添付では
	 * metadata の width / height は縮小・回転後の寸法であり、これを期待寸法の
	 * 計算に使うと、原画から生成した実寸法と丸めで 1px ズレることがある
	 * （例: 原画 3000×2000 の 2048x2048 は 2048×1365、-scaled 2560×1707 から
	 * 計算すると 2048×1366）。ズレたままだと「要再生成」が再生成しても
	 * 消えない添付が生まれるため、診断（FR-1.3）と再生成（FR-3.1）の両方が
	 * このメソッドの寸法を基準にする。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param array $meta          _wp_attachment_metadata の値。
	 * @return array{0: int, 1: int} 幅と高さ。原画が読めない場合は metadata の寸法。
	 */
	public static function source_dimensions( int $attachment_id, array $meta ): array {
		$width  = (int) ( $meta['width'] ?? 0 );
		$height = (int) ( $meta['height'] ?? 0 );

		if ( empty( $meta['original_image'] ) ) {
			return array( $width, $height );
		}

		$original = wp_get_original_image_path( $attachment_id );

		if ( ! is_string( $original ) || '' === $original || ! is_file( $original ) ) {
			// メディアオフロード等で原画がローカルに無い場合は metadata の寸法で近似する
			return array( $width, $height );
		}

		$dims = wp_getimagesize( $original );

		if ( ! is_array( $dims ) || empty( $dims[0] ) || empty( $dims[1] ) ) {
			return array( $width, $height );
		}

		$src_w = (int) $dims[0];
		$src_h = (int) $dims[1];

		// 生成時は EXIF の向きで先に回転してから作る（コアの _wp_make_subsizes と
		// 同じ）ため、90度系の向きなら回転後の寸法に入れ替える。適用条件
		// （JPEG かつ exif が使えること）も WP_Image_Editor::maybe_exif_rotate に合わせる。
		if ( 'image/jpeg' === ( $dims['mime'] ?? '' ) && is_callable( 'exif_read_data' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- コア（WP_Image_Editor::maybe_exif_rotate）と同じ読み方。壊れた EXIF は警告を出すが、失敗時は向き補正なしとして扱えばよい。
			$exif        = @exif_read_data( $original );
			$orientation = is_array( $exif ) ? (int) ( $exif['Orientation'] ?? 0 ) : 0;

			if ( in_array( $orientation, array( 5, 6, 7, 8 ), true ) ) {
				list( $src_w, $src_h ) = array( $src_h, $src_w );
			}
		}

		return array( $src_w, $src_h );
	}

	/**
	 * 添付1件の「1ピクセルあたりのバイト数」を推定する（FR-6.2 の増加容量見積もり）
	 *
	 * 同じ画像・同じ形式で圧縮された既存の中間サイズの実測が最も近い手がかり
	 * なので、metadata に filesize を持つ中間サイズの合計から求める。1つも
	 * 無ければ添付ファイル本体（-scaled ならその縮小版）で近似する。
	 * あくまで表示用の見積もりであり、生成要否の判定には使わないこと。
	 *
	 * @param array  $meta       _wp_attachment_metadata の値。
	 * @param array  $meta_sizes metadata の sizes。
	 * @param string $basedir    uploads ベースディレクトリ（末尾スラッシュ付き）。
	 * @return float 推定 bytes/px。手がかりが無ければ 0。
	 */
	private static function bytes_per_pixel( array $meta, array $meta_sizes, string $basedir ): float {
		$bytes  = 0;
		$pixels = 0;

		foreach ( $meta_sizes as $size_meta ) {
			if ( ! is_array( $size_meta ) || empty( $size_meta['filesize'] ) ) {
				continue;
			}

			$width  = (int) ( $size_meta['width'] ?? 0 );
			$height = (int) ( $size_meta['height'] ?? 0 );

			if ( $width > 0 && $height > 0 ) {
				$bytes  += (int) $size_meta['filesize'];
				$pixels += $width * $height;
			}
		}

		if ( 0 === $pixels ) {
			$width  = (int) ( $meta['width'] ?? 0 );
			$height = (int) ( $meta['height'] ?? 0 );
			$size   = (int) ( $meta['filesize'] ?? 0 );

			if ( $size < 1 && ! empty( $meta['file'] ) && is_string( $meta['file'] ) ) {
				$path = $basedir . $meta['file'];
				$size = is_file( $path ) ? (int) filesize( $path ) : 0;
			}

			if ( $width > 0 && $height > 0 && $size > 0 ) {
				$bytes  = $size;
				$pixels = $width * $height;
			}
		}

		return $pixels > 0 ? $bytes / $pixels : 0.0;
	}

	/**
	 * 保存済みの集計結果を返す
	 *
	 * @return array|null 未集計なら null。
	 */
	public static function get_cached_stats(): ?array {
		$stats = get_option( self::STATS_OPTION );

		if ( ! is_array( $stats ) ) {
			return null;
		}

		return self::normalize_totals( $stats ) + array(
			'generated_at' => (int) ( $stats['generated_at'] ?? 0 ),
			'fingerprint'  => (string) ( $stats['fingerprint'] ?? '' ),
		);
	}

	/**
	 * 累積値を正規の構造に丸める
	 *
	 * REST 経由でクライアントから持ち回られる値のため、
	 * 数値化と既知キーへの制限を必ず通す。
	 *
	 * @param mixed $totals 入力。
	 * @return array 正規化済みの累積値。
	 */
	public static function normalize_totals( $totals ): array {
		$out = array(
			'attachments'  => 0,
			'skipped'      => 0,
			'sizes'        => array(),
			'unregistered' => array(),
		);

		if ( ! is_array( $totals ) ) {
			return $out;
		}

		$out['attachments'] = absint( $totals['attachments'] ?? 0 );
		$out['skipped']     = absint( $totals['skipped'] ?? 0 );

		$sizes = isset( $totals['sizes'] ) && is_array( $totals['sizes'] ) ? $totals['sizes'] : array();
		foreach ( $sizes as $name => $bucket ) {
			$name = sanitize_text_field( (string) $name );
			self::ensure_size_bucket( $out['sizes'], $name );

			foreach ( array( 'files', 'bytes', 'stale', 'missing', 'excess', 'est_add_bytes' ) as $key ) {
				$out['sizes'][ $name ][ $key ] = absint( is_array( $bucket ) ? ( $bucket[ $key ] ?? 0 ) : 0 );
			}
		}

		$unregistered = isset( $totals['unregistered'] ) && is_array( $totals['unregistered'] ) ? $totals['unregistered'] : array();
		foreach ( $unregistered as $name => $bucket ) {
			$name = sanitize_text_field( (string) $name );

			$out['unregistered'][ $name ] = array(
				'files' => absint( is_array( $bucket ) ? ( $bucket['files'] ?? 0 ) : 0 ),
				'bytes' => absint( is_array( $bucket ) ? ( $bucket['bytes'] ?? 0 ) : 0 ),
			);
		}

		return $out;
	}

	/**
	 * サイズ集計バケットを初期化する
	 *
	 * @param array  $sizes 集計配列（参照渡し）。
	 * @param string $name  サイズ名。
	 */
	private static function ensure_size_bucket( array &$sizes, string $name ): void {
		if ( ! isset( $sizes[ $name ] ) ) {
			$sizes[ $name ] = array(
				'files'         => 0,
				'bytes'         => 0,
				'stale'         => 0,
				'missing'       => 0,
				'excess'        => 0,
				'est_add_bytes' => 0,
			);
		}
	}

	/**
	 * 中間サイズ1件の容量を求める
	 *
	 * WP 6.0 以降は metadata に filesize が記録される。無い古い添付だけ
	 * ファイルを stat する（バッチ内なので件数は限定される）。
	 *
	 * @param array  $size_meta metadata の sizes 配下1件。
	 * @param string $dir_path  添付ディレクトリの絶対パス（末尾スラッシュ付き）。
	 * @return int バイト数。ファイルが無ければ 0。
	 */
	private static function size_bytes( array $size_meta, string $dir_path ): int {
		if ( isset( $size_meta['filesize'] ) ) {
			return (int) $size_meta['filesize'];
		}

		if ( empty( $size_meta['file'] ) || ! is_string( $size_meta['file'] ) ) {
			return 0;
		}

		$path = $dir_path . $size_meta['file'];

		return is_file( $path ) ? (int) filesize( $path ) : 0;
	}
}
