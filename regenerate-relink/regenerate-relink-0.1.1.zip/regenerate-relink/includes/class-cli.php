<?php
/**
 * WP-CLI コマンド（FR-8）
 *
 * 管理画面と同じロジックを呼ぶ薄い層に徹する（FR-8.2）。判定・検出・
 * 書き換えの実装をここへ持ち込まないこと。各コマンドは Size_Registry /
 * Scanner / Regenerator / Applier / Cleanup の start() / step() を
 * 完了まで回し、結果を整形して出すだけ。
 *
 * 実行系（regenerate / apply / cleanup / run / restore / purge）は既定で
 * 確認を求める（FR-8.3）。--yes で抑止できる。抑止するのは確認だけで、
 * 前提の照合は必ず通る。
 *
 * プレビュー（scan）で算出した内容だけを適用する（FR-6.3）ため、開始時に
 * サイズ定義のフィンガープリント／スキャンIDを渡して照合する。ズレていれば
 * 実行せず scan のやり直しを促す（FR-6.4）。
 *
 * 出力形式は table / csv / json / yaml から選べる（FR-8.4）。列名は
 * 翻訳しない安定した語彙とし、人向けの表記は label / human 列に持たせる。
 *
 * **コマンド本体だけインスタンスメソッドにしてある。** WP-CLI の
 * CommandFactory はサブコマンドを探すとき静的メソッドを除外するため、
 * 静的にすると1つも登録されない。内部ヘルパーは他クラスと同じく静的。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_CLI;
use WP_CLI\Formatter;
use WP_CLI\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * wp regenerate-relink のコマンド
 */
class CLI {

	/**
	 * 一覧出力で1度に読む行数
	 */
	const LIST_BATCH = 500;

	/**
	 * サマリ表の列
	 */
	const SUMMARY_FIELDS = array( 'metric', 'label', 'value', 'human' );

	/**
	 * スキップ内訳表の列
	 */
	const SKIP_FIELDS = array( 'reason', 'label', 'refs', 'posts' );

	/**
	 * サイズ一覧表の列
	 */
	const SIZE_FIELDS = array( 'size', 'width', 'height', 'crop', 'source', 'generate', 'files', 'missing', 'stale', 'bytes', 'used' );

	/*
	 * ---------------------------------------------------------------------
	 * 参照系
	 * ---------------------------------------------------------------------
	 */

	/**
	 * Lists registered image sizes with their diagnostics.
	 *
	 * Shows the stored diagnostics (FR-1). Statistics are calculated
	 * automatically when none are stored yet.
	 *
	 * ## OPTIONS
	 *
	 * [--refresh]
	 * : Recalculate the statistics before printing.
	 *
	 * [--fields=<fields>]
	 * : Limit the output to specific fields.
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 *   - yaml
	 *   - count
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     # Show the diagnostics for every registered size.
	 *     $ wp regenerate-relink sizes
	 *
	 *     # Recalculate first, then export.
	 *     $ wp regenerate-relink sizes --refresh --format=csv
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function sizes( array $args, array $assoc_args ): void {
		if ( Utils\get_flag_value( $assoc_args, 'refresh', false ) || null === Size_Registry::get_cached_stats() ) {
			self::aggregate();
		}

		$stats    = Size_Registry::get_cached_stats();
		$stats    = is_array( $stats ) ? $stats : Size_Registry::normalize_totals( array() );
		$disabled = Size_Registry::disabled_sizes();
		$scan     = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );
		$usage    = $scan ? Reference_Graph::counts_by_size( (int) $scan->scan_id ) : array();

		$items = array();

		foreach ( Size_Registry::get_sizes() as $size ) {
			$name   = $size['name'];
			$bucket = isset( $stats['sizes'][ $name ] ) ? $stats['sizes'][ $name ] : array();

			$items[] = array(
				'size'     => $name,
				'width'    => (int) $size['width'],
				'height'   => (int) $size['height'],
				'crop'     => $size['crop'] ? 'yes' : 'no',
				'source'   => $size['source'],
				'generate' => in_array( $name, $disabled, true ) ? 'off' : 'on',
				'files'    => (int) ( $bucket['files'] ?? 0 ),
				'missing'  => (int) ( $bucket['missing'] ?? 0 ),
				'stale'    => (int) ( $bucket['stale'] ?? 0 ),
				'bytes'    => (int) ( $bucket['bytes'] ?? 0 ),
				'used'     => $scan ? (int) ( $usage[ $name ] ?? 0 ) : '',
			);
		}

		// 定義から消えたのにファイルが残っているサイズも隠さない（削除ステージの母数）
		foreach ( $stats['unregistered'] as $name => $bucket ) {
			$items[] = array(
				'size'     => $name,
				'width'    => '',
				'height'   => '',
				'crop'     => '',
				'source'   => 'unregistered',
				'generate' => '',
				'files'    => (int) ( $bucket['files'] ?? 0 ),
				'missing'  => '',
				'stale'    => '',
				'bytes'    => (int) ( $bucket['bytes'] ?? 0 ),
				'used'     => $scan ? (int) ( $usage[ $name ] ?? 0 ) : '',
			);
		}

		$formatter = new Formatter( $assoc_args, self::SIZE_FIELDS );
		$formatter->display_items( $items );

		if ( ! $scan ) {
			WP_CLI::log( __( 'The “used” column needs a content scan: run wp regenerate-relink scan.', 'regenerate-relink' ) );
		}
	}

	/**
	 * Shows the dry-run report of a scan.
	 *
	 * Reads the stored scan results (FR-6.6). Nothing is recalculated and
	 * nothing is modified.
	 *
	 * ## OPTIONS
	 *
	 * [--scan_id=<id>]
	 * : The scan to report on. Defaults to the latest completed scan.
	 *
	 * [--section=<section>]
	 * : Which part of the report to print.
	 * ---
	 * default: summary
	 * options:
	 *   - summary
	 *   - skips
	 *   - refs
	 *   - cleanup
	 * ---
	 *
	 * [--fields=<fields>]
	 * : Limit the output to specific fields.
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 *   - yaml
	 *   - count
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     # Headline figures of the latest preview.
	 *     $ wp regenerate-relink report
	 *
	 *     # Everything that will be skipped, and why.
	 *     $ wp regenerate-relink report --section=skips
	 *
	 *     # Every reference found by scan #12, as CSV.
	 *     $ wp regenerate-relink report --scan_id=12 --section=refs --format=csv
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function report( array $args, array $assoc_args ): void {
		$scan_id = absint( Utils\get_flag_value( $assoc_args, 'scan_id', 0 ) );

		if ( $scan_id > 0 && ! Reference_Graph::get_scan( $scan_id ) ) {
			WP_CLI::error( __( 'The requested scan was not found.', 'regenerate-relink' ) );
		}

		$report = Report::build( $scan_id > 0 ? $scan_id : null );
		$scan   = $report['scan'];

		switch ( (string) Utils\get_flag_value( $assoc_args, 'section', 'summary' ) ) {
			case 'skips':
				self::require_scan( $scan );
				$formatter = new Formatter( $assoc_args, self::SKIP_FIELDS );
				$formatter->display_items( self::skip_items( $report ) );
				break;

			case 'refs':
				self::require_scan( $scan );
				$formatter = new Formatter( $assoc_args, Report::csv_field_keys() );
				$formatter->display_items( self::ref_items( (int) $scan['scan_id'] ) );
				break;

			case 'cleanup':
				self::require_scan( $scan );
				$formatter = new Formatter( $assoc_args, Report::cleanup_csv_field_keys() );
				$formatter->display_items( self::cleanup_items( (int) $scan['scan_id'] ) );
				break;

			default:
				$formatter = new Formatter( $assoc_args, self::SUMMARY_FIELDS );
				$formatter->display_items( self::summary_items( $report ) );
				break;
		}
	}

	/**
	 * Shows the state of the quarantine area.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Render output in a particular format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 *   - yaml
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink quarantine
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function quarantine( array $args, array $assoc_args ): void {
		$usage    = Quarantine::usage();
		$settings = Quarantine::settings();

		$items = array(
			array(
				'metric' => 'files',
				'label'  => __( 'Files held in quarantine', 'regenerate-relink' ),
				'value'  => $usage['files'],
				'human'  => number_format_i18n( $usage['files'] ),
			),
			array(
				'metric' => 'bytes',
				'label'  => __( 'Space used by the quarantine area', 'regenerate-relink' ),
				'value'  => $usage['bytes'],
				'human'  => size_format( $usage['bytes'] ),
			),
			array(
				'metric' => 'retention_days',
				'label'  => __( 'Retention period in days (0 = keep until deleted manually)', 'regenerate-relink' ),
				'value'  => $settings['retention_days'],
				'human'  => 0 === $settings['retention_days']
					? __( 'Keep until manually deleted', 'regenerate-relink' )
					: number_format_i18n( $settings['retention_days'] ),
			),
			array(
				'metric' => 'delete_scaled',
				'label'  => __( 'Include “-scaled” copies in cleanup candidates', 'regenerate-relink' ),
				'value'  => $settings['delete_scaled'] ? 1 : 0,
				'human'  => $settings['delete_scaled'] ? __( 'yes', 'regenerate-relink' ) : __( 'no', 'regenerate-relink' ),
			),
		);

		$formatter = new Formatter( $assoc_args, self::SUMMARY_FIELDS );
		$formatter->display_items( $items );
	}

	/*
	 * ---------------------------------------------------------------------
	 * プレビュー（FR-6.1: 実データを一切変更しない）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * Creates the dry-run preview: diagnostics, content scan and cleanup candidates.
	 *
	 * Nothing is modified: no files are written or moved, and post content and
	 * attachment metadata stay untouched (FR-6.1). Run this before any stage —
	 * the stages only apply what this preview calculated (FR-6.3).
	 *
	 * ## OPTIONS
	 *
	 * [--restart]
	 * : Discard an interrupted scan and start a new one. Without this flag an
	 * interrupted scan is resumed.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink scan
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function scan( array $args, array $assoc_args ): void {
		$restart = (bool) Utils\get_flag_value( $assoc_args, 'restart', false );

		// 生成ステージのプレビュー（見込み容量と照合用フィンガープリント）
		self::aggregate();

		$scan_id = self::run_scan( $restart );

		// 削除ステージのプレビュー。完了したばかりのスキャンを根拠に取り直す
		self::run_plan( $scan_id );

		WP_CLI::success(
			sprintf(
				/* translators: %s: スキャンID */
				__( 'Preview ready (scan #%s). Nothing has been modified.', 'regenerate-relink' ),
				$scan_id
			)
		);

		self::print_report( Report::build( $scan_id ) );
	}

	/*
	 * ---------------------------------------------------------------------
	 * 実行系（FR-8.3: 既定で確認を求める）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * Runs all three stages: regenerate, update references, quarantine.
	 *
	 * Applies what the last preview calculated, in the only safe order:
	 * thumbnails are created first, content references are updated next, and
	 * obsolete files are quarantined last (FR-7.5).
	 *
	 * ## OPTIONS
	 *
	 * [--restart]
	 * : Discard interrupted jobs and start each stage from the beginning.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink run --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function run( array $args, array $assoc_args ): void {
		$restart = (bool) Utils\get_flag_value( $assoc_args, 'restart', false );
		$report  = Report::build();

		self::require_scan( $report['scan'] );

		if ( null === $report['generation'] ) {
			WP_CLI::error( __( 'No diagnostics have been calculated yet. Run wp regenerate-relink scan first.', 'regenerate-relink' ) );
		}

		self::print_report( $report );

		WP_CLI::confirm(
			__( 'Run all three stages? Thumbnails will be created, post content will be rewritten, and obsolete files will be moved to the quarantine area. Back up your site first.', 'regenerate-relink' ),
			$assoc_args
		);

		self::stage_regenerate( $restart );
		self::stage_apply( $restart );
		self::stage_cleanup( $restart );

		WP_CLI::success( __( 'All stages finished.', 'regenerate-relink' ) );
	}

	/**
	 * Creates missing and outdated thumbnails.
	 *
	 * Always resizes from the original image, never from a “-scaled” copy
	 * (FR-3.3). Existing files are never deleted here.
	 *
	 * ## OPTIONS
	 *
	 * [--restart]
	 * : Discard an interrupted job and start from the beginning.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink regenerate --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function regenerate( array $args, array $assoc_args ): void {
		$restart  = (bool) Utils\get_flag_value( $assoc_args, 'restart', false );
		$forecast = Report::build()['generation'];

		if ( null === $forecast ) {
			WP_CLI::error( __( 'No diagnostics have been calculated yet. Run wp regenerate-relink scan first.', 'regenerate-relink' ) );
		}

		WP_CLI::log(
			sprintf(
				/* translators: 1: 生成されるファイル数, 2: 未生成数, 3: 要再生成数, 4: 推定増加容量 */
				__( 'Thumbnails to create: %1$s (%2$s missing, %3$s outdated), estimated %4$s added.', 'regenerate-relink' ),
				number_format_i18n( $forecast['files'] ),
				number_format_i18n( $forecast['missing'] ),
				number_format_i18n( $forecast['stale'] ),
				size_format( $forecast['est_add_bytes'] )
			)
		);

		if ( 0 === $forecast['files'] && ! self::has_running_job( Jobs::TYPE_REGENERATE ) ) {
			WP_CLI::success( __( 'Nothing to regenerate.', 'regenerate-relink' ) );
			return;
		}

		WP_CLI::confirm(
			__( 'Create these thumbnails? New files will be written to the uploads directory. Back up your site first.', 'regenerate-relink' ),
			$assoc_args
		);

		self::stage_regenerate( $restart );
	}

	/**
	 * Updates image references in post content.
	 *
	 * Applies exactly what the last scan calculated (FR-6.3). Only the
	 * filename part of each URL is replaced, posts keep their modified date,
	 * and the previous content is stored as a revision (FR-4).
	 *
	 * ## OPTIONS
	 *
	 * [--restart]
	 * : Discard an interrupted job and start from the beginning.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink apply --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function apply( array $args, array $assoc_args ): void {
		$restart = (bool) Utils\get_flag_value( $assoc_args, 'restart', false );
		$report  = Report::build();

		self::require_scan( $report['scan'] );

		WP_CLI::log(
			sprintf(
				/* translators: 1: 更新される参照数, 2: 対象記事数, 3: スキャンID */
				__( 'References to update: %1$s across %2$s posts (scan #%3$s).', 'regenerate-relink' ),
				number_format_i18n( $report['update']['refs'] ),
				number_format_i18n( $report['update']['posts'] ),
				$report['scan']['scan_id']
			)
		);

		if ( 0 === $report['update']['refs'] && ! self::has_running_job( Jobs::TYPE_APPLY ) ) {
			WP_CLI::success( __( 'Nothing to update.', 'regenerate-relink' ) );
			return;
		}

		WP_CLI::confirm(
			__( 'Update these references? Post content will be rewritten. Back up your site first.', 'regenerate-relink' ),
			$assoc_args
		);

		self::stage_apply( $restart );
	}

	/**
	 * Moves obsolete thumbnail files to the quarantine area.
	 *
	 * Only files that pass every safety check are moved (FR-5.1); anything
	 * else is reported and left alone. Nothing is deleted immediately — run
	 * “wp regenerate-relink restore” to put everything back.
	 *
	 * Refuses to run while content references are still waiting to be
	 * updated (FR-7.5).
	 *
	 * ## OPTIONS
	 *
	 * [--restart]
	 * : Discard an interrupted job and start from the beginning.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink cleanup --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function cleanup( array $args, array $assoc_args ): void {
		$restart  = (bool) Utils\get_flag_value( $assoc_args, 'restart', false );
		$forecast = Report::build()['cleanup'];

		if ( null === $forecast ) {
			WP_CLI::error( __( 'No cleanup candidates have been calculated. Run wp regenerate-relink scan first.', 'regenerate-relink' ) );
		}

		WP_CLI::log(
			sprintf(
				/* translators: 1: 隔離候補ファイル数, 2: 削減容量 */
				__( 'Files to quarantine: %1$s (%2$s reclaimed).', 'regenerate-relink' ),
				number_format_i18n( $forecast['files'] ),
				size_format( $forecast['bytes'] )
			)
		);

		// FR-7.5: 順序違反は確認を出す前に、理由を示して中断する
		if ( $forecast['pending_updates'] > 0 ) {
			self::abort_on_error(
				array(
					'error'   => 'apply_incomplete',
					'pending' => $forecast['pending_updates'],
				)
			);
		}

		if ( 0 === $forecast['files'] && ! self::has_running_job( Jobs::TYPE_QUARANTINE ) ) {
			WP_CLI::success( __( 'Nothing to quarantine.', 'regenerate-relink' ) );
			return;
		}

		WP_CLI::confirm(
			__( 'Move these files to the quarantine area? Nothing is permanently deleted: everything can be restored afterwards. Back up your site first.', 'regenerate-relink' ),
			$assoc_args
		);

		self::stage_cleanup( $restart );
	}

	/**
	 * Restores every quarantined file to its original location.
	 *
	 * Files whose original location is occupied again are left in quarantine
	 * and reported (nothing is overwritten).
	 *
	 * ## OPTIONS
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink restore --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function restore( array $args, array $assoc_args ): void {
		$usage = Quarantine::usage();

		if ( 0 === $usage['files'] ) {
			WP_CLI::success( __( 'The quarantine area is empty. Nothing to restore.', 'regenerate-relink' ) );
			return;
		}

		WP_CLI::confirm(
			sprintf(
				/* translators: 1: 隔離中のファイル数, 2: 合計容量 */
				__( 'Restore %1$s files (%2$s) to their original locations?', 'regenerate-relink' ),
				number_format_i18n( $usage['files'] ),
				size_format( $usage['bytes'] )
			),
			$assoc_args
		);

		$bar      = self::progress_bar( __( 'Restoring files', 'regenerate-relink' ), $usage['files'] );
		$cursor   = 0;
		$restored = 0;
		$failed   = 0;

		for ( ;; ) {
			$result    = Cleanup::restore_batch( $cursor );
			$restored += (int) $result['restored'];
			$failed   += (int) $result['failed'];

			$bar->tick( (int) $result['processed'] );

			if ( $result['done'] ) {
				break;
			}

			$cursor = (int) $result['next_cursor'];
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		if ( $failed > 0 ) {
			WP_CLI::warning(
				sprintf(
					/* translators: %s: 復元できなかったファイル数 */
					__( '%s files could not be restored. A file with the same name may exist again — see wp regenerate-relink report --section=cleanup.', 'regenerate-relink' ),
					number_format_i18n( $failed )
				)
			);
		}

		WP_CLI::success(
			sprintf(
				/* translators: %s: 復元したファイル数 */
				__( '%s files restored.', 'regenerate-relink' ),
				number_format_i18n( $restored )
			)
		);
	}

	/**
	 * Permanently deletes everything in the quarantine area.
	 *
	 * This cannot be undone. Quarantined files are also deleted automatically
	 * once the retention period has passed (FR-5.5).
	 *
	 * ## OPTIONS
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp regenerate-relink purge --yes
	 *
	 * @param array $args       位置引数。
	 * @param array $assoc_args フラグ。
	 */
	public function purge( array $args, array $assoc_args ): void {
		$usage = Quarantine::usage();

		if ( 0 === $usage['files'] ) {
			WP_CLI::success( __( 'The quarantine area is empty. Nothing to delete.', 'regenerate-relink' ) );
			return;
		}

		WP_CLI::confirm(
			sprintf(
				/* translators: 1: 削除されるファイル数, 2: 合計容量 */
				__( 'Permanently delete %1$s files (%2$s)? This cannot be undone.', 'regenerate-relink' ),
				number_format_i18n( $usage['files'] ),
				size_format( $usage['bytes'] )
			),
			$assoc_args
		);

		$bar    = self::progress_bar( __( 'Deleting files', 'regenerate-relink' ), $usage['files'] );
		$cursor = 0;
		$purged = 0;

		for ( ;; ) {
			$result  = Cleanup::empty_batch( $cursor );
			$purged += (int) $result['purged'];

			$bar->tick( (int) $result['processed'] );

			if ( $result['done'] ) {
				break;
			}

			$cursor = (int) $result['next_cursor'];
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		WP_CLI::success(
			sprintf(
				/* translators: %s: 削除したファイル数 */
				__( '%s files permanently deleted.', 'regenerate-relink' ),
				number_format_i18n( $purged )
			)
		);
	}

	/*
	 * ---------------------------------------------------------------------
	 * ステージの実行（確認は呼び出し側で済ませてから呼ぶ）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 生成ステージを完了まで回す（FR-3）
	 *
	 * @param bool $restart 進行中のジョブを破棄して始めるか。
	 */
	private static function stage_regenerate( bool $restart ): void {
		$stats       = Size_Registry::get_cached_stats();
		$fingerprint = is_array( $stats ) ? (string) $stats['fingerprint'] : '';

		// FR-6.3: プレビュー時点のサイズ定義と一致するときだけ実行する
		$progress = Regenerator::start( $restart, '' === $fingerprint ? null : $fingerprint );

		self::abort_on_error( $progress );

		$job_id = (int) $progress['job_id'];
		$bar    = self::progress_bar( __( 'Regenerating thumbnails', 'regenerate-relink' ), (int) $progress['images_total'] );

		$bar->tick( (int) $progress['images_done'] );

		while ( ! $progress['done'] ) {
			$progress = Regenerator::step( $job_id );

			if ( null === $progress ) {
				WP_CLI::error( __( 'The regeneration job stopped unexpectedly. Run the command again to start a new one.', 'regenerate-relink' ) );
			}

			$bar->tick( (int) $progress['processed'] );
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		$totals = $progress['totals'];

		WP_CLI::log(
			sprintf(
				/* translators: 1: 生成したサムネイル数, 2: 増加容量 */
				__( '%1$s thumbnails created (%2$s added).', 'regenerate-relink' ),
				number_format_i18n( $totals['generated'] ),
				size_format( $totals['bytes'] )
			)
		);

		self::log_skipped( $totals['skipped'], Report::regenerate_skip_labels() );

		if ( $totals['no_metadata'] > 0 ) {
			WP_CLI::log(
				sprintf(
					/* translators: %s: 件数 */
					__( 'Images without size data (SVG etc.): %s', 'regenerate-relink' ),
					number_format_i18n( $totals['no_metadata'] )
				)
			);
		}

		if ( $totals['failed'] > 0 ) {
			WP_CLI::warning(
				sprintf(
					/* translators: %s: 失敗件数 */
					__( '%s thumbnails failed. See wp regenerate-relink report for the affected items.', 'regenerate-relink' ),
					number_format_i18n( $totals['failed'] )
				)
			);
		}
	}

	/**
	 * 置換ステージを完了まで回す（FR-4）
	 *
	 * @param bool $restart 進行中のジョブを破棄して始めるか。
	 */
	private static function stage_apply( bool $restart ): void {
		$scan_id = self::latest_scan_id();

		// FR-6.3: プレビューに表示したスキャンだけを適用する
		$progress = Applier::start( $restart, $scan_id > 0 ? $scan_id : null );

		self::abort_on_error( $progress );

		$job_id = (int) $progress['job_id'];
		$bar    = self::progress_bar( __( 'Updating content references', 'regenerate-relink' ), (int) $progress['posts_total'] );

		$bar->tick( (int) $progress['posts_done'] );

		while ( ! $progress['done'] ) {
			$progress = Applier::step( $job_id );

			if ( null === $progress ) {
				WP_CLI::error( __( 'The update job stopped unexpectedly. Run the command again to start a new one.', 'regenerate-relink' ) );
			}

			$bar->tick( (int) $progress['processed'] );
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		$totals = $progress['totals'];

		WP_CLI::log(
			sprintf(
				/* translators: 1: 更新した参照数, 2: 更新した記事数 */
				__( '%1$s references updated across %2$s posts.', 'regenerate-relink' ),
				number_format_i18n( $totals['applied'] ),
				number_format_i18n( $totals['posts_updated'] )
			)
		);

		self::log_skipped( $totals['skipped'], Report::skip_reason_labels() );

		if ( $totals['failed'] > 0 ) {
			WP_CLI::warning(
				sprintf(
					/* translators: %s: 失敗件数 */
					__( '%s references failed. See wp regenerate-relink report --section=skips for the reasons.', 'regenerate-relink' ),
					number_format_i18n( $totals['failed'] )
				)
			);
		}
	}

	/**
	 * 削除（隔離）ステージを完了まで回す（FR-5）
	 *
	 * @param bool $restart 進行中のジョブを破棄して始めるか。
	 */
	private static function stage_cleanup( bool $restart ): void {
		$forecast = Report::build()['cleanup'];

		if ( null === $forecast ) {
			WP_CLI::log( __( 'No cleanup candidates have been calculated for this scan. Skipping the quarantine stage.', 'regenerate-relink' ) );
			return;
		}

		$scan_id = self::latest_scan_id();

		// FR-7.5 のガード（本文更新が未完なら中断）は start_run が持つ
		$progress = Cleanup::start_run( $restart, $scan_id > 0 ? $scan_id : null );

		self::abort_on_error( $progress );

		$job_id = (int) $progress['job_id'];
		$bar    = self::progress_bar( __( 'Quarantining files', 'regenerate-relink' ), (int) $progress['files_total'] );

		$bar->tick( (int) $progress['files_done'] );

		while ( ! $progress['done'] ) {
			$progress = Cleanup::step_run( $job_id );

			if ( null === $progress ) {
				WP_CLI::error( __( 'The quarantine job stopped unexpectedly. Run the command again to start a new one.', 'regenerate-relink' ) );
			}

			self::abort_on_error( $progress );

			$bar->tick( (int) $progress['processed'] );
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		$totals = $progress['totals'];

		WP_CLI::log(
			sprintf(
				/* translators: 1: 隔離したファイル数, 2: 削減容量 */
				__( '%1$s files quarantined (%2$s reclaimed). Run wp regenerate-relink restore to put them back.', 'regenerate-relink' ),
				number_format_i18n( $totals['quarantined'] ),
				size_format( $totals['bytes'] )
			)
		);

		self::log_skipped( $totals['skipped'], Report::cleanup_reason_labels() );
	}

	/*
	 * ---------------------------------------------------------------------
	 * 実行の共通部品
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 診断集計を完了まで回す（FR-1）
	 */
	private static function aggregate(): void {
		$bar    = self::progress_bar( __( 'Calculating statistics', 'regenerate-relink' ), Size_Registry::count_image_attachments() );
		$cursor = 0;
		$totals = array();

		for ( ;; ) {
			$result = Size_Registry::aggregate_batch( $cursor, $totals );
			$cursor = (int) $result['cursor'];
			$totals = $result['totals'];

			$bar->tick( (int) $result['processed'] );

			if ( $result['done'] ) {
				break;
			}

			Utils\wp_clear_object_cache();
		}

		$bar->finish();
	}

	/**
	 * 本文スキャンを完了まで回す（FR-4 の scan 側）
	 *
	 * @param bool $restart 進行中のスキャンを破棄して始めるか。
	 * @return int 完了したスキャンID。
	 */
	private static function run_scan( bool $restart ): int {
		$progress = Scanner::start( $restart );
		$scan_id  = (int) $progress['scan_id'];

		if ( $scan_id <= 0 ) {
			WP_CLI::error( __( 'The scan could not be started.', 'regenerate-relink' ) );
		}

		if ( $progress['posts_scanned'] > 0 ) {
			WP_CLI::log(
				sprintf(
					/* translators: %s: スキャンID */
					__( 'Resuming the interrupted scan #%s.', 'regenerate-relink' ),
					$scan_id
				)
			);
		}

		$bar = self::progress_bar( __( 'Scanning post content', 'regenerate-relink' ), (int) $progress['posts_total'] );

		$bar->tick( (int) $progress['posts_scanned'] );

		while ( ! $progress['done'] ) {
			$progress = Scanner::step( $scan_id );

			if ( null === $progress ) {
				WP_CLI::error( __( 'The scan stopped unexpectedly. Run the command again to start a new one.', 'regenerate-relink' ) );
			}

			$bar->tick( (int) $progress['processed'] );
			Utils\wp_clear_object_cache();
		}

		$bar->finish();

		return $scan_id;
	}

	/**
	 * 削除候補の算出を完了まで回す（FR-5.1 / FR-6.1）
	 *
	 * 完了したばかりのスキャンを根拠に取り直すため、進行中の算出があれば
	 * 破棄する（restart = true）。ファイルには一切触れない。
	 *
	 * @param int $scan_id 根拠にするスキャンID。
	 */
	private static function run_plan( int $scan_id ): void {
		$progress = Cleanup::start_plan( true, $scan_id );

		self::abort_on_error( $progress );

		$job_id = (int) $progress['job_id'];
		$bar    = self::progress_bar( __( 'Checking files for cleanup', 'regenerate-relink' ), (int) $progress['attachments_total'] );

		while ( ! $progress['done'] ) {
			$progress = Cleanup::step_plan( $job_id );

			if ( null === $progress ) {
				WP_CLI::error( __( 'The cleanup planning job stopped unexpectedly. Run the command again to start a new one.', 'regenerate-relink' ) );
			}

			$bar->tick( (int) $progress['processed'] );
			Utils\wp_clear_object_cache();
		}

		$bar->finish();
	}

	/**
	 * start() / step() が返した error キーを CLI のエラーへ変換する
	 *
	 * 文言は管理画面と別に持つ（次に打つべきコマンドを示すため）。判定そのものは
	 * 各実行クラスが行い、ここでは訳出しかしない。
	 *
	 * @param array $result start() / step() の戻り値。
	 */
	private static function abort_on_error( array $result ): void {
		if ( ! isset( $result['error'] ) ) {
			return;
		}

		$message = __( 'The operation could not be started.', 'regenerate-relink' );

		switch ( $result['error'] ) {
			case 'no_scan':
				$message = __( 'No completed content scan was found. Run wp regenerate-relink scan first.', 'regenerate-relink' );
				break;

			case 'stale_preview':
				$message = __( 'The preview is out of date: the size definitions or the scan have changed since it was created. Run wp regenerate-relink scan again, review it, and try again.', 'regenerate-relink' );
				break;

			case 'no_plan':
				$message = __( 'No cleanup candidates have been calculated for this preview. Run wp regenerate-relink scan first.', 'regenerate-relink' );
				break;

			case 'apply_incomplete':
				// FR-7.5: 実行を試みた時点で理由を提示して中断する
				$message = sprintf(
					/* translators: %s: 残っている更新予定の参照数 */
					__( 'Content references have not been updated yet (%s references are still waiting). Quarantining files before updating references would break images in your content, so run wp regenerate-relink apply first.', 'regenerate-relink' ),
					number_format_i18n( (int) ( $result['pending'] ?? 0 ) )
				);
				break;

			case 'dir_failed':
				$message = __( 'The quarantine directory could not be created. Check that the uploads directory is writable.', 'regenerate-relink' );
				break;
		}

		WP_CLI::error( $message );
	}

	/**
	 * 完了済みスキャンが無ければ中断する
	 *
	 * @param array|null $scan Report::build() の scan 区画。
	 */
	private static function require_scan( ?array $scan ): void {
		if ( null === $scan ) {
			WP_CLI::error( __( 'No completed content scan was found. Run wp regenerate-relink scan first.', 'regenerate-relink' ) );
		}
	}

	/**
	 * 中断したジョブが残っているか
	 *
	 * 「やることが無い」と判断して打ち切る前に確認する。プレビュー上の残件が
	 * 0 でも、中断したジョブは再開できるようにしておく（FR-3.5 / FR-7.7）。
	 *
	 * @param string $job_type ジョブ種別（Jobs::TYPE_* 定数）。
	 */
	private static function has_running_job( string $job_type ): bool {
		return null !== Jobs::latest_job( $job_type, Jobs::JOB_RUNNING );
	}

	/**
	 * 最新の完了スキャンIDを返す
	 *
	 * @return int 完了スキャンが無ければ 0。
	 */
	private static function latest_scan_id(): int {
		$scan = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );

		return $scan ? (int) $scan->scan_id : 0;
	}

	/**
	 * 進捗バーを作る
	 *
	 * @param string $message 表示する文言。
	 * @param int    $total   総件数。
	 * @return \cli\progress\Bar|\WP_CLI\NoOp
	 */
	private static function progress_bar( string $message, int $total ) {
		return Utils\make_progress_bar( $message, max( 1, $total ) );
	}

	/**
	 * スキップ内訳を理由別に出す（FR-6.2）
	 *
	 * @param array $skipped 理由コード => 件数。
	 * @param array $labels  理由コード => 表示ラベル。
	 */
	private static function log_skipped( array $skipped, array $labels ): void {
		arsort( $skipped );

		foreach ( $skipped as $reason => $count ) {
			WP_CLI::log(
				sprintf(
					/* translators: 1: スキップ理由, 2: 件数 */
					__( 'Skipped — %1$s: %2$s', 'regenerate-relink' ),
					$labels[ $reason ] ?? $reason,
					number_format_i18n( (int) $count )
				)
			);
		}
	}

	/*
	 * ---------------------------------------------------------------------
	 * レポートの整形
	 * ---------------------------------------------------------------------
	 */

	/**
	 * レポートの要点とスキップ内訳を表で出す
	 *
	 * @param array $report Report::build() の戻り値。
	 */
	private static function print_report( array $report ): void {
		Utils\format_items( 'table', self::summary_items( $report ), self::SUMMARY_FIELDS );

		$skips = self::skip_items( $report );

		if ( ! empty( $skips ) ) {
			// FR-6.2: スキップ件数を理由別に示す
			Utils\format_items( 'table', $skips, self::SKIP_FIELDS );
		}
	}

	/**
	 * レポートの要点を metric / label / value / human の行に整える
	 *
	 * value は生値（機械可読）、human は表示用。両方出すことで
	 * --format=json のまま集計に使える（FR-8.4）。
	 *
	 * @param array $report Report::build() の戻り値。
	 * @return array
	 */
	private static function summary_items( array $report ): array {
		$items = array();

		$add = function ( $metric, $label, $value, $human = null ) use ( &$items ) {
			$items[] = array(
				'metric' => $metric,
				'label'  => $label,
				'value'  => $value,
				'human'  => null === $human ? (string) $value : $human,
			);
		};

		if ( null !== $report['scan'] ) {
			$add( 'scan_id', __( 'Scan', 'regenerate-relink' ), $report['scan']['scan_id'], '#' . $report['scan']['scan_id'] );
			$add( 'scanned_at', __( 'Scan finished', 'regenerate-relink' ), (string) $report['scan']['finished_at'] );
			$add( 'posts_scanned', __( 'Posts scanned', 'regenerate-relink' ), $report['scan']['posts_scanned'], number_format_i18n( $report['scan']['posts_scanned'] ) );
		}

		if ( null !== $report['generation'] ) {
			$generation = $report['generation'];

			$add( 'thumbnails_to_create', __( 'Thumbnails to create', 'regenerate-relink' ), $generation['files'], number_format_i18n( $generation['files'] ) );
			$add( 'thumbnails_missing', __( 'Of those, never generated', 'regenerate-relink' ), $generation['missing'], number_format_i18n( $generation['missing'] ) );
			$add( 'thumbnails_outdated', __( 'Of those, outdated', 'regenerate-relink' ), $generation['stale'], number_format_i18n( $generation['stale'] ) );
			$add( 'est_add_bytes', __( 'Estimated space added', 'regenerate-relink' ), $generation['est_add_bytes'], size_format( $generation['est_add_bytes'] ) );
		}

		if ( null !== $report['update'] ) {
			$add( 'references_to_update', __( 'References to update', 'regenerate-relink' ), $report['update']['refs'], number_format_i18n( $report['update']['refs'] ) );
			$add( 'posts_to_update', __( 'Posts to update', 'regenerate-relink' ), $report['update']['posts'], number_format_i18n( $report['update']['posts'] ) );
		}

		if ( null !== $report['statuses'] ) {
			$applied = (int) ( $report['statuses'][ Reference_Graph::REF_APPLIED ] ?? 0 );

			$add( 'references_applied', __( 'References already applied from this scan', 'regenerate-relink' ), $applied, number_format_i18n( $applied ) );
		}

		if ( null !== $report['cleanup'] ) {
			$cleanup = $report['cleanup'];

			$add( 'cleanup_files', __( 'Files to quarantine', 'regenerate-relink' ), $cleanup['files'], number_format_i18n( $cleanup['files'] ) );
			$add( 'cleanup_bytes', __( 'Space reclaimed by quarantining', 'regenerate-relink' ), $cleanup['bytes'], size_format( $cleanup['bytes'] ) );
			$add( 'cleanup_pending_updates', __( 'References blocking the quarantine stage', 'regenerate-relink' ), $cleanup['pending_updates'], number_format_i18n( $cleanup['pending_updates'] ) );
			$add( 'scaled_files_left', __( '“-scaled” copies left untouched', 'regenerate-relink' ), $cleanup['scaled_files'], number_format_i18n( $cleanup['scaled_files'] ) );
		}

		$net = $report['capacity']['net_est_bytes'];

		if ( null !== $net ) {
			$add(
				'net_est_bytes',
				__( 'Estimated disk change', 'regenerate-relink' ),
				$net,
				( $net < 0 ? '−' : '+' ) . size_format( abs( $net ) )
			);
		}

		$usage = $report['quarantine']['usage'];

		$add( 'quarantine_files', __( 'Files held in quarantine', 'regenerate-relink' ), $usage['files'], number_format_i18n( $usage['files'] ) );
		$add( 'quarantine_bytes', __( 'Space used by the quarantine area', 'regenerate-relink' ), $usage['bytes'], size_format( $usage['bytes'] ) );

		return $items;
	}

	/**
	 * スキップ内訳を行に整える（FR-6.2 / FR-6.8 / FR-6.9）
	 *
	 * @param array $report Report::build() の戻り値。
	 * @return array
	 */
	private static function skip_items( array $report ): array {
		$labels = Report::skip_reason_labels();
		$items  = array();

		foreach ( (array) $report['skips'] as $reason => $entry ) {
			$items[] = array(
				'reason' => $reason,
				'label'  => $labels[ $reason ] ?? $reason,
				'refs'   => (int) $entry['refs'],
				'posts'  => (int) $entry['posts'],
			);
		}

		return $items;
	}

	/**
	 * 参照一覧を行に整える（CSV エクスポートと同じ整形を使う）
	 *
	 * @param int $scan_id スキャンID。
	 * @return array
	 */
	private static function ref_items( int $scan_id ): array {
		$keys  = Report::csv_field_keys();
		$items = array();
		$after = 0;

		for ( ;; ) {
			$refs = Reference_Graph::refs_batch( $scan_id, $after, self::LIST_BATCH );

			if ( empty( $refs ) ) {
				break;
			}

			foreach ( $refs as $ref ) {
				$items[] = array_combine( $keys, Report::csv_row( $ref ) );
				$after   = (int) $ref->ref_id;
			}
		}

		return $items;
	}

	/**
	 * 削除候補・隔離マニフェストを行に整える
	 *
	 * @param int $scan_id スキャンID。
	 * @return array
	 */
	private static function cleanup_items( int $scan_id ): array {
		$keys  = Report::cleanup_csv_field_keys();
		$items = array();
		$after = 0;

		for ( ;; ) {
			$rows = Quarantine::export_batch( $scan_id, $after, self::LIST_BATCH );

			if ( empty( $rows ) ) {
				break;
			}

			foreach ( $rows as $row ) {
				$items[] = array_combine( $keys, Report::cleanup_csv_row( $row ) );
				$after   = (int) $row->file_id;
			}
		}

		return $items;
	}
}
