<?php
/**
 * 生成オン／オフ（FR-2）
 *
 * サイズ単位のアップロード時生成の停止（FR-2.1）と、大画像の自動縮小
 * （big_image_size_threshold、-scaled 生成）の無効化（FR-2.3）を担う。
 *
 * 停止設定はオプションに保存し、再アクティベートしても保持される
 * （FR-2.2。削除はアンインストール時のみ）。停止操作そのものは
 * 既存ファイルを一切削除しない（FR-2.5。削除は FR-5 の隔離工程で行う）。
 *
 * 読み取りは Size_Registry::disabled_sizes()（再生成 FR-3.2 と共用）、
 * 書き込みはこのクラスに集約する。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * アップロード時の生成制御と設定の書き込み
 */
class Generation_Control {

	const SETTINGS_OPTION = 'rgrl_settings';

	/**
	 * 停止設定されたサイズをアップロード時の生成対象から外す（FR-2.1）
	 *
	 * intermediate_image_sizes_advanced のコールバック。新規アップロードの
	 * ほか、コアの wp_create_image_subsizes を通る処理すべてに効く。
	 * サイズ定義（登録）そのものには手を触れない（§1.3: 検知と追随のみ）。
	 *
	 * @param array $sizes 生成予定のサイズ定義（name => def）。
	 * @return array 停止分を除いたサイズ定義。
	 */
	public static function filter_intermediate_sizes( array $sizes ): array {
		foreach ( Size_Registry::disabled_sizes() as $name ) {
			unset( $sizes[ $name ] );
		}

		return $sizes;
	}

	/**
	 * 大画像の自動縮小しきい値を無効化する（FR-2.3）
	 *
	 * big_image_size_threshold のコールバック。設定が有効なときだけ
	 * false を返して -scaled の生成を止める。無効時は素通しし、
	 * 他プラグインの設定を上書きしない。
	 *
	 * @param int|false $threshold しきい値（px）。
	 * @return int|false 無効化時は false。
	 */
	public static function filter_big_image_threshold( $threshold ) {
		return self::big_image_threshold_disabled() ? false : $threshold;
	}

	/**
	 * 大画像の自動縮小を無効化する設定か
	 */
	public static function big_image_threshold_disabled(): bool {
		$settings = get_option( self::SETTINGS_OPTION, array() );

		return is_array( $settings ) && ! empty( $settings['disable_big_image_threshold'] );
	}

	/**
	 * 現在の設定を返す（REST / 管理画面の初期描画用）
	 *
	 * @return array { disabled_sizes: string[], disable_big_image_threshold: bool }
	 */
	public static function current(): array {
		return array(
			'disabled_sizes'              => Size_Registry::disabled_sizes(),
			'disable_big_image_threshold' => self::big_image_threshold_disabled(),
		);
	}

	/**
	 * 設定を更新する
	 *
	 * null の引数は「変更しない」。disabled_sizes は登録済みサイズに対する
	 * 全量指定として扱い、登録されていないサイズの停止設定は温存する
	 * （テーマ切替等で一時的に消えたサイズの設定を UI 経由の保存で
	 * 失わないため。FR-2.2）。
	 *
	 * オプションの書き込みだけを行い、ファイルには一切触れない（FR-2.5）。
	 *
	 * @param array|null $disabled_sizes 停止するサイズ名の全量。null なら変更しない。
	 * @param bool|null  $disable_big_image_threshold -scaled 生成を止めるか。null なら変更しない。
	 * @return array 更新後の設定（current() と同形）。
	 */
	public static function update( ?array $disabled_sizes, ?bool $disable_big_image_threshold ): array {
		if ( null !== $disabled_sizes ) {
			$registered = array_keys( wp_get_registered_image_subsizes() );

			// 画面に出ない（未登録の）停止設定は温存する
			$kept      = array_diff( Size_Registry::disabled_sizes(), $registered );
			$requested = array_map( 'sanitize_text_field', array_map( 'strval', $disabled_sizes ) );
			$accepted  = array_intersect( $requested, $registered );

			update_option(
				Size_Registry::DISABLED_OPTION,
				array_values( array_unique( array_merge( $kept, $accepted ) ) )
			);
		}

		if ( null !== $disable_big_image_threshold ) {
			$settings = get_option( self::SETTINGS_OPTION, array() );

			if ( ! is_array( $settings ) ) {
				$settings = array();
			}

			$settings['disable_big_image_threshold'] = $disable_big_image_threshold;

			update_option( self::SETTINGS_OPTION, $settings );
		}

		return self::current();
	}
}
