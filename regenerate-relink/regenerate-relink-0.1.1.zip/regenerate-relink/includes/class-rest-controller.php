<?php
/**
 * REST API（管理画面の非同期取得用）
 *
 * FR-1.4: 集計で管理画面をブロックしないため、初期表示後に
 * クライアントがここを呼んで統計を組み立てる。
 *
 * 管理画面と WP-CLI（FR-8.2）はどちらも Size_Registry / Reference_Graph の
 * 同一ロジックを呼ぶ。REST 層に処理を書かないこと。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST ルート定義
 */
class Rest_Controller {

	const ROUTE_NAMESPACE = 'rgrl/v1';

	/**
	 * ルートを登録する
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/sizes',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_sizes' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/sizes/aggregate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'aggregate' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'cursor' => array(
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0,
					),
					'totals' => array(
						'type'    => 'object',
						'default' => array(),
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_settings' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'update_settings' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'args'                => array(
						'disabled_sizes'              => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
						'disable_big_image_threshold' => array(
							'type' => 'boolean',
						),
						'retention_days'              => array(
							'type'    => 'integer',
							'minimum' => 0,
							'maximum' => 3650,
						),
						'delete_scaled'               => array(
							'type' => 'boolean',
						),
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/regenerate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'regenerate_start' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'restart'     => array(
						'type'    => 'boolean',
						'default' => false,
					),
					// FR-6.1 / FR-6.3: 管理画面経路はプレビュー（診断集計）を
					// 経てから実行する。集計時点の照合値を必須で受け取る
					'fingerprint' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/regenerate/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'regenerate_step' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'job_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/regenerate/latest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'regenerate_latest' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/apply',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'apply_start' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'restart' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					// FR-6.1 / FR-6.3: プレビューに表示したスキャンだけを適用する
					'scan_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/apply/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'apply_step' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'job_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/apply/latest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'apply_latest' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/scan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'scan_start' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'restart' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/scan/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'scan_step' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'scan_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/scan/latest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'scan_latest' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/report',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_report' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'scan_id' => array(
						'type'    => 'integer',
						'minimum' => 1,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/plan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_plan_start' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'restart' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					// FR-6.1 / FR-6.3: プレビューに表示したスキャンを根拠に算出する
					'scan_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/plan/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_plan_step' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'job_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/run',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_run_start' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'restart' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					// FR-6.3: プレビューに表示した候補だけを隔離する
					'scan_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/run/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_run_step' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'job_id' => array(
						'type'     => 'integer',
						'minimum'  => 1,
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/latest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'cleanup_latest' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/restore',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_restore' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'cursor' => array(
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0,
					),
				),
			)
		);

		register_rest_route(
			self::ROUTE_NAMESPACE,
			'/cleanup/empty',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'cleanup_empty' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'cursor' => array(
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0,
					),
				),
			)
		);
	}

	/**
	 * 権限チェック（NFR-5.1）
	 */
	public static function can_manage(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * サイズ定義・保存済み統計・本文使用回数を返す
	 */
	public static function get_sizes(): WP_REST_Response {
		$scan  = Reference_Graph::latest_scan( Reference_Graph::SCAN_COMPLETE );
		$usage = null;

		if ( $scan ) {
			$usage = Reference_Graph::counts_by_size( (int) $scan->scan_id );
		}

		return rest_ensure_response(
			array(
				'sizes'             => Size_Registry::get_sizes(),
				'stats'             => Size_Registry::get_cached_stats(),
				'usage'             => $usage,
				'scan'              => $scan ? array(
					'scan_id'     => (int) $scan->scan_id,
					'finished_at' => $scan->finished_at,
				) : null,
				'attachments_total' => Size_Registry::count_image_attachments(),
			)
		);
	}

	/**
	 * 診断集計を1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function aggregate( WP_REST_Request $request ): WP_REST_Response {
		$cursor = absint( $request->get_param( 'cursor' ) );
		$totals = $request->get_param( 'totals' );

		$result = Size_Registry::aggregate_batch( $cursor, is_array( $totals ) ? $totals : array() );

		return rest_ensure_response( $result );
	}

	/**
	 * 生成オン／オフ（FR-2）と隔離（FR-5.2 / FR-5.5）の設定を返す
	 */
	public static function get_settings(): WP_REST_Response {
		return rest_ensure_response( Generation_Control::current() + Quarantine::settings() );
	}

	/**
	 * 生成オン／オフ（FR-2）と隔離（FR-5.2 / FR-5.5）の設定を更新する
	 *
	 * 送られたキーだけ更新する。disabled_sizes は登録済みサイズに対する
	 * 全量指定（未登録分の温存は Generation_Control::update が行う）。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function update_settings( WP_REST_Request $request ): WP_REST_Response {
		$disabled  = $request->get_param( 'disabled_sizes' );
		$threshold = $request->get_param( 'disable_big_image_threshold' );
		$retention = $request->get_param( 'retention_days' );
		$scaled    = $request->get_param( 'delete_scaled' );

		$generation = Generation_Control::update(
			is_array( $disabled ) ? $disabled : null,
			null === $threshold ? null : (bool) $threshold
		);

		$quarantine = Quarantine::update_settings(
			null === $retention ? null : absint( $retention ),
			null === $scaled ? null : (bool) $scaled
		);

		return rest_ensure_response( $generation + $quarantine );
	}

	/**
	 * 再生成を開始（進行中があれば再開）する
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function regenerate_start( WP_REST_Request $request ) {
		$result = Regenerator::start(
			(bool) $request->get_param( 'restart' ),
			(string) $request->get_param( 'fingerprint' )
		);

		if ( isset( $result['error'] ) && 'stale_preview' === $result['error'] ) {
			return new \WP_Error(
				'rgrl_preview_stale',
				__( 'The size definitions have changed since the preview was created. Update the preview, review it, and try again.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * 再生成を1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function regenerate_step( WP_REST_Request $request ) {
		$result = Regenerator::step( absint( $request->get_param( 'job_id' ) ) );

		if ( null === $result ) {
			return new \WP_Error(
				'rgrl_regenerate_not_running',
				__( 'The regeneration job is not running. Start a new one.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * 最新の再生成ジョブの状態と集計を返す
	 */
	public static function regenerate_latest(): WP_REST_Response {
		$job = Jobs::latest_job( Jobs::TYPE_REGENERATE );

		if ( ! $job ) {
			return rest_ensure_response( array( 'job' => null ) );
		}

		return rest_ensure_response(
			array(
				'job'    => array(
					'job_id'       => (int) $job->job_id,
					'status'       => $job->status,
					'images_total' => (int) $job->items_total,
					'images_done'  => (int) $job->items_done,
					'started_at'   => $job->started_at,
					'finished_at'  => $job->finished_at,
				),
				'totals' => Regenerator::normalize_totals( Jobs::decode_totals( $job ) ),
			)
		);
	}

	/**
	 * 参照更新を開始（進行中があれば再開）する
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function apply_start( WP_REST_Request $request ) {
		$result = Applier::start(
			(bool) $request->get_param( 'restart' ),
			absint( $request->get_param( 'scan_id' ) )
		);

		if ( isset( $result['error'] ) && 'no_scan' === $result['error'] ) {
			return new \WP_Error(
				'rgrl_apply_no_scan',
				__( 'No completed content scan was found. Run a scan first.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		if ( isset( $result['error'] ) && 'stale_preview' === $result['error'] ) {
			return new \WP_Error(
				'rgrl_preview_stale',
				__( 'A newer scan has completed since the preview was created. Update the preview, review it, and try again.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * 参照更新を1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function apply_step( WP_REST_Request $request ) {
		$result = Applier::step( absint( $request->get_param( 'job_id' ) ) );

		if ( null === $result ) {
			return new \WP_Error(
				'rgrl_apply_not_running',
				__( 'The update job is not running. Start a new one.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * 最新の参照更新ジョブの状態と集計を返す
	 */
	public static function apply_latest(): WP_REST_Response {
		$job = Jobs::latest_job( Jobs::TYPE_APPLY );

		if ( ! $job ) {
			return rest_ensure_response( array( 'job' => null ) );
		}

		return rest_ensure_response(
			array(
				'job'    => array(
					'job_id'      => (int) $job->job_id,
					'status'      => $job->status,
					'posts_total' => (int) $job->items_total,
					'posts_done'  => (int) $job->items_done,
					'started_at'  => $job->started_at,
					'finished_at' => $job->finished_at,
				),
				'totals' => Applier::normalize_totals( Jobs::decode_totals( $job ) ),
			)
		);
	}

	/**
	 * スキャンを開始（進行中があれば再開）する
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function scan_start( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( Scanner::start( (bool) $request->get_param( 'restart' ) ) );
	}

	/**
	 * スキャンを1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function scan_step( WP_REST_Request $request ) {
		$result = Scanner::step( absint( $request->get_param( 'scan_id' ) ) );

		if ( null === $result ) {
			return new \WP_Error(
				'rgrl_scan_not_running',
				__( 'The scan is not running. Start a new scan.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * dry-run レポートを返す（FR-6.2 / FR-6.6）
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function get_report( WP_REST_Request $request ) {
		$scan_id = $request->get_param( 'scan_id' );

		if ( null !== $scan_id && ! Reference_Graph::get_scan( absint( $scan_id ) ) ) {
			return new \WP_Error(
				'rgrl_report_not_found',
				__( 'The requested scan was not found.', 'regenerate-relink' ),
				array( 'status' => 404 )
			);
		}

		return rest_ensure_response( Report::build( null === $scan_id ? null : absint( $scan_id ) ) );
	}

	/**
	 * 削除候補の算出を開始（進行中があれば再開）する
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function cleanup_plan_start( WP_REST_Request $request ) {
		$result = Cleanup::start_plan(
			(bool) $request->get_param( 'restart' ),
			absint( $request->get_param( 'scan_id' ) )
		);

		return self::cleanup_error_or_response( $result );
	}

	/**
	 * 削除候補の算出を1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function cleanup_plan_step( WP_REST_Request $request ) {
		$result = Cleanup::step_plan( absint( $request->get_param( 'job_id' ) ) );

		if ( null === $result ) {
			return new \WP_Error(
				'rgrl_cleanup_plan_not_running',
				__( 'The cleanup planning job is not running. Start a new one.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( $result );
	}

	/**
	 * 隔離の実行を開始（進行中があれば再開）する
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function cleanup_run_start( WP_REST_Request $request ) {
		$result = Cleanup::start_run(
			(bool) $request->get_param( 'restart' ),
			absint( $request->get_param( 'scan_id' ) )
		);

		return self::cleanup_error_or_response( $result );
	}

	/**
	 * 隔離を1バッチ進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|\WP_Error
	 */
	public static function cleanup_run_step( WP_REST_Request $request ) {
		$result = Cleanup::step_run( absint( $request->get_param( 'job_id' ) ) );

		if ( null === $result ) {
			return new \WP_Error(
				'rgrl_cleanup_not_running',
				__( 'The quarantine job is not running. Start a new one.', 'regenerate-relink' ),
				array( 'status' => 409 )
			);
		}

		return self::cleanup_error_or_response( $result );
	}

	/**
	 * 隔離まわりの最新状態（ジョブ・使用量・設定）を返す
	 */
	public static function cleanup_latest(): WP_REST_Response {
		$plan = Jobs::latest_job( Jobs::TYPE_CLEANUP_PLAN );
		$run  = Jobs::latest_job( Jobs::TYPE_QUARANTINE );

		return rest_ensure_response(
			array(
				'plan'     => $plan ? array(
					'job_id'      => (int) $plan->job_id,
					'status'      => $plan->status,
					'total'       => (int) $plan->items_total,
					'done'        => (int) $plan->items_done,
					'started_at'  => $plan->started_at,
					'finished_at' => $plan->finished_at,
					'totals'      => Cleanup::normalize_plan_totals( Jobs::decode_totals( $plan ) ),
				) : null,
				'run'      => $run ? array(
					'job_id'      => (int) $run->job_id,
					'status'      => $run->status,
					'total'       => (int) $run->items_total,
					'done'        => (int) $run->items_done,
					'started_at'  => $run->started_at,
					'finished_at' => $run->finished_at,
					'totals'      => Cleanup::normalize_run_totals( Jobs::decode_totals( $run ) ),
				) : null,
				'usage'    => Quarantine::usage(),
				'settings' => Quarantine::settings(),
			)
		);
	}

	/**
	 * 隔離済みファイルの復元を1バッチ進める（FR-5.4）
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function cleanup_restore( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( Cleanup::restore_batch( absint( $request->get_param( 'cursor' ) ) ) );
	}

	/**
	 * 隔離領域の手動削除を1バッチ進める（FR-5.7）
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function cleanup_empty( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( Cleanup::empty_batch( absint( $request->get_param( 'cursor' ) ) ) );
	}

	/**
	 * Cleanup の error キーを REST エラーへ変換する
	 *
	 * @param array $result Cleanup::start_plan / start_run / step_run の戻り値。
	 * @return WP_REST_Response|\WP_Error
	 */
	private static function cleanup_error_or_response( array $result ) {
		if ( ! isset( $result['error'] ) ) {
			return rest_ensure_response( $result );
		}

		switch ( $result['error'] ) {
			case 'no_scan':
				return new \WP_Error(
					'rgrl_cleanup_no_scan',
					__( 'No completed content scan was found. Run a scan first.', 'regenerate-relink' ),
					array( 'status' => 409 )
				);

			case 'stale_preview':
				return new \WP_Error(
					'rgrl_preview_stale',
					__( 'A newer scan has completed since the preview was created. Update the preview, review it, and try again.', 'regenerate-relink' ),
					array( 'status' => 409 )
				);

			case 'no_plan':
				return new \WP_Error(
					'rgrl_cleanup_no_plan',
					__( 'No cleanup candidates have been calculated for this preview. Update the preview first.', 'regenerate-relink' ),
					array( 'status' => 409 )
				);

			case 'apply_incomplete':
				// FR-7.5: 実行を試みた時点で理由を提示して中断する
				return new \WP_Error(
					'rgrl_apply_incomplete',
					sprintf(
						/* translators: %s: 残っている更新予定の参照数 */
						__( 'Content references have not been updated yet (%s references are still waiting). Quarantining files before updating references would break images in your content, so run “Update content references” first.', 'regenerate-relink' ),
						number_format_i18n( (int) ( $result['pending'] ?? 0 ) )
					),
					array( 'status' => 409 )
				);

			case 'dir_failed':
				return new \WP_Error(
					'rgrl_quarantine_dir_failed',
					__( 'The quarantine directory could not be created. Check that the uploads directory is writable.', 'regenerate-relink' ),
					array( 'status' => 500 )
				);
		}

		return new \WP_Error(
			'rgrl_cleanup_failed',
			__( 'The cleanup operation could not be started.', 'regenerate-relink' ),
			array( 'status' => 500 )
		);
	}

	/**
	 * 最新スキャンの状態と集計を返す
	 */
	public static function scan_latest(): WP_REST_Response {
		$scan = Reference_Graph::latest_scan();

		if ( ! $scan ) {
			return rest_ensure_response( array( 'scan' => null ) );
		}

		$scan_id = (int) $scan->scan_id;

		return rest_ensure_response(
			array(
				'scan'     => array(
					'scan_id'       => $scan_id,
					'status'        => $scan->status,
					'posts_total'   => (int) $scan->posts_total,
					'posts_scanned' => (int) $scan->posts_scanned,
					'started_at'    => $scan->started_at,
					'finished_at'   => $scan->finished_at,
				),
				'statuses' => Reference_Graph::counts_by_status( $scan_id ),
				'skips'    => Reference_Graph::counts_by_skip_reason( $scan_id ),
			)
		);
	}
}
