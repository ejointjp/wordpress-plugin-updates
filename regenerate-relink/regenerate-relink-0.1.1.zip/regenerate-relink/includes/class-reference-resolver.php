<?php
/**
 * 参照の判定器（FR-4 の scan 側）
 *
 * 検出器が拾った「img 1つ分の生情報」を受け取り、
 *
 * 1. 参照ファイル名がその添付ファイル由来かを検証する（FR-4.3）
 * 2. サイズ名を確定する（属性 → クラス → ファイル名逆引きの順）
 * 3. 現在のメタデータに基づく「あるべき URL」を算出する（FR-4.2 / FR-4.9）
 *
 * を行って参照グラフの1行に落とす。判定に迷うものは必ず報告側へ倒す
 * （NFR-1.1）。URL はファイル名部分のみ差し替え、ゼロから組み立てない。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 参照1件の解決
 */
class Reference_Resolver {

	/**
	 * 添付ファイル情報のバッチ内キャッシュ
	 *
	 * @var array<int, array|null>
	 */
	private $attachments = array();

	/**
	 * img 1つ分の生情報から参照グラフの行を作る
	 *
	 * @param array $input {
	 *     post_id / route / position / url は必須。
	 *
	 *     @type int    $post_id       記事ID。
	 *     @type string $route         経路種別（block / html / caption）。
	 *     @type string $position      位置（ブロックパス等）。
	 *     @type string $url           現在の src。
	 *     @type int    $attachment_id 添付ID。0 = 不明。
	 *     @type string $size_name     ブロック属性由来のサイズ名。'' = 無し。
	 *     @type string $class_size    size-{slug} クラス由来のサイズ名。'' = 無し。
	 *     @type mixed  $width         現在の width 属性値。
	 *     @type mixed  $height        現在の height 属性値。
	 *     @type array  $details       details に加える付帯情報。
	 * }
	 * @return array|null 参照グラフ行。null = 記録対象外（本プラグインと無関係な画像）。
	 */
	public function resolve( array $input ) {
		$url           = (string) ( $input['url'] ?? '' );
		$attachment_id = (int) ( $input['attachment_id'] ?? 0 );
		$filename      = $this->extract_filename( $url );

		$row = array(
			'post_id'       => (int) ( $input['post_id'] ?? 0 ),
			'route'         => (string) ( $input['route'] ?? '' ),
			'position'      => (string) ( $input['position'] ?? '' ),
			'attachment_id' => $attachment_id,
			'size_name'     => '',
			'url'           => $url,
			'new_url'       => '',
			'status'        => Reference_Graph::REF_SKIP,
			'skip_reason'   => '',
			'details'       => is_array( $input['details'] ?? null ) ? $input['details'] : array(),
		);

		if ( '' === $url ) {
			return null;
		}

		if ( $attachment_id < 1 ) {
			// 添付IDが取れない画像は、アップロード由来らしきものだけ
			// 「スコープ外」として報告し、外部画像は記録しない。
			if ( ! $this->looks_like_upload( $url, $filename ) ) {
				return null;
			}

			$row['skip_reason'] = Reference_Graph::SKIP_OUT_OF_SCOPE;

			return $row;
		}

		$att = $this->attachment_info( $attachment_id );

		if ( null === $att ) {
			$row['skip_reason'] = Reference_Graph::SKIP_ATTACHMENT_MISSING;

			return $row;
		}

		// FR-4.3: 参照ファイル名がこの添付のファイル群
		// （原画・-scaled・各中間サイズ・中間サイズ命名規則）に一致するか。
		if ( ! $this->filename_in_family( $filename, $att ) ) {
			$row['skip_reason'] = Reference_Graph::SKIP_FILENAME_MISMATCH;

			return $row;
		}

		$size = $this->determine_size( $input, $filename, $att );

		if ( '' === $size ) {
			$row['skip_reason'] = Reference_Graph::SKIP_SIZE_UNKNOWN;

			return $row;
		}

		$row['size_name'] = $size;

		if ( 'full' === $size ) {
			// 原画参照はサイズ定義変更の影響を受けない。
			// -scaled と原画の使い分け（§10 未決 #3）にも踏み込まず、変更しない。
			$row['skip_reason'] = Reference_Graph::SKIP_NO_CHANGE;

			return $row;
		}

		if ( ! isset( $att['sizes'][ $size ] ) ) {
			// FR-4.9: 中間サイズが無いサイズ名への参照は
			// フルサイズへフォールバックさせず報告する。
			$row['skip_reason'] = Reference_Graph::SKIP_NO_INTERMEDIATE;

			return $row;
		}

		$new_filename = $att['sizes'][ $size ]['file'];

		$row['details']['new_width']  = $att['sizes'][ $size ]['width'];
		$row['details']['new_height'] = $att['sizes'][ $size ]['height'];

		if ( null !== ( $input['width'] ?? null ) ) {
			$row['details']['old_width'] = (int) $input['width'];
		}
		if ( null !== ( $input['height'] ?? null ) ) {
			$row['details']['old_height'] = (int) $input['height'];
		}

		if ( $filename === $new_filename ) {
			// FR-4.12: 参照がすでに現メタデータと一致していれば変更しない。
			$row['skip_reason'] = Reference_Graph::SKIP_NO_CHANGE;

			return $row;
		}

		$row['status']  = Reference_Graph::REF_UPDATE;
		$row['new_url'] = $this->replace_filename( $url, $new_filename );

		return $row;
	}

	/**
	 * URL からデコード済みファイル名を取り出す
	 *
	 * @param string $url URL。
	 */
	public function extract_filename( string $url ): string {
		$path = $this->strip_query_fragment( $url );
		$pos  = strrpos( $path, '/' );
		$name = false === $pos ? $path : substr( $path, $pos + 1 );

		return rawurldecode( $name );
	}

	/**
	 * URL のファイル名部分だけを差し替える（FR-4.2）
	 *
	 * スキーム・ホスト・ディレクトリ・クエリ・フラグメントは保存する。
	 * 旧ファイル名がパーセントエンコードされていた場合のみ、新ファイル名も
	 * エンコードする（NFR-3.2: 日本語ファイル名の表記を壊さない）。
	 *
	 * @param string $url          現在の URL。
	 * @param string $new_filename 新しいファイル名（デコード済み表記）。
	 */
	public function replace_filename( string $url, string $new_filename ): string {
		$fragment = '';
		$query    = '';

		$pos = strpos( $url, '#' );
		if ( false !== $pos ) {
			$fragment = substr( $url, $pos );
			$url      = substr( $url, 0, $pos );
		}

		$pos = strpos( $url, '?' );
		if ( false !== $pos ) {
			$query = substr( $url, $pos );
			$url   = substr( $url, 0, $pos );
		}

		$slash    = strrpos( $url, '/' );
		$dir      = false === $slash ? '' : substr( $url, 0, $slash + 1 );
		$old_name = false === $slash ? $url : substr( $url, $slash + 1 );

		if ( rawurldecode( $old_name ) !== $old_name ) {
			$new_filename = rawurlencode( $new_filename );
		}

		return $dir . $new_filename . $query . $fragment;
	}

	/**
	 * サイズ名を確定する
	 *
	 * 優先順: ブロック属性 → size-{slug} クラス → ファイル名の逆引き。
	 * 逆引きは現メタデータの各中間サイズのファイル名との完全一致、
	 * または原画・-scaled ファイル名（= full）。
	 *
	 * @param array  $input    resolve() の入力。
	 * @param string $filename デコード済み参照ファイル名。
	 * @param array  $att      attachment_info() の結果。
	 * @return string サイズ名。'' = 確定できない。
	 */
	private function determine_size( array $input, string $filename, array $att ): string {
		$from_attr = (string) ( $input['size_name'] ?? '' );
		if ( '' !== $from_attr ) {
			return $from_attr;
		}

		$from_class = (string) ( $input['class_size'] ?? '' );
		if ( '' !== $from_class ) {
			return $from_class;
		}

		foreach ( $att['sizes'] as $name => $size_meta ) {
			if ( $filename === $size_meta['file'] ) {
				return (string) $name;
			}
		}

		if ( in_array( $filename, $att['full_files'], true ) ) {
			return 'full';
		}

		return '';
	}

	/**
	 * ファイル名がこの添付のファイル群由来か検証する（FR-4.3）
	 *
	 * 一致対象は、原画・-scaled・現メタデータの各中間サイズと、
	 * 過去の再生成で作られた可能性のある {原画名}-{幅}x{高さ}.{拡張子}。
	 * それ以外はすべて「別物」とみなし更新しない。
	 *
	 * @param string $filename デコード済み参照ファイル名。
	 * @param array  $att      attachment_info() の結果。
	 */
	private function filename_in_family( string $filename, array $att ): bool {
		if ( in_array( $filename, $att['full_files'], true ) ) {
			return true;
		}

		foreach ( $att['sizes'] as $size_meta ) {
			if ( $filename === $size_meta['file'] ) {
				return true;
			}
		}

		foreach ( $att['stems'] as $stem ) {
			$pattern = '/^' . preg_quote( $stem, '/' ) . '-\d+x\d+\.' . preg_quote( $att['ext'], '/' ) . '$/';

			if ( preg_match( $pattern, $filename ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * URL がアップロード画像らしいか（添付ID不明時の記録判定）
	 *
	 * @param string $url      URL。
	 * @param string $filename デコード済みファイル名。
	 */
	private function looks_like_upload( string $url, string $filename ): bool {
		if ( false !== strpos( $url, '/wp-content/uploads/' ) ) {
			return true;
		}

		return (bool) preg_match( '/-\d+x\d+\.(jpe?g|png|gif|webp|avif)$/i', $filename );
	}

	/**
	 * 添付のファイル情報をまとめて返す（バッチ内キャッシュ付き）
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array|null {
	 *     @type array $sizes      メタデータの sizes（file/width/height）。
	 *     @type array $full_files 原画として扱うファイル名（メイン・original_image）。
	 *     @type array $stems      中間サイズ命名規則の照合に使う stem。
	 *     @type string $ext       拡張子。
	 * } 画像添付でなければ null。
	 */
	private function attachment_info( int $attachment_id ) {
		if ( array_key_exists( $attachment_id, $this->attachments ) ) {
			return $this->attachments[ $attachment_id ];
		}

		$info = null;
		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( is_array( $meta ) && ! empty( $meta['file'] ) ) {
			$main_file = wp_basename( (string) $meta['file'] );
			$ext       = strtolower( (string) pathinfo( $main_file, PATHINFO_EXTENSION ) );

			$full_files = array( $main_file );
			$stems      = array( (string) pathinfo( $main_file, PATHINFO_FILENAME ) );

			if ( ! empty( $meta['original_image'] ) ) {
				// 大画像は file が -scaled、original_image が真の原画（FR-3.3 の元）。
				// 中間サイズの stem は原画名ベースで生成される（実測済み）。
				$original     = wp_basename( (string) $meta['original_image'] );
				$full_files[] = $original;
				$stems[]      = (string) pathinfo( $original, PATHINFO_FILENAME );
			}

			$sizes = array();
			if ( isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
				foreach ( $meta['sizes'] as $name => $size_meta ) {
					if ( is_array( $size_meta ) && ! empty( $size_meta['file'] ) ) {
						$sizes[ $name ] = array(
							'file'   => (string) $size_meta['file'],
							'width'  => (int) ( $size_meta['width'] ?? 0 ),
							'height' => (int) ( $size_meta['height'] ?? 0 ),
						);
					}
				}
			}

			$info = array(
				'sizes'      => $sizes,
				'full_files' => array_values( array_unique( $full_files ) ),
				'stems'      => array_values( array_unique( $stems ) ),
				'ext'        => $ext,
			);
		}

		$this->attachments[ $attachment_id ] = $info;

		return $info;
	}

	/**
	 * クエリとフラグメントを除いたパス部分を返す
	 *
	 * @param string $url URL。
	 */
	private function strip_query_fragment( string $url ): string {
		$pos = strpos( $url, '#' );
		if ( false !== $pos ) {
			$url = substr( $url, 0, $pos );
		}

		$pos = strpos( $url, '?' );
		if ( false !== $pos ) {
			$url = substr( $url, 0, $pos );
		}

		return $url;
	}
}
