<?php
/**
 * 自己ホストの更新チェック
 *
 * wordpress.org には載せていないので、更新の情報は配布用のリポジトリ
 * （ejointjp/wordpress-plugin-updates）に置いた info.json から取る。
 * メインファイルのヘッダーに Update URI（https://yuiami.jp/wp-plugins/regenerate-relink）が
 * あると、WordPress はこのプラグインの更新を wordpress.org に問い合わせず、そのホスト名の付いた
 * フィルタ update_plugins_yuiami.jp を呼ぶ。Update URI は識別子で、実在しなくてよい。
 *
 * - 更新の判定（update_plugins_yuiami.jp）は、キャッシュを読まずに毎回取得する。
 *   本体が12時間おきにしか確認しないうえ、「再確認」ですぐ反映させたいため
 * - 詳細の表示（plugins_api）は、1時間キャッシュした情報を使う
 * - 取得できなければ、理由を PHP のエラーログに残して「更新なし」として扱う
 * - 問い合わせで送るのは、info.json の URL と固定の User-Agent だけ。サイトの URL やデータは送らない
 *
 * フックの登録は Plugin::boot()。定期の更新チェックは wp-cron で動くので、admin 判定の外に置く。
 * プラグインが停止中のサイトでは動かない。
 * 中身は /wp-plugin-publish のひな形（assets/selfhost/update-checker.php）と同じで、
 * クラスにまとめる形だけをこのプラグインの書き方に合わせてある。導入の手順は同スキルの references/selfhost.md。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 配布用のリポジトリにある最新版の情報を、WordPress の更新の仕組みへ渡す
 */
class Update_Checker {

	const SLUG = 'regenerate-relink';

	/**
	 * 配布用のリポジトリの、このプラグインの置き場
	 */
	const BASE_URL = 'https://raw.githubusercontent.com/ejointjp/wordpress-plugin-updates/main/regenerate-relink/';

	/**
	 * 更新の情報のキャッシュ（サイトのトランジェント）の名前。uninstall.php が同じ名前で消す
	 */
	const INFO_TRANSIENT = 'rgrl_update_info';

	/**
	 * 更新の判定に、配布用のリポジトリにある最新版の情報を返す
	 *
	 * update_plugins_yuiami.jp のコールバック。新しいかどうかは本体が比べる。
	 *
	 * @param array|false $update      ここまでのフィルタの結果。
	 * @param array       $plugin_data プラグインのヘッダー。
	 * @param string      $plugin_file プラグインのファイル（plugin_basename() の形）。
	 * @return array|false
	 */
	public static function filter_update( $update, $plugin_data, $plugin_file ) {
		if ( plugin_basename( RGRL_FILE ) !== $plugin_file ) {
			return $update;
		}

		$info = self::get_info( true );

		if ( null === $info ) {
			return $update;
		}

		return array(
			'slug'         => self::SLUG,
			'version'      => $info['version'],
			'package'      => $info['package'],
			'url'          => isset( $plugin_data['AuthorURI'] ) ? $plugin_data['AuthorURI'] : '',
			'requires'     => self::field( $info, 'requires' ),
			'requires_php' => self::field( $info, 'requires_php' ),
			'tested'       => self::tested( self::field( $info, 'tested' ) ),
		);
	}

	/**
	 * 「詳細を表示」のポップアップに、配布用のリポジトリにある情報を返す
	 *
	 * plugins_api のコールバック。
	 *
	 * @param false|object|array $result ここまでのフィルタの結果。
	 * @param string             $action plugins_api() の種類。
	 * @param object             $args   plugins_api() の引数。
	 * @return false|object|array|\WP_Error
	 */
	public static function filter_plugin_information( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}

		$info = self::get_info( false );

		if ( null === $info ) {
			// false のまま返すと、本体が wordpress.org の同じ slug を見に行く。エラーにして止める。
			return new \WP_Error( 'rgrl_update_info', __( 'The update information could not be retrieved. Please try again later.', 'regenerate-relink' ) );
		}

		$sections = isset( $info['sections'] ) && is_array( $info['sections'] ) ? array_filter( $info['sections'], 'is_string' ) : array();

		return (object) array(
			'name'          => esc_html( self::field( $info, 'name' ) ),
			'slug'          => self::SLUG,
			'version'       => $info['version'],
			'author'        => esc_html( self::field( $info, 'author' ) ),
			'requires'      => self::field( $info, 'requires' ),
			'requires_php'  => self::field( $info, 'requires_php' ),
			'tested'        => self::tested( self::field( $info, 'tested' ) ),
			'last_updated'  => self::field( $info, 'last_updated' ),
			'sections'      => $sections,
			'download_link' => $info['package'],
			// wordpress.org のプラグインページへのリンクを出さない。
			'external'      => true,
		);
	}

	/**
	 * 更新の情報（info.json）を返す
	 *
	 * @param bool $fresh true ならキャッシュを読まずに取得する。
	 * @return array|null 取得できなければ null。
	 */
	private static function get_info( bool $fresh ): ?array {
		if ( ! $fresh ) {
			$cached = get_site_transient( self::INFO_TRANSIENT );

			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		// WordPress の既定の User-Agent はサイトの URL を含む。配布元へ送らないよう、固定の文字列にする。
		$response = wp_remote_get(
			self::BASE_URL . 'info.json',
			array(
				'timeout'    => 10,
				'user-agent' => 'regenerate-relink update check',
			)
		);

		if ( is_wp_error( $response ) ) {
			self::log( $response->get_error_message() );

			return null;
		}

		$status = wp_remote_retrieve_response_code( $response );

		if ( 200 !== $status ) {
			self::log( 'HTTP ' . $status );

			return null;
		}

		$info = json_decode( wp_remote_retrieve_body( $response ), true );

		// zip の URL は、このプラグインの置き場にあるものだけを受け付ける。
		if (
			! is_array( $info )
			|| '' === self::field( $info, 'version' )
			|| 0 !== strpos( self::field( $info, 'package' ), self::BASE_URL )
		) {
			self::log( 'info.json is not valid' );

			return null;
		}

		set_site_transient( self::INFO_TRANSIENT, $info, HOUR_IN_SECONDS );

		return $info;
	}

	/**
	 * 更新の情報を取得できなかった理由を、PHP のエラーログに残す
	 *
	 * @param string $reason 理由。
	 */
	private static function log( string $reason ): void {
		error_log( 'Regenerate & Relink update check: ' . $reason ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 更新の情報を取得できなかった理由を残すため
	}

	/**
	 * 更新の情報から文字列の項目を取り出す
	 *
	 * @param array  $info 更新の情報。
	 * @param string $key  項目名。
	 * @return string なければ空文字。
	 */
	private static function field( array $info, string $key ): string {
		return isset( $info[ $key ] ) && is_string( $info[ $key ] ) ? $info[ $key ] : '';
	}

	/**
	 * 「Tested up to」を、サイトの WordPress と同じ系列なら、サイトの版に読み替える
	 *
	 * readme.txt にはメジャー番号だけ（7.1）を書く。本体は version_compare() で比べるので、
	 * そのまま返すと、7.1.2 のサイトで「テストされていない」と表示される。
	 * wordpress.org の API も、同じ系列の最新のパッチ版に読み替えて返す。
	 *
	 * @param string $tested info.json の tested。
	 */
	private static function tested( string $tested ): string {
		$current = get_bloginfo( 'version' );

		if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $current, $tested . '.' ) ) {
			return $current;
		}

		return $tested;
	}
}
