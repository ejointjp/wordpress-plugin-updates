<?php
/**
 * カスタムテーブルの作成と版管理
 *
 * 参照グラフ（FR-10）は次の2テーブルで構成する。
 *
 * - rgrl_scans: スキャン単位（FR-10.5）。実行状態と再開カーソルを持つ
 * - rgrl_refs:  参照そのもの（FR-10.1〜10.3）。参照元（記事）と参照先（添付）の
 *   双方にインデックスを張り、双方向から引けるようにする
 *
 * これに加えて、再生成（FR-3）などの長時間バッチ処理の実行状態を
 * rgrl_jobs で持つ。ジョブ種別ごとの詳細カウンタは totals（JSON）に格納する。
 *
 * 隔離（FR-5）は rgrl_quarantine が「削除候補リスト」と「隔離マニフェスト」
 * （FR-5.3: 退避先・元パス・添付ID・日時）を兼ねる。候補行（candidate /
 * report）はプレビューのたびに作り直し、隔離済み行（quarantined 以降）は
 * 監査記録として残す。
 *
 * テーブル・オプションを増やしたら uninstall.php を同じコミットで更新すること。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * テーブル作成・アップグレード
 */
class Schema {

	const DB_VERSION_OPTION = 'rgrl_db_version';

	/**
	 * アクティベーション時の処理
	 */
	public static function activate(): void {
		self::create_tables();
	}

	/**
	 * スキーマ版がズレていたら作り直す
	 *
	 * dbDelta は冪等なので、既存テーブルには差分だけが適用される。
	 */
	public static function maybe_upgrade(): void {
		if ( RGRL_DB_VERSION !== get_option( self::DB_VERSION_OPTION ) ) {
			self::create_tables();
		}
	}

	/**
	 * テーブルを作成する
	 *
	 * dbDelta の整形規約（PRIMARY KEY の後ろはスペース2つ、KEY は1行1定義）を
	 * 崩さないこと。崩すと差分検出が誤作動し、実行のたびに ALTER が走る。
	 */
	public static function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}rgrl_scans (
  scan_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  status varchar(20) NOT NULL DEFAULT 'running',
  started_at datetime NOT NULL,
  finished_at datetime DEFAULT NULL,
  posts_total int(11) unsigned NOT NULL DEFAULT 0,
  posts_scanned int(11) unsigned NOT NULL DEFAULT 0,
  last_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (scan_id),
  KEY status (status)
) $charset_collate;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}rgrl_jobs (
  job_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  job_type varchar(20) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'running',
  started_at datetime NOT NULL,
  finished_at datetime DEFAULT NULL,
  items_total int(11) unsigned NOT NULL DEFAULT 0,
  items_done int(11) unsigned NOT NULL DEFAULT 0,
  last_item_id bigint(20) unsigned NOT NULL DEFAULT 0,
  totals longtext,
  PRIMARY KEY  (job_id),
  KEY type_status (job_type,status)
) $charset_collate;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}rgrl_quarantine (
  file_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  scan_id bigint(20) unsigned NOT NULL DEFAULT 0,
  attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
  size_name varchar(64) NOT NULL DEFAULT '',
  rel_path text NOT NULL,
  bytes bigint(20) unsigned NOT NULL DEFAULT 0,
  status varchar(20) NOT NULL DEFAULT 'candidate',
  reason varchar(32) NOT NULL DEFAULT '',
  stored_name varchar(191) NOT NULL DEFAULT '',
  quarantined_at datetime DEFAULT NULL,
  details longtext,
  PRIMARY KEY  (file_id),
  KEY scan_status (scan_id,status),
  KEY status (status),
  KEY attachment (attachment_id)
) $charset_collate;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}rgrl_refs (
  ref_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  scan_id bigint(20) unsigned NOT NULL,
  post_id bigint(20) unsigned NOT NULL,
  route varchar(32) NOT NULL DEFAULT '',
  position varchar(191) NOT NULL DEFAULT '',
  attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
  size_name varchar(64) NOT NULL DEFAULT '',
  url text NOT NULL,
  new_url text,
  status varchar(20) NOT NULL DEFAULT 'found',
  skip_reason varchar(32) NOT NULL DEFAULT '',
  details longtext,
  PRIMARY KEY  (ref_id),
  KEY scan_post (scan_id,post_id),
  KEY scan_attachment (scan_id,attachment_id),
  KEY scan_status (scan_id,status)
) $charset_collate;"
		);

		update_option( self::DB_VERSION_OPTION, RGRL_DB_VERSION );
	}
}
