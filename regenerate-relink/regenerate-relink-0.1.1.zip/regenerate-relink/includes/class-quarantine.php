<?php
/**
 * 隔離領域とマニフェストのデータ層（FR-5）
 *
 * rgrl_quarantine テーブルは「削除候補リスト」と「隔離マニフェスト」
 * （FR-5.3: 退避先・元パス・添付ID・日時）を兼ねる。候補の算出と
 * 隔離・復元の実行は Cleanup クラスが担い、本クラスは格納・照会・
 * 隔離領域（ディレクトリ）の管理・期限切れの自動削除（FR-5.5）に徹する。
 *
 * 隔離領域は uploads 直下の推測困難なランダム名ディレクトリに平置きし、
 * .htaccess と空 index.php で Web からの直接アクセスを遮る（FR-5.6）。
 * nginx 等 .htaccess が効かない環境ではディレクトリ名のランダム性が
 * 実質的な防御となる。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- カスタムテーブルのデータ層のため $wpdb 直接クエリが本務。結果の再利用は呼び出し側の責務とする。

/**
 * 隔離マニフェストの格納・照会と隔離領域の管理
 */
class Quarantine {
	/*
	 * 行の状態
	 *
	 * candidate / report はプレビュー（plan）のたびに作り直す使い捨て。
	 * quarantined 以降はマニフェスト＝監査記録として残す。
	 *
	 * candidate   = 隔離候補（実行待ち）
	 * report      = 報告のみ（FR-5.1 の条件を欠く。reason に理由）
	 * quarantined = 隔離済み（復元可能）
	 * restored    = 復元済み
	 * purged      = 完全削除済み（自動削除・手動空にする）
	 * skipped     = 実行時に前提が変わり見送った（FR-6.4）
	 */
	const ST_CANDIDATE   = 'candidate';
	const ST_REPORT      = 'report';
	const ST_QUARANTINED = 'quarantined';
	const ST_RESTORED    = 'restored';
	const ST_PURGED      = 'purged';
	const ST_SKIPPED     = 'skipped';

	/*
	 * 候補の理由（なぜ削除対象になったか）
	 *
	 * orphaned      = 現在のメタデータに含まれない中間サイズファイル
	 * disabled_size = 生成を停止したサイズのファイル（FR-5.1.3）
	 * scaled        = -scaled 本体（FR-5.2 のオプトイン時のみ）
	 */
	const REASON_ORPHANED = 'orphaned';
	const REASON_DISABLED = 'disabled_size';
	const REASON_SCALED   = 'scaled';

	/*
	 * 報告のみの理由（どの条件を欠いたか）
	 *
	 * referenced        = 本文から参照されている（FR-5.1.4）
	 * claimed_elsewhere = 他の添付・編集バックアップがこのファイル名を使用
	 */
	const REASON_REFERENCED = 'referenced';
	const REASON_CLAIMED    = 'claimed_elsewhere';

	/*
	 * 実行時スキップ・復元失敗の理由
	 */
	const REASON_PRECONDITION   = 'precondition_changed';
	const REASON_FILE_MISSING   = 'file_missing';
	const REASON_PATH_INVALID   = 'path_invalid';
	const REASON_MOVE_FAILED    = 'move_failed';
	const REASON_CONFLICT       = 'restore_conflict';
	const REASON_RESTORE_FAILED = 'restore_failed';

	/**
	 * 自動削除の cron フック名
	 */
	const PURGE_HOOK = 'rgrl_quarantine_purge';

	/**
	 * 保持期間（日）の既定値（FR-5.5）
	 */
	const DEFAULT_RETENTION_DAYS = 30;

	/**
	 * 1回の cron 実行で削除処理に使う時間の上限（秒）
	 */
	const PURGE_TIME_BUDGET = 30;

	/*
	 * ---------------------------------------------------------------------
	 * 設定（FR-5.2 / FR-5.5）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 隔離まわりの設定を返す
	 *
	 * @return array { retention_days: int（0 = 手動で削除するまで保持）,
	 *                 delete_scaled: bool }
	 */
	public static function settings(): array {
		$settings = get_option( Generation_Control::SETTINGS_OPTION, array() );
		$settings = is_array( $settings ) ? $settings : array();

		$days = isset( $settings['quarantine_retention_days'] )
			? absint( $settings['quarantine_retention_days'] )
			: self::DEFAULT_RETENTION_DAYS;

		return array(
			'retention_days' => $days,
			'delete_scaled'  => ! empty( $settings['delete_scaled'] ),
		);
	}

	/**
	 * 隔離まわりの設定を更新する
	 *
	 * @param int|null  $retention_days 保持日数。0 = 手動まで保持。null なら変更しない。
	 * @param bool|null $delete_scaled  -scaled を隔離対象にするか（FR-5.2）。null なら変更しない。
	 * @return array 更新後の設定（settings() と同形）。
	 */
	public static function update_settings( ?int $retention_days, ?bool $delete_scaled ): array {
		$settings = get_option( Generation_Control::SETTINGS_OPTION, array() );
		$settings = is_array( $settings ) ? $settings : array();

		if ( null !== $retention_days ) {
			$settings['quarantine_retention_days'] = absint( $retention_days );
		}

		if ( null !== $delete_scaled ) {
			$settings['delete_scaled'] = $delete_scaled;
		}

		update_option( Generation_Control::SETTINGS_OPTION, $settings );

		return self::settings();
	}

	/*
	 * ---------------------------------------------------------------------
	 * 隔離領域（FR-5.6）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 隔離ディレクトリの絶対パスを返す。無ければ作る
	 *
	 * @return string|null 作成に失敗した場合は null。
	 */
	public static function ensure_dir(): ?string {
		$settings = get_option( Generation_Control::SETTINGS_OPTION, array() );
		$settings = is_array( $settings ) ? $settings : array();

		$dirname = (string) ( $settings['quarantine_dir'] ?? '' );

		if ( '' === $dirname ) {
			$dirname = 'rgrl-quarantine-' . wp_generate_password( 12, false, false );

			$settings['quarantine_dir'] = $dirname;
			update_option( Generation_Control::SETTINGS_OPTION, $settings );
		}

		$upload_dir = wp_get_upload_dir();
		$dir        = trailingslashit( $upload_dir['basedir'] ) . $dirname;

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return null;
		}

		self::write_guard_files( $dir );

		return $dir;
	}

	/**
	 * 隔離ディレクトリの絶対パスを返す（作成はしない）
	 *
	 * @return string|null 未作成なら null。
	 */
	public static function dir(): ?string {
		$settings = get_option( Generation_Control::SETTINGS_OPTION, array() );
		$dirname  = is_array( $settings ) ? (string) ( $settings['quarantine_dir'] ?? '' ) : '';

		if ( '' === $dirname ) {
			return null;
		}

		$upload_dir = wp_get_upload_dir();
		$dir        = trailingslashit( $upload_dir['basedir'] ) . $dirname;

		return is_dir( $dir ) ? $dir : null;
	}

	/**
	 * Web からの直接アクセスを遮るファイルを配置する（FR-5.6）
	 *
	 * @param string $dir 隔離ディレクトリの絶対パス。
	 */
	private static function write_guard_files( string $dir ): void {
		$htaccess = trailingslashit( $dir ) . '.htaccess';

		if ( ! file_exists( $htaccess ) ) {
			$rules = "# Regenerate & Relink quarantine area — deny all web access.\n"
				. "<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n"
				. "<IfModule !mod_authz_core.c>\n\tOrder deny,allow\n\tDeny from all\n</IfModule>\n";

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- uploads 配下への小ファイル配置。WP_Filesystem の資格情報要求は REST/cron 文脈では使えない。
			file_put_contents( $htaccess, $rules );
		}

		$index = trailingslashit( $dir ) . 'index.php';

		if ( ! file_exists( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- 上と同じ。
			file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}
	}

	/*
	 * ---------------------------------------------------------------------
	 * マニフェストの格納・照会
	 * ---------------------------------------------------------------------
	 */

	/**
	 * プレビュー行（candidate / report）を全削除する
	 *
	 * plan の開始時に呼び、古いプレビューの残骸が新しい候補集計へ
	 * 混ざらないようにする。隔離済み以降の行（マニフェスト）は消さない。
	 */
	public static function clear_plan_rows(): void {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}rgrl_quarantine WHERE status IN (%s, %s)",
				self::ST_CANDIDATE,
				self::ST_REPORT
			)
		);
	}

	/**
	 * 行をまとめて追加する
	 *
	 * @param array $rows 各要素は scan_id / attachment_id / size_name / rel_path /
	 *                    bytes / status / reason / details（配列可）を持つ連想配列。
	 * @return int 挿入した行数。
	 */
	public static function add_rows( array $rows ): int {
		global $wpdb;

		if ( empty( $rows ) ) {
			return 0;
		}

		$placeholders = array();
		$values       = array();

		foreach ( $rows as $row ) {
			$placeholders[] = '(%d, %d, %s, %s, %d, %s, %s, %s)';

			$details = $row['details'] ?? '';

			if ( is_array( $details ) ) {
				$details = (string) wp_json_encode( $details );
			}

			$values[] = (int) ( $row['scan_id'] ?? 0 );
			$values[] = (int) ( $row['attachment_id'] ?? 0 );
			$values[] = (string) ( $row['size_name'] ?? '' );
			$values[] = (string) ( $row['rel_path'] ?? '' );
			$values[] = (int) ( $row['bytes'] ?? 0 );
			$values[] = (string) ( $row['status'] ?? self::ST_CANDIDATE );
			$values[] = (string) ( $row['reason'] ?? '' );
			$values[] = (string) $details;
		}

		$sql = "INSERT INTO {$wpdb->prefix}rgrl_quarantine
			(scan_id, attachment_id, size_name, rel_path, bytes, status, reason, details)
			VALUES " . implode( ",\n", $placeholders );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql はプレースホルダのみで組み立てており、値はすべて prepare() に渡している。
		$result = $wpdb->query( $wpdb->prepare( $sql, $values ) );

		return false === $result ? 0 : (int) $result;
	}

	/**
	 * 行を1件取得する
	 *
	 * @param int $file_id 行ID。
	 * @return object|null
	 */
	public static function get_row( int $file_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_quarantine WHERE file_id = %d",
				$file_id
			)
		);
	}

	/**
	 * 行の状態・付帯情報を更新する
	 *
	 * @param int   $file_id 行ID。
	 * @param array $fields  更新するカラム。details は配列で渡す（JSON 化はここで行う）。
	 *                       許可外のキーは無視する。
	 * @return bool 1行更新できたか。
	 */
	public static function update_row( int $file_id, array $fields ): bool {
		global $wpdb;

		$allowed = array(
			'status'         => '%s',
			'reason'         => '%s',
			'stored_name'    => '%s',
			'quarantined_at' => '%s',
			'bytes'          => '%d',
			'details'        => '%s',
		);

		if ( isset( $fields['details'] ) && is_array( $fields['details'] ) ) {
			$fields['details'] = (string) wp_json_encode( $fields['details'] );
		}

		$data    = array();
		$formats = array();

		foreach ( $allowed as $key => $format ) {
			if ( array_key_exists( $key, $fields ) ) {
				$data[ $key ] = $fields[ $key ];
				$formats[]    = $format;
			}
		}

		if ( empty( $data ) ) {
			return false;
		}

		$updated = $wpdb->update(
			$wpdb->prefix . 'rgrl_quarantine',
			$data,
			array( 'file_id' => $file_id ),
			$formats,
			array( '%d' )
		);

		return 1 === $updated;
	}

	/**
	 * 行の details（JSON）を配列に戻す
	 *
	 * @param object|null $row 行。
	 * @return array 壊れている場合は空配列。
	 */
	public static function decode_details( $row ): array {
		if ( ! $row || empty( $row->details ) ) {
			return array();
		}

		$details = json_decode( (string) $row->details, true );

		return is_array( $details ) ? $details : array();
	}

	/**
	 * 指定状態の行をカーソル式で取得する
	 *
	 * @param string $status        状態（ST_* 定数）。
	 * @param int    $after_file_id この行IDより大きいものから。
	 * @param int    $limit         件数。
	 * @return object[]
	 */
	public static function rows_batch( string $status, int $after_file_id, int $limit ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_quarantine
				WHERE status = %s AND file_id > %d
				ORDER BY file_id LIMIT %d",
				$status,
				$after_file_id,
				$limit
			)
		);
	}

	/**
	 * スキャンに紐づく全行をカーソル式で取得する（CSV エクスポート用）
	 *
	 * quarantined 以降のマニフェスト行は scan_id に関わらず含める
	 * （「いま隔離領域に何があるか」を1枚で見渡せるようにする）。
	 *
	 * @param int $scan_id       プレビュー行を絞るスキャンID。
	 * @param int $after_file_id この行IDより大きいものから。
	 * @param int $limit         件数。
	 * @return object[]
	 */
	public static function export_batch( int $scan_id, int $after_file_id, int $limit ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_quarantine
				WHERE ( scan_id = %d OR status IN (%s, %s) ) AND file_id > %d
				ORDER BY file_id LIMIT %d",
				$scan_id,
				self::ST_QUARANTINED,
				self::ST_RESTORED,
				$after_file_id,
				$limit
			)
		);
	}

	/**
	 * 状態・理由ごとの件数と容量を集計する
	 *
	 * @param int|null $scan_id スキャンで絞る場合に指定（candidate / report 向け）。
	 * @return array<string, array<string, array{files: int, bytes: int}>> status => reason => 集計。
	 */
	public static function breakdown( ?int $scan_id = null ): array {
		global $wpdb;

		if ( null === $scan_id ) {
			$rows = $wpdb->get_results(
				"SELECT status, reason, COUNT(*) AS files, COALESCE(SUM(bytes), 0) AS bytes
				FROM {$wpdb->prefix}rgrl_quarantine
				GROUP BY status, reason"
			);
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT status, reason, COUNT(*) AS files, COALESCE(SUM(bytes), 0) AS bytes
					FROM {$wpdb->prefix}rgrl_quarantine
					WHERE scan_id = %d
					GROUP BY status, reason",
					$scan_id
				)
			);
		}

		$out = array();

		foreach ( $rows as $row ) {
			$out[ $row->status ][ $row->reason ] = array(
				'files' => (int) $row->files,
				'bytes' => (int) $row->bytes,
			);
		}

		return $out;
	}

	/**
	 * 指定状態の行数を数える
	 *
	 * @param string $status 状態（ST_* 定数）。
	 */
	public static function count_status( string $status ): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}rgrl_quarantine WHERE status = %s",
				$status
			)
		);
	}

	/**
	 * 隔離領域の現在の使用量を返す（FR-5.7）
	 *
	 * @return array{files: int, bytes: int}
	 */
	public static function usage(): array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS files, COALESCE(SUM(bytes), 0) AS bytes
				FROM {$wpdb->prefix}rgrl_quarantine
				WHERE status = %s",
				self::ST_QUARANTINED
			)
		);

		return array(
			'files' => $row ? (int) $row->files : 0,
			'bytes' => $row ? (int) $row->bytes : 0,
		);
	}

	/**
	 * candidate 行が属するスキャンIDを返す
	 *
	 * plan の結果がどのスキャンを根拠にしているかの照合（FR-6.3）に使う。
	 *
	 * @return int candidate 行が無ければ 0。
	 */
	public static function plan_scan_id(): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT scan_id FROM {$wpdb->prefix}rgrl_quarantine
				WHERE status IN (%s, %s) ORDER BY file_id LIMIT 1",
				self::ST_CANDIDATE,
				self::ST_REPORT
			)
		);
	}

	/*
	 * ---------------------------------------------------------------------
	 * 自動削除（FR-5.5）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 自動削除の日次イベントを登録する（未登録のときだけ）
	 */
	public static function schedule_purge(): void {
		if ( ! wp_next_scheduled( self::PURGE_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::PURGE_HOOK );
		}
	}

	/**
	 * 自動削除の日次イベントを解除する
	 */
	public static function unschedule_purge(): void {
		wp_clear_scheduled_hook( self::PURGE_HOOK );
	}

	/**
	 * 保持期間を過ぎた隔離ファイルを完全削除する（cron コールバック）
	 *
	 * 時間予算を超えたら打ち切り、残りは翌日の実行に回す（NFR-2.3）。
	 * ファイルが既に無い行も purged へ倒す（再実行で整合が回復する。NFR-1.6）。
	 */
	public static function purge_expired(): void {
		$settings = self::settings();

		if ( $settings['retention_days'] < 1 ) {
			// 「手動で削除するまで保持」（FR-5.5）
			return;
		}

		$threshold = gmdate( 'Y-m-d H:i:s', time() - $settings['retention_days'] * DAY_IN_SECONDS );
		$started   = microtime( true );

		for ( ;; ) {
			$rows = self::expired_rows( $threshold, 50 );

			if ( empty( $rows ) ) {
				break;
			}

			foreach ( $rows as $row ) {
				self::purge_row( $row );

				if ( microtime( true ) - $started > self::PURGE_TIME_BUDGET ) {
					return;
				}
			}
		}
	}

	/**
	 * 隔離済み1行の実ファイルを削除し、purged として記録する
	 *
	 * ファイルが既に無い行も purged へ倒す（再実行で整合が回復する）。
	 * 削除に失敗した行は quarantined のまま残し、次回に再試行する。
	 *
	 * @param object $row quarantined 状態の行。
	 * @return bool 行を purged にできたか。
	 */
	public static function purge_row( $row ): bool {
		$dir = self::dir();

		if ( null !== $dir && '' !== (string) $row->stored_name ) {
			$path = trailingslashit( $dir ) . $row->stored_name;

			// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink -- 削除失敗は戻り値で検出して行を残す。並行削除の TOCTOU があるため事前チェックでは警告を防ぎ切れない。WP_Filesystem の資格情報要求は REST/cron 文脈では使えない。
			if ( is_file( $path ) && ! @unlink( $path ) ) {
				return false;
			}
		}

		return self::update_row( (int) $row->file_id, array( 'status' => self::ST_PURGED ) );
	}

	/**
	 * 保持期限を過ぎた隔離済み行を取得する
	 *
	 * @param string $threshold この日時より前に隔離された行。
	 * @param int    $limit     件数。
	 * @return object[]
	 */
	private static function expired_rows( string $threshold, int $limit ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_quarantine
				WHERE status = %s AND quarantined_at IS NOT NULL AND quarantined_at < %s
				ORDER BY file_id LIMIT %d",
				self::ST_QUARANTINED,
				$threshold,
				$limit
			)
		);
	}
}
