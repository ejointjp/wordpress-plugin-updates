<?php
/**
 * 参照グラフのデータ層（FR-10）
 *
 * 「どの添付ファイルが、どこから、どのサイズで参照されているか」を
 * スキャン単位で記録・照会する。本文更新のための一時データではなく、
 * 削除の安全判定（FR-5.1.4）・スキップ集計（FR-6.2）・Pro の未使用メディア
 * 検出（P-2）が同じデータを別角度から読む中核資産。
 *
 * 書き込みはスキャナ（FR-4）が行う。本クラスは格納と照会に徹する。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- カスタムテーブルのデータ層のため $wpdb 直接クエリが本務。結果の再利用は呼び出し側の責務とする。

/**
 * 参照グラフの格納・照会
 */
class Reference_Graph {
	/*
	 * スキャンの状態
	 */
	const SCAN_RUNNING  = 'running';
	const SCAN_COMPLETE = 'complete';
	const SCAN_ABORTED  = 'aborted';

	/*
	 * 参照の状態
	 *
	 * found   = 検出のみ（変更の要否未判定）
	 * update  = 更新対象として算出済み（new_url 保持）
	 * skip    = 更新しない（skip_reason 必須）
	 * applied = 適用済み
	 * failed  = 適用に失敗
	 */
	const REF_FOUND   = 'found';
	const REF_UPDATE  = 'update';
	const REF_SKIP    = 'skip';
	const REF_APPLIED = 'applied';
	const REF_FAILED  = 'failed';

	/*
	 * スキップ理由の区分（FR-6.2）
	 *
	 * 区分を増やすときは値の追加のみで済ませ、既存値の意味を変えないこと。
	 */
	const SKIP_SIZE_UNKNOWN         = 'size_unknown';
	const SKIP_ATTACHMENT_MISSING   = 'attachment_missing';
	const SKIP_NO_INTERMEDIATE      = 'no_intermediate';
	const SKIP_FILENAME_MISMATCH    = 'filename_mismatch';
	const SKIP_OUT_OF_SCOPE         = 'out_of_scope';
	const SKIP_BUILDER              = 'builder';
	const SKIP_POSTMETA             = 'postmeta';
	const SKIP_PRECONDITION_CHANGED = 'precondition_changed';
	const SKIP_NO_CHANGE            = 'no_change';
	const SKIP_FAILED               = 'failed';

	/**
	 * スキャンを開始する
	 *
	 * @param int $posts_total 走査予定の記事数。
	 * @return int 新しい scan_id。失敗時は 0。
	 */
	public static function create_scan( int $posts_total = 0 ): int {
		global $wpdb;

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'rgrl_scans',
			array(
				'status'      => self::SCAN_RUNNING,
				'started_at'  => gmdate( 'Y-m-d H:i:s' ),
				'posts_total' => $posts_total,
			),
			array( '%s', '%s', '%d' )
		);

		return $inserted ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * スキャンを1件取得する
	 *
	 * @param int $scan_id スキャンID。
	 * @return object|null
	 */
	public static function get_scan( int $scan_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_scans WHERE scan_id = %d",
				$scan_id
			)
		);
	}

	/**
	 * 最新のスキャンを取得する
	 *
	 * @param string|null $status 状態で絞る場合に指定（SCAN_* 定数）。
	 * @return object|null
	 */
	public static function latest_scan( ?string $status = null ) {
		global $wpdb;

		if ( null === $status ) {
			return $wpdb->get_row(
				"SELECT * FROM {$wpdb->prefix}rgrl_scans ORDER BY scan_id DESC LIMIT 1"
			);
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_scans WHERE status = %s ORDER BY scan_id DESC LIMIT 1",
				$status
			)
		);
	}

	/**
	 * スキャンの進捗・状態を更新する
	 *
	 * @param int   $scan_id スキャンID。
	 * @param array $fields  更新するカラム。許可外のキーは無視する。
	 * @return bool 1行更新できたか。
	 */
	public static function update_scan( int $scan_id, array $fields ): bool {
		global $wpdb;

		$allowed = array(
			'status'        => '%s',
			'finished_at'   => '%s',
			'posts_total'   => '%d',
			'posts_scanned' => '%d',
			'last_post_id'  => '%d',
		);

		$data    = array();
		$formats = array();

		foreach ( $allowed as $key => $format ) {
			if ( array_key_exists( $key, $fields ) ) {
				$data[ $key ] = $fields[ $key ];
				$formats[]    = $format;
			}
		}

		if ( empty( $data ) ) {
			return false;
		}

		$updated = $wpdb->update(
			$wpdb->prefix . 'rgrl_scans',
			$data,
			array( 'scan_id' => $scan_id ),
			$formats,
			array( '%d' )
		);

		return 1 === $updated;
	}

	/**
	 * 参照をまとめて記録する
	 *
	 * @param int   $scan_id スキャンID。
	 * @param array $refs    参照の配列。各要素は post_id / route / position /
	 *                       attachment_id / size_name / url / new_url / status /
	 *                       skip_reason / details を持つ連想配列（不足キーは既定値）。
	 * @return int 挿入した行数。
	 */
	public static function add_refs( int $scan_id, array $refs ): int {
		global $wpdb;

		if ( empty( $refs ) ) {
			return 0;
		}

		$placeholders = array();
		$values       = array();

		foreach ( $refs as $ref ) {
			$placeholders[] = '(%d, %d, %s, %s, %d, %s, %s, %s, %s, %s, %s)';

			$values[] = $scan_id;
			$values[] = (int) ( $ref['post_id'] ?? 0 );
			$values[] = (string) ( $ref['route'] ?? '' );
			$values[] = (string) ( $ref['position'] ?? '' );
			$values[] = (int) ( $ref['attachment_id'] ?? 0 );
			$values[] = (string) ( $ref['size_name'] ?? '' );
			$values[] = (string) ( $ref['url'] ?? '' );
			$values[] = (string) ( $ref['new_url'] ?? '' );
			$values[] = (string) ( $ref['status'] ?? self::REF_FOUND );
			$values[] = (string) ( $ref['skip_reason'] ?? '' );
			$values[] = (string) ( $ref['details'] ?? '' );
		}

		$sql = "INSERT INTO {$wpdb->prefix}rgrl_refs
			(scan_id, post_id, route, position, attachment_id, size_name, url, new_url, status, skip_reason, details)
			VALUES " . implode( ",\n", $placeholders );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql はプレースホルダのみで組み立てており、値はすべて prepare() に渡している。
		$result = $wpdb->query( $wpdb->prepare( $sql, $values ) );

		return false === $result ? 0 : (int) $result;
	}

	/**
	 * サイズ名ごとの参照数を集計する（FR-1.2 の「本文使用回数」）
	 *
	 * @param int $scan_id スキャンID。
	 * @return array<string, int> size_name => 件数。
	 */
	public static function counts_by_size( int $scan_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT size_name, COUNT(*) AS refs
				FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d
				GROUP BY size_name",
				$scan_id
			)
		);

		$counts = array();
		foreach ( $rows as $row ) {
			$counts[ $row->size_name ] = (int) $row->refs;
		}

		return $counts;
	}

	/**
	 * 状態ごとの参照数を集計する
	 *
	 * @param int $scan_id スキャンID。
	 * @return array<string, int> status => 件数。
	 */
	public static function counts_by_status( int $scan_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) AS refs
				FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d
				GROUP BY status",
				$scan_id
			)
		);

		$counts = array();
		foreach ( $rows as $row ) {
			$counts[ $row->status ] = (int) $row->refs;
		}

		return $counts;
	}

	/**
	 * スキップ理由ごとの件数を集計する（FR-6.2）
	 *
	 * @param int $scan_id スキャンID。
	 * @return array<string, int> skip_reason => 件数。
	 */
	public static function counts_by_skip_reason( int $scan_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT skip_reason, COUNT(*) AS refs
				FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND status = %s
				GROUP BY skip_reason",
				$scan_id,
				self::REF_SKIP
			)
		);

		$counts = array();
		foreach ( $rows as $row ) {
			$counts[ $row->skip_reason ] = (int) $row->refs;
		}

		return $counts;
	}

	/**
	 * 指定状態の参照数と該当記事数を返す（FR-6.2）
	 *
	 * @param int    $scan_id スキャンID。
	 * @param string $status  状態（REF_* 定数）。
	 * @return array{refs: int, posts: int}
	 */
	public static function status_breakdown( int $scan_id, string $status ): array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS refs, COUNT(DISTINCT post_id) AS posts
				FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND status = %s",
				$scan_id,
				$status
			)
		);

		return array(
			'refs'  => $row ? (int) $row->refs : 0,
			'posts' => $row ? (int) $row->posts : 0,
		);
	}

	/**
	 * スキップ理由ごとの参照数と該当記事数を集計する（FR-6.2 / FR-6.5）
	 *
	 * @param int $scan_id スキャンID。
	 * @return array<string, array{refs: int, posts: int}> skip_reason ごとの内訳。
	 */
	public static function skip_breakdown( int $scan_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT skip_reason, COUNT(*) AS refs, COUNT(DISTINCT post_id) AS posts
				FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND status = %s
				GROUP BY skip_reason",
				$scan_id,
				self::REF_SKIP
			)
		);

		$out = array();
		foreach ( $rows as $row ) {
			$out[ $row->skip_reason ] = array(
				'refs'  => (int) $row->refs,
				'posts' => (int) $row->posts,
			);
		}

		return $out;
	}

	/**
	 * 状態（と理由）に該当する記事IDの先頭数件を返す（FR-6.5 のリンク用）
	 *
	 * 全件はレポートの CSV エクスポート（FR-6.7）で取得できる。画面には
	 * 手掛かりとして先頭の数記事だけを載せる。
	 *
	 * @param int         $scan_id     スキャンID。
	 * @param string      $status      状態（REF_* 定数）。
	 * @param string|null $skip_reason スキップ理由で絞る場合に指定。
	 * @param int         $limit       件数。
	 * @return int[]
	 */
	public static function sample_post_ids( int $scan_id, string $status, ?string $skip_reason = null, int $limit = 5 ): array {
		global $wpdb;

		if ( null === $skip_reason ) {
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT post_id FROM {$wpdb->prefix}rgrl_refs
					WHERE scan_id = %d AND status = %s
					ORDER BY post_id LIMIT %d",
					$scan_id,
					$status,
					$limit
				)
			);
		} else {
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT post_id FROM {$wpdb->prefix}rgrl_refs
					WHERE scan_id = %d AND status = %s AND skip_reason = %s
					ORDER BY post_id LIMIT %d",
					$scan_id,
					$status,
					$skip_reason,
					$limit
				)
			);
		}

		return array_map( 'intval', $ids );
	}

	/**
	 * スキャンの参照をカーソル式で取得する（CSV エクスポート・CLI 用）
	 *
	 * @param int $scan_id      スキャンID。
	 * @param int $after_ref_id この ref_id より大きいものから。
	 * @param int $limit        件数。
	 * @return object[]
	 */
	public static function refs_batch( int $scan_id, int $after_ref_id, int $limit ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND ref_id > %d
				ORDER BY ref_id LIMIT %d",
				$scan_id,
				$after_ref_id,
				$limit
			)
		);
	}

	/**
	 * 記事側から参照を引く（FR-10.1）
	 *
	 * @param int $scan_id スキャンID。
	 * @param int $post_id 記事ID。
	 * @return object[]
	 */
	public static function refs_for_post( int $scan_id, int $post_id ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND post_id = %d
				ORDER BY ref_id",
				$scan_id,
				$post_id
			)
		);
	}

	/**
	 * 添付側から参照を引く（FR-10.1）
	 *
	 * @param int $scan_id       スキャンID。
	 * @param int $attachment_id 添付ID。
	 * @return object[]
	 */
	public static function refs_for_attachment( int $scan_id, int $attachment_id ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND attachment_id = %d
				ORDER BY ref_id",
				$scan_id,
				$attachment_id
			)
		);
	}

	/**
	 * 更新対象（status=update）の参照を持つ記事数を数える（apply の分母）
	 *
	 * @param int $scan_id スキャンID。
	 */
	public static function count_posts_with_updates( int $scan_id ): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND status = %s",
				$scan_id,
				self::REF_UPDATE
			)
		);
	}

	/**
	 * 更新対象の参照を持つ記事IDをカーソル式で取得する（apply のバッチ単位）
	 *
	 * @param int $scan_id  スキャンID。
	 * @param int $after_id この記事IDより大きいものから。
	 * @param int $limit    件数。
	 * @return int[]
	 */
	public static function posts_with_updates( int $scan_id, int $after_id, int $limit ): array {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT post_id FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND status = %s AND post_id > %d
				ORDER BY post_id LIMIT %d",
				$scan_id,
				self::REF_UPDATE,
				$after_id,
				$limit
			)
		);

		return array_map( 'intval', $ids );
	}

	/**
	 * 複数参照の状態を一括で更新する（apply の結果記録）
	 *
	 * @param int[]  $ref_ids     対象の ref_id。
	 * @param string $status      新しい状態（REF_* 定数）。
	 * @param string $skip_reason スキップ理由（REF_SKIP 時のみ意味を持つ）。
	 * @return int 更新した行数。
	 */
	public static function update_refs_status( array $ref_ids, string $status, string $skip_reason = '' ): int {
		global $wpdb;

		$ref_ids = array_values( array_filter( array_map( 'intval', $ref_ids ) ) );

		if ( empty( $ref_ids ) ) {
			return 0;
		}

		$ids_in = implode( ',', array_fill( 0, count( $ref_ids ), '%d' ) );
		$params = array_merge( array( $status, $skip_reason ), $ref_ids );

		$sql = "UPDATE {$wpdb->prefix}rgrl_refs
			SET status = %s, skip_reason = %s
			WHERE ref_id IN ($ids_in)";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- IN 句はプレースホルダのみで組み立てており、値はすべて prepare() に渡している。
		$result = $wpdb->query( $wpdb->prepare( $sql, $params ) );

		return false === $result ? 0 : (int) $result;
	}

	/**
	 * 参照1件の details にキーを追記する（失敗理由の記録用）
	 *
	 * @param int   $ref_id 対象の ref_id。
	 * @param array $merge  details にマージするキーと値。
	 */
	public static function merge_ref_details( int $ref_id, array $merge ): void {
		global $wpdb;

		$current = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT details FROM {$wpdb->prefix}rgrl_refs WHERE ref_id = %d",
				$ref_id
			)
		);

		$details = json_decode( (string) $current, true );
		$details = is_array( $details ) ? $details : array();

		$wpdb->update(
			$wpdb->prefix . 'rgrl_refs',
			array( 'details' => (string) wp_json_encode( array_merge( $details, $merge ) ) ),
			array( 'ref_id' => $ref_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * ファイル名が本文参照に現れるかを調べる（FR-5.1.4 の削除安全判定）
	 *
	 * 「本文に実在する URL」だけを保護対象にするため、参照の状態で
	 * 見る列を分ける。
	 *
	 * - url:     found / update / skip / failed（本文がまだ旧 URL のもの）
	 * - new_url: update / applied（適用予定・適用済みの新 URL）
	 *
	 * applied 行の url（旧 URL）は本文から消えたことが確認済みのため
	 * 保護しない。ここを保護すると、参照更新が済んだ旧ファイルを
	 * 永久に片付けられなくなる。
	 *
	 * @param int    $scan_id  スキャンID。
	 * @param string $filename ファイル名（basename）。部分一致で照合する。
	 * @return bool 1件でも現れれば true。
	 */
	public static function mentions_filename( int $scan_id, string $filename ): bool {
		global $wpdb;

		$like = '%' . $wpdb->esc_like( $filename ) . '%';

		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}rgrl_refs
				WHERE scan_id = %d AND (
					( status IN (%s, %s, %s, %s) AND url LIKE %s )
					OR ( status IN (%s, %s) AND new_url LIKE %s )
				)",
				$scan_id,
				self::REF_FOUND,
				self::REF_UPDATE,
				self::REF_SKIP,
				self::REF_FAILED,
				$like,
				self::REF_UPDATE,
				self::REF_APPLIED,
				$like
			)
		);

		return (int) $count > 0;
	}

	/**
	 * 参照が1件も無い画像添付を列挙する（FR-10.3）
	 *
	 * 全記事の再走査を伴わず、参照グラフの逆引きだけで求める。
	 * Pro の未使用メディア検出（P-2）もこのメソッドを読む側に回る。
	 *
	 * @param int $scan_id スキャンID。
	 * @param int $limit   最大件数。
	 * @param int $offset  取得開始位置。
	 * @return int[] 添付IDの配列。
	 */
	public static function unreferenced_attachment_ids( int $scan_id, int $limit = 100, int $offset = 0 ): array {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				WHERE p.post_type = 'attachment'
				AND p.post_mime_type LIKE %s
				AND NOT EXISTS (
					SELECT 1 FROM {$wpdb->prefix}rgrl_refs r
					WHERE r.scan_id = %d AND r.attachment_id = p.ID
				)
				ORDER BY p.ID
				LIMIT %d OFFSET %d",
				$wpdb->esc_like( 'image/' ) . '%',
				$scan_id,
				$limit,
				$offset
			)
		);

		return array_map( 'intval', $ids );
	}

	/**
	 * スキャンと配下の参照を削除する
	 *
	 * @param int $scan_id スキャンID。
	 */
	public static function delete_scan( int $scan_id ): void {
		global $wpdb;

		$wpdb->delete( $wpdb->prefix . 'rgrl_refs', array( 'scan_id' => $scan_id ), array( '%d' ) );
		$wpdb->delete( $wpdb->prefix . 'rgrl_scans', array( 'scan_id' => $scan_id ), array( '%d' ) );
	}
}
