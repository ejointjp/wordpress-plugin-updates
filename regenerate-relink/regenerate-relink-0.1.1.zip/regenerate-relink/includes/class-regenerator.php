<?php
/**
 * サムネイル再生成（FR-3）
 *
 * 有効なサイズのうち、未生成または定義とズレているものだけを生成する
 * （FR-3.1）。リサイズ元は常に原画（FR-3.3）。生成のたびに添付メタデータへ
 * 保存する（FR-3.7）ため、途中で接続が切れても完了済みの作業は失われず、
 * ジョブ（rgrl_jobs）のカーソルから再開できる（FR-3.5）。
 *
 * 既存ファイルは削除も上書きもしない。定義とズレたサイズを再生成すると
 * 寸法入りの新ファイル名で保存され、旧ファイルは本文更新（FR-4）が済むまで
 * 参照され続け、その後の隔離（FR-5）で片付ける。ズレたサイズの新旧で
 * ファイル名が同じになるのは寸法が同じとき（= 中身も同じ）だけなので、
 * 上書きが起きても破壊にならない。
 *
 * 判定の計算基準（生成元寸法・期待寸法）は Size_Registry と共有し、
 * 診断（FR-1）の「未生成・要再生成」と実際の生成対象が一致する。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 再生成の実行制御
 */
class Regenerator {

	/**
	 * 1バッチの実行時間の上限（秒）
	 *
	 * 画像処理は1件が重く件数では制御しきれないため、超過したら
	 * バッチを打ち切って残りを次のリクエストに回す。
	 */
	const TIME_BUDGET = 15;

	/**
	 * ジョブに記録する問題詳細の最大件数（カウンタは全件正確に保つ）
	 */
	const MAX_ISSUES = 100;

	/*
	 * スキップ理由（FR-3.6）。UI 側のラベルと対にする
	 */
	const SKIP_TOO_SMALL        = 'too_small';
	const SKIP_ORIGINAL_MISSING = 'original_missing';

	/*
	 * 問題詳細の区分
	 */
	const ISSUE_EDITOR = 'editor_failed';
	const ISSUE_RESIZE = 'resize_failed';
	const ISSUE_ROTATE = 'rotate_failed';

	/**
	 * 再生成ジョブを開始する。進行中のものがあればそれを返す（再開）
	 *
	 * @param bool        $restart              true なら進行中のジョブを破棄して新規に始める。
	 * @param string|null $expected_fingerprint プレビュー（診断集計）時点のサイズ定義
	 *                                          フィンガープリント。指定時、現在値と一致
	 *                                          しなければ開始しない（FR-6.3 / FR-6.4）。
	 *                                          null = 照合しない（CLI 等、独自に確認する経路用）。
	 * @return array progress() の形式。開始できない場合は error キーを持つ。
	 */
	public static function start( bool $restart = false, ?string $expected_fingerprint = null ): array {
		$running = Jobs::latest_job( Jobs::TYPE_REGENERATE, Jobs::JOB_RUNNING );

		if ( $running && ! $restart ) {
			return self::progress( $running, 0, false );
		}

		// 新規開始の前提チェック。restart 時も、破棄より先に検証する
		// （ズレていた場合に進行中ジョブへ副作用を残さない）
		if ( null !== $expected_fingerprint && Size_Registry::definitions_fingerprint() !== $expected_fingerprint ) {
			return array( 'error' => 'stale_preview' );
		}

		if ( $running ) {
			Jobs::update_job(
				(int) $running->job_id,
				array(
					'status'      => Jobs::JOB_ABORTED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}

		$total  = Size_Registry::count_image_attachments();
		$job_id = Jobs::create_job( Jobs::TYPE_REGENERATE, $total, self::normalize_totals( array() ) );

		return self::progress( Jobs::get_job( $job_id ), 0, false );
	}

	/**
	 * 再生成を1バッチ進める
	 *
	 * @param int $job_id 対象ジョブ。running であること。
	 * @return array|null 進捗。null = ジョブが存在しないか running でない。
	 */
	public static function step( int $job_id ) {
		$job = Jobs::get_job( $job_id );

		if ( ! $job || Jobs::TYPE_REGENERATE !== $job->job_type || Jobs::JOB_RUNNING !== $job->status ) {
			return null;
		}

		/**
		 * 1バッチで処理する添付数
		 *
		 * @param int $batch_size 既定 5。TIME_BUDGET 秒を超えた時点でも打ち切る。
		 */
		$batch_size = max( 1, (int) apply_filters( 'rgrl_regenerate_batch_size', 5 ) );

		$ids    = self::next_attachment_ids( (int) $job->last_item_id, $batch_size );
		$totals = self::normalize_totals( Jobs::decode_totals( $job ) );

		if ( empty( $ids ) ) {
			Jobs::update_job(
				$job_id,
				array(
					'status'      => Jobs::JOB_COMPLETE,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);

			return array(
				'job_id'       => $job_id,
				'images_total' => (int) $job->items_total,
				'images_done'  => (int) $job->items_done,
				'processed'    => 0,
				'done'         => true,
				'totals'       => $totals,
			);
		}

		update_meta_cache( 'post', $ids );

		$started   = microtime( true );
		$processed = 0;
		$last_id   = (int) $job->last_item_id;

		foreach ( $ids as $attachment_id ) {
			$totals  = self::merge_result( $totals, self::regenerate_attachment( $attachment_id ) );
			$last_id = $attachment_id;
			++$processed;

			// メタデータはサイズ単位で保存済みのため、どこで打ち切っても
			// 完了分は失われない（FR-3.5）
			if ( microtime( true ) - $started > self::TIME_BUDGET ) {
				break;
			}
		}

		Jobs::update_job(
			$job_id,
			array(
				'items_done'   => (int) $job->items_done + $processed,
				'last_item_id' => $last_id,
				'totals'       => $totals,
			)
		);

		return array(
			'job_id'       => $job_id,
			'images_total' => (int) $job->items_total,
			'images_done'  => (int) $job->items_done + $processed,
			'processed'    => $processed,
			'done'         => false,
			'totals'       => $totals,
		);
	}

	/**
	 * 添付1件について必要なサイズを生成する
	 *
	 * CLI（FR-8.2）もこのメソッドを使う。ここに UI 依存を持ち込まないこと。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array 1件分の結果（generated / bytes / failed / no_metadata /
	 *               skipped / issues）。merge_result() で累積へ足す。
	 */
	public static function regenerate_attachment( int $attachment_id ): array {
		$result = self::empty_result();

		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $meta ) || empty( $meta['width'] ) || empty( $meta['height'] ) || empty( $meta['file'] ) ) {
			// SVG 等、寸法情報を持たない画像添付は中間サイズの対象外
			$result['no_metadata'] = 1;
			return $result;
		}

		$plan = self::plan_sizes( $attachment_id, $meta, $result );

		if ( empty( $plan ) ) {
			return $result;
		}

		// リサイズ元は常に原画（FR-3.3）。-scaled を元にすると再圧縮で劣化する
		$original = wp_get_original_image_path( $attachment_id );

		if ( ! is_string( $original ) || '' === $original || ! is_file( $original ) ) {
			$result['skipped'][ self::SKIP_ORIGINAL_MISSING ] = count( $plan );
			self::add_issue(
				$result,
				$attachment_id,
				'',
				self::SKIP_ORIGINAL_MISSING,
				__( 'The original image file was not found.', 'regenerate-relink' )
			);
			return $result;
		}

		$editor = wp_get_image_editor( $original );

		if ( is_wp_error( $editor ) ) {
			$result['failed'] += count( $plan );
			self::add_issue( $result, $attachment_id, '', self::ISSUE_EDITOR, $editor->get_error_message() );
			return $result;
		}

		// 原画に EXIF の向きが残っている場合は、コアのアップロード時
		// （_wp_make_subsizes）と同様に、生成前に回転する
		if ( ! empty( $meta['image_meta'] ) ) {
			$rotated = $editor->maybe_exif_rotate();

			if ( is_wp_error( $rotated ) ) {
				// コア同様、回転失敗でも生成は続行する。ただし黙殺せず記録する
				self::add_issue( $result, $attachment_id, '', self::ISSUE_ROTATE, $rotated->get_error_message() );
			}
		}

		foreach ( $plan as $name => $def ) {
			$size_meta = self::make_one( $editor, $def );

			if ( is_wp_error( $size_meta ) ) {
				++$result['failed'];
				self::add_issue( $result, $attachment_id, $name, self::ISSUE_RESIZE, $size_meta->get_error_message() );
				continue;
			}

			// 成功のたびに最新のメタデータへ反映・保存する（FR-3.5 / FR-3.7）。
			// 失敗したサイズには触れないため、既存の旧エントリが消えて
			// フルサイズへのフォールバックが起きることはない（NFR-1.6）
			$meta = wp_get_attachment_metadata( $attachment_id );
			$meta = is_array( $meta ) ? $meta : array();

			if ( ! isset( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
				$meta['sizes'] = array();
			}

			$meta['sizes'][ $name ] = $size_meta;
			wp_update_attachment_metadata( $attachment_id, $meta );

			++$result['generated'];
			$result['bytes'] += (int) ( $size_meta['filesize'] ?? 0 );
		}

		return $result;
	}

	/**
	 * 添付1件について、生成が必要なサイズを判定する
	 *
	 * 診断（FR-1.3）と同じ基準: 生成元寸法（Size_Registry::source_dimensions）に
	 * image_resize_dimensions() を適用した期待寸法と、metadata の実寸法を
	 * 突き合わせる。無効化されたサイズは対象にしない（FR-3.2）。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param array $meta          _wp_attachment_metadata の値。
	 * @param array $result        スキップ理由の記録先（参照渡し）。
	 * @return array<string, array> 生成するサイズ名 => 定義。生成順に並べ済み。
	 */
	private static function plan_sizes( int $attachment_id, array $meta, array &$result ): array {
		$registered = wp_get_registered_image_subsizes();
		$disabled   = Size_Registry::disabled_sizes();
		$meta_sizes = isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ? $meta['sizes'] : array();

		list( $src_w, $src_h ) = Size_Registry::source_dimensions( $attachment_id, $meta );

		$plan = array();

		foreach ( $registered as $name => $def ) {
			// 無効化されたサイズは生成しない（FR-3.2）
			if ( in_array( $name, $disabled, true ) ) {
				continue;
			}

			$expected = image_resize_dimensions(
				$src_w,
				$src_h,
				(int) $def['width'],
				(int) $def['height'],
				$def['crop']
			);

			$has_file = isset( $meta_sizes[ $name ] ) && is_array( $meta_sizes[ $name ] );

			if ( ! $expected ) {
				// 原画が定義寸法より小さく生成できない。エラーとせず理由を
				// 記録する（FR-3.6）。ファイルが既にある場合は過剰ファイル
				// （FR-5 の領域）なので、ここでは何もしない
				if ( ! $has_file ) {
					$result['skipped'][ self::SKIP_TOO_SMALL ] =
						( $result['skipped'][ self::SKIP_TOO_SMALL ] ?? 0 ) + 1;
				}
				continue;
			}

			if ( ! $has_file ) {
				// 未生成（FR-3.1）
				$plan[ $name ] = $def;
				continue;
			}

			$actual_w = (int) ( $meta_sizes[ $name ]['width'] ?? 0 );
			$actual_h = (int) ( $meta_sizes[ $name ]['height'] ?? 0 );

			if ( $actual_w !== (int) $expected[4] || $actual_h !== (int) $expected[5] ) {
				// 定義とズレている（FR-3.1）
				$plan[ $name ] = $def;
			}
		}

		if ( empty( $plan ) ) {
			return array();
		}

		// 途中で失敗しても利用頻度の高いサイズから残るよう、
		// コア（_wp_make_subsizes）と同じ優先順で生成する
		$priority = array(
			'medium'       => null,
			'large'        => null,
			'thumbnail'    => null,
			'medium_large' => null,
		);

		return array_filter( array_merge( $priority, $plan ) );
	}

	/**
	 * 1サイズを生成して保存する
	 *
	 * make_subsize（WP 5.3+）は読み込み済み画像を保ったまま1サイズだけ
	 * 生成・保存するため、エディタの読み込みは添付1件につき1回で済む。
	 * 実装を持たないカスタムエディタは multi_resize に落とす。
	 *
	 * @param \WP_Image_Editor $editor 原画を読み込んだエディタ。
	 * @param array            $def    サイズ定義（width / height / crop）。
	 * @return array|WP_Error 生成した中間サイズのメタデータ。
	 */
	private static function make_one( $editor, array $def ) {
		$size_data = array(
			'width'  => (int) $def['width'],
			'height' => (int) $def['height'],
			'crop'   => $def['crop'] ?? false,
		);

		if ( method_exists( $editor, 'make_subsize' ) ) {
			return $editor->make_subsize( $size_data );
		}

		$made = $editor->multi_resize( array( $size_data ) );

		if ( is_array( $made ) && ! empty( $made ) ) {
			return reset( $made );
		}

		return new WP_Error(
			'rgrl_subsize_failed',
			__( 'The image could not be resized.', 'regenerate-relink' )
		);
	}

	/**
	 * 結果の空構造を返す
	 *
	 * generated / failed / skipped は「画像×サイズ」単位（FR-3.4）、
	 * no_metadata のみ画像単位。
	 */
	private static function empty_result(): array {
		return array(
			'generated'   => 0,
			'bytes'       => 0,
			'failed'      => 0,
			'no_metadata' => 0,
			'skipped'     => array(),
			'issues'      => array(),
		);
	}

	/**
	 * 1件分の結果を累積カウンタへ足し込む
	 *
	 * @param array $totals 累積値（normalize_totals 済み）。
	 * @param array $result regenerate_attachment() の戻り値。
	 * @return array 更新後の累積値。
	 */
	public static function merge_result( array $totals, array $result ): array {
		foreach ( array( 'generated', 'bytes', 'failed', 'no_metadata' ) as $key ) {
			$totals[ $key ] += (int) ( $result[ $key ] ?? 0 );
		}

		foreach ( (array) ( $result['skipped'] ?? array() ) as $reason => $count ) {
			$totals['skipped'][ $reason ] = ( $totals['skipped'][ $reason ] ?? 0 ) + (int) $count;
		}

		foreach ( (array) ( $result['issues'] ?? array() ) as $issue ) {
			if ( count( $totals['issues'] ) >= self::MAX_ISSUES ) {
				break;
			}
			$totals['issues'][] = $issue;
		}

		return $totals;
	}

	/**
	 * 累積値を正規の構造に丸める
	 *
	 * @param mixed $totals ジョブ行の totals（JSON 復号後）。
	 * @return array 正規化済みの累積値。
	 */
	public static function normalize_totals( $totals ): array {
		$out = array(
			'generated'   => 0,
			'bytes'       => 0,
			'failed'      => 0,
			'no_metadata' => 0,
			'skipped'     => array(),
			'issues'      => array(),
		);

		if ( ! is_array( $totals ) ) {
			return $out;
		}

		foreach ( array( 'generated', 'bytes', 'failed', 'no_metadata' ) as $key ) {
			$out[ $key ] = absint( $totals[ $key ] ?? 0 );
		}

		$skipped = isset( $totals['skipped'] ) && is_array( $totals['skipped'] ) ? $totals['skipped'] : array();

		foreach ( $skipped as $reason => $count ) {
			$out['skipped'][ sanitize_key( (string) $reason ) ] = absint( $count );
		}

		$issues = isset( $totals['issues'] ) && is_array( $totals['issues'] ) ? $totals['issues'] : array();

		foreach ( $issues as $issue ) {
			if ( ! is_array( $issue ) ) {
				continue;
			}

			$out['issues'][] = array(
				'attachment_id' => absint( $issue['attachment_id'] ?? 0 ),
				'title'         => sanitize_text_field( (string) ( $issue['title'] ?? '' ) ),
				'size'          => sanitize_text_field( (string) ( $issue['size'] ?? '' ) ),
				'code'          => sanitize_key( (string) ( $issue['code'] ?? '' ) ),
				'message'       => sanitize_text_field( (string) ( $issue['message'] ?? '' ) ),
				'edit_url'      => esc_url_raw( (string) ( $issue['edit_url'] ?? '' ) ),
			);

			if ( count( $out['issues'] ) >= self::MAX_ISSUES ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * 問題詳細を1件記録する（ユーザーが手作業で対処するための手がかり）
	 *
	 * @param array  $result        記録先（参照渡し）。
	 * @param int    $attachment_id 添付ID。
	 * @param string $size          サイズ名。添付全体の問題は空文字。
	 * @param string $code          区分（SKIP_* / ISSUE_* 定数）。
	 * @param string $message       表示用メッセージ。
	 */
	private static function add_issue( array &$result, int $attachment_id, string $size, string $code, string $message ): void {
		$edit_url = get_edit_post_link( $attachment_id, 'raw' );

		$result['issues'][] = array(
			'attachment_id' => $attachment_id,
			'title'         => (string) get_the_title( $attachment_id ),
			'size'          => $size,
			'code'          => $code,
			'message'       => $message,
			'edit_url'      => is_string( $edit_url ) ? $edit_url : '',
		);
	}

	/**
	 * ジョブの進捗を応答形式に整える
	 *
	 * @param object|null $job       ジョブ行。
	 * @param int         $processed このリクエストで処理した件数。
	 * @param bool        $done      完了したか。
	 */
	private static function progress( $job, int $processed, bool $done ): array {
		if ( ! $job ) {
			return array(
				'job_id'       => 0,
				'images_total' => 0,
				'images_done'  => 0,
				'processed'    => 0,
				'done'         => $done,
				'totals'       => self::normalize_totals( array() ),
			);
		}

		return array(
			'job_id'       => (int) $job->job_id,
			'images_total' => (int) $job->items_total,
			'images_done'  => (int) $job->items_done,
			'processed'    => $processed,
			'done'         => $done,
			'totals'       => self::normalize_totals( Jobs::decode_totals( $job ) ),
		);
	}

	/**
	 * カーソル以降の画像添付IDを取得する
	 *
	 * @param int $after_id   このIDより大きい添付から。
	 * @param int $batch_size 件数。
	 * @return int[]
	 */
	private static function next_attachment_ids( int $after_id, int $batch_size ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- カーソル式ページングのため ID 直接取得が必要。WP_Query の OFFSET ページングは大規模サイトで劣化する。
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment' AND post_mime_type LIKE %s AND ID > %d
				ORDER BY ID LIMIT %d",
				$wpdb->esc_like( 'image/' ) . '%',
				$after_id,
				$batch_size
			)
		);

		return array_map( 'intval', $ids );
	}
}
