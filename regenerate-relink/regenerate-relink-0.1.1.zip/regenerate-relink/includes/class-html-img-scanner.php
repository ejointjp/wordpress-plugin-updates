<?php
/**
 * HTML 断片からの img 抽出
 *
 * WP_HTML_Tag_Processor（WP 6.2+）で走査するため、属性の記述順・
 * 大文字小文字・自己終了タグ・空白の差異に依存しない（NFR-1.2）。
 * 正規表現で HTML を処理しない（付録A の事故の根源）。
 *
 * クラス値のトークン照合は ^…$ の完全一致で行い、wp-image-12 が
 * wp-image-123 にマッチする前方一致事故を構造的に防ぐ（NFR-1.3）。
 * has_class() は WP 6.4+ のため使わない（付録B）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_HTML_Tag_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * img タグの列挙
 */
class Html_Img_Scanner {

	/**
	 * HTML 内のすべての img を列挙する
	 *
	 * @param string $html HTML 断片。
	 * @return array[] 各要素は url / attachment_id / class_size / width / height / img_index。
	 */
	public static function scan( string $html ): array {
		if ( '' === $html || false === stripos( $html, '<img' ) ) {
			return array();
		}

		$processor = new WP_HTML_Tag_Processor( $html );
		$images    = array();
		$index     = 0;

		while ( $processor->next_tag( 'img' ) ) {
			$class_attr = $processor->get_attribute( 'class' );
			$found      = self::parse_class_tokens( is_string( $class_attr ) ? $class_attr : '' );

			$images[] = array(
				'url'           => (string) $processor->get_attribute( 'src' ),
				'attachment_id' => $found['attachment_id'],
				'class_size'    => $found['class_size'],
				'width'         => self::int_or_null( $processor->get_attribute( 'width' ) ),
				'height'        => self::int_or_null( $processor->get_attribute( 'height' ) ),
				'img_index'     => $index,
			);

			++$index;
		}

		return $images;
	}

	/**
	 * class 属性から wp-image-{id} と size-{slug} を取り出す
	 *
	 * @param string $class_attr class 属性の値。
	 * @return array attachment_id と class_size。
	 */
	private static function parse_class_tokens( string $class_attr ): array {
		$attachment_id = 0;
		$class_size    = '';

		foreach ( preg_split( '/\s+/', $class_attr, -1, PREG_SPLIT_NO_EMPTY ) as $token ) {
			if ( preg_match( '/^wp-image-(\d+)$/', $token, $m ) ) {
				$attachment_id = (int) $m[1];
				continue;
			}

			if ( preg_match( '/^size-([\w-]+)$/', $token, $m ) ) {
				$class_size = $m[1];
			}
		}

		return array(
			'attachment_id' => $attachment_id,
			'class_size'    => $class_size,
		);
	}

	/**
	 * 属性値を int に。数値でなければ null
	 *
	 * @param mixed $value 属性値。
	 * @return int|null
	 */
	private static function int_or_null( $value ) {
		if ( is_string( $value ) && is_numeric( $value ) ) {
			return (int) $value;
		}

		return null;
	}
}
