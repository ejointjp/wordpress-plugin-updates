<?php
/**
 * 本文スキャナ（FR-4 の scan 側）
 *
 * 記事本文を走査して参照を検出し、参照グラフ（FR-10）に記録する。
 * 本文・ファイル・添付メタデータは一切変更しない（scan の定義 §2）。
 *
 * ブロック構造は parse_blocks() で取得し、classic とブロックを単一の
 * 入口で処理する（付録B）。検出はアダプタ方式で、標準検出器に加えて
 * rgrl_block_detectors / rgrl_post_detectors フィルタで追加できる
 * （NFR-4.2 / NFR-4.3）。
 *
 * 処理は記事IDカーソルのバッチ方式（NFR-2.3）。途中で接続が切れても
 * scans テーブルの last_post_id から再開できる（FR-7.7）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * スキャンの実行制御
 */
class Scanner {

	/**
	 * スキャンを開始する。進行中のものがあればそれを返す（再開）
	 *
	 * @param bool $restart true なら進行中のスキャンを破棄して新規に始める。
	 * @return array scan_id / posts_total / posts_scanned / done。
	 */
	public static function start( bool $restart = false ): array {
		$running = Reference_Graph::latest_scan( Reference_Graph::SCAN_RUNNING );

		if ( $running && $restart ) {
			Reference_Graph::update_scan(
				(int) $running->scan_id,
				array(
					'status'      => Reference_Graph::SCAN_ABORTED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
			$running = null;
		}

		if ( $running ) {
			return array(
				'scan_id'       => (int) $running->scan_id,
				'posts_total'   => (int) $running->posts_total,
				'posts_scanned' => (int) $running->posts_scanned,
				'done'          => false,
			);
		}

		$total   = self::count_posts();
		$scan_id = Reference_Graph::create_scan( $total );

		return array(
			'scan_id'       => $scan_id,
			'posts_total'   => $total,
			'posts_scanned' => 0,
			'done'          => false,
		);
	}

	/**
	 * スキャンを1バッチ進める
	 *
	 * @param int $scan_id 対象スキャン。running であること。
	 * @return array|null 進捗。null = スキャンが存在しないか running でない。
	 */
	public static function step( int $scan_id ) {
		$scan = Reference_Graph::get_scan( $scan_id );

		if ( ! $scan || Reference_Graph::SCAN_RUNNING !== $scan->status ) {
			return null;
		}

		/**
		 * 1バッチで走査する記事数
		 *
		 * @param int $batch_size 既定 25。
		 */
		$batch_size = max( 1, (int) apply_filters( 'rgrl_scan_batch_size', 25 ) );

		$post_ids = self::next_post_ids( (int) $scan->last_post_id, $batch_size );

		if ( empty( $post_ids ) ) {
			Reference_Graph::update_scan(
				$scan_id,
				array(
					'status'      => Reference_Graph::SCAN_COMPLETE,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);

			return array(
				'scan_id'       => $scan_id,
				'posts_total'   => (int) $scan->posts_total,
				'posts_scanned' => (int) $scan->posts_scanned,
				'processed'     => 0,
				'done'          => true,
			);
		}

		// 本文とメタをまとめてロードする（NFR-2 の N+1 回避）
		_prime_post_caches( $post_ids, false, true );

		$resolver  = new Reference_Resolver();
		$last_id   = (int) $scan->last_post_id;
		$processed = 0;

		foreach ( $post_ids as $post_id ) {
			$post    = get_post( $post_id );
			$last_id = $post_id;

			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$rows = self::scan_post( $post, $resolver );

			if ( ! empty( $rows ) ) {
				Reference_Graph::add_refs( $scan_id, $rows );
			}

			++$processed;
		}

		Reference_Graph::update_scan(
			$scan_id,
			array(
				'posts_scanned' => (int) $scan->posts_scanned + $processed,
				'last_post_id'  => $last_id,
			)
		);

		return array(
			'scan_id'       => $scan_id,
			'posts_total'   => (int) $scan->posts_total,
			'posts_scanned' => (int) $scan->posts_scanned + $processed,
			'processed'     => $processed,
			'done'          => false,
		);
	}

	/**
	 * 記事1件を走査して参照グラフ行を作る
	 *
	 * CLI（FR-8.2）もこのメソッドを使う。ここに UI 依存を持ち込まないこと。
	 *
	 * @param WP_Post            $post     記事。
	 * @param Reference_Resolver $resolver 判定器（バッチ内で共有しキャッシュを効かす）。
	 * @return array 参照グラフ行の配列（details は JSON 文字列化済み）。
	 */
	public static function scan_post( WP_Post $post, Reference_Resolver $resolver ): array {
		$ctx = array(
			'post_id'  => $post->ID,
			'resolver' => $resolver,
		);

		/**
		 * ブロック検出器の一覧
		 *
		 * @param callable[] $detectors fn( array $block, array $ctx ): ?array。
		 */
		$block_detectors = apply_filters( 'rgrl_block_detectors', Core_Detectors::block_detectors() );

		$rows = self::walk_blocks( parse_blocks( $post->post_content ), '', $block_detectors, $ctx );

		/**
		 * 記事単位の検出器の一覧
		 *
		 * @param callable[] $detectors fn( WP_Post $post ): array。
		 */
		$post_detectors = apply_filters( 'rgrl_post_detectors', Core_Detectors::post_detectors() );

		foreach ( $post_detectors as $detector ) {
			$detected = $detector( $post );

			if ( is_array( $detected ) ) {
				$rows = array_merge( $rows, $detected );
			}
		}

		// 適用時の前提変化検出（FR-6.4）に使う本文ハッシュを全行へ刻む
		$content_hash = md5( $post->post_content );

		foreach ( $rows as $i => $row ) {
			$details                 = is_array( $row['details'] ?? null ) ? $row['details'] : array();
			$details['content_hash'] = $content_hash;
			$rows[ $i ]['details']   = (string) wp_json_encode( $details );
		}

		return $rows;
	}

	/**
	 * ブロック樹を再帰で歩き、検出器を適用する
	 *
	 * 各ブロックに対して検出器を順に試し、最初に非 null を返したものが
	 * そのブロックを担当する。どれも関与しなければ汎用 img 検出に落とす。
	 * 子ブロックは担当の有無にかかわらず常に再帰する（media-text の
	 * テキスト側など、担当ブロックの内側にも画像ブロックが入るため）。
	 *
	 * @param array      $blocks    parse_blocks の結果。
	 * @param string     $path      親までのブロックパス。
	 * @param callable[] $detectors ブロック検出器。
	 * @param array      $ctx       post_id / resolver。
	 * @return array 参照グラフ行の配列。
	 */
	private static function walk_blocks( array $blocks, string $path, array $detectors, array $ctx ): array {
		$rows = array();

		foreach ( $blocks as $index => $block ) {
			$position        = '' === $path ? (string) $index : $path . '/' . $index;
			$ctx['position'] = $position;

			$handled = null;

			foreach ( $detectors as $detector ) {
				$handled = $detector( $block, $ctx );

				if ( null !== $handled ) {
					break;
				}
			}

			if ( null === $handled ) {
				$handled = Core_Detectors::generic_block_html( $block, $ctx );
			}

			if ( is_array( $handled ) && ! empty( $handled ) ) {
				$rows = array_merge( $rows, $handled );
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$rows = array_merge(
					$rows,
					self::walk_blocks( $block['innerBlocks'], $position, $detectors, $ctx )
				);
			}
		}

		return $rows;
	}

	/**
	 * 走査対象の記事総数を数える
	 */
	public static function count_posts(): int {
		global $wpdb;

		list( $types_in, $statuses_in, $params ) = self::scope_placeholders();

		$sql = "SELECT COUNT(*) FROM {$wpdb->posts}
			WHERE post_type IN ($types_in) AND post_status IN ($statuses_in)";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- IN 句はプレースホルダのみで組み立てており、値はすべて prepare() に渡している。COUNT のみの軽量クエリ。
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * カーソル以降の記事IDを取得する
	 *
	 * @param int $after_id   このIDより大きい記事から。
	 * @param int $batch_size 件数。
	 * @return int[]
	 */
	private static function next_post_ids( int $after_id, int $batch_size ): array {
		global $wpdb;

		list( $types_in, $statuses_in, $params ) = self::scope_placeholders();

		$params[] = $after_id;
		$params[] = $batch_size;

		$sql = "SELECT ID FROM {$wpdb->posts}
			WHERE post_type IN ($types_in) AND post_status IN ($statuses_in) AND ID > %d
			ORDER BY ID LIMIT %d";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- IN 句はプレースホルダのみで組み立てており、値はすべて prepare() に渡している。カーソル式ページングのため直接クエリ。
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );

		return array_map( 'intval', $ids );
	}

	/**
	 * 走査対象の post_type / post_status のプレースホルダと値を作る
	 *
	 * @return array{0: string, 1: string, 2: array} IN 句2つと bind 値。
	 */
	private static function scope_placeholders(): array {
		/**
		 * 走査対象の投稿タイプ
		 *
		 * @param string[] $post_types 既定は post / page。
		 */
		$types = (array) apply_filters( 'rgrl_scan_post_types', array( 'post', 'page' ) );

		/**
		 * 走査対象の投稿ステータス
		 *
		 * @param string[] $statuses 公開済みに限らず、本文を持つ状態を広く含める。
		 */
		$statuses = (array) apply_filters(
			'rgrl_scan_post_statuses',
			array( 'publish', 'future', 'draft', 'pending', 'private' )
		);

		$types    = array_values( array_filter( array_map( 'strval', $types ) ) );
		$statuses = array_values( array_filter( array_map( 'strval', $statuses ) ) );

		if ( empty( $types ) ) {
			$types = array( 'post' );
		}
		if ( empty( $statuses ) ) {
			$statuses = array( 'publish' );
		}

		$types_in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$statuses_in = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

		return array( $types_in, $statuses_in, array_merge( $types, $statuses ) );
	}
}
