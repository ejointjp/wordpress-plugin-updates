<?php
/**
 * コア標準の参照検出器（§3.3 の対象）
 *
 * 検出はアダプタ方式（NFR-4.2）。ここにあるのは無料版同梱の標準
 * アダプタで、rgrl_block_detectors / rgrl_post_detectors フィルタで
 * 外部（Pro 含む）から追加・差し替えできる。
 *
 * ブロック検出器の契約:
 * - 引数はブロック（parse_blocks の1要素）とコンテキスト。
 * - 関与しないブロックなら null を返す（次の検出器へ渡る）。
 * - 処理したら参照グラフ行の配列を返す（空配列 = 参照なし。
 *   汎用 img 検出はそのブロックには適用されない）。
 * - 子ブロックの再帰は Scanner が常に行う。検出器は自ブロックの
 *   innerHTML だけを見ること。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 標準検出器群
 */
class Core_Detectors {

	/**
	 * 標準のブロック検出器一覧
	 *
	 * @return callable[]
	 */
	public static function block_detectors(): array {
		return array(
			array( __CLASS__, 'image_block' ),
			array( __CLASS__, 'media_text_block' ),
			array( __CLASS__, 'gallery_block' ),
			array( __CLASS__, 'cover_block' ),
			array( __CLASS__, 'classic_html' ),
		);
	}

	/**
	 * 標準の記事単位検出器一覧
	 *
	 * @return callable[]
	 */
	public static function post_detectors(): array {
		return array(
			array( __CLASS__, 'page_builders' ),
			array( __CLASS__, 'postmeta_urls' ),
		);
	}

	/**
	 * core/image（§3.3: ブロック属性の ID + サイズ名）
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   post_id / position / resolver。
	 * @return array|null
	 */
	public static function image_block( array $block, array $ctx ) {
		if ( 'core/image' !== $block['blockName'] ) {
			return null;
		}

		$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
		$rows  = array();

		foreach ( Html_Img_Scanner::scan( (string) $block['innerHTML'] ) as $img ) {
			$row = $ctx['resolver']->resolve(
				array(
					'post_id'       => $ctx['post_id'],
					'route'         => 'block',
					'position'      => $ctx['position'] . ':img' . $img['img_index'],
					'url'           => $img['url'],
					'attachment_id' => (int) ( $attrs['id'] ?? $img['attachment_id'] ),
					'size_name'     => (string) ( $attrs['sizeSlug'] ?? '' ),
					'class_size'    => $img['class_size'],
					'width'         => $img['width'],
					'height'        => $img['height'],
					'details'       => array( 'block' => 'core/image' ),
				)
			);

			if ( null !== $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * core/media-text（§3.3: メディアID + メディアサイズ名）
	 *
	 * メディア参照は innerHTML 側にあり、テキスト側のコンテンツは
	 * innerBlocks として Scanner が再帰処理する。
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   コンテキスト。
	 * @return array|null
	 */
	public static function media_text_block( array $block, array $ctx ) {
		if ( 'core/media-text' !== $block['blockName'] ) {
			return null;
		}

		$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
		$rows  = array();

		foreach ( Html_Img_Scanner::scan( (string) $block['innerHTML'] ) as $img ) {
			$row = $ctx['resolver']->resolve(
				array(
					'post_id'       => $ctx['post_id'],
					'route'         => 'block',
					'position'      => $ctx['position'] . ':img' . $img['img_index'],
					'url'           => $img['url'],
					'attachment_id' => (int) ( $attrs['mediaId'] ?? $img['attachment_id'] ),
					'size_name'     => (string) ( $attrs['mediaSizeSlug'] ?? '' ),
					'class_size'    => $img['class_size'],
					'width'         => $img['width'],
					'height'        => $img['height'],
					'details'       => array( 'block' => 'core/media-text' ),
				)
			);

			if ( null !== $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * core/gallery
	 *
	 * 新形式（WP 5.9+）は入れ子の core/image で構成され、Scanner の
	 * 再帰が個別に処理するため、ここでは何も返さない。
	 * 旧形式（innerBlocks が無く innerHTML に img を直接持つ）は
	 * サイズ情報が存在しないため報告のみ（§3.3）。
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   コンテキスト。
	 * @return array|null
	 */
	public static function gallery_block( array $block, array $ctx ) {
		if ( 'core/gallery' !== $block['blockName'] ) {
			return null;
		}

		if ( ! empty( $block['innerBlocks'] ) ) {
			return array();
		}

		$rows = array();

		foreach ( Html_Img_Scanner::scan( (string) $block['innerHTML'] ) as $img ) {
			$rows[] = array(
				'post_id'       => $ctx['post_id'],
				'route'         => 'block',
				'position'      => $ctx['position'] . ':img' . $img['img_index'],
				'attachment_id' => $img['attachment_id'],
				'size_name'     => '',
				'url'           => $img['url'],
				'status'        => Reference_Graph::REF_SKIP,
				'skip_reason'   => Reference_Graph::SKIP_OUT_OF_SCOPE,
				'details'       => array( 'block' => 'core/gallery-legacy' ),
			);
		}

		return $rows;
	}

	/**
	 * core/cover
	 *
	 * サイズ名を持たないため報告のみ（§3.3）。内側のコンテンツは
	 * innerBlocks として Scanner が再帰処理する。
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   コンテキスト。
	 * @return array|null
	 */
	public static function cover_block( array $block, array $ctx ) {
		if ( 'core/cover' !== $block['blockName'] ) {
			return null;
		}

		$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();

		if ( isset( $attrs['backgroundType'] ) && 'image' !== $attrs['backgroundType'] ) {
			return array();
		}

		$url = (string) ( $attrs['url'] ?? '' );

		if ( '' === $url ) {
			foreach ( Html_Img_Scanner::scan( (string) $block['innerHTML'] ) as $img ) {
				$url = $img['url'];
				break;
			}
		}

		if ( '' === $url ) {
			return array();
		}

		return array(
			array(
				'post_id'       => $ctx['post_id'],
				'route'         => 'block',
				'position'      => $ctx['position'],
				'attachment_id' => (int) ( $attrs['id'] ?? 0 ),
				'size_name'     => '',
				'url'           => $url,
				'status'        => Reference_Graph::REF_SKIP,
				'skip_reason'   => Reference_Graph::SKIP_OUT_OF_SCOPE,
				'details'       => array( 'block' => 'core/cover' ),
			),
		);
	}

	/**
	 * クラシック記事・クラシックブロック（§3.3: wp-image / size- クラス）
	 *
	 * parse_blocks はブロックデリミタの無い本文を blockName null の
	 * 単一ブロックとして返すため、純クラシック記事・ブロック間の地の
	 * HTML・クラシックブロック（core/freeform）を同じ入口で扱える。
	 *
	 * [caption] ショートコード内の img は route を caption にし、
	 * ショートコードの width 属性を details に記録する（FR-4.7 の材料）。
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   コンテキスト。
	 * @return array|null
	 */
	public static function classic_html( array $block, array $ctx ) {
		if ( null !== $block['blockName'] && 'core/freeform' !== $block['blockName'] ) {
			return null;
		}

		$html = (string) $block['innerHTML'];

		if ( '' === trim( $html ) ) {
			return array();
		}

		$rows          = array();
		$caption_index = 0;

		// キャプション部分を切り出して先に処理し、残りを地の HTML として処理する。
		// ショートコードの構文解析にはコアの正規表現を用いる（HTML の解析ではない）。
		$pattern   = get_shortcode_regex( array( 'caption' ) );
		$remaining = preg_replace_callback(
			'/' . $pattern . '/',
			function ( $m ) use ( &$rows, &$caption_index, $ctx ) {
				$atts  = shortcode_parse_atts( $m[3] );
				$width = is_array( $atts ) && isset( $atts['width'] ) ? (int) $atts['width'] : null;

				foreach ( Html_Img_Scanner::scan( $m[5] ) as $img ) {
					$row = $ctx['resolver']->resolve(
						array(
							'post_id'       => $ctx['post_id'],
							'route'         => 'caption',
							'position'      => $ctx['position'] . ':caption' . $caption_index . ':img' . $img['img_index'],
							'url'           => $img['url'],
							'attachment_id' => $img['attachment_id'],
							'size_name'     => '',
							'class_size'    => $img['class_size'],
							'width'         => $img['width'],
							'height'        => $img['height'],
							'details'       => null === $width ? array() : array( 'caption_width' => $width ),
						)
					);

					if ( null !== $row ) {
						$rows[] = $row;
					}
				}

				++$caption_index;

				return '';
			},
			$html
		);

		foreach ( Html_Img_Scanner::scan( (string) $remaining ) as $img ) {
			$row = $ctx['resolver']->resolve(
				array(
					'post_id'       => $ctx['post_id'],
					'route'         => 'html',
					'position'      => $ctx['position'] . ':img' . $img['img_index'],
					'url'           => $img['url'],
					'attachment_id' => $img['attachment_id'],
					'size_name'     => '',
					'class_size'    => $img['class_size'],
					'width'         => $img['width'],
					'height'        => $img['height'],
					'details'       => array(),
				)
			);

			if ( null !== $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * 未知ブロックへの汎用フォールバック（§3.3: 標準クラス規約準拠）
	 *
	 * どの検出器も関与しなかったブロックの innerHTML から、
	 * wp-image / size- クラス規約に従う img を拾う。
	 * Scanner が最後の受け皿として直接呼ぶ（フィルタ対象外）。
	 *
	 * @param array $block ブロック。
	 * @param array $ctx   コンテキスト。
	 * @return array
	 */
	public static function generic_block_html( array $block, array $ctx ): array {
		$rows = array();

		foreach ( Html_Img_Scanner::scan( (string) $block['innerHTML'] ) as $img ) {
			$row = $ctx['resolver']->resolve(
				array(
					'post_id'       => $ctx['post_id'],
					'route'         => 'html',
					'position'      => $ctx['position'] . ':img' . $img['img_index'],
					'url'           => $img['url'],
					'attachment_id' => $img['attachment_id'],
					'size_name'     => '',
					'class_size'    => $img['class_size'],
					'width'         => $img['width'],
					'height'        => $img['height'],
					'details'       => array( 'block' => (string) $block['blockName'] ),
				)
			);

			if ( null !== $row ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}

	/**
	 * ページビルダー製コンテンツの検出（FR-6.8）
	 *
	 * 対応範囲外であることを件数付きで明示するための検出。
	 * 実データの書き換え対象にはしない（P-3 の領域）。
	 *
	 * @param WP_Post $post 記事。
	 * @return array 参照グラフ行の配列。
	 */
	public static function page_builders( WP_Post $post ): array {
		$builders = array();

		if ( '' !== (string) get_post_meta( $post->ID, '_elementor_data', true ) ) {
			$builders[] = 'elementor';
		}

		if ( get_post_meta( $post->ID, '_fl_builder_enabled', true ) ) {
			$builders[] = 'beaver-builder';
		}

		if ( '' !== (string) get_post_meta( $post->ID, '_bricks_page_content_2', true ) ) {
			$builders[] = 'bricks';
		}

		if ( false !== strpos( $post->post_content, '[et_pb_' ) ) {
			$builders[] = 'divi';
		}

		if ( false !== strpos( $post->post_content, '[vc_row' ) ) {
			$builders[] = 'wpbakery';
		}

		$rows = array();

		foreach ( $builders as $builder ) {
			$rows[] = array(
				'post_id'     => $post->ID,
				'route'       => 'builder',
				'position'    => '',
				'size_name'   => '',
				'url'         => '',
				'status'      => Reference_Graph::REF_SKIP,
				'skip_reason' => Reference_Graph::SKIP_BUILDER,
				'details'     => array( 'builder' => $builder ),
			);
		}

		return $rows;
	}

	/**
	 * postmeta に焼かれた画像URLの検出（FR-6.9）
	 *
	 * カスタムフィールドにサイズ付きファイル名が保存されている場合を
	 * meta_key 単位で報告する。書き換えは行わない（P-3 の領域。
	 * シリアライズ構造の素朴な置換は禁止されている）。
	 *
	 * @param WP_Post $post 記事。
	 * @return array 参照グラフ行の配列。
	 */
	public static function postmeta_urls( WP_Post $post ): array {
		$exclude = apply_filters(
			'rgrl_postmeta_exclude_keys',
			array( '_edit_lock', '_edit_last', '_encloseme', '_pingme', '_thumbnail_id', '_wp_page_template' )
		);

		$rows = array();

		foreach ( (array) get_post_meta( $post->ID ) as $meta_key => $values ) {
			if ( in_array( $meta_key, $exclude, true ) ) {
				continue;
			}

			foreach ( (array) $values as $value ) {
				if ( ! is_string( $value ) || '' === $value ) {
					continue;
				}

				if ( ! preg_match( '/[\w%\-]+-\d+x\d+\.(jpe?g|png|gif|webp|avif)/i', $value, $m ) ) {
					continue;
				}

				$rows[] = array(
					'post_id'     => $post->ID,
					'route'       => 'meta',
					'position'    => $meta_key,
					'size_name'   => '',
					'url'         => $m[0],
					'status'      => Reference_Graph::REF_SKIP,
					'skip_reason' => Reference_Graph::SKIP_POSTMETA,
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- DB クエリではなく details 配列のキー。
					'details'     => array( 'meta_key' => $meta_key ),
				);

				break;
			}
		}

		return $rows;
	}
}
