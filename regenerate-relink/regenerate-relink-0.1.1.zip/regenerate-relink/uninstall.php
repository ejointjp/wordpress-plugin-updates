<?php
/**
 * アンインストール時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 *
 * 要件定義書 FR-9: 本プラグインが作成したテーブル・オプションを削除する。
 * 隔離領域（FR-5）はプラグインの管理物であり、マニフェスト（テーブル）を
 * 失うと復元不能になるため、ディレクトリごと削除する。uninstall.php では
 * ユーザーへの対話的警告ができないため、FR-9.2 の警告は管理画面の隔離区画に
 * 常設表示している。アンインストールが記事本文・サイトの画像ファイルを
 * 変更してはならない（FR-9.3。隔離領域の外には一切触れない）。
 *
 * オプション・トランジェント・cron・カスタムテーブルを増やしたら
 * **同じコミットで**ここも更新すること。足し忘れが残骸になる。
 *
 * @package Regenerate_Relink
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * 1サイト分の後始末
 *
 * マルチサイトでは各サイトの prefix でテーブル・オプションを持つため、
 * サイトごとに呼ぶ（NFR-3.3）。
 */
function rgrl_uninstall_site(): void {
	global $wpdb;

	rgrl_uninstall_remove_quarantine_dir();

	wp_clear_scheduled_hook( 'rgrl_quarantine_purge' );

	delete_option( 'rgrl_settings' );
	delete_option( 'rgrl_db_version' );
	delete_option( 'rgrl_size_stats' );
	delete_option( 'rgrl_disabled_sizes' );

	// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- 自プラグインのテーブル削除。テーブル名は $wpdb->prefix と固定文字列のみで構成。
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}rgrl_refs" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}rgrl_scans" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}rgrl_jobs" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}rgrl_quarantine" );
	// phpcs:enable
}

/**
 * 隔離ディレクトリを中身ごと削除する
 *
 * 隔離領域は平置き（サブディレクトリ無し）で、場所は設定オプションに
 * 記録されたディレクトリ名から解決する。uploads 配下であることを
 * 実パスで検証してから消す（NFR-1.4。オプション改竄への防御）。
 */
function rgrl_uninstall_remove_quarantine_dir(): void {
	$settings = get_option( 'rgrl_settings', array() );
	$dirname  = is_array( $settings ) ? (string) ( $settings['quarantine_dir'] ?? '' ) : '';

	if ( '' === $dirname || false !== strpos( $dirname, '/' ) || false !== strpos( $dirname, '\\' ) ) {
		return;
	}

	$upload_dir = wp_get_upload_dir();
	$basedir    = realpath( $upload_dir['basedir'] );
	$dir        = realpath( trailingslashit( $upload_dir['basedir'] ) . $dirname );

	if ( false === $basedir || false === $dir || 0 !== strpos( $dir, $basedir . DIRECTORY_SEPARATOR ) || ! is_dir( $dir ) ) {
		return;
	}

	$entries = scandir( $dir );

	foreach ( is_array( $entries ) ? $entries : array() as $entry ) {
		$path = $dir . DIRECTORY_SEPARATOR . $entry;

		if ( is_file( $path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- 自プラグインの隔離領域の後始末。WP_Filesystem の資格情報要求は uninstall では使えない。
			unlink( $path );
		}
	}

	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- 上と同じ。
	rmdir( $dir );
}

if ( is_multisite() ) {
	$rgrl_site_ids = get_sites( array( 'fields' => 'ids' ) );

	foreach ( $rgrl_site_ids as $rgrl_site_id ) {
		switch_to_blog( (int) $rgrl_site_id );
		rgrl_uninstall_site();
		restore_current_blog();
	}
} else {
	rgrl_uninstall_site();
}

// 更新の情報のキャッシュ（Update_Checker）は、マルチサイトでもネットワーク全体で1つ。サイトごとの後始末の外で消す。
delete_site_transient( 'rgrl_update_info' );
