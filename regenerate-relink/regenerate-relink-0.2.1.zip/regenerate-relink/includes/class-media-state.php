<?php
/**
 * 添付ファイルの状態（ファイル名とメタデータ）の取得・適用・比較
 *
 * 差し替え・名前変更・取り消し（FR-11〜13）は、添付の「状態」を丸ごと
 * 入れ替える操作として扱う。状態は_wp_attached_file・_wp_attachment_metadata・
 * _wp_attachment_backup_sizes・post_mime_typeの4つ。ここではファイル名の
 * 一覧化と語幹の扱いも持つ。ファイル操作とDBの検索はしない。
 *
 * ファイル名の分解にpathinfo()を使わないこと。ロケールによっては
 * マルチバイトの名前を壊す（NFR-3.2）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 添付の状態
 */
class Media_State {

	/**
	 * 添付の現在の状態を取得する
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array|null { attached_file, metadata, backup_sizes, mime }。
	 *                    ファイルかメタデータがなければnull。
	 */
	public static function capture( int $attachment_id ): ?array {
		$file = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
		$meta = wp_get_attachment_metadata( $attachment_id, true );

		if ( '' === $file || ! is_array( $meta ) || empty( $meta['file'] ) ) {
			return null;
		}

		$backup = get_post_meta( $attachment_id, '_wp_attachment_backup_sizes', true );

		return array(
			'attached_file' => $file,
			'metadata'      => $meta,
			'backup_sizes'  => is_array( $backup ) && ! empty( $backup ) ? $backup : null,
			'mime'          => (string) get_post_mime_type( $attachment_id ),
		);
	}

	/**
	 * 状態の照合値
	 *
	 * プレビューのあと・操作のあとに添付が変わっていないかの確認に使う
	 * （FR-6.4と同じ考え方）。比べる側も必ずcapture()から作ること。
	 *
	 * @param array|null $state capture()の値。
	 * @return string nullなら空文字。
	 */
	public static function hash( ?array $state ): string {
		return null === $state ? '' : md5( (string) wp_json_encode( $state ) );
	}

	/**
	 * 状態を添付へ書き込む
	 *
	 * ファイルは動かさない（Media_Filesの役目）。メタデータは
	 * wp_update_attachment_metadata()を通し、ほかのプラグインのフックに
	 * 新しい状態を知らせる。
	 *
	 * MIMEが空の状態は書かない（何も書き換えずにfalseを返す）。書くと添付が画像で
	 * なくなり、以後の操作も取り消しもできなくなる。
	 *
	 * @param int   $attachment_id 添付ID。
	 * @param array $state         書き込む状態。
	 * @return bool ファイル名・MIMEが書き込んだとおりになったか。
	 */
	public static function apply( int $attachment_id, array $state ): bool {
		global $wpdb;

		if ( '' === (string) ( $state['mime'] ?? '' ) ) {
			return false;
		}

		update_post_meta( $attachment_id, '_wp_attached_file', wp_slash( (string) $state['attached_file'] ) );
		// update_post_metaは値をunslashするため、メタデータもslashして渡さないと
		// 文字列中のバックスラッシュが消える（コアの同関数はslashしない）
		wp_update_attachment_metadata( $attachment_id, wp_slash( $state['metadata'] ) );

		if ( empty( $state['backup_sizes'] ) ) {
			delete_post_meta( $attachment_id, '_wp_attachment_backup_sizes' );
		} else {
			update_post_meta( $attachment_id, '_wp_attachment_backup_sizes', wp_slash( $state['backup_sizes'] ) );
		}

		if ( (string) get_post_mime_type( $attachment_id ) !== (string) $state['mime'] ) {
			// wp_update_postは説明文（post_content）にksesを通して変質させうるため使わない。
			// MIMEの1列だけを書き換え、キャッシュを捨てる
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 1列だけの更新。直後にclean_post_cache()する。
			$wpdb->update(
				$wpdb->posts,
				array( 'post_mime_type' => (string) $state['mime'] ),
				array( 'ID' => $attachment_id ),
				array( '%s' ),
				array( '%d' )
			);
			clean_post_cache( $attachment_id );
		}

		$now = self::capture( $attachment_id );

		if ( null === $now || $now['attached_file'] !== $state['attached_file'] || $now['mime'] !== $state['mime'] ) {
			return false;
		}

		$expected = array_map( 'strval', array_keys( self::entries( $state ) ) );
		$actual   = array_map( 'strval', array_keys( self::entries( $now ) ) );

		sort( $expected );
		sort( $actual );

		return $expected === $actual;
	}

	/**
	 * 状態に含まれるファイル名の一覧
	 *
	 * 同じファイルを複数の役割が共有する（寸法が同じ2サイズなど）ため、
	 * ファイル名ごとに役割をまとめる。
	 *
	 * @param array $state 状態。
	 * @return array<string, array{roles: string[], width: int, height: int}>
	 *         役割はfile / original / size:{サイズ名} / backup:{キー}。
	 *         寸法が分からないもの（original_image）は0。
	 */
	public static function entries( array $state ): array {
		$entries = array();
		$meta    = $state['metadata'];
		$width   = (int) ( $meta['width'] ?? 0 );
		$height  = (int) ( $meta['height'] ?? 0 );

		self::add_entry( $entries, wp_basename( (string) $meta['file'] ), 'file', $width, $height );
		self::add_entry( $entries, wp_basename( (string) $state['attached_file'] ), 'file', $width, $height );

		if ( ! empty( $meta['original_image'] ) ) {
			self::add_entry( $entries, wp_basename( (string) $meta['original_image'] ), 'original', 0, 0 );
		}

		$sizes = isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ? $meta['sizes'] : array();

		foreach ( $sizes as $size => $size_meta ) {
			if ( is_array( $size_meta ) && ! empty( $size_meta['file'] ) ) {
				self::add_entry(
					$entries,
					wp_basename( (string) $size_meta['file'] ),
					'size:' . $size,
					(int) ( $size_meta['width'] ?? 0 ),
					(int) ( $size_meta['height'] ?? 0 )
				);
			}
		}

		$backups = is_array( $state['backup_sizes'] ) ? $state['backup_sizes'] : array();

		foreach ( $backups as $key => $backup ) {
			if ( is_array( $backup ) && ! empty( $backup['file'] ) ) {
				self::add_entry(
					$entries,
					wp_basename( (string) $backup['file'] ),
					'backup:' . $key,
					(int) ( $backup['width'] ?? 0 ),
					(int) ( $backup['height'] ?? 0 )
				);
			}
		}

		return $entries;
	}

	/**
	 * 一覧に1件足す（同名なら役割を足す）
	 *
	 * @param array  $entries 一覧（参照渡し）。
	 * @param string $name    ファイル名。
	 * @param string $role    役割。
	 * @param int    $width   幅（不明なら0）。
	 * @param int    $height  高さ（不明なら0）。
	 */
	private static function add_entry( array &$entries, string $name, string $role, int $width, int $height ): void {
		if ( '' === $name ) {
			return;
		}

		if ( ! isset( $entries[ $name ] ) ) {
			$entries[ $name ] = array(
				'roles'  => array(),
				'width'  => $width,
				'height' => $height,
			);
		} elseif ( 0 === $entries[ $name ]['width'] && $width > 0 ) {
			$entries[ $name ]['width']  = $width;
			$entries[ $name ]['height'] = $height;
		}

		if ( ! in_array( $role, $entries[ $name ]['roles'], true ) ) {
			$entries[ $name ]['roles'][] = $role;
		}
	}

	/**
	 * uploadsからのサブディレクトリ（年月）
	 *
	 * @param array $state 状態。
	 * @return string 年月フォルダを使わない設定なら空文字。
	 */
	public static function subdir( array $state ): string {
		$dir = dirname( (string) $state['attached_file'] );

		return '.' === $dir ? '' : $dir;
	}

	/**
	 * ファイル名を語幹と拡張子に分ける
	 *
	 * @param string $name ファイル名。
	 * @return array{0: string, 1: string} 語幹と拡張子。拡張子がなければ''。
	 */
	public static function split_name( string $name ): array {
		$pos = strrpos( $name, '.' );

		if ( false === $pos || 0 === $pos ) {
			return array( $name, '' );
		}

		return array( substr( $name, 0, $pos ), substr( $name, $pos + 1 ) );
	}

	/**
	 * 添付のファイル群に共通する語幹
	 *
	 * 原画（original_image）・画像編集前の原画（backupのfull-orig）・
	 * メタデータのfileの語幹のうち最も短いもの。-scaledや画像編集の
	 * -e{数字}は後ろに付くため、最も短いものが共通の語幹になる。
	 *
	 * @param array $state 状態。
	 * @return string 語幹。
	 */
	public static function stem( array $state ): string {
		$meta  = $state['metadata'];
		$names = array( wp_basename( (string) $meta['file'] ) );

		if ( ! empty( $meta['original_image'] ) ) {
			$names[] = wp_basename( (string) $meta['original_image'] );
		}

		if ( ! empty( $state['backup_sizes']['full-orig']['file'] ) ) {
			$names[] = wp_basename( (string) $state['backup_sizes']['full-orig']['file'] );
		}

		$stems = array();

		foreach ( $names as $name ) {
			$stems[] = self::split_name( $name )[0];
		}

		usort(
			$stems,
			static function ( $a, $b ) {
				return strlen( $a ) - strlen( $b );
			}
		);

		return (string) $stems[0];
	}

	/**
	 * 全ファイルが語幹で始まり、その直後がピリオドかハイフンか
	 *
	 * 名前変更は先頭の語幹だけを置き換えるため、満たさない添付は
	 * 対象外にする（NFR-1.1）。
	 *
	 * @param array  $state 状態。
	 * @param string $stem  語幹。
	 */
	public static function family_ok( array $state, string $stem ): bool {
		if ( '' === $stem ) {
			return false;
		}

		$length = strlen( $stem );

		foreach ( array_keys( self::entries( $state ) ) as $name ) {
			$name = (string) $name;
			$next = substr( $name, $length, 1 );

			if ( 0 !== strpos( $name, $stem ) || ( '.' !== $next && '-' !== $next ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * 先頭の語幹だけを置き換えたファイル名
	 *
	 * @param string $name     ファイル名（$old_stemで始まること）。
	 * @param string $old_stem 旧語幹。
	 * @param string $new_stem 新語幹。
	 */
	public static function renamed( string $name, string $old_stem, string $new_stem ): string {
		return $new_stem . substr( $name, strlen( $old_stem ) );
	}

	/**
	 * 語幹を変えた状態
	 *
	 * ディレクトリ・寸法・MIMEはそのまま。family_ok()を満たす状態にだけ使う。
	 *
	 * @param array  $state    状態。
	 * @param string $old_stem 旧語幹。
	 * @param string $new_stem 新語幹。
	 * @return array 新しい状態。
	 */
	public static function rename_state( array $state, string $old_stem, string $new_stem ): array {
		$rename_path = static function ( string $path ) use ( $old_stem, $new_stem ): string {
			$dir  = dirname( $path );
			$name = self::renamed( wp_basename( $path ), $old_stem, $new_stem );

			return '.' === $dir ? $name : $dir . '/' . $name;
		};

		$state['attached_file']    = $rename_path( (string) $state['attached_file'] );
		$state['metadata']['file'] = $rename_path( (string) $state['metadata']['file'] );

		if ( ! empty( $state['metadata']['original_image'] ) ) {
			$state['metadata']['original_image'] = self::renamed( (string) $state['metadata']['original_image'], $old_stem, $new_stem );
		}

		$sizes = isset( $state['metadata']['sizes'] ) && is_array( $state['metadata']['sizes'] ) ? $state['metadata']['sizes'] : array();

		foreach ( $sizes as $size => $size_meta ) {
			if ( is_array( $size_meta ) && ! empty( $size_meta['file'] ) ) {
				$state['metadata']['sizes'][ $size ]['file'] = self::renamed( (string) $size_meta['file'], $old_stem, $new_stem );
			}
		}

		$backups = is_array( $state['backup_sizes'] ) ? $state['backup_sizes'] : array();

		foreach ( $backups as $key => $backup ) {
			if ( is_array( $backup ) && ! empty( $backup['file'] ) ) {
				$state['backup_sizes'][ $key ]['file'] = self::renamed( (string) $backup['file'], $old_stem, $new_stem );
			}
		}

		return $state;
	}

	/**
	 * サブディレクトリを変えた状態（FR-12.5）
	 *
	 * 変えるのはattached_fileとメタデータのfileのディレクトリ部分だけ。sizes・
	 * original_image・backup_sizesはファイル名だけを持つので変わらない。
	 *
	 * @param array  $state  状態。
	 * @param string $subdir 新しいサブディレクトリ（uploads直下なら空文字）。
	 * @return array 新しい状態。
	 */
	public static function move_state( array $state, string $subdir ): array {
		$place = static function ( string $path ) use ( $subdir ): string {
			$name = wp_basename( $path );

			return '' === $subdir ? $name : $subdir . '/' . $name;
		};

		$state['attached_file']    = $place( (string) $state['attached_file'] );
		$state['metadata']['file'] = $place( (string) $state['metadata']['file'] );

		return $state;
	}
}
