<?php
/**
 * メディア操作（画像の差し替え・ファイル名の変更・取り消し。FR-11〜13）
 *
 * 1操作は「計画（局所スキャン）→ 実行（段1〜4）」で進む（設計書 §4）。
 *
 * - 段1: 新ファイルを作る（旧ファイルの横。フォルダを変える操作では移動先。失敗・中断したら巻き戻して終える）
 * - 段2: メタデータを新しい状態へ切り替える（失敗したら元に戻し、戻せたときだけ段1も巻き戻して終える）
 * - 段3: 本文の参照を追随させる（記事単位のバッチ）
 * - 段4: 参照が残らない旧ファイルだけを隔離する
 *
 * この順番なら、どこで止まっても旧URLは有効なままでリンク切れが起きない
 * （FR-13.1 / NFR-1.6）。本文の判定はScanner / Reference_Resolver、書き換えと
 * 保存はApplierの関数を使い、規則を二重に持たない（FR-8.2）。RESTと画面に
 * 依存しないこと（後からWP-CLIを足せるように）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * メディア操作の計画と実行
 */
class Media_Operation {

	/**
	 * 1回の要求で使う時間の上限（秒）
	 */
	const TIME_BUDGET = 15;

	/**
	 * 記録するスキップの詳細の最大件数（件数は全件正確に数える）
	 */
	const MAX_ISSUES = 100;

	/**
	 * 段2の切り替え（と、その失敗の後始末でメタデータを旧状態へ戻すこと）を試す回数の上限
	 *
	 * 他プラグインのフックが毎回fatalを起こすなど、要求ごと死に続けると、操作が
	 * runningのまま残り、サイト全体のメディア操作と実行タブを止め続ける。この回数を
	 * 試しても終わらなければ、失敗として扱う。
	 */
	const MAX_STEP2_ATTEMPTS = 2;

	/*
	 * ---------------------------------------------------------------------
	 * 状態の照会
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 操作の対象にできるか（設計書 §3.1）
	 *
	 * @param int $attachment_id 添付ID。
	 * @return string できなければ理由コード（not_image / no_metadata / original_missing）。できれば''。
	 */
	public static function eligibility( int $attachment_id ): string {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return 'not_image';
		}

		$state = Media_State::capture( $attachment_id );

		if ( null === $state ) {
			return 'no_metadata';
		}

		$subdir = Media_State::subdir( $state );
		$files  = array( wp_basename( $state['attached_file'] ) );

		if ( ! empty( $state['metadata']['original_image'] ) ) {
			$files[] = wp_basename( (string) $state['metadata']['original_image'] );
		}

		// オフロード系プラグインで原画が手元にない添付は扱わない
		foreach ( $files as $name ) {
			if ( ! Media_Files::exists( Media_Files::rel_path( $subdir, $name ) ) ) {
				return 'original_missing';
			}
		}

		return '';
	}

	/**
	 * 実行タブのジョブが動いているか（FR-13.4）
	 */
	public static function job_running(): bool {
		foreach ( array( Jobs::TYPE_REGENERATE, Jobs::TYPE_APPLY, Jobs::TYPE_QUARANTINE ) as $type ) {
			if ( Jobs::latest_job( $type, Jobs::JOB_RUNNING ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * 添付の操作の状態（画面の初期表示・GET /media/{id}）
	 *
	 * stemは名前変更が基にする語幹（Media_State::stem()）。画面に出すfilenameは
	 * -scaledなどが付いたものなので、名前変更の入力欄の初期値にはこちらを使う。
	 * 状態を取れない添付では空文字。
	 * folderは今のサブディレクトリ（uploads直下なら空文字）。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array
	 */
	public static function status( int $attachment_id ): array {
		$state   = Media_State::capture( $attachment_id );
		$reason  = self::eligibility( $attachment_id );
		$undo    = self::undo_blocker( $attachment_id );
		$latest  = Media_Ops::latest_effective( $attachment_id );
		$running = Media_Ops::running();
		$own     = $running && (int) $running->attachment_id === $attachment_id;
		$busy    = '';

		if ( $running && ! $own ) {
			$busy = 'busy_media_op';
		} elseif ( self::job_running() ) {
			$busy = 'busy_job';
		}

		return array(
			'attachment_id' => $attachment_id,
			'eligible'      => '' === $reason,
			'reason'        => $reason,
			'filename'      => null === $state ? '' : wp_basename( $state['attached_file'] ),
			'stem'          => null === $state ? '' : Media_State::stem( $state ),
			// 名前・フォルダの変更の、フォルダの入力欄の初期値（uploads直下なら空文字）
			'folder'        => null === $state ? '' : Media_State::subdir( $state ),
			'width'         => (int) ( $state['metadata']['width'] ?? 0 ),
			'height'        => (int) ( $state['metadata']['height'] ?? 0 ),
			'mime'          => null === $state ? '' : $state['mime'],
			'last_op'       => $latest ? self::summary( $latest ) : null,
			'can_undo'      => '' === $undo,
			'undo_reason'   => $undo,
			'running'       => $own ? self::summary( $running ) : null,
			'busy'          => $busy,
			// ほかの画像の操作で止まっているとき、その画像（編集画面で再開してもらう）
			'busy_op'       => 'busy_media_op' === $busy ? self::running_info( $running ) : null,
			'failed_op'     => self::failed_leftover( $attachment_id ),
		);
	}

	/**
	 * 実行中の操作の画像（止められた画面で、どこで再開すればよいかを伝える）
	 *
	 * 中断した操作は、その画像の編集画面で誰かが「続きから実行」を押すまで終わらない
	 * （AC-5 #40）。ほかの画像・実行タブ・CLIで止められたときに、その画像を示す。
	 *
	 * @param object|null $op 実行中の操作。省略するとMedia_Ops::running()で探す。
	 * @return array|null { op_id, attachment_id, title, edit_url }。実行中の操作がなければnull。
	 */
	public static function running_info( $op = null ): ?array {
		$op = $op ? $op : Media_Ops::running();

		if ( ! $op ) {
			return null;
		}

		$attachment_id = (int) $op->attachment_id;
		$title         = trim( (string) get_post_field( 'post_title', $attachment_id, 'raw' ) );

		// タイトルが空なら、ファイル名で示す
		if ( '' === $title ) {
			$title = wp_basename( (string) get_post_meta( $attachment_id, '_wp_attached_file', true ) );
		}

		return array(
			'op_id'         => (int) $op->op_id,
			'attachment_id' => $attachment_id,
			'title'         => '' === $title ? '#' . $attachment_id : $title,
			// 権限で空にならないよう、コアの編集画面のURLを直接組む（CLIでも同じURLを出す）
			'edit_url'      => admin_url( 'post.php?post=' . $attachment_id . '&action=edit' ),
		);
	}

	/**
	 * 後始末が残った失敗（編集画面で知らせる）
	 *
	 * 直近の操作（計画だけのものを除く）が失敗で、巻き戻せなかったファイルが
	 * あるか、メタデータを旧状態へ戻せなかったときだけ返す。失敗を伝えたModalを
	 * 閉じたあとも、編集画面に痕跡を残すため。隔離領域に残った行は、隔離タブの
	 * 一括復元から戻せる（Quarantine::restorable_batch()）。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array|null { op_id, op_type, finished_at, error, rollback, metadata_restored }。
	 */
	private static function failed_leftover( int $attachment_id ): ?array {
		$op = Media_Ops::latest_attempt( $attachment_id );

		if ( ! $op || Media_Ops::ST_FAILED !== $op->status ) {
			return null;
		}

		$details  = Media_Ops::decode( $op, 'details' );
		$rollback = array_values( array_map( 'strval', (array) ( $details['rollback_errors'] ?? array() ) ) );
		$restored = (bool) ( $details['metadata_restored'] ?? true );

		if ( empty( $rollback ) && $restored ) {
			return null;
		}

		return array(
			'op_id'             => (int) $op->op_id,
			'op_type'           => (string) $op->op_type,
			'finished_at'       => (string) $op->finished_at,
			'error'             => (string) ( $details['error'] ?? '' ),
			'rollback'          => $rollback,
			'metadata_restored' => $restored,
		);
	}

	/**
	 * 操作の要約（画面の1行表示用）
	 *
	 * @param object $op 操作。
	 * @return array
	 */
	private static function summary( $op ): array {
		$details = Media_Ops::decode( $op, 'details' );

		return array(
			'op_id'       => (int) $op->op_id,
			'op_type'     => (string) $op->op_type,
			'status'      => (string) $op->status,
			'step'        => (int) $op->step,
			'finished_at' => (string) $op->finished_at,
			'from_name'   => isset( $details['from_state']['attached_file'] ) ? wp_basename( (string) $details['from_state']['attached_file'] ) : '',
			'to_name'     => (string) ( $details['to']['name'] ?? '' ),
			// フォルダを変えた操作かどうかの表示用（同じなら名前だけの変更）
			'from_folder' => isset( $details['from_state']['attached_file'] ) ? self::from_subdir( $details ) : '',
			'to_folder'   => isset( $details['from_state']['attached_file'] ) ? self::to_subdir( $details ) : '',
			'error'       => (string) ( $details['error'] ?? '' ),
		);
	}

	/**
	 * 直前の操作を元に戻せない理由（設計書 §7.3）
	 *
	 * @param int $attachment_id 添付ID。
	 * @return string 戻せれば''。no_op / changed / files_missing / shared_file。
	 */
	public static function undo_blocker( int $attachment_id ): string {
		$latest = Media_Ops::latest_effective( $attachment_id );

		// 戻せるのは1段だけ。最新が取り消しなら、それより前の操作は戻さない
		if ( ! $latest || Media_Ops::TYPE_UNDO === $latest->op_type || Media_Ops::ST_COMPLETE !== $latest->status ) {
			return 'no_op';
		}

		$details = Media_Ops::decode( $latest, 'details' );

		// 操作のあとに再生成・画像編集などが入っていたら戻さない
		if ( Media_State::hash( Media_State::capture( $attachment_id ) ) !== (string) ( $details['to_hash'] ?? '' ) ) {
			return 'changed';
		}

		$rows = Quarantine::rows_for_op(
			(int) $latest->op_id,
			array( Quarantine::ST_QUARANTINED, Quarantine::ST_RESTORED, Quarantine::ST_PURGED )
		);

		foreach ( $rows as $row ) {
			if ( ! Media_Files::is_quarantined( (int) $row->file_id ) ) {
				return 'files_missing';
			}
		}

		$subdir = Media_State::subdir( $details['from_state'] );

		foreach ( (array) ( $details['kept'] ?? array() ) as $name ) {
			if ( ! Media_Files::exists( Media_Files::rel_path( $subdir, (string) $name ) ) ) {
				return 'files_missing';
			}
		}

		// 戻すときに今のファイルと入れ替わるファイルを、ほかの添付も使っていれば戻さない
		// （翻訳プラグインの複製など。入れ替えると、そちらの表示も黙って変わる）。
		// 今の状態はto_hashと一致しているので、今のファイルはto_stateのファイル
		$current = self::state_paths( (array) $details['to_state'] );
		$swaps   = array();

		foreach ( $rows as $row ) {
			// 名前でなくパスで比べる。フォルダを変えた操作では、戻し先にある同名のファイルは別のファイル
			if ( Media_Files::occupied( (string) $row->rel_path ) && in_array( (string) $row->rel_path, $current, true ) ) {
				$swaps[] = (int) $row->file_id;
			}
		}

		if ( ! empty( Media_References::shared_names( self::swap_names( $rows, $swaps ), $attachment_id, $subdir ) ) ) {
			return 'shared_file';
		}

		return '';
	}

	/**
	 * 取り消しで今のファイルと入れ替える隔離行の、ファイル名
	 *
	 * @param object[] $rows  元の操作の隔離行。
	 * @param int[]    $swaps 入れ替える行のfile_id。
	 * @return string[]
	 */
	private static function swap_names( array $rows, array $swaps ): array {
		$names = array();

		foreach ( $rows as $row ) {
			if ( in_array( (int) $row->file_id, $swaps, true ) ) {
				$names[] = wp_basename( (string) $row->rel_path );
			}
		}

		return $names;
	}

	/*
	 * ---------------------------------------------------------------------
	 * 計画（プレビュー）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 名前・フォルダの変更のプレビューを始める（FR-12）
	 *
	 * 名前（語幹）とフォルダのどちらか、または両方を変える。フォルダを省くと
	 * 今のフォルダのまま（名前だけの変更）。プレビューでは移動先のフォルダを
	 * 作らない（FR-6.1）。
	 *
	 * @param int         $attachment_id 添付ID。
	 * @param string      $input         新しい名前（語幹。拡張子付きでもよい）。今の語幹なら名前は変えない。
	 * @param string|null $folder        移動先のフォルダ（uploadsからの相対パス。空文字はuploads直下）。
	 *                                   nullなら今のフォルダ。
	 * @return array plan_step()と同じ形。始められなければerrorキー（とdetail / moving）を持つ。
	 */
	public static function preview_rename( int $attachment_id, string $input, ?string $folder = null ): array {
		$blocked = self::preview_blocker( $attachment_id );

		if ( '' !== $blocked ) {
			return array( 'error' => $blocked );
		}

		$state    = Media_State::capture( $attachment_id );
		$subdir   = Media_State::subdir( $state );
		$old_stem = Media_State::stem( $state );
		$ext      = Media_State::split_name( wp_basename( $state['attached_file'] ) )[1];

		// 今の語幹がそのまま入力されたら、名前は変えない。正規化（sanitize_file_name()）を通すと、
		// 今の名前でも別の名前に変わりうる（日本語の名前をmd5にするプラグインなど）
		$new_stem = self::input_stem( $input, $ext ) === $old_stem ? $old_stem : self::normalize_stem( $input, $ext );

		if ( '' === $new_stem ) {
			return array( 'error' => 'invalid_name' );
		}

		// 今のフォルダと同じ入力は、文字の規則にかけず「変えない」と扱う。サイトが
		// upload_dirで作る日本語や.・空白入りのフォルダの添付も、名前だけは変えられるように
		if ( null === $folder || self::trim_folder( $folder ) === $subdir ) {
			$to_subdir = $subdir;
		} else {
			$to_subdir = self::normalize_folder( $folder );
		}

		if ( null === $to_subdir ) {
			return array( 'error' => 'invalid_folder' );
		}

		$renaming = $new_stem !== $old_stem;
		$moving   = $to_subdir !== $subdir;

		if ( ! $renaming && ! $moving ) {
			return array( 'error' => 'same_name' );
		}

		// 先頭の語幹を置き換えるのは、名前を変えるときだけ。フォルダだけの移動は、語幹がそろわない添付でもできる
		if ( $renaming && ! Media_State::family_ok( $state, $old_stem ) ) {
			return array( 'error' => 'unsupported_names' );
		}

		if ( $moving && self::folder_forbidden( $to_subdir ) ) {
			return array( 'error' => 'forbidden_folder' );
		}

		$entries = self::with_original_dims( Media_State::entries( $state ), $subdir );
		$map     = array();

		foreach ( $entries as $name => $entry ) {
			$new = $renaming ? Media_State::renamed( (string) $name, $old_stem, $new_stem ) : (string) $name;
			$to  = Media_Files::rel_path( $to_subdir, $new );

			// FR-12.3: 新しいファイルの置き先が1つでも使われていれば実行しない（連番は付けない）。
			// フォルダが変わるときは、親ディレクトリを作らないtaken()で確かめる
			if ( $moving ? Media_Files::taken( $to ) : Media_Files::occupied( $to ) ) {
				return array(
					'error'  => 'name_taken',
					'detail' => $moving ? $to : $new,
					'moving' => $moving,
				);
			}

			$map[ (string) $name ] = array(
				'name'   => $new,
				'width'  => (int) $entry['width'],
				'height' => (int) $entry['height'],
			);
		}

		$to_state = $renaming ? Media_State::rename_state( $state, $old_stem, $new_stem ) : $state;

		if ( $moving ) {
			$to_state = Media_State::move_state( $to_state, $to_subdir );
		}

		return self::begin_plan(
			$attachment_id,
			Media_Ops::TYPE_RENAME,
			array(
				'from_state'   => $state,
				'from_hash'    => Media_State::hash( $state ),
				'from_entries' => $entries,
				'to_state'     => $to_state,
				'file_map'     => $map,
				'to'           => array(
					'name'   => wp_basename( $to_state['attached_file'] ),
					'width'  => (int) ( $state['metadata']['width'] ?? 0 ),
					'height' => (int) ( $state['metadata']['height'] ?? 0 ),
					'mime'   => $state['mime'],
				),
			)
		);
	}

	/**
	 * 差し替えのプレビューを始める（FR-11）
	 *
	 * ファイル名は旧語幹を維持し、拡張子だけ新しい形式に合わせる（FR-11.2）。
	 * 新しい中間サイズの名前は、寸法からの見込みで衝突を確かめる（実際の名前は
	 * 段1の生成結果で決まり、そこでもう一度確かめる）。
	 *
	 * @param int    $attachment_id 添付ID。
	 * @param string $upload_id     Media_Upload::store()が返したID。
	 * @return array plan_step()と同じ形。始められなければerrorキー（とdetail）を持つ。
	 */
	public static function preview_replace( int $attachment_id, string $upload_id ): array {
		$blocked = self::preview_blocker( $attachment_id );

		if ( '' !== $blocked ) {
			return array( 'error' => $blocked );
		}

		$upload = Media_Upload::get( $upload_id, $attachment_id );

		if ( null === $upload ) {
			return array( 'error' => 'upload_missing' );
		}

		$state   = Media_State::capture( $attachment_id );
		$subdir  = Media_State::subdir( $state );
		$stem    = Media_State::stem( $state );
		$ext     = (string) $upload['ext'];
		$entries = self::with_original_dims( Media_State::entries( $state ), $subdir );
		$names   = array_map( 'strval', array_keys( $entries ) );
		$main    = $stem . '.' . $ext;
		$sizes   = self::predicted_sizes( (int) $upload['width'], (int) $upload['height'] );

		$predicted = array( $main );

		foreach ( $sizes as $dims ) {
			$predicted[] = $stem . '-' . $dims[0] . 'x' . $dims[1] . '.' . $ext;
		}

		$predicted = array_values( array_unique( $predicted ) );

		// この添付のものでないファイルとぶつかるなら始めない（ほかの添付を巻き込まない）
		foreach ( $predicted as $name ) {
			if ( ! in_array( $name, $names, true ) && Media_Files::occupied( Media_Files::rel_path( $subdir, $name ) ) ) {
				return array(
					'error'  => 'name_taken',
					'detail' => $name,
				);
			}
		}

		// 同名で入れ替わる見込みのファイルを、ほかの添付も使っていれば始めない（翻訳プラグインの
		// 複製など。入れ替えると、そちらの表示も黙って変わる）。段1の入れ替えの直前にも確かめる
		$shared = Media_References::shared_names( array_values( array_intersect( $predicted, $names ) ), $attachment_id, $subdir );

		if ( ! empty( $shared ) ) {
			return array(
				'error'  => 'shared_file',
				'detail' => $shared[0],
			);
		}

		return self::begin_plan(
			$attachment_id,
			Media_Ops::TYPE_REPLACE,
			array(
				'from_state'      => $state,
				'from_hash'       => Media_State::hash( $state ),
				'from_entries'    => $entries,
				'upload_id'       => $upload_id,
				'to'              => array(
					'name'   => $main,
					'width'  => (int) $upload['width'],
					'height' => (int) $upload['height'],
					'mime'   => (string) $upload['mime'],
					'bytes'  => (int) $upload['bytes'],
				),
				'predicted_names' => $predicted,
				// 旧 → 新ファイルの対応の見込み（プレビューで、書き換えのあとに残る旧ファイル名を見積もる。
				// 対応のないもの＝作られなくなるサイズ・画像編集のバックアップは、参照されていれば残る見込みになる）
				'predicted_map'   => self::replace_map( $entries, self::predicted_entries( $main, (int) $upload['width'], (int) $upload['height'], $stem, $ext, $sizes ) ),
				// 同じURLのまま中身が変わると、ブラウザやCDNのキャッシュで旧画像が見え続けることがある
				'notices'         => in_array( $main, $names, true ) ? array( 'same_url' ) : array(),
			)
		);
	}

	/**
	 * 差し替えで作られる見込みのファイル（replace_map()に渡す形）
	 *
	 * 名前は寸法からの見込み（実際の名前は段1の生成結果で決まる）。
	 *
	 * @param string $main   新しい原画の名前。
	 * @param int    $width  新しい画像の幅。
	 * @param int    $height 新しい画像の高さ。
	 * @param string $stem   語幹。
	 * @param string $ext    新しい拡張子。
	 * @param array  $sizes  predicted_sizes()の戻り値。
	 * @return array<string, array{roles: string[], width: int, height: int}>
	 */
	private static function predicted_entries( string $main, int $width, int $height, string $stem, string $ext, array $sizes ): array {
		$entries = array(
			$main => array(
				'roles'  => array( 'file' ),
				'width'  => $width,
				'height' => $height,
			),
		);

		foreach ( $sizes as $size => $dims ) {
			$name = $stem . '-' . $dims[0] . 'x' . $dims[1] . '.' . $ext;

			if ( ! isset( $entries[ $name ] ) ) {
				$entries[ $name ] = array(
					'roles'  => array(),
					'width'  => (int) $dims[0],
					'height' => (int) $dims[1],
				);
			}

			$entries[ $name ]['roles'][] = 'size:' . $size;
		}

		return $entries;
	}

	/**
	 * 新しい画像から作られる見込みのサイズ（プレビューの見込み用）
	 *
	 * 停止中のサイズは作らない（FR-3.2）。サードパーティのフィルタは通さない
	 * （見込みのために副作用を起こさない）。
	 *
	 * @param int $width  新しい画像の幅。
	 * @param int $height 新しい画像の高さ。
	 * @return array<string, array{0: int, 1: int}> サイズ名 => 寸法。
	 */
	private static function predicted_sizes( int $width, int $height ): array {
		$disabled = Size_Registry::disabled_sizes();
		$sizes    = array();

		foreach ( wp_get_registered_image_subsizes() as $name => $def ) {
			if ( in_array( $name, $disabled, true ) ) {
				continue;
			}

			$dims = image_resize_dimensions( $width, $height, (int) $def['width'], (int) $def['height'], $def['crop'] ?? false );

			if ( is_array( $dims ) ) {
				$sizes[ $name ] = array( (int) $dims[4], (int) $dims[5] );
			}
		}

		return $sizes;
	}

	/**
	 * 直前の操作を元に戻すプレビューを始める（FR-13.3）
	 *
	 * 新旧を入れ替えた同じ流れ（段1〜4）を通す。記事のリビジョンを丸ごと
	 * 戻すことはしない（操作のあとの別の編集を消さないため）。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return array plan_step()と同じ形。始められなければerrorキーを持つ。
	 */
	public static function preview_undo( int $attachment_id ): array {
		$blocked = self::preview_blocker( $attachment_id );

		if ( '' !== $blocked ) {
			return array( 'error' => $blocked );
		}

		$blocker = self::undo_blocker( $attachment_id );

		if ( '' !== $blocker ) {
			return array( 'error' => $blocker );
		}

		$forward  = Media_Ops::latest_effective( $attachment_id );
		$previous = Media_Ops::decode( $forward, 'details' );
		$state    = Media_State::capture( $attachment_id );
		$subdir   = Media_State::subdir( $state );
		$to_state = $previous['from_state'];

		return self::begin_plan(
			$attachment_id,
			Media_Ops::TYPE_UNDO,
			array(
				'from_state'   => $state,
				'from_hash'    => Media_State::hash( $state ),
				'from_entries' => self::with_original_dims( Media_State::entries( $state ), $subdir ),
				'to_state'     => $to_state,
				'file_map'     => self::inverse_map( (array) $previous['file_map'], (array) $previous['from_entries'] ),
				'to'           => array(
					'name'   => wp_basename( (string) $to_state['attached_file'] ),
					'width'  => (int) ( $to_state['metadata']['width'] ?? 0 ),
					'height' => (int) ( $to_state['metadata']['height'] ?? 0 ),
					'mime'   => (string) $to_state['mime'],
				),
			),
			(int) $forward->op_id
		);
	}

	/**
	 * 対応表を逆向きにする（取り消し用）
	 *
	 * 同じ新ファイルへ複数の旧ファイルが対応していた場合は、次の順で1つに決める。
	 * 1. 役割にfileを持つ旧ファイル。WordPressがフルサイズとして出していたファイルで
	 *    （-scaledのある画像の-scaled）、本文のフルサイズの参照が差し替えで新ファイルへ
	 *    移っているため、取り消しではここへ戻す。原画（-scaledでないほう）を選ぶと、
	 *    本文がもとの巨大な画像を指してしまう
	 * 2. fileを持つものがなければ、新ファイルと同名の旧ファイル
	 * 3. どちらもなければ、先に現れたもの
	 *
	 * @param array $map         操作の対応表（旧 => 新）。
	 * @param array $old_entries 操作前のファイルの一覧（役割と寸法の出どころ）。
	 * @return array 新ファイル名 => { name, width, height }。
	 */
	private static function inverse_map( array $map, array $old_entries ): array {
		$inverse = array();
		$ranks   = array();

		foreach ( $map as $old => $new ) {
			if ( ! is_array( $new ) ) {
				continue;
			}

			$old    = (string) $old;
			$target = (string) $new['name'];
			$rank   = 0;

			if ( in_array( 'file', (array) ( $old_entries[ $old ]['roles'] ?? array() ), true ) ) {
				$rank = 2;
			} elseif ( $old === $target ) {
				$rank = 1;
			}

			// 順位が同じなら先に現れたものを残す
			if ( isset( $ranks[ $target ] ) && $rank <= $ranks[ $target ] ) {
				continue;
			}

			$ranks[ $target ]   = $rank;
			$inverse[ $target ] = array(
				'name'   => $old,
				'width'  => (int) ( $old_entries[ $old ]['width'] ?? 0 ),
				'height' => (int) ( $old_entries[ $old ]['height'] ?? 0 ),
			);
		}

		return $inverse;
	}

	/**
	 * プレビューを始められない理由
	 *
	 * @param int $attachment_id 添付ID。
	 * @return string 始められれば''。
	 */
	private static function preview_blocker( int $attachment_id ): string {
		$reason = self::eligibility( $attachment_id );

		if ( '' !== $reason ) {
			return $reason;
		}

		// FR-13.4: 実行中のメディア操作・ジョブがあれば始めない
		if ( Media_Ops::running() ) {
			return 'busy_media_op';
		}

		return self::job_running() ? 'busy_job' : '';
	}

	/**
	 * 入力された名前から、前後の空白と今の拡張子を外す
	 *
	 * @param string $input 入力（拡張子付きでもよい）。
	 * @param string $ext   現在の拡張子。
	 * @return string 正規化する前の語幹。
	 */
	private static function input_stem( string $input, string $ext ): string {
		$input  = trim( $input );
		$suffix = '' === $ext ? '' : '.' . $ext;
		$length = strlen( $suffix );

		if ( $length > 0 && strlen( $input ) > $length && 0 === strcasecmp( substr( $input, -$length ), $suffix ) ) {
			$input = substr( $input, 0, -$length );
		}

		return $input;
	}

	/**
	 * 入力されたフォルダの、前後の空白と/を除き、連続する/を1つにまとめる
	 *
	 * 文字の規則は見ない（normalize_folder()と、今のフォルダとの比較で共有する）。
	 *
	 * @param string $input 入力。
	 * @return string|null 整えた文字列。正規表現が失敗したらnull（空文字＝uploads直下と取り違えない）。
	 */
	private static function trim_folder( string $input ): ?string {
		return preg_replace( '#/+#', '/', trim( trim( $input ), '/' ) );
	}

	/**
	 * 入力されたフォルダを、uploadsからの相対パスに正規化する（FR-12.6。設計書2026-11-12の§4.2）
	 *
	 * 前後の空白と/を除き、連続する/を1つにまとめる。各階層に使えるのは半角英数字・
	 * ハイフン・アンダースコアだけ。違反は直さずに拒否する（フォルダはURLの一部に
	 * なるので、黙って変えた値を本文に入れない）。画面側で同じ規則を再実装しない。
	 *
	 * @param string $input 入力。
	 * @return string|null 正規化したパス（uploads直下は空文字）。使えない文字を含む、または処理に失敗すればnull。
	 */
	private static function normalize_folder( string $input ): ?string {
		$folder = self::trim_folder( $input );

		if ( null === $folder ) {
			return null;
		}

		if ( '' === $folder ) {
			return '';
		}

		foreach ( explode( '/', $folder ) as $segment ) {
			// 末尾の改行を$に一致させない（D修飾子）
			if ( 1 !== preg_match( '/^[A-Za-z0-9_-]+$/D', $segment ) ) {
				return null;
			}
		}

		return $folder;
	}

	/**
	 * 移動先にできないフォルダか（FR-12.6。設計書2026-11-12の§4.2）
	 *
	 * - 隔離ディレクトリとその下（今の隔離ディレクトリ名に限らず、接頭辞で拒否する）
	 * - マルチサイトのメインサイトの、サブサイトのアップロード領域（sites）
	 * - 実パスがuploadsの外に解決されるもの（NFR-1.4）
	 *
	 * @param string $folder normalize_folder()を通したパス。
	 */
	private static function folder_forbidden( string $folder ): bool {
		$first = strtolower( explode( '/', $folder )[0] );

		if ( 0 === strpos( $first, 'rgrl-quarantine-' ) ) {
			return true;
		}

		if ( is_multisite() && is_main_site() && 'sites' === $first ) {
			return true;
		}

		return ! Media_Files::folder_inside_uploads( $folder );
	}

	/**
	 * 入力された名前を語幹に正規化する
	 *
	 * 正規化はコアのアップロードと同じsanitize_file_name()に任せる。
	 * 画面側で同じ規則を再実装しない（結果はプレビューで見せる）。
	 *
	 * @param string $input 入力（拡張子付きでもよい）。
	 * @param string $ext   現在の拡張子。
	 * @return string 語幹。使えなければ''。
	 */
	private static function normalize_stem( string $input, string $ext ): string {
		$input  = self::input_stem( $input, $ext );
		$suffix = '' === $ext ? '' : '.' . $ext;
		$length = strlen( $suffix );

		if ( '' === $input ) {
			return '';
		}

		$name = sanitize_file_name( $input . $suffix );

		if ( 0 === $length ) {
			return $name;
		}

		if ( strlen( $name ) <= $length || 0 !== strcasecmp( substr( $name, -$length ), $suffix ) ) {
			return '';
		}

		return substr( $name, 0, -$length );
	}

	/**
	 * 寸法が分からない原画（original_image）の寸法を、ファイルから補う
	 *
	 * 本文のwidth / heightを書き換えてよいかの照合（old_dims）に使う。
	 *
	 * @param array  $entries Media_State::entries()の値。
	 * @param string $subdir  年月ディレクトリ。
	 * @return array 寸法を補った一覧。
	 */
	private static function with_original_dims( array $entries, string $subdir ): array {
		foreach ( $entries as $name => $entry ) {
			if ( $entry['width'] > 0 || ! in_array( 'original', $entry['roles'], true ) ) {
				continue;
			}

			$path = Media_Files::abs_existing( Media_Files::rel_path( $subdir, (string) $name ) );
			$size = null === $path ? false : wp_getimagesize( $path );

			if ( is_array( $size ) ) {
				$entries[ $name ]['width']  = (int) $size[0];
				$entries[ $name ]['height'] = (int) $size[1];
			}
		}

		return $entries;
	}

	/**
	 * 操作を記録し、計画の最初の1回分を進める
	 *
	 * @param int    $attachment_id 添付ID。
	 * @param string $op_type       Media_Ops::TYPE_*。
	 * @param array  $details       旧状態・対応表など。
	 * @param int    $undo_of       取り消しのとき、取り消す操作のop_id。
	 * @return array plan_step()の戻り値。
	 */
	private static function begin_plan( int $attachment_id, string $op_type, array $details, int $undo_of = 0 ): array {
		$names = array_map( 'strval', array_keys( $details['from_entries'] ) );
		$plan  = array(
			'total'      => Media_References::count_candidates( $names ),
			'scanned'    => 0,
			'posts'      => array(),
			'refs'       => 0,
			'skipped'    => array(),
			'issues'     => array(),
			'skip_names' => array(),
			'left_names' => array(),
		);

		$op_id = Media_Ops::create( $attachment_id, $op_type, $details, $plan, $undo_of );

		if ( $op_id < 1 ) {
			return array( 'error' => 'db_failed' );
		}

		return self::plan_step( $op_id );
	}

	/**
	 * 計画（局所スキャン）を1回分進める
	 *
	 * 対象添付のファイル名を含む記事だけを読み、Scannerの判定を通して
	 * 書き換え対象とスキップに分ける。終わったらプレビューを作る。
	 *
	 * @param int $op_id 操作ID。
	 * @return array { op_id, done, posts_scanned, posts_total, preview }。
	 */
	public static function plan_step( int $op_id ): array {
		$op = Media_Ops::get( $op_id );

		if ( ! $op ) {
			return array( 'error' => 'not_found' );
		}

		if ( Media_Ops::ST_PLANNED === $op->status ) {
			return self::plan_progress( $op, true );
		}

		if ( Media_Ops::ST_PLANNING !== $op->status ) {
			return array( 'error' => 'not_planning' );
		}

		$details = Media_Ops::decode( $op, 'details' );
		$plan    = Media_Ops::decode( $op, 'plan' );
		$names   = array_map( 'strval', array_keys( $details['from_entries'] ) );
		$subdir  = self::from_subdir( $details );
		$cleanup = self::cleanup_names( $details );

		/**
		 * メディア操作の計画で1回に読む記事数
		 *
		 * @param int $batch_size 既定20。TIME_BUDGET秒を超えた時点でも打ち切る。
		 */
		$batch    = max( 1, (int) apply_filters( 'rgrl_media_plan_batch_size', 20 ) );
		$resolver = new Reference_Resolver();
		$started  = microtime( true );
		$last     = (int) $op->last_post_id;
		$done     = false;

		while ( microtime( true ) - $started < self::TIME_BUDGET ) {
			$ids = Media_References::candidate_post_ids( $names, $last, $batch );

			if ( empty( $ids ) ) {
				$done = true;
				break;
			}

			foreach ( $ids as $post_id ) {
				$post = get_post( $post_id );

				if ( $post instanceof WP_Post ) {
					$classified = Media_References::classify( Scanner::scan_post( $post, $resolver ), (int) $op->attachment_id, $subdir, $names );

					self::add_to_plan( $plan, $classified );

					$plan['left_names'] = array_values(
						array_unique(
							array_merge(
								(array) ( $plan['left_names'] ?? array() ),
								self::names_left_after_rewrite( $post, $classified['targets'], $details, $cleanup )
							)
						)
					);
				}

				$last = $post_id;
				++$plan['scanned'];
			}
		}

		if ( ! $done ) {
			Media_Ops::update(
				$op_id,
				array(
					'last_post_id' => $last,
					'plan'         => $plan,
				)
			);

			return self::plan_progress( Media_Ops::get( $op_id ), false );
		}

		$details['preview'] = self::build_preview( $op, $details, $plan );

		Media_Ops::update(
			$op_id,
			array(
				'status'       => Media_Ops::ST_PLANNED,
				'last_post_id' => 0,
				'details'      => $details,
				'plan'         => $plan,
			)
		);

		return self::plan_progress( Media_Ops::get( $op_id ), true );
	}

	/**
	 * 段3の書き換えを本文に当てたあとも残る、隔離の候補のファイル名（プレビューの見込み）
	 *
	 * 段4は、旧ファイル名が本文に文字列として残っていれば隔離しない。局所スキャンが
	 * 拾わない書き方（メディアファイルへのリンク<a href>、ショートコードの属性など）や、
	 * 書き換えない参照（スキップ・対応するファイルがないもの）の名前は残る。段3と同じ
	 * 書き換え（Applier::rewrite_content()）をメモリ上で当て、段4と同じく大文字小文字を
	 * 区別せずに探す。保存はしない。新しい名前は、名前変更・取り消しでは決まっている
	 * 対応表、差し替えでは寸法からの見込み（predicted_map）を使う。
	 * フォルダが変わる操作では、書き換えたあとの本文から新URLを取り除いてから探す
	 * （新URLも同じファイル名を含むため。設計書2026-11-12の§7.3）。
	 *
	 * @param WP_Post  $post    記事。
	 * @param array    $targets classify()の書き換え対象。
	 * @param array    $details details（file_map / predicted_map）。
	 * @param string[] $cleanup 隔離の候補（旧にあって新にない名前）。
	 * @return string[] 残るファイル名。
	 */
	private static function names_left_after_rewrite( WP_Post $post, array $targets, array $details, array $cleanup ): array {
		if ( empty( $cleanup ) ) {
			return array();
		}

		$file_map = isset( $details['file_map'] ) ? (array) $details['file_map'] : (array) ( $details['predicted_map'] ?? array() );
		$resolver = new Reference_Resolver();
		$moving   = self::folder_changes( $details );
		$map      = array();
		$strip    = array();

		foreach ( $targets as $target ) {
			$new = $file_map[ (string) $target['name'] ] ?? null;
			$url = (string) $target['url'];

			// 対応するファイルがない参照は書き換えない（段3と同じ）
			if ( ! is_array( $new ) || isset( $map[ $url ] ) ) {
				continue;
			}

			$new_url = self::new_url( $resolver, $details, $url, (string) $new['name'] );

			// 場所を差し替えられなかった参照は書き換えない（段3と同じ）
			if ( $moving && $new_url === $url ) {
				continue;
			}

			$map[ $url ] = array(
				'new_url'       => $new_url,
				'new_width'     => (int) $new['width'],
				'new_height'    => (int) $new['height'],
				'caption_width' => null,
				'old_dims'      => null,
			);

			if ( $moving ) {
				$strip = array_merge( $strip, self::written_forms( $new_url ) );
			}
		}

		$content = (string) $post->post_content;
		$content = empty( $map ) ? $content : Applier::rewrite_content( $content, $map );

		// フォルダが変わる操作では、書いた新URLも旧ファイルと同じファイル名を含む。
		// 段4と同じく、取り除いてから探す（FR-12.8）
		if ( ! empty( $strip ) ) {
			$content = str_replace( array_values( array_unique( $strip ) ), '', $content );
		}

		$left = array();

		foreach ( $cleanup as $name ) {
			foreach ( Media_References::variants( (string) $name ) as $variant ) {
				if ( false !== stripos( $content, $variant ) ) {
					$left[] = (string) $name;
					break;
				}
			}
		}

		return $left;
	}

	/**
	 * 局所スキャン1記事分を計画へ足す
	 *
	 * @param array $plan       計画（参照渡し）。
	 * @param array $classified Media_References::classify()の戻り値。
	 */
	private static function add_to_plan( array &$plan, array $classified ): void {
		foreach ( $classified['targets'] as $target ) {
			$plan['posts'][ (int) $target['post_id'] ][] = $target;
			++$plan['refs'];
		}

		foreach ( $classified['skips'] as $skip ) {
			self::count_skip( $plan, (int) $skip['post_id'], (string) $skip['reason'], 1 );

			if ( '' !== $skip['name'] && ! in_array( $skip['name'], $plan['skip_names'], true ) ) {
				$plan['skip_names'][] = (string) $skip['name'];
			}
		}
	}

	/**
	 * スキップを理由別に数え、記事へのリンク付きで記録する（FR-6.5）
	 *
	 * @param array  $bucket  skipped / issuesを持つ配列（参照渡し）。
	 * @param int    $post_id 記事ID。
	 * @param string $reason  理由。
	 * @param int    $count   件数。
	 */
	private static function count_skip( array &$bucket, int $post_id, string $reason, int $count ): void {
		if ( $count < 1 ) {
			return;
		}

		$bucket['skipped'][ $reason ] = (int) ( $bucket['skipped'][ $reason ] ?? 0 ) + $count;

		// 変更不要は問題ではないため、一覧には出さない
		if ( Reference_Graph::SKIP_NO_CHANGE === $reason || count( $bucket['issues'] ) >= self::MAX_ISSUES ) {
			return;
		}

		foreach ( $bucket['issues'] as $issue ) {
			if ( (int) $issue['post_id'] === $post_id && $issue['reason'] === $reason ) {
				return;
			}
		}

		$bucket['issues'][] = array(
			'post_id'  => $post_id,
			'title'    => get_the_title( $post_id ),
			'edit_url' => (string) get_edit_post_link( $post_id, 'raw' ),
			'reason'   => $reason,
		);
	}

	/**
	 * プレビューを組み立てる（FR-11.5）
	 *
	 * 残す見込みのファイルとは、隔離の候補（`cleanup_names()`）のうち、段4で
	 * まだDBに現れると見込まれるもの。走査範囲の記事の本文は、段3の書き換えを当てた
	 * あとに残る名前（names_left_after_rewrite()。スキップになった参照の名前も含む）、
	 * それ以外（範囲内の記事の抜粋、範囲外の記事、各メタ、options）はその時点の検索で見る。
	 *
	 * @param object $op      操作。
	 * @param array  $details details。
	 * @param array  $plan    計画。
	 * @return array
	 */
	private static function build_preview( $op, array $details, array $plan ): array {
		$from     = $details['from_state'];
		$cleanup  = self::cleanup_names( $details );
		$expected = array_merge(
			(array) $plan['skip_names'],
			(array) ( $plan['left_names'] ?? array() ),
			Media_References::still_referenced( $cleanup, (int) $op->attachment_id, true )
		);

		return array(
			'type'    => (string) $op->op_type,
			'from'    => array(
				'name'   => wp_basename( (string) $from['attached_file'] ),
				'folder' => self::from_subdir( $details ),
				'width'  => (int) ( $from['metadata']['width'] ?? 0 ),
				'height' => (int) ( $from['metadata']['height'] ?? 0 ),
				'mime'   => (string) $from['mime'],
			),
			// folderは、フォルダが変わる操作で「旧 → 新」を相対パスで見せるために足す
			'to'      => array_merge( (array) $details['to'], array( 'folder' => self::to_subdir( $details ) ) ),
			'posts'   => count( (array) $plan['posts'] ),
			'refs'    => (int) $plan['refs'],
			'skipped' => (array) $plan['skipped'],
			'issues'  => (array) $plan['issues'],
			'keep'    => array_values( array_intersect( $cleanup, $expected ) ),
			'notices' => (array) ( $details['notices'] ?? array() ),
		);
	}

	/**
	 * 操作のあとのファイル名（差し替えは段1までは見込み）
	 *
	 * @param array $details details。
	 * @return string[]
	 */
	private static function to_names( array $details ): array {
		if ( isset( $details['to_state'] ) ) {
			return array_map( 'strval', array_keys( Media_State::entries( $details['to_state'] ) ) );
		}

		return array_map( 'strval', (array) ( $details['predicted_names'] ?? array() ) );
	}

	/**
	 * 操作の前のファイルがあるサブディレクトリ
	 *
	 * @param array $details details。
	 * @return string uploads直下なら空文字。
	 */
	private static function from_subdir( array $details ): string {
		return Media_State::subdir( (array) $details['from_state'] );
	}

	/**
	 * 操作のあとのファイルを置くサブディレクトリ
	 *
	 * 新しい状態がまだ決まっていない（差し替えの段1より前）ときは、操作の前と同じ。
	 *
	 * @param array $details details。
	 * @return string uploads直下なら空文字。
	 */
	private static function to_subdir( array $details ): string {
		return isset( $details['to_state'] ) ? Media_State::subdir( (array) $details['to_state'] ) : self::from_subdir( $details );
	}

	/**
	 * 操作でフォルダが変わるか
	 *
	 * @param array $details details。
	 */
	private static function folder_changes( array $details ): bool {
		return self::from_subdir( $details ) !== self::to_subdir( $details );
	}

	/**
	 * 隔離の候補のファイル名
	 *
	 * 操作の前のファイルのうち、操作のあとのファイルと同じパスでないもの。
	 * フォルダが変わる操作では、名前が同じでも別のファイルなので、すべてが候補になる。
	 *
	 * @param array $details details。
	 * @return string[]
	 */
	private static function cleanup_names( array $details ): array {
		$names = array_map( 'strval', array_keys( (array) $details['from_entries'] ) );

		if ( self::folder_changes( $details ) ) {
			return $names;
		}

		return array_values( array_diff( $names, self::to_names( $details ) ) );
	}

	/**
	 * 状態に含まれるファイルの、uploadsからの相対パス
	 *
	 * @param array $state 状態。
	 * @return string[]
	 */
	private static function state_paths( array $state ): array {
		$subdir = Media_State::subdir( $state );
		$paths  = array();

		foreach ( array_keys( Media_State::entries( $state ) ) as $name ) {
			$paths[] = Media_Files::rel_path( $subdir, (string) $name );
		}

		return $paths;
	}

	/**
	 * 書き換え後のURL（FR-4.2 / FR-12.7）
	 *
	 * フォルダが変わらない操作ではファイル名部分だけ、変わる操作では末尾の
	 * 「サブディレクトリ/ファイル名」だけを差し替える。フォルダが変わる操作で
	 * 戻り値が元のURLと同じなら、場所を差し替えられなかった（書き換えないこと）。
	 *
	 * @param Reference_Resolver $resolver リゾルバ。
	 * @param array              $details  details。
	 * @param string             $url      現在のURL。
	 * @param string             $new_name 新しいファイル名。
	 */
	private static function new_url( Reference_Resolver $resolver, array $details, string $url, string $new_name ): string {
		return $resolver->replace_location( $url, self::from_subdir( $details ), self::to_subdir( $details ), $new_name );
	}

	/**
	 * 新URLが本文に書き出されるときの形（設計書2026-11-12の§7.1）
	 *
	 * HTMLタグ処理APIは属性の値をエスケープして書き出す（WordPressの版によって
	 * esc_url()かesc_attr()）。旧ファイルの参照を探す前に本文から取り除くため、
	 * 括る引用符ごと返す（タグ処理APIは属性値を常にダブルクォートで書くため。
	 * 裸のURLだと、書き換えていない別の参照の末尾に一致して取り除いてしまう）。
	 *
	 * @param string $new_url 新URL。
	 * @return string[]
	 */
	private static function written_forms( string $new_url ): array {
		$forms = array_values( array_unique( array_filter( array( $new_url, esc_url( $new_url ), esc_attr( $new_url ) ), 'strlen' ) ) );

		return array_map(
			static function ( $form ) {
				return '"' . $form . '"';
			},
			$forms
		);
	}

	/**
	 * 計画の進捗
	 *
	 * @param object $op   操作。
	 * @param bool   $done 終わったか。
	 * @return array
	 */
	private static function plan_progress( $op, bool $done ): array {
		$plan    = Media_Ops::decode( $op, 'plan' );
		$details = Media_Ops::decode( $op, 'details' );

		return array(
			'op_id'         => (int) $op->op_id,
			'done'          => $done,
			'posts_scanned' => (int) ( $plan['scanned'] ?? 0 ),
			'posts_total'   => (int) ( $plan['total'] ?? 0 ),
			'preview'       => $done ? ( $details['preview'] ?? null ) : null,
		);
	}

	/*
	 * ---------------------------------------------------------------------
	 * 実行（段1〜4）
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 操作を1回分進める（plannedなら開始の確認から）
	 *
	 * 同じ操作を同時に進めない。二重送信や、プロキシのタイムアウト後の再開で
	 * 前の要求がまだ動いているときは、何も変えずにin_progressを返す。ロックは
	 * 接続が切れれば外れるため、ロックを取れたのに段1の途中状態が残っていれば
	 * 前の要求は確かに死んでいる（run_step1()が巻き戻して終える）。
	 *
	 * @param int $op_id 操作ID。
	 * @return array run_progress()の形。進められなければerrorキー（とdetail / op_id / failed / rollback）を持つ。
	 */
	public static function step( int $op_id ): array {
		if ( ! Media_Ops::get( $op_id ) ) {
			return array( 'error' => 'not_found' );
		}

		$lock = Media_Ops::lock_key( 'op_' . $op_id );
		$got  = Media_Ops::lock( $lock, 0 );

		if ( false === $got ) {
			return array(
				'error' => 'in_progress',
				'op_id' => $op_id,
			);
		}

		try {
			return self::step_locked( $op_id );
		} finally {
			// nullはロックの関数が使えないDB。取っていないので外さない
			if ( true === $got ) {
				Media_Ops::unlock( $lock );
			}
		}
	}

	/**
	 * step()の本体（操作のロックを持っている間だけ呼ぶ）
	 *
	 * 各段のあとで操作を読み直し、runningでなければ先へ進まない。
	 *
	 * @param int $op_id 操作ID。
	 * @return array step()と同じ形。
	 */
	private static function step_locked( int $op_id ): array {
		// ロックを取る前に別の要求が進めていたかもしれないため、ここで読み直す
		$op = Media_Ops::get( $op_id );

		if ( ! $op ) {
			return array( 'error' => 'not_found' );
		}

		if ( Media_Ops::ST_PLANNED === $op->status ) {
			$error = self::start_run( $op );

			if ( '' !== $error ) {
				return array(
					'error' => $error,
					'op_id' => $op_id,
				);
			}

			$op = Media_Ops::get( $op_id );
		}

		if ( Media_Ops::ST_COMPLETE === $op->status ) {
			return self::run_progress( $op );
		}

		if ( Media_Ops::ST_RUNNING !== $op->status ) {
			return array(
				'error' => 'not_running',
				'op_id' => $op_id,
			);
		}

		$started = microtime( true );

		if ( 0 === (int) $op->step ) {
			$error = self::run_step1( $op );

			if ( '' !== $error ) {
				return self::failure( $op_id, $error );
			}

			$op = Media_Ops::get( $op_id );

			if ( Media_Ops::ST_RUNNING !== $op->status ) {
				return self::run_progress( $op );
			}
		}

		if ( 1 === (int) $op->step ) {
			$error = self::run_step2( $op );

			if ( '' !== $error ) {
				return self::failure( $op_id, $error );
			}

			$op = Media_Ops::get( $op_id );

			if ( Media_Ops::ST_RUNNING !== $op->status ) {
				return self::run_progress( $op );
			}
		}

		if ( 2 === (int) $op->step && ! self::relink_batch( $op, $started ) ) {
			return self::run_progress( Media_Ops::get( $op_id ) );
		}

		$op = Media_Ops::get( $op_id );

		if ( Media_Ops::ST_RUNNING !== $op->status ) {
			return self::run_progress( $op );
		}

		if ( 3 === (int) $op->step ) {
			self::finish_run( $op );
			$op = Media_Ops::get( $op_id );
		}

		return self::run_progress( $op );
	}

	/**
	 * 段1・段2が失敗したときの応答
	 *
	 * failedで終えられていれば{ error, detail, op_id, failed, rollback, metadata_restored, moving }。
	 * 終えられていなければ（失敗の記録を書けなかった）runningのまま残っており、
	 * 次の要求が続きから後始末するため、{ error, op_id }だけを返す。
	 *
	 * @param int    $op_id 操作ID。
	 * @param string $error 理由コード。
	 * @return array
	 */
	private static function failure( int $op_id, string $error ): array {
		$op = Media_Ops::get( $op_id );

		if ( ! $op || Media_Ops::ST_FAILED !== $op->status ) {
			return array(
				'error' => $error,
				'op_id' => $op_id,
			);
		}

		$details = Media_Ops::decode( $op, 'details' );

		return array(
			'error'             => $error,
			'detail'            => (string) ( $details['error_detail'] ?? '' ),
			'op_id'             => $op_id,
			'failed'            => true,
			// 巻き戻せなかったファイル（通常は空）。握りつぶさず画面まで届ける
			'rollback'          => array_map( 'strval', (array) ( $details['rollback_errors'] ?? array() ) ),
			// メタデータを旧状態へ戻せたか（段1の失敗ではメタデータに触れないのでtrue）。
			// falseなら、新旧どちらのファイルも残してある
			'metadata_restored' => (bool) ( $details['metadata_restored'] ?? true ),
			// フォルダを変える操作か（文言が、detailを移動先の相対パスとして示す）
			'moving'            => self::folder_changes( $details ),
		);
	}

	/**
	 * 実行を始めてよいか確かめ、runningにする
	 *
	 * 「ほかにrunningがないことの確認」から「runningにする」までを、サイト全体の
	 * 開始のロック（Media_Ops::while_starting()）で包む。包まないと、別の操作や
	 * ジョブの開始と同時に走ったとき、どちらも確認を通ってしまう（NFR-2.4）。
	 *
	 * @param object $op 操作（planned）。
	 * @return string 始められなければ理由コード。ロックを取れなければin_progress。
	 */
	private static function start_run( $op ): string {
		$error = Media_Ops::while_starting(
			static function () use ( $op ) {
				return self::start_run_locked( $op );
			}
		);

		return null === $error ? 'in_progress' : $error;
	}

	/**
	 * start_run()の本体（開始のロックを持っている間だけ呼ぶ）
	 *
	 * @param object $op 操作（planned）。
	 * @return string 始められなければ理由コード。
	 */
	private static function start_run_locked( $op ): string {
		$attachment_id = (int) $op->attachment_id;
		$details       = Media_Ops::decode( $op, 'details' );
		$plan          = Media_Ops::decode( $op, 'plan' );

		if ( Media_Ops::running() ) {
			return 'busy_media_op';
		}

		if ( self::job_running() ) {
			return 'busy_job';
		}

		// プレビューのあとに添付が変わっていたら実行しない（FR-6.4と同じ考え方）
		if ( Media_State::hash( Media_State::capture( $attachment_id ) ) !== (string) ( $details['from_hash'] ?? '' ) ) {
			return 'stale';
		}

		$error = self::type_precondition( $op, $details );

		if ( '' !== $error ) {
			return $error;
		}

		$details['quarantined'] = array();
		$details['kept']        = array();
		$details['result']      = array(
			'posts_total'   => count( (array) ( $plan['posts'] ?? array() ) ),
			'posts_updated' => 0,
			'refs_updated'  => 0,
			'skipped'       => (array) ( $plan['skipped'] ?? array() ),
			'issues'        => (array) ( $plan['issues'] ?? array() ),
			'kept'          => array(),
			'quarantined'   => 0,
		);

		// plannedのときだけrunningにする。読んでから書くまでに、ほかの要求が始めていたら書かない
		// （ロックの関数が使えないDBで、同じ操作を二重に始めないように）
		$moved = Media_Ops::update_if_status(
			(int) $op->op_id,
			Media_Ops::ST_PLANNED,
			array(
				'status'       => Media_Ops::ST_RUNNING,
				'step'         => 0,
				'last_post_id' => 0,
				'details'      => $details,
				'journal'      => array(),
			)
		);

		if ( null === $moved ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 操作を始められなかった理由を握りつぶさないため
			error_log( sprintf( 'Regenerate & Relink: could not start media operation %d.', (int) $op->op_id ) );

			return 'db_failed';
		}

		return 0 === $moved ? 'in_progress' : '';
	}

	/**
	 * 種別ごとの開始の前提
	 *
	 * @param object $op      操作。
	 * @param array  $details details。
	 * @return string 満たさなければ理由コード。
	 */
	private static function type_precondition( $op, array $details ): string {
		switch ( (string) $op->op_type ) {
			case Media_Ops::TYPE_RENAME:
				// 名前変更の新しい状態はプレビューで決まっている
				return isset( $details['to_state'] ) ? '' : 'not_supported';

			case Media_Ops::TYPE_REPLACE:
				return null === Media_Upload::get( (string) ( $details['upload_id'] ?? '' ), (int) $op->attachment_id ) ? 'upload_missing' : '';

			case Media_Ops::TYPE_UNDO:
				$latest = Media_Ops::latest_effective( (int) $op->attachment_id );

				// プレビューのあとに別の操作が入っていたら戻さない
				if ( ! $latest || (int) $latest->op_id !== (int) $op->undo_of ) {
					return 'no_op';
				}

				return self::undo_blocker( (int) $op->attachment_id );
		}

		return 'not_supported';
	}

	/**
	 * 段1: 新ファイルを作る（旧ファイルの横。フォルダを変える操作では移動先）
	 *
	 * 失敗・中断したら作りかけを巻き戻し、旧状態のままfailedで終える。
	 *
	 * @param object $op 操作（running、step 0）。
	 * @return string 失敗の理由コード。成功なら''。
	 */
	private static function run_step1( $op ): string {
		$op_id   = (int) $op->op_id;
		$details = Media_Ops::decode( $op, 'details' );

		if ( ! empty( $details['step1_started'] ) ) {
			// 前回の段1が途中で止まった（タイムアウト等）。やりかけを巻き戻して終える
			self::rollback( $op_id );
			self::fail( $op_id, 'interrupted' );

			return 'interrupted';
		}

		$details['step1_started'] = true;
		Media_Ops::update( $op_id, array( 'details' => $details ) );

		switch ( (string) $op->op_type ) {
			case Media_Ops::TYPE_RENAME:
				$error = self::step1_rename( $op, $details );
				break;

			case Media_Ops::TYPE_REPLACE:
				$error = self::step1_replace( $op, $details );
				break;

			case Media_Ops::TYPE_UNDO:
				$error = self::step1_undo( $op, $details );
				break;

			default:
				$error = 'not_supported';
		}

		if ( '' !== $error ) {
			// error_detailを残してから巻き戻す
			Media_Ops::update( $op_id, array( 'details' => $details ) );
			self::rollback( $op_id );
			self::fail( $op_id, $error );

			return $error;
		}

		unset( $details['step1_started'] );

		// journalは消さない。段2が失敗したときも、段1で作ったファイルを巻き戻すために使う
		Media_Ops::update(
			$op_id,
			array(
				'step'    => 1,
				'details' => $details,
			)
		);

		return '';
	}

	/**
	 * 段1（名前・フォルダの変更）: 新しい名前・場所へファイルを複製する
	 *
	 * 旧ファイルは段4まで残し、どの時点でも旧URLを有効なままにする。
	 * フォルダを変えるときは、移動先のフォルダをここで作る（プレビューでは作らない）。
	 * 作ったフォルダは、巻き戻しでも消さない。
	 *
	 * @param object $op      操作。
	 * @param array  $details details（参照渡し。error_detailを書く）。
	 * @return string 失敗の理由コード。成功なら''。
	 */
	private static function step1_rename( $op, array &$details ): string {
		$op_id       = (int) $op->op_id;
		$from_subdir = self::from_subdir( $details );
		$to_subdir   = self::to_subdir( $details );
		$moving      = $from_subdir !== $to_subdir;

		if ( $moving ) {
			// プレビューのあとに移動先が変わっていないか（シンボリックリンクの差し替えなど）を
			// 確かめ直してから作る（設計書2026-11-12の§5.2）
			if ( self::folder_forbidden( $to_subdir ) ) {
				$details['error_detail'] = $to_subdir;
				return 'forbidden_folder';
			}

			if ( ! Media_Files::ensure_folder( $to_subdir ) ) {
				$details['error_detail'] = $to_subdir;
				return 'mkdir_failed';
			}
		}

		foreach ( (array) $details['file_map'] as $old => $new ) {
			$from = Media_Files::rel_path( $from_subdir, (string) $old );

			// メタデータにあるが実体のないファイルは、名前だけが変わる
			if ( ! is_array( $new ) || ! Media_Files::exists( $from ) ) {
				continue;
			}

			$to = Media_Files::rel_path( $to_subdir, (string) $new['name'] );

			if ( Media_Files::occupied( $to ) ) {
				$details['error_detail'] = $moving ? $to : (string) $new['name'];
				return 'name_taken';
			}

			// 先に記録してから動かす（中断しても巻き戻せるように）。記録できなければ動かさない
			$recorded = Media_Ops::append_journal(
				$op_id,
				array(
					'type'     => 'created',
					'rel_path' => $to,
				)
			);

			if ( ! $recorded ) {
				$details['error_detail'] = (string) $new['name'];
				return 'db_failed';
			}

			if ( ! Media_Files::copy( $from, $to ) ) {
				$details['error_detail'] = (string) $new['name'];
				return 'copy_failed';
			}
		}

		return '';
	}

	/**
	 * 段1（差し替え）: 新しい画像と中間サイズを作り、旧ファイルの横に置く
	 *
	 * 生成は作業用ディレクトリで行い、最終的な名前のファイルを作ってから
	 * uploadsへ置く。同名で置き換わるファイルは、ほかがすべて置けてから
	 * 旧ファイルを隔離して置き換える（設計書 §4.2）。置くたびに先に
	 * journalへ記録し、記録できなければ動かさない。
	 *
	 * @param object $op      操作。
	 * @param array  $details details（参照渡し。to_state / file_map / error_detailなどを書く）。
	 * @return string 失敗の理由コード。成功なら''。
	 */
	private static function step1_replace( $op, array &$details ): string {
		$op_id         = (int) $op->op_id;
		$attachment_id = (int) $op->attachment_id;
		$upload        = Media_Upload::get( (string) $details['upload_id'], $attachment_id );

		if ( null === $upload ) {
			return 'upload_missing';
		}

		$staging = Media_Files::staging_dir( $op_id );

		if ( null === $staging ) {
			return 'dir_failed';
		}

		$from   = $details['from_state'];
		$subdir = Media_State::subdir( $from );
		$staged = trailingslashit( $staging ) . Media_State::stem( $from ) . '.' . $upload['ext'];

		if ( ! Media_Files::stage_upload( (string) $upload['path'], $staged ) ) {
			return 'move_failed';
		}

		Media_Upload::forget( (string) $details['upload_id'] );

		$meta = self::generate( $staged, $attachment_id );

		if ( empty( $meta['file'] ) ) {
			return 'generate_failed';
		}

		$main         = wp_basename( (string) $meta['file'] );
		$meta['file'] = Media_Files::rel_path( $subdir, $main );
		$filetype     = wp_check_filetype( $main );
		$mime         = (string) $filetype['type'];

		// 出力形式の変換で、このサイトが許可していない形式になった場合など。空や画像でないMIMEを
		// 書くと添付が画像でなくなり、取り消しもできなくなるため、ここで止めて巻き戻す
		if ( 0 !== strpos( $mime, 'image/' ) ) {
			$details['error_detail'] = $main;
			return 'generate_failed';
		}

		$to_state  = array(
			'attached_file' => $meta['file'],
			'metadata'      => $meta,
			'backup_sizes'  => null,
			'mime'          => $mime,
		);
		$new_names = array_map( 'strval', array_keys( Media_State::entries( $to_state ) ) );
		$old_names = array_map( 'strval', array_keys( $details['from_entries'] ) );
		$swaps     = array();

		foreach ( $new_names as $name ) {
			if ( ! is_file( trailingslashit( $staging ) . $name ) ) {
				$details['error_detail'] = $name;
				return 'generate_failed';
			}

			if ( Media_Files::occupied( Media_Files::rel_path( $subdir, $name ) ) ) {
				// この添付の旧ファイルとだけ置き換える。ほかのファイルとぶつかったら止める
				if ( ! in_array( $name, $old_names, true ) ) {
					$details['error_detail'] = $name;
					return 'name_taken';
				}

				$swaps[] = $name;
			}
		}

		// プレビューのあとに、入れ替えるファイルをほかの添付が使い始めていたら、何も置かずに止める
		$shared = Media_References::shared_names( $swaps, $attachment_id, $subdir );

		if ( ! empty( $shared ) ) {
			$details['error_detail'] = $shared[0];
			return 'shared_file';
		}

		foreach ( $new_names as $name ) {
			if ( in_array( $name, $swaps, true ) ) {
				continue;
			}

			$rel = Media_Files::rel_path( $subdir, $name );

			// 先に記録してから動かす（中断しても巻き戻せるように）。記録できなければ動かさない
			$recorded = Media_Ops::append_journal(
				$op_id,
				array(
					'type'     => 'created',
					'rel_path' => $rel,
				)
			);

			if ( ! $recorded ) {
				$details['error_detail'] = $name;
				return 'db_failed';
			}

			if ( ! Media_Files::move_into_uploads( trailingslashit( $staging ) . $name, $rel ) ) {
				$details['error_detail'] = $name;
				return 'move_failed';
			}
		}

		foreach ( $swaps as $name ) {
			$rel     = Media_Files::rel_path( $subdir, $name );
			$file_id = Media_Files::quarantine( $attachment_id, $rel, Quarantine::REASON_REPLACED, $op_id );

			if ( null === $file_id ) {
				$details['error_detail'] = $name;
				return 'move_failed';
			}

			$details['quarantined'][ $name ] = $file_id;

			// 旧ファイルを隔離したあとに記録する（記録が先だと、巻き戻しが旧ファイルを消してしまう）。
			// 記録できなければ置かない。巻き戻しは隔離の行から旧ファイルを元の場所へ戻す
			$recorded = Media_Ops::append_journal(
				$op_id,
				array(
					'type'     => 'created',
					'rel_path' => $rel,
				)
			);

			if ( ! $recorded ) {
				$details['error_detail'] = $name;
				return 'db_failed';
			}

			if ( ! Media_Files::move_into_uploads( trailingslashit( $staging ) . $name, $rel ) ) {
				$details['error_detail'] = $name;
				return 'move_failed';
			}
		}

		Media_Files::remove_staging( $op_id );

		$to_entries = self::with_original_dims( Media_State::entries( $to_state ), $subdir );

		$details['to_state']   = $to_state;
		$details['to_entries'] = $to_entries;
		$details['file_map']   = self::replace_map( (array) $details['from_entries'], $to_entries );
		// 実際の名前（大きな画像は-scaledになる）
		$details['to']['name'] = wp_basename( $to_state['attached_file'] );

		return '';
	}

	/**
	 * 新しい画像から中間サイズを作り、メタデータを返す（DBには書かない）
	 *
	 * コアのアップロードと同じwp_create_image_subsizes()を使う（停止中の
	 * サイズ・big_image_size_threshold・EXIFの回転・出力形式の変換が同じに
	 * なる）。コアは生成の途中で添付のメタデータを書き込むため、その間だけ
	 * この添付の_wp_attached_file / _wp_attachment_metadataへの書き込みを
	 * 止め、段2でまとめて切り替える。wp_update_attachment_metadataの
	 * フィルタは通るため、画像最適化系のプラグインは作業用のファイルに
	 * 対して動くことがある。
	 *
	 * @param string $file          作業用ディレクトリに置いた新しい原画。
	 * @param int    $attachment_id 添付ID。
	 * @return array メタデータ。作れなければ空配列。
	 */
	private static function generate( string $file, int $attachment_id ): array {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$block = static function ( $check, $object_id, $meta_key ) use ( $attachment_id ) {
			if ( (int) $object_id === $attachment_id && in_array( $meta_key, array( '_wp_attached_file', '_wp_attachment_metadata' ), true ) ) {
				return true;
			}

			return $check;
		};

		add_filter( 'add_post_metadata', $block, 10, 3 );
		add_filter( 'update_post_metadata', $block, 10, 3 );
		add_filter( 'delete_post_metadata', $block, 10, 3 );

		try {
			$meta = wp_create_image_subsizes( $file, $attachment_id );
		} finally {
			remove_filter( 'add_post_metadata', $block, 10 );
			remove_filter( 'update_post_metadata', $block, 10 );
			remove_filter( 'delete_post_metadata', $block, 10 );
		}

		return is_array( $meta ) ? $meta : array();
	}

	/**
	 * 差し替えの旧 → 新ファイルの対応表（設計書 §5.3）
	 *
	 * 役割で対応させる。原画は新しい原画（なければ新しいfile）、fileは
	 * 新しいfile、各サイズは同じサイズ。画像編集のバックアップには対応が
	 * ない。複数の役割が別々の新ファイルを指すときは、判定に迷うため対応なし
	 * とする（NFR-1.1）。
	 *
	 * @param array $old_entries 旧ファイルの一覧。
	 * @param array $new_entries 新ファイルの一覧。
	 * @return array 旧ファイル名 => { name, width, height }またはnull。
	 */
	private static function replace_map( array $old_entries, array $new_entries ): array {
		$by_role = array();

		foreach ( $new_entries as $name => $entry ) {
			foreach ( $entry['roles'] as $role ) {
				if ( ! isset( $by_role[ $role ] ) ) {
					$by_role[ $role ] = (string) $name;
				}
			}
		}

		$map = array();

		foreach ( $old_entries as $name => $entry ) {
			$targets = array();

			foreach ( $entry['roles'] as $role ) {
				if ( 'original' === $role ) {
					$targets[] = $by_role['original'] ?? ( $by_role['file'] ?? '' );
				} elseif ( 'file' === $role || 0 === strpos( $role, 'size:' ) ) {
					$targets[] = $by_role[ $role ] ?? '';
				}
			}

			$targets = array_values( array_unique( array_filter( $targets, 'strlen' ) ) );

			if ( 1 !== count( $targets ) ) {
				$map[ (string) $name ] = null;
				continue;
			}

			$target = $targets[0];

			$map[ (string) $name ] = array(
				'name'   => $target,
				'width'  => (int) $new_entries[ $target ]['width'],
				'height' => (int) $new_entries[ $target ]['height'],
			);
		}

		return $map;
	}

	/**
	 * 段1（取り消し）: 元の操作が隔離した旧ファイルを、元の場所へ戻す
	 *
	 * 同じ場所に今のファイルがある（同名で置き換わった）ものは、ほかを
	 * 戻してから今のファイルを隔離して入れ替える（設計書 §4.2と同じ）。
	 * 戻すたびに先にjournalへ記録し、記録できなければ動かさない。
	 *
	 * @param object $op      操作（取り消し）。
	 * @param array  $details details（参照渡し。quarantined / error_detailを書く）。
	 * @return string 失敗の理由コード。成功なら''。
	 */
	private static function step1_undo( $op, array &$details ): string {
		$op_id         = (int) $op->op_id;
		$attachment_id = (int) $op->attachment_id;
		$current       = self::state_paths( (array) $details['from_state'] );
		$rows          = Quarantine::rows_for_op( (int) $op->undo_of, array( Quarantine::ST_QUARANTINED ) );
		$swaps         = array();

		foreach ( $rows as $row ) {
			if ( ! Media_Files::is_quarantined( (int) $row->file_id ) ) {
				return 'files_missing';
			}

			if ( Media_Files::occupied( (string) $row->rel_path ) ) {
				$name = wp_basename( (string) $row->rel_path );

				// 今のこの添付のファイルとだけ入れ替える。ほかのファイルとぶつかったら止める。
				// 名前でなくパスで比べる（フォルダを変えた操作では、戻し先にある同名のファイルは別のファイル）
				if ( ! in_array( (string) $row->rel_path, $current, true ) ) {
					$details['error_detail'] = self::folder_changes( $details ) ? (string) $row->rel_path : $name;
					return 'name_taken';
				}

				$swaps[] = (int) $row->file_id;
			}
		}

		// 開始の確認のあとに、入れ替えるファイルをほかの添付が使い始めていたら、何も戻さずに止める
		$shared = Media_References::shared_names( self::swap_names( $rows, $swaps ), $attachment_id, Media_State::subdir( $details['from_state'] ) );

		if ( ! empty( $shared ) ) {
			$details['error_detail'] = $shared[0];
			return 'shared_file';
		}

		foreach ( $rows as $row ) {
			if ( in_array( (int) $row->file_id, $swaps, true ) ) {
				continue;
			}

			// 先に記録してから動かす（中断しても巻き戻せるように）。記録できなければ動かさない
			$recorded = Media_Ops::append_journal(
				$op_id,
				array(
					'type'    => 'restored',
					'file_id' => (int) $row->file_id,
				)
			);

			if ( ! $recorded ) {
				$details['error_detail'] = wp_basename( (string) $row->rel_path );
				return 'db_failed';
			}

			if ( ! Media_Files::restore( (int) $row->file_id ) ) {
				$details['error_detail'] = wp_basename( (string) $row->rel_path );
				return 'restore_failed';
			}
		}

		foreach ( $rows as $row ) {
			if ( ! in_array( (int) $row->file_id, $swaps, true ) ) {
				continue;
			}

			$name    = wp_basename( (string) $row->rel_path );
			$file_id = Media_Files::quarantine( $attachment_id, (string) $row->rel_path, Quarantine::REASON_UNDONE, $op_id );

			if ( null === $file_id ) {
				$details['error_detail'] = $name;
				return 'move_failed';
			}

			$details['quarantined'][ $name ] = $file_id;

			// 今のファイルを隔離したあとに記録する。記録できなければ戻さない
			// （巻き戻しは、この操作の隔離の行から今のファイルを元の場所へ戻す）
			$recorded = Media_Ops::append_journal(
				$op_id,
				array(
					'type'    => 'restored',
					'file_id' => (int) $row->file_id,
				)
			);

			if ( ! $recorded ) {
				$details['error_detail'] = $name;
				return 'db_failed';
			}

			if ( ! Media_Files::restore( (int) $row->file_id ) ) {
				$details['error_detail'] = $name;
				return 'restore_failed';
			}
		}

		return '';
	}

	/**
	 * 段1を巻き戻す（段1の失敗・中断と、段2の失敗で使う）
	 *
	 * 復元した隔離行を戻し → 作ったファイルを消し → この操作が隔離した
	 * ファイルを元の場所へ戻す、の順（同じ場所を空けてから戻すため）。
	 * 巻き戻せなかったファイルのパスは、握りつぶさずdetailsのrollback_errorsに残す
	 * （パスだけの一覧。再実行しても現在の状態から数え直す）。
	 *
	 * 同名で入れ替えたパスでは、この操作が隔離した元のファイルを隔離領域から戻せる
	 * ときだけ、今のファイルをどかす。元のファイルの行がもう隔離中でなければ
	 * （空にする・保持期限の削除で消えた）、今のファイルを残してrollback_errorsに積む
	 * （パスを空にしない）。元のファイルが戻り済み（前回の巻き戻しの途中で止まった）
	 * なら、そのパスにあるのは元のファイルなので消さない。
	 *
	 * @param int $op_id 操作ID。
	 */
	private static function rollback( int $op_id ): void {
		$op      = Media_Ops::get( $op_id );
		$journal = array_reverse( Media_Ops::decode( $op, 'journal' ) );
		$details = Media_Ops::decode( $op, 'details' );
		$errors  = array();
		$swapped = array();

		// 段1で同名のファイルを入れ替えたパス => この操作が隔離した、そのパスの元のファイルの行
		foreach ( Quarantine::rows_for_op( $op_id, array( Quarantine::ST_QUARANTINED, Quarantine::ST_RESTORED, Quarantine::ST_PURGED ) ) as $row ) {
			if ( ! isset( $swapped[ (string) $row->rel_path ] ) ) {
				$swapped[ (string) $row->rel_path ] = $row;
			}
		}

		foreach ( $journal as $entry ) {
			if ( 'restored' !== ( $entry['type'] ?? '' ) ) {
				continue;
			}

			$row = Quarantine::get_row( (int) $entry['file_id'] );

			if ( ! $row || Quarantine::ST_RESTORED !== $row->status ) {
				continue;
			}

			$swap = $swapped[ (string) $row->rel_path ] ?? null;

			// 入れ替えたパスで元のファイルを戻せないなら、戻したファイルを隔離し直さない
			if ( ( $swap && ! Media_Files::is_quarantined( (int) $swap->file_id ) ) || ! Media_Files::requarantine( (int) $entry['file_id'] ) ) {
				$errors[] = (string) $row->rel_path;
			}
		}

		foreach ( $journal as $entry ) {
			if ( 'created' !== ( $entry['type'] ?? '' ) ) {
				continue;
			}

			$rel  = (string) $entry['rel_path'];
			$swap = $swapped[ $rel ] ?? null;

			if ( $swap && Quarantine::ST_RESTORED === $swap->status ) {
				continue;
			}

			// 入れ替えたパスで元のファイルを戻せないなら、今のファイルを消さない
			if ( ( $swap && ! Media_Files::is_quarantined( (int) $swap->file_id ) ) || ! Media_Files::delete_own( $rel ) ) {
				$errors[] = $rel;
			}
		}

		foreach ( Quarantine::rows_for_op( $op_id, array( Quarantine::ST_QUARANTINED ) ) as $row ) {
			if ( ! Media_Files::return_row( $row ) ) {
				$errors[] = (string) $row->rel_path;
			}
		}

		Media_Files::remove_staging( $op_id );

		if ( empty( $errors ) ) {
			unset( $details['rollback_errors'] );
		} else {
			$details['rollback_errors'] = array_values( array_unique( $errors ) );
		}

		$details['quarantined'] = array();

		Media_Ops::update(
			$op_id,
			array(
				'details' => $details,
				'journal' => array(),
			)
		);
	}

	/**
	 * 操作をfailedで終える
	 *
	 * @param int    $op_id 操作ID。
	 * @param string $code  理由コード。
	 * @param array  $extra detailsへ一緒に書く項目（段2でメタデータを戻せたかなど）。
	 */
	private static function fail( int $op_id, string $code, array $extra = array() ): void {
		$details          = array_merge( Media_Ops::decode( Media_Ops::get( $op_id ), 'details' ), $extra );
		$details['error'] = $code;

		Media_Ops::update(
			$op_id,
			array(
				'status'      => Media_Ops::ST_FAILED,
				'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				'details'     => $details,
			)
		);

		Media_Files::remove_staging( $op_id );
	}

	/**
	 * 段2: メタデータを新しい状態へ切り替える
	 *
	 * 切り替えに失敗したら、先に「失敗した」という判断を記録し、そのあと後始末
	 * （abort_step2()）をしてfailedで終える。記録を先にするのは、後始末の途中で
	 * 要求が死んでも、次の要求が切り替えをやり直さず後始末を続けられるようにするため
	 * （やり直して成功すると、段3が新URLへ書き換えたあと、段4で旧ファイルを隔離してしまう）。
	 * 記録できなければ何も消さず、runningのまま次の要求に任せる。
	 *
	 * 切り替えを試す前に回数を記録する。切り替えの途中で要求ごと死に続けて
	 * MAX_STEP2_ATTEMPTS回に達したら、切り替えの失敗として扱う（段2の失敗は終端）。
	 *
	 * @param object $op 操作（running、step 1）。
	 * @return string 失敗の理由コード（meta_failed。添付がほかの処理で変わっていたらmeta_changed。
	 *                判断を記録できなければdb_failed）。成功なら''。
	 */
	private static function run_step2( $op ): string {
		$op_id         = (int) $op->op_id;
		$attachment_id = (int) $op->attachment_id;
		$details       = Media_Ops::decode( $op, 'details' );

		// 前の要求が、後始末の途中で死んでいた。切り替えをやり直さず、後始末を続ける
		if ( ! empty( $details['step2_failed'] ) ) {
			return self::abort_step2( $op );
		}

		$attempts = (int) ( $details['step2_attempts'] ?? 0 );

		// 初めて切り替える前に、添付がプレビューのときのままかを確かめ直す。段1のあとで要求が
		// 死んで再開するまでに、ほかの処理（画像の編集・別のツールの再生成など）が添付を変えていたら、
		// 新しい状態で上書きせず、旧状態へも戻さずに止める（変えられた内容を消さないため）。
		// 前の要求が切り替えを試していたら確かめない。その書き込み（途中までのものや、フィルタで
		// 変わったもの）と、ほかの処理の変更とを見分けられないため、切り替えをやり直し、失敗したら
		// 後始末で旧状態へ戻す（止めると、壊れたかもしれないメタデータを残してしまう）
		if ( 0 === $attempts && Media_State::hash( Media_State::capture( $attachment_id ) ) !== (string) ( $details['from_hash'] ?? '' ) ) {
			return self::stop_step2_changed( $op_id );
		}

		if ( $attempts < self::MAX_STEP2_ATTEMPTS ) {
			$details['step2_attempts'] = $attempts + 1;

			// 回数を記録できなければ、切り替えない（死に続けたときに抜け出せなくなる）
			if ( ! Media_Ops::update( $op_id, array( 'details' => $details ) ) ) {
				return 'db_failed';
			}

			$applied = Media_State::apply( $attachment_id, $details['to_state'] );
		} else {
			// 前の要求が、切り替えの途中で繰り返し死んだ。やり直しても同じところで死にうる
			$applied = false;
		}

		if ( ! $applied ) {
			$details['step2_failed'] = true;

			// 判断を記録できなければ、ファイルには触れない。新旧のファイルが残っていれば、
			// 次の要求の切り替えが成功しても、旧URLと新URLのどちらも表示できる
			if ( ! Media_Ops::update( $op_id, array( 'details' => $details ) ) ) {
				return 'db_failed';
			}

			return self::abort_step2( $op );
		}

		unset( $details['step2_attempts'] );

		// 取り消しの前提（操作のあとに添付が変わっていないこと）の照合値
		$details['to_hash'] = Media_State::hash( Media_State::capture( $attachment_id ) );

		// 段2を終えたので、段1の巻き戻し用の記録は役目を終える
		Media_Ops::update(
			$op_id,
			array(
				'step'    => 2,
				'details' => $details,
				'journal' => array(),
			)
		);

		return '';
	}

	/**
	 * 段2の前に添付がほかの処理で変わっていたときに、何も戻さずfailedで終える
	 *
	 * メタデータはほかの処理が書いたものなので、新しい状態にも旧状態にもしない。どちらの
	 * 名前を指していても表示できるよう、段1で作ったファイルも隔離した旧ファイルも残し、
	 * 確かめてもらうファイルとしてrollback_errorsに挙げる（rollback_leftovers()）。
	 * 隔離した旧ファイルは、失敗した操作の行として一括復元から戻せる。
	 *
	 * @param int $op_id 操作ID。
	 * @return string meta_changed。
	 */
	private static function stop_step2_changed( int $op_id ): string {
		self::fail(
			$op_id,
			'meta_changed',
			array(
				'metadata_restored' => false,
				'rollback_errors'   => self::rollback_leftovers( $op_id ),
			)
		);

		return 'meta_changed';
	}

	/**
	 * 段2の失敗の後始末（メタデータを戻し、戻せたときだけ段1のファイルを消してfailedで終える）
	 *
	 * 順序は、メタデータを旧状態へ戻す → 戻せたときだけ段1で作ったファイルを消す →
	 * failedにする。メタデータを戻せなかったときは、_wp_attached_fileなどが新しい名前を
	 * 指しているかもしれないため、新旧どちらのファイルも消さずに残し、どちらの名前を
	 * 指していても表示できるようにする（NFR-1.1）。そのことはdetailsの
	 * metadata_restoredにfalseで残す。途中で死んでも冪等で、step2_failedを見た
	 * 次の要求がここからやり直す。
	 *
	 * 旧状態へ戻すことも、試す前に回数を記録する。戻す途中で要求ごと死に続けて
	 * MAX_STEP2_ATTEMPTS回に達したら、戻せたか分からないため、戻せなかったときと
	 * 同じく新旧どちらのファイルも消さずに終える。
	 *
	 * 戻せたら、そのことをstep2_restoredに記録してから段1のファイルを巻き戻す。
	 * 巻き戻しの途中で死んだ次の要求は、メタデータを戻し直さず巻き戻しを続ける。
	 * 巻き戻しの回数は、戻す回数とは別に数える（同じ回数で数えると、巻き戻しの途中で
	 * 死んだだけなのに「戻せなかった」として終え、新旧どちらも残したと伝えてしまう）。
	 * 巻き戻しでもMAX_STEP2_ATTEMPTS回に達したら、巻き戻しをあきらめ、触れたかもしれない
	 * ファイルをrollback_errorsに積んで終える（rollback_leftovers()）。
	 *
	 * @param object $op 操作（running、step 1、step2_failedを記録済み）。
	 * @return string meta_failed。回数を記録できなければdb_failed（runningのまま）。
	 */
	private static function abort_step2( $op ): string {
		$op_id = (int) $op->op_id;
		// 呼び出し元が書いたstep2_failedなどを消さないよう、記録から読み直す
		$details  = Media_Ops::decode( Media_Ops::get( $op_id ), 'details' );
		$restored = ! empty( $details['step2_restored'] );

		if ( ! $restored ) {
			$attempts = (int) ( $details['step2_restore_attempts'] ?? 0 );

			if ( $attempts < self::MAX_STEP2_ATTEMPTS ) {
				$details['step2_restore_attempts'] = $attempts + 1;

				if ( ! Media_Ops::update( $op_id, array( 'details' => $details ) ) ) {
					return 'db_failed';
				}

				$restored = Media_State::apply( (int) $op->attachment_id, $details['from_state'] );
			}
		}

		$extra = array( 'metadata_restored' => $restored );

		if ( $restored ) {
			$attempts = (int) ( $details['step2_rollback_attempts'] ?? 0 );

			if ( $attempts < self::MAX_STEP2_ATTEMPTS ) {
				$details['step2_restored']          = true;
				$details['step2_rollback_attempts'] = $attempts + 1;

				if ( ! Media_Ops::update( $op_id, array( 'details' => $details ) ) ) {
					return 'db_failed';
				}

				self::rollback( $op_id );
			} else {
				$extra['rollback_errors'] = self::rollback_leftovers( $op_id );
			}
		}

		self::fail( $op_id, 'meta_failed', $extra );

		return 'meta_failed';
	}

	/**
	 * 巻き戻しをあきらめるときに、確かめてもらうファイル
	 *
	 * 巻き戻しの途中で要求が死に続けると、どこまで巻き戻せたか分からない。そのため、
	 * 巻き戻しが触れるはずだったファイル（段1で作ったファイル、戻した隔離行、この操作が
	 * 隔離したまま戻していない行）をすべて挙げる。ファイルには触れない。
	 * 隔離したままの行は、失敗した操作の行として一括復元から戻せる。
	 *
	 * @param int $op_id 操作ID。
	 * @return string[] uploads相対パス（前の巻き戻しが積んだrollback_errorsを含む）。
	 */
	private static function rollback_leftovers( int $op_id ): array {
		$op      = Media_Ops::get( $op_id );
		$details = Media_Ops::decode( $op, 'details' );
		$paths   = array_map( 'strval', (array) ( $details['rollback_errors'] ?? array() ) );

		foreach ( Media_Ops::decode( $op, 'journal' ) as $entry ) {
			if ( 'created' === ( $entry['type'] ?? '' ) ) {
				$paths[] = (string) $entry['rel_path'];
			} elseif ( 'restored' === ( $entry['type'] ?? '' ) ) {
				$row = Quarantine::get_row( (int) $entry['file_id'] );

				if ( $row ) {
					$paths[] = (string) $row->rel_path;
				}
			}
		}

		foreach ( Quarantine::rows_for_op( $op_id, array( Quarantine::ST_QUARANTINED ) ) as $row ) {
			$paths[] = (string) $row->rel_path;
		}

		return array_values( array_unique( $paths ) );
	}

	/**
	 * 段3: 本文の参照を1回分追随させる
	 *
	 * 記事を書き換える前に、処理中の記事をdetailsのrelinkingに記録する。次の要求の
	 * 開始時にそれが残っていれば、前の要求はその記事の途中で死んでいる（他プラグインの
	 * save_postのfatalなど）。やり直すと同じところで死に続けるため、その記事は失敗として
	 * 飛ばし、relink_crashedに残す。旧名が本文に残るので、段4はその旧ファイルを
	 * 残す（安全側）。
	 *
	 * @param object $op      操作（running、step 2）。
	 * @param float  $started この要求の開始時刻。
	 * @return bool 全記事を終えたらtrue（stepを3にする）。
	 */
	private static function relink_batch( $op, float $started ): bool {
		$op_id   = (int) $op->op_id;
		$details = Media_Ops::decode( $op, 'details' );
		$posts   = (array) ( Media_Ops::decode( $op, 'plan' )['posts'] ?? array() );
		$ids     = array_map( 'intval', array_keys( $posts ) );
		$after   = (int) $op->last_post_id;
		$crashed = (int) ( $details['relinking'] ?? 0 );

		sort( $ids );

		unset( $details['relinking'] );

		if ( $crashed > $after && isset( $posts[ $crashed ] ) ) {
			self::count_skip( $details['result'], $crashed, Reference_Graph::SKIP_FAILED, count( (array) $posts[ $crashed ] ) );

			$details['relink_crashed'][] = $crashed;
			$after                       = $crashed;

			Media_Ops::update(
				$op_id,
				array(
					'last_post_id' => $crashed,
					'details'      => $details,
				)
			);
		}

		/**
		 * メディア操作の段3で1回に書き換える記事数
		 *
		 * @param int $batch_size 既定10。TIME_BUDGET秒を超えた時点でも打ち切る。
		 */
		$batch = max( 1, (int) apply_filters( 'rgrl_media_apply_batch_size', 10 ) );
		$count = 0;

		foreach ( $ids as $post_id ) {
			if ( $post_id <= $after ) {
				continue;
			}

			if ( $count >= $batch || microtime( true ) - $started > self::TIME_BUDGET ) {
				return false;
			}

			// 書き換える前に、処理中の記事を記録する（この記事で死んだら、次の要求が飛ばせるように）
			$details['relinking'] = $post_id;

			if ( ! Media_Ops::update( $op_id, array( 'details' => $details ) ) ) {
				// 記録できなくても書き換えは進める（止めると、記録が戻るまで段3が進まない）。
				// 記録がないと、この記事で死に続けたときに飛ばせないため、ログに残す
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 失敗を握りつぶさないため
				error_log( sprintf( 'Regenerate & Relink: could not record post %1$d as being relinked for media operation %2$d.', $post_id, $op_id ) );
			}

			unset( $details['relinking'] );

			self::relink_post( $post_id, (array) $posts[ $post_id ], $details );
			++$count;

			// 記事ごとに記録する。どこで止まっても書き換え済みの記事を二重に書き換えない（FR-4.12）
			Media_Ops::update(
				$op_id,
				array(
					'last_post_id' => $post_id,
					'details'      => $details,
				)
			);
		}

		Media_Ops::update( $op_id, array( 'step' => 3 ) );

		return true;
	}

	/**
	 * 記事1件の参照を追随させる
	 *
	 * 書き換え対象はプレビュー時点で確定しており、ここで選び直さない（FR-6.3）。
	 * 新しいURLは旧URLのファイル名部分だけ（フォルダを変える操作では、末尾の
	 * 「サブディレクトリ/ファイル名」だけ）を差し替えて作る（FR-4.2 / FR-12.7）。
	 *
	 * @param int   $post_id 記事ID。
	 * @param array $targets この記事の書き換え対象。
	 * @param array $details details（参照渡し。resultを更新する）。
	 */
	private static function relink_post( int $post_id, array $targets, array &$details ): void {
		$result = &$details['result'];
		$post   = get_post( $post_id );

		if ( ! $post instanceof WP_Post ) {
			self::count_skip( $result, $post_id, Reference_Graph::SKIP_FAILED, count( $targets ) );
			return;
		}

		$content = (string) $post->post_content;
		$hash    = md5( $content );

		// FR-6.4: プレビューのあとに本文が変わっていたら書き換えない
		foreach ( $targets as $target ) {
			if ( (string) ( $target['content_hash'] ?? '' ) !== $hash ) {
				self::count_skip( $result, $post_id, Reference_Graph::SKIP_PRECONDITION_CHANGED, count( $targets ) );
				return;
			}
		}

		$resolver = new Reference_Resolver();
		$map      = array();
		$counts   = array();
		$moving   = self::folder_changes( $details );

		foreach ( $targets as $target ) {
			$name = (string) $target['name'];
			$new  = $details['file_map'][ $name ] ?? null;
			$old  = $details['from_entries'][ $name ] ?? array(
				'width'  => 0,
				'height' => 0,
			);

			if ( ! is_array( $new ) ) {
				// 対応するファイルがない。フルサイズへ逃がさず、旧ファイルを残す（FR-4.9）
				self::count_skip( $result, $post_id, Media_References::SKIP_NO_COUNTERPART, 1 );
				continue;
			}

			// フォルダが変わる操作では、名前と寸法が同じでもURLは変わる
			if ( ! $moving && (string) $new['name'] === $name && (int) $new['width'] === (int) $old['width'] && (int) $new['height'] === (int) $old['height'] ) {
				self::count_skip( $result, $post_id, Reference_Graph::SKIP_NO_CHANGE, 1 );
				continue;
			}

			$url     = (string) $target['url'];
			$new_url = self::new_url( $resolver, $details, $url, (string) $new['name'] );

			if ( $moving && $new_url === $url ) {
				// 末尾が旧の場所と一致せず、場所を差し替えられなかった。書き換えずに報告する
				// （旧URLが本文に残るので、段4は旧ファイルを残す）
				self::count_skip( $result, $post_id, Reference_Graph::SKIP_FILENAME_MISMATCH, 1 );
				continue;
			}

			if ( ! isset( $map[ $url ] ) ) {
				$old_width  = (int) $old['width'];
				$old_height = (int) $old['height'];

				$map[ $url ]    = array(
					'new_url'       => $new_url,
					'new_width'     => (int) $new['width'],
					'new_height'    => (int) $new['height'],
					'caption_width' => null,
					'old_dims'      => $old_width > 0 && $old_height > 0 ? array( $old_width, $old_height ) : null,
				);
				$counts[ $url ] = 0;
			}

			++$counts[ $url ];

			if ( null === $map[ $url ]['caption_width'] && isset( $target['caption_width'] ) ) {
				$map[ $url ]['caption_width'] = (int) $target['caption_width'];
			}
		}

		if ( empty( $map ) ) {
			return;
		}

		$refs        = array_sum( $counts );
		$new_content = Applier::rewrite_content( $content, $map );

		if ( $new_content === $content ) {
			// 同名・属性なしの参照など、書き換えるものがなかった
			self::count_skip( $result, $post_id, Reference_Graph::SKIP_NO_CHANGE, $refs );
			return;
		}

		$saved = Applier::save_content( $post, $new_content );

		if ( is_wp_error( $saved ) ) {
			self::count_skip( $result, $post_id, Reference_Graph::SKIP_FAILED, $refs );
			return;
		}

		++$result['posts_updated'];
		$result['refs_updated'] += $refs;
	}

	/**
	 * 段4: 参照が残らない旧ファイルだけを隔離し、操作を終える（FR-11.6）
	 *
	 * @param object $op 操作（running、step 3）。
	 */
	private static function finish_run( $op ): void {
		$op_id         = (int) $op->op_id;
		$attachment_id = (int) $op->attachment_id;
		$details       = Media_Ops::decode( $op, 'details' );
		$subdir        = self::from_subdir( $details );
		$cleanup       = self::cleanup_names( $details );

		// 隔離済みの行を正とする（前回この段の途中で止まっていても取りこぼさない）。
		// 行は動かす前に書かれるため、隔離領域に実際にファイルがある行だけを数える
		$details['quarantined'] = array();
		$lost                   = array_map( 'strval', (array) ( $details['quarantine_errors'] ?? array() ) );

		foreach ( Quarantine::rows_for_op( $op_id, array( Quarantine::ST_QUARANTINED ) ) as $row ) {
			if ( Media_Files::is_quarantined( (int) $row->file_id ) ) {
				$details['quarantined'][ wp_basename( (string) $row->rel_path ) ] = (int) $row->file_id;
				continue;
			}

			// 行だけあってファイルが動いていない。元の場所に残っていれば行を消して候補に戻し、
			// どちらにもなければ握りつぶさずdetailsに残す
			if ( ! Media_Files::return_row( $row ) ) {
				$lost[] = (string) $row->rel_path;
			}
		}

		if ( ! empty( $lost ) ) {
			$details['quarantine_errors'] = array_values( array_unique( $lost ) );
		}

		$handled    = array_map( 'strval', array_keys( $details['quarantined'] ) );
		$candidates = array();

		foreach ( $cleanup as $name ) {
			if ( in_array( $name, $handled, true ) ) {
				continue;
			}

			if ( Media_Files::exists( Media_Files::rel_path( $subdir, $name ) ) ) {
				$candidates[] = $name;
			}
		}

		// ファイル名がDBのどこかに残っていれば隔離しない（リンク切れを作らない）。
		// フォルダが変わる操作では、段3で書いた新URLも同じファイル名を含むため、取り除いてから探す（FR-12.8）
		$written    = self::folder_changes( $details ) ? self::written_by_post( $op, $details ) : array();
		$referenced = Media_References::still_referenced( $candidates, $attachment_id, false, $written );
		$reason     = self::quarantine_reason( (string) $op->op_type );
		$kept       = array();
		$not_moved  = array();

		foreach ( $candidates as $name ) {
			if ( in_array( $name, $referenced, true ) ) {
				$kept[] = $name;
				continue;
			}

			$file_id = Media_Files::quarantine( $attachment_id, Media_Files::rel_path( $subdir, $name ), $reason, $op_id );

			if ( null === $file_id ) {
				// 隔離できなかった（ファイルは元の場所に残る）。使われているので残したものとは分けて伝える
				$not_moved[] = $name;
				continue;
			}

			$details['quarantined'][ $name ] = $file_id;
		}

		// keptは、元に戻すときに元の場所にあるべき旧ファイル（undo_blocker()が確かめる）。
		// 隔離できずに残ったものも含める
		$details['kept']                  = array_values( array_merge( $kept, $not_moved ) );
		$details['result']['kept']        = $kept;
		$details['result']['quarantined'] = count( (array) $details['quarantined'] );
		// 隔離領域へ動かせなかった旧ファイル（隔離できなかったものと、行だけ残ってどこにもないもの）
		$details['result']['quarantine_errors'] = array_values( array_unique( array_merge( $not_moved, array_map( 'wp_basename', $lost ) ) ) );

		$plan = Media_Ops::decode( $op, 'plan' );

		Media_Ops::update(
			$op_id,
			array(
				'status'      => Media_Ops::ST_COMPLETE,
				'step'        => 4,
				'finished_at' => gmdate( 'Y-m-d H:i:s' ),
				'details'     => $details,
				// 段3で使い終えた書き換え対象は件数だけ残す
				'plan'        => array(
					'total'   => (int) ( $plan['total'] ?? 0 ),
					'scanned' => (int) ( $plan['scanned'] ?? 0 ),
					'refs'    => (int) ( $plan['refs'] ?? 0 ),
				),
			)
		);

		if ( Media_Ops::TYPE_UNDO === $op->op_type && (int) $op->undo_of > 0 ) {
			Media_Ops::update( (int) $op->undo_of, array( 'status' => Media_Ops::ST_UNDONE ) );
		}
	}

	/**
	 * 段3が記事の本文に書いた新URL（設計書2026-11-12の§7.1）
	 *
	 * 計画の書き換え対象から求める。前提変化などで書き換えなかった記事も含める
	 * （本文に新URLがないだけで、Media_References::still_referenced()が同じ経路で
	 * 調べ、旧URLの名前が見つかって残す側になる）。
	 *
	 * @param object $op      操作。
	 * @param array  $details details。
	 * @return array 記事ID => 書いた新URLの文字列の配列。
	 */
	private static function written_by_post( $op, array $details ): array {
		$resolver = new Reference_Resolver();
		$written  = array();

		foreach ( (array) ( Media_Ops::decode( $op, 'plan' )['posts'] ?? array() ) as $post_id => $targets ) {
			$forms = array();

			foreach ( (array) $targets as $target ) {
				$new = $details['file_map'][ (string) $target['name'] ] ?? null;
				$url = (string) $target['url'];

				if ( ! is_array( $new ) ) {
					continue;
				}

				$new_url = self::new_url( $resolver, $details, $url, (string) $new['name'] );

				if ( $new_url !== $url ) {
					$forms = array_merge( $forms, self::written_forms( $new_url ) );
				}
			}

			$written[ (int) $post_id ] = array_values( array_unique( $forms ) );
		}

		return $written;
	}

	/**
	 * 隔離の理由
	 *
	 * @param string $op_type Media_Ops::TYPE_*。
	 * @return string Quarantine::REASON_*。
	 */
	private static function quarantine_reason( string $op_type ): string {
		if ( Media_Ops::TYPE_REPLACE === $op_type ) {
			return Quarantine::REASON_REPLACED;
		}

		if ( Media_Ops::TYPE_RENAME === $op_type ) {
			return Quarantine::REASON_RENAMED;
		}

		return Quarantine::REASON_UNDONE;
	}

	/**
	 * 実行の進捗
	 *
	 * @param object $op 操作。
	 * @return array
	 */
	private static function run_progress( $op ): array {
		$details  = Media_Ops::decode( $op, 'details' );
		$complete = Media_Ops::ST_COMPLETE === $op->status;
		$total    = (int) ( $details['result']['posts_total'] ?? 0 );
		$done     = $total;

		if ( ! $complete ) {
			$done = 0;

			if ( 2 <= (int) $op->step ) {
				foreach ( array_keys( (array) ( Media_Ops::decode( $op, 'plan' )['posts'] ?? array() ) ) as $post_id ) {
					if ( (int) $post_id <= (int) $op->last_post_id ) {
						++$done;
					}
				}
			}
		}

		return array(
			'op_id'       => (int) $op->op_id,
			'status'      => (string) $op->status,
			'step'        => (int) $op->step,
			'posts_total' => $total,
			'posts_done'  => $done,
			'done'        => $complete,
			'result'      => $complete ? ( $details['result'] ?? null ) : null,
		);
	}

	/**
	 * 古い一時アップロードと、実行されなかった計画と、残った作業用ディレクトリを消す（日次）
	 */
	public static function purge_stale(): void {
		Media_Upload::purge_expired();
		Media_Ops::delete_stale_plans( gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) );
		self::purge_leftover_staging();
	}

	/**
	 * 終わった操作の作業用ディレクトリ（staging-{op_id}/）を消す
	 *
	 * 作業用ディレクトリは段1の終わりか巻き戻しで消すが、消せなかったときや、中断中に
	 * 添付が消えて放棄した操作（ファイルに触れずに終える）のものが残る。中身は段1で
	 * 作った新しいファイルで、どこからも参照されない。runningの操作のものは、段1の途中の
	 * 巻き戻しに使うため消さない。操作を読めなかったもの（DBの失敗）も消さない。
	 */
	public static function purge_leftover_staging(): void {
		global $wpdb;

		$finished = array( Media_Ops::ST_COMPLETE, Media_Ops::ST_FAILED, Media_Ops::ST_UNDONE );

		foreach ( Media_Files::staging_op_ids() as $op_id ) {
			$op = Media_Ops::get( $op_id );

			if ( null === $op && '' !== $wpdb->last_error ) {
				continue;
			}

			// 行がないものは、操作の記録ごと消えている（再開されることがない）
			if ( null === $op || in_array( (string) $op->status, $finished, true ) ) {
				Media_Files::remove_staging( $op_id );
			}
		}
	}
}
