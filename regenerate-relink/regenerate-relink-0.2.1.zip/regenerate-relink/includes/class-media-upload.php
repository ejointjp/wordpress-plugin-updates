<?php
/**
 * 差し替え用の画像の一時保存（FR-11）
 *
 * アップロードされた画像を隔離ディレクトリの下のincoming/に置き、
 * プレビューと実行で使う。uploadsの年月ディレクトリには置かない
 * （添付として扱われず、Webから直接読まれないように。FR-5.6と同じ守り）。
 * 24時間たったものは日次の掃除（Quarantine::PURGE_HOOK）で消す。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 差し替え用の画像の一時保存
 */
class Media_Upload {

	/**
	 * 一時アップロードを残す時間（秒）。DAY_IN_SECONDSと同じ
	 */
	const MAX_AGE = 86400;

	/**
	 * 一時アップロードの情報を持つtransientの接頭辞
	 */
	const TRANSIENT_PREFIX = 'rgrl_upload_';

	/**
	 * 一時置き場の絶対パス（なければ作る）
	 *
	 * @return string|null 作れなければnull。
	 */
	public static function dir(): ?string {
		$qdir = Quarantine::ensure_dir();

		if ( null === $qdir ) {
			return null;
		}

		$dir = trailingslashit( $qdir ) . 'incoming';

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return null;
		}

		$index = trailingslashit( $dir ) . 'index.php';

		if ( ! file_exists( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- uploads配下への小ファイル配置。WP_Filesystemの資格情報要求はRESTの文脈では使えない。
			file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}

		return $dir;
	}

	/**
	 * アップロードされたファイルを受け取る
	 *
	 * コアのアップロード（wp_handle_upload()）と同じく、受け取る前に
	 * wp_handle_upload_prefilterを通す。マルチサイトの容量制限（check_upload_size()）や、
	 * セキュリティ系・画像最適化系のプラグインの検査がここで効く。フィルタがerrorに
	 * 文言を入れたら受け取らず、その文言をdetailで返す。置き場所は一時置き場のまま
	 * （wp_handle_upload()そのものは通さない。後処理のフックで一時ファイルを
	 * 持ち出されないように）。
	 *
	 * @param int   $attachment_id 差し替える添付ID。
	 * @param array $file          $_FILESの1件（name / tmp_name / error）。
	 * @return array 情報。受け取れなければerrorキー（upload_rejected / upload_failed / not_image /
	 *               not_editable / dir_failed）。upload_rejectedはdetailにフィルタの文言を持つ。
	 */
	public static function store( int $attachment_id, array $file ): array {
		$tmp = (string) ( $file['tmp_name'] ?? '' );

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- コアのフックを、コアと同じ引数で呼ぶ
		$file = (array) apply_filters( 'wp_handle_upload_prefilter', $file );

		// コアと同じく、数値でないerrorはフィルタが断った理由
		if ( isset( $file['error'] ) && ! is_numeric( $file['error'] ) && $file['error'] ) {
			return array(
				'error'  => 'upload_rejected',
				'detail' => wp_strip_all_tags( (string) $file['error'] ),
			);
		}

		// 受け取るのは、HTTPで届いた元の一時ファイルだけ（フィルタがtmp_nameを差し替えても使わない）
		if ( '' === $tmp || ! isset( $file['error'] ) || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $tmp ) ) {
			return array( 'error' => 'upload_failed' );
		}

		return self::accept( $attachment_id, $tmp, (string) ( $file['name'] ?? '' ), true );
	}

	/**
	 * サーバ上のファイルを受け取る（WP-CLI・テスト用。RESTからは呼ばない）
	 *
	 * @param int    $attachment_id 差し替える添付ID。
	 * @param string $path          ファイルの絶対パス（複製する）。
	 * @param string $name          元のファイル名（形式の判定に使う）。
	 * @return array store()と同じ形。
	 */
	public static function store_local( int $attachment_id, string $path, string $name ): array {
		return self::accept( $attachment_id, $path, $name, false );
	}

	/**
	 * 画像として検証し、一時置き場へ置く
	 *
	 * @param int    $attachment_id 差し替える添付ID。
	 * @param string $tmp           受け取ったファイルの絶対パス。
	 * @param string $name          元のファイル名。
	 * @param bool   $uploaded      HTTPでアップロードされたファイルか（move_uploaded_fileを使う）。
	 * @return array store()と同じ形。
	 */
	private static function accept( int $attachment_id, string $tmp, string $name, bool $uploaded ): array {
		// WordPressがアップロードを許可していて、画像エディタで開ける形式に限る（設計書 §5.1）
		$check = wp_check_filetype_and_ext( $tmp, $name );
		$ext   = strtolower( (string) $check['ext'] );
		$type  = (string) $check['type'];

		if ( '' === $ext || 0 !== strpos( $type, 'image/' ) || ! in_array( $type, get_allowed_mime_types(), true ) ) {
			return array( 'error' => 'not_image' );
		}

		$size = wp_getimagesize( $tmp );

		if ( ! is_array( $size ) ) {
			return array( 'error' => 'not_image' );
		}

		if ( is_wp_error( wp_get_image_editor( $tmp ) ) ) {
			return array( 'error' => 'not_editable' );
		}

		$dir = self::dir();

		if ( null === $dir ) {
			return array( 'error' => 'dir_failed' );
		}

		// 20文字の英小文字と数字（get()が形を確かめる）
		$upload_id = Media_Files::token( 10 );

		if ( null === $upload_id ) {
			return array( 'error' => 'upload_failed' );
		}

		$dest = trailingslashit( $dir ) . $upload_id . '.' . $ext;

		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged -- 失敗は戻り値で検出する。
		$moved = $uploaded ? @move_uploaded_file( $tmp, $dest ) : @copy( $tmp, $dest );

		if ( ! $moved ) {
			return array( 'error' => 'upload_failed' );
		}

		$info = array(
			'upload_id'     => $upload_id,
			'attachment_id' => $attachment_id,
			'user_id'       => get_current_user_id(),
			'ext'           => $ext,
			'mime'          => $type,
			'width'         => (int) $size[0],
			'height'        => (int) $size[1],
			'bytes'         => (int) filesize( $dest ),
			'name'          => sanitize_file_name( $name ),
		);

		set_transient( self::TRANSIENT_PREFIX . $upload_id, $info, self::MAX_AGE );

		return $info;
	}

	/**
	 * 一時アップロードを取得する
	 *
	 * @param string $upload_id     store()が返したID。
	 * @param int    $attachment_id 差し替える添付ID（アップロード時と一致すること）。
	 * @return array|null 情報にpath（絶対パス）を足したもの。なければnull。
	 */
	public static function get( string $upload_id, int $attachment_id ): ?array {
		if ( ! preg_match( '/^[a-z0-9]{20}$/', $upload_id ) ) {
			return null;
		}

		$info = get_transient( self::TRANSIENT_PREFIX . $upload_id );

		if ( ! is_array( $info ) || $attachment_id !== (int) $info['attachment_id'] || get_current_user_id() !== (int) $info['user_id'] ) {
			return null;
		}

		$dir = self::dir();

		if ( null === $dir ) {
			return null;
		}

		$path = trailingslashit( $dir ) . $upload_id . '.' . (string) $info['ext'];

		if ( ! is_file( $path ) ) {
			return null;
		}

		$info['path'] = $path;

		return $info;
	}

	/**
	 * 一時アップロードの情報を消す（ファイルは段1で作業用ディレクトリへ移したあと）
	 *
	 * @param string $upload_id ID。
	 */
	public static function forget( string $upload_id ): void {
		delete_transient( self::TRANSIENT_PREFIX . $upload_id );
	}

	/**
	 * 期限切れの一時アップロードを消す（日次）
	 */
	public static function purge_expired(): void {
		$qdir = Quarantine::dir();

		if ( null === $qdir ) {
			return;
		}

		$threshold = time() - self::MAX_AGE;

		foreach ( (array) glob( trailingslashit( $qdir ) . 'incoming/*' ) as $file ) {
			if ( is_string( $file ) && is_file( $file ) && 'index.php' !== wp_basename( $file ) && filemtime( $file ) < $threshold ) {
				wp_delete_file( $file );
			}
		}
	}
}
