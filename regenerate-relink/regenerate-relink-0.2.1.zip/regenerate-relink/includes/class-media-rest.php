<?php
/**
 * メディア操作のRESTルート（FR-11〜13）
 *
 * 処理はMedia_Operation / Media_Uploadが持ち、ここは引数の受け渡しと
 * エラーの翻訳だけを行う（FR-8.2）。名前空間はRest_Controllerと同じ。
 * Rest_Controllerはすでに大きいため、メディア操作のルートはここに分ける。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * メディア操作のRESTルート
 */
class Media_Rest {

	/**
	 * ルートを登録する
	 */
	public static function register_routes(): void {
		$id_arg = array(
			'id' => array(
				'type'     => 'integer',
				'minimum'  => 1,
				'required' => true,
			),
		);
		$op_arg = array(
			'op' => array(
				'type'     => 'integer',
				'minimum'  => 1,
				'required' => true,
			),
		);

		register_rest_route(
			Rest_Controller::ROUTE_NAMESPACE,
			'/media/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_status' ),
				'permission_callback' => array( __CLASS__, 'can_edit_attachment' ),
				'args'                => $id_arg,
			)
		);

		register_rest_route(
			Rest_Controller::ROUTE_NAMESPACE,
			'/media/(?P<id>\d+)/upload',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'upload' ),
				'permission_callback' => array( __CLASS__, 'can_edit_attachment' ),
				'args'                => $id_arg,
			)
		);

		register_rest_route(
			Rest_Controller::ROUTE_NAMESPACE,
			'/media/(?P<id>\d+)/preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'preview' ),
				'permission_callback' => array( __CLASS__, 'can_edit_attachment' ),
				'args'                => array_merge(
					$id_arg,
					array(
						'type'      => array(
							'type'     => 'string',
							'enum'     => array( 'rename', 'replace', 'undo' ),
							'required' => true,
						),
						'stem'      => array(
							'type'    => 'string',
							'default' => '',
						),
						// 移動先のフォルダ（uploadsからの相対パス。空文字はuploads直下）。省くと今のフォルダ
						'folder'    => array(
							'type' => 'string',
						),
						'upload_id' => array(
							'type'    => 'string',
							'default' => '',
						),
					)
				),
			)
		);

		register_rest_route(
			Rest_Controller::ROUTE_NAMESPACE,
			'/media/ops/(?P<op>\d+)/plan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'plan' ),
				'permission_callback' => array( __CLASS__, 'can_edit_op' ),
				'args'                => $op_arg,
			)
		);

		register_rest_route(
			Rest_Controller::ROUTE_NAMESPACE,
			'/media/ops/(?P<op>\d+)/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'step' ),
				'permission_callback' => array( __CLASS__, 'can_edit_op' ),
				'args'                => $op_arg,
			)
		);
	}

	/**
	 * 添付を操作できるか（FR-13.5: manage_optionsと対象添付の編集権限）
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function can_edit_attachment( WP_REST_Request $request ): bool {
		return Rest_Controller::can_manage() && current_user_can( 'edit_post', absint( $request->get_param( 'id' ) ) );
	}

	/**
	 * 操作を進められるか
	 *
	 * 存在しない操作は、権限の問題ではなくnot_foundとしてcallbackで返す。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function can_edit_op( WP_REST_Request $request ): bool {
		if ( ! Rest_Controller::can_manage() ) {
			return false;
		}

		$op = Media_Ops::get( absint( $request->get_param( 'op' ) ) );

		return ! $op || current_user_can( 'edit_post', (int) $op->attachment_id );
	}

	/**
	 * 添付の操作の状態を返す
	 *
	 * @param WP_REST_Request $request リクエスト。
	 */
	public static function get_status( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( Media_Operation::status( absint( $request->get_param( 'id' ) ) ) );
	}

	/**
	 * 差し替え用の画像を受け取る
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public static function upload( WP_REST_Request $request ) {
		$attachment_id = absint( $request->get_param( 'id' ) );
		$reason        = Media_Operation::eligibility( $attachment_id );

		if ( '' !== $reason ) {
			return self::error( array( 'error' => $reason ) );
		}

		$files = $request->get_file_params();

		if ( empty( $files['file'] ) || ! is_array( $files['file'] ) ) {
			return self::error( array( 'error' => 'upload_failed' ) );
		}

		return self::respond( Media_Upload::store( $attachment_id, $files['file'] ) );
	}

	/**
	 * プレビューを始める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public static function preview( WP_REST_Request $request ) {
		$attachment_id = absint( $request->get_param( 'id' ) );

		switch ( (string) $request->get_param( 'type' ) ) {
			case 'rename':
				$folder = $request->get_param( 'folder' );
				$result = Media_Operation::preview_rename( $attachment_id, (string) $request->get_param( 'stem' ), null === $folder ? null : (string) $folder );
				break;

			case 'replace':
				$result = Media_Operation::preview_replace( $attachment_id, (string) $request->get_param( 'upload_id' ) );
				break;

			default:
				$result = Media_Operation::preview_undo( $attachment_id );
		}

		return self::respond( $result );
	}

	/**
	 * 計画を1回分進める
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public static function plan( WP_REST_Request $request ) {
		return self::respond( Media_Operation::plan_step( absint( $request->get_param( 'op' ) ) ) );
	}

	/**
	 * 操作を1回分進める
	 *
	 * 成功の結果（quarantine_errorsや、空のときに[]になる連想配列を含む）は
	 * 手を加えずに返す。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public static function step( WP_REST_Request $request ) {
		return self::respond( Media_Operation::step( absint( $request->get_param( 'op' ) ) ) );
	}

	/**
	 * 結果を応答にする
	 *
	 * @param array $result Media_Operation / Media_Uploadの戻り値。
	 * @return WP_REST_Response|WP_Error
	 */
	private static function respond( array $result ) {
		return isset( $result['error'] ) ? self::error( $result ) : rest_ensure_response( $result );
	}

	/**
	 * errorキーをRESTのエラーにする
	 *
	 * 文言は、原因の文と、結果の文（何が残ったか）の2つで組む。巻き戻せなかった
	 * ファイルがあるときは、結果の文を「戻せなかったファイルの確認」に差し替える。
	 * 「何も変えていない」と伝えたすぐあとに、戻せなかったファイルを挙げると、
	 * 文が食い違うため。
	 *
	 * @param array $result error / detail / op_id / failed / rollback / metadata_restored / media_op / movingを持つ配列。
	 */
	public static function error( array $result ): WP_Error {
		// ほかの画像の操作で止まっているときは、その画像を示す（その画像の編集画面で再開してもらう）
		if ( 'busy_media_op' === (string) $result['error'] && ! isset( $result['media_op'] ) ) {
			$result['media_op'] = Media_Operation::running_info();
		}

		$parts   = self::message( (string) $result['error'], $result );
		$message = $parts[0];
		$status  = $parts[1];
		$outcome = $parts[2] ?? '';

		if ( ! empty( $result['rollback'] ) ) {
			$outcome = sprintf(
				/* translators: %s: ファイル名の一覧 */
				__( 'These files could not be put back and need checking: %s', 'regenerate-relink' ),
				implode( ', ', array_map( 'strval', (array) $result['rollback'] ) )
			);
		}

		if ( '' !== $outcome ) {
			$message = sprintf(
				/* translators: 1: 何が起きたかの説明, 2: そのあとの状態の説明 */
				__( '%1$s %2$s', 'regenerate-relink' ),
				$message,
				$outcome
			);
		}

		$data = array(
			'status' => $status,
			'op_id'  => (int) ( $result['op_id'] ?? 0 ),
			'failed' => ! empty( $result['failed'] ),
		);

		// メタデータを旧状態へ戻せたか。段2の失敗（meta_failed）のときだけ付く
		if ( isset( $result['metadata_restored'] ) ) {
			$data['metadata_restored'] = (bool) $result['metadata_restored'];
		}

		// 実行中の操作の画像（busy_media_opのときだけ付く。画面がリンクにする）
		if ( ! empty( $result['media_op'] ) ) {
			$data['media_op'] = $result['media_op'];
		}

		return new WP_Error( 'rgrl_media_' . (string) $result['error'], $message, $data );
	}

	/**
	 * 実行中の操作で止められたときの文言（その画像の編集画面で再開してもらう）
	 *
	 * 実行タブ・隔離タブ（Rest_Controller）と添付の編集画面（busy_media_op）で同じ文言を使う。
	 *
	 * @param string $title 実行中の操作の画像のタイトル。
	 */
	public static function media_op_running_message( string $title ): string {
		return sprintf(
			/* translators: %s: 画像のタイトル */
			__( 'Replacing or renaming the image “%s” has not finished. Resume it on that image’s edit screen, then try again.', 'regenerate-relink' ),
			$title
		);
	}

	/**
	 * エラーコードの文言とHTTPの状態
	 *
	 * 3つ目は、そのあとの状態を伝える文。文が完結しているコードでは省く。
	 * 戻す途中で残ったファイルがあれば、error()が差し替える。
	 *
	 * @param string $code   エラーコード。
	 * @param array  $result error()に渡された配列（detail / failed / metadata_restoredで文言を分ける）。
	 * @return array{0: string, 1: int, 2?: string} 原因の文、HTTPの状態、結果の文（なければ省く）。
	 */
	private static function message( string $code, array $result ): array {
		switch ( $code ) {
			case 'not_image':
				return array( __( 'This attachment is not an image.', 'regenerate-relink' ), 400 );

			case 'no_metadata':
				return array( __( 'This image has no attachment data to work with.', 'regenerate-relink' ), 409 );

			case 'original_missing':
				return array( __( 'The original image file is not on this server. Images offloaded to external storage cannot be replaced or renamed.', 'regenerate-relink' ), 409 );

			case 'unsupported_names':
				return array( __( 'The files of this image do not share a common name, so it cannot be renamed safely.', 'regenerate-relink' ), 409 );

			case 'invalid_name':
				return array( __( 'Enter a file name that can be used on this server.', 'regenerate-relink' ), 400 );

			case 'same_name':
				return array( __( 'The new name is the same as the current name.', 'regenerate-relink' ), 400 );

			case 'name_taken':
				// フォルダを変える操作では、detailは移動先の相対パス
				if ( ! empty( $result['moving'] ) ) {
					return array(
						sprintf(
							/* translators: %s: uploadsからの相対パス（例: products/photo.jpg） */
							__( '“%s” already exists in the destination folder. Choose another name or folder.', 'regenerate-relink' ),
							(string) ( $result['detail'] ?? '' )
						),
						409,
					);
				}

				return array(
					sprintf(
						/* translators: %s: ファイル名 */
						__( 'A file named “%s” already exists in the same folder. Choose another name, or quarantine unused files from the Regenerate & Relink screen first.', 'regenerate-relink' ),
						(string) ( $result['detail'] ?? '' )
					),
					409,
				);

			case 'invalid_folder':
				return array( __( 'Folder names can contain only letters, digits, hyphens and underscores. Use “/” to separate levels.', 'regenerate-relink' ), 400 );

			case 'forbidden_folder':
				return array( __( 'Files cannot be moved to that folder. Choose another folder.', 'regenerate-relink' ), 400 );

			case 'upload_rejected':
				// アップロードの検査（wp_handle_upload_prefilter。マルチサイトの容量制限など）が断った。文言はフィルタのもの
				if ( '' !== (string) ( $result['detail'] ?? '' ) ) {
					return array( (string) $result['detail'], 400 );
				}

				return array( __( 'The image could not be uploaded.', 'regenerate-relink' ), 400 );

			case 'upload_failed':
				return array( __( 'The image could not be uploaded.', 'regenerate-relink' ), 400 );

			case 'upload_missing':
				return array( __( 'The uploaded image has expired. Upload it again.', 'regenerate-relink' ), 409 );

			case 'not_editable':
				return array( __( 'The image library on this server cannot process this image format.', 'regenerate-relink' ), 400 );

			case 'dir_failed':
				return array( __( 'The quarantine directory could not be created. Check that the uploads directory is writable.', 'regenerate-relink' ), 500 );

			case 'mkdir_failed':
				return array(
					__( 'The destination folder could not be created. Check that the uploads directory is writable.', 'regenerate-relink' ),
					500,
					__( 'Nothing was changed. Start again.', 'regenerate-relink' ),
				);

			case 'shared_file':
				return array(
					__( 'Another attachment uses the same file (for example, a copy made by a translation plugin). Changing the file here would change that attachment as well.', 'regenerate-relink' ),
					409,
					__( 'Nothing was changed.', 'regenerate-relink' ),
				);

			case 'busy_media_op':
				if ( ! empty( $result['media_op']['title'] ) ) {
					return array( self::media_op_running_message( (string) $result['media_op']['title'] ), 409 );
				}

				// 確かめる間に操作が終わっていた
				return array( __( 'Another image is being replaced or renamed. Try again when it finishes.', 'regenerate-relink' ), 409 );

			case 'busy_job':
				return array( __( 'A job on the Regenerate & Relink screen is in progress. Finish or resume it first.', 'regenerate-relink' ), 409 );

			case 'in_progress':
				// 同じ操作を別の要求が処理中（操作ごとのロック）か、開始のロックを取れなかった。何も変えていない
				return array( __( 'This operation is being processed by another request. Wait a moment, then try again.', 'regenerate-relink' ), 409 );

			case 'no_op':
				return array( __( 'There is no operation to undo.', 'regenerate-relink' ), 409 );

			case 'changed':
				return array( __( 'The image has changed since the last operation, so it cannot be undone.', 'regenerate-relink' ), 409 );

			case 'files_missing':
				return array( __( 'Files needed to undo were deleted from the quarantine area.', 'regenerate-relink' ), 409 );

			case 'stale':
				return array( __( 'The image changed after the preview was created. Create the preview again.', 'regenerate-relink' ), 409 );

			case 'not_found':
				return array( __( 'The operation was not found.', 'regenerate-relink' ), 404 );

			case 'not_planning':
			case 'not_running':
				return array( __( 'The operation is not in progress. Start again from the edit screen.', 'regenerate-relink' ), 409 );

			case 'meta_failed':
				// 失敗で終えている。metadata_restoredがfalseのときだけ、旧状態へ戻せていない
				if ( isset( $result['metadata_restored'] ) && ! $result['metadata_restored'] ) {
					return array( __( 'The attachment data could not be updated or put back. Both the old and the new files were kept so that images keep working; check this image.', 'regenerate-relink' ), 500 );
				}

				return array(
					__( 'The attachment data could not be updated, so the change was undone.', 'regenerate-relink' ),
					500,
					__( 'Nothing was changed. Start again.', 'regenerate-relink' ),
				);

			case 'meta_changed':
				// 段2の前に、ほかの処理が添付を変えていた。メタデータにもファイルにも触れずに終えている
				return array(
					__( 'The image was changed by something else while this operation was stopped, so its attachment data was not switched.', 'regenerate-relink' ),
					409,
					__( 'Both the old and the new files were kept; check this image.', 'regenerate-relink' ),
				);

			case 'db_failed':
				// failedなら段1の記録の書き込みに失敗し、すべて巻き戻している。
				// op_idがなければ、プレビューの開始で操作の行を作れなかった。再開する操作がないため、
				// これも何も変えていない。操作がrunningでなければ、runningにする書き込みに失敗した
				// （plannedのまま）。それ以外は、段2を取り消す判断を記録できず、操作が実行中のまま残っている
				$op = empty( $result['op_id'] ) ? null : Media_Ops::get( (int) $result['op_id'] );

				if ( ! empty( $result['failed'] ) || empty( $result['op_id'] ) || ( $op && Media_Ops::ST_RUNNING !== $op->status ) ) {
					return array(
						__( 'The operation could not be recorded.', 'regenerate-relink' ),
						500,
						__( 'Nothing was changed. Start again.', 'regenerate-relink' ),
					);
				}

				return array( __( 'The operation could not be recorded. Resume to try again.', 'regenerate-relink' ), 500 );

			case 'interrupted':
				return array(
					__( 'The previous attempt stopped partway.', 'regenerate-relink' ),
					409,
					__( 'Its changes were reverted. Start again.', 'regenerate-relink' ),
				);

			case 'generate_failed':
				return array(
					__( 'The image sizes for the new image could not be created.', 'regenerate-relink' ),
					500,
					__( 'Nothing was changed. Start again.', 'regenerate-relink' ),
				);

			case 'copy_failed':
			case 'move_failed':
			case 'restore_failed':
				return array(
					__( 'Files could not be moved.', 'regenerate-relink' ),
					500,
					__( 'Nothing was changed. Start again.', 'regenerate-relink' ),
				);
		}

		return array( __( 'The operation could not be completed.', 'regenerate-relink' ), 500 );
	}
}
