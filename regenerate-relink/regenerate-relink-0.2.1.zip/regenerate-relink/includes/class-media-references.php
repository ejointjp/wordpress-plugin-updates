<?php
/**
 * メディア操作の参照検出（局所スキャンの部品と、残っている参照の検索）
 *
 * 局所スキャン: 対象添付のファイル名を含む記事だけをLIKEで拾い、判定は
 * 既存のScanner::scan_post()とReference_Resolverに任せる。LIKEは候補を
 * 拾うだけで、書き換えの判定には使わない（付録A: HTMLを正規表現で
 * 処理しない）。
 *
 * 残っている参照の検索: 旧ファイルを隔離してよいかを、ファイル名がDBの
 * どこか（記事・postmeta・options）にまだ現れるかで決める（設計書 §4.1）。
 * 迷う対象は残す側に倒す（NFR-1.1）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- 候補記事と残っている参照を一度に調べる集計クエリ。メディア操作1回につき数回だけ走る。

/**
 * メディア操作の参照検出
 */
class Media_References {
	/*
	 * メディア操作に固有のスキップ理由（Reference_Graph::SKIP_* と同じ欄に入る）
	 *
	 * not_in_metadata = 対象添付の参照だが、現在のメタデータにないファイルを指す
	 *                   （過去の再生成で古くなった参照。実行タブの参照更新が先）
	 * no_counterpart  = 操作のあとに対応するファイルがない（新画像が小さく、
	 *                   そのサイズが作られなかった等）
	 */
	const SKIP_NOT_IN_METADATA = 'not_in_metadata';
	const SKIP_NO_COUNTERPART  = 'no_counterpart';

	/**
	 * 書き換えてよい、既存の判定の理由（許可リスト）
	 *
	 * ''              = 判定に迷うところがない（参照更新の対象になる参照）
	 * no_change       = 今のメタデータと一致している（メディア操作でよく出る形）
	 * no_intermediate = そのサイズ名の中間サイズはないが、ファイル名は今のメタデータにある
	 *
	 * これ以外の理由はすべて報告だけにする（NFR-1.1）。理由が増えても、ここに足すまでは
	 * 書き換えない側に倒れる。
	 */
	const REWRITABLE = array(
		'',
		Reference_Graph::SKIP_NO_CHANGE,
		Reference_Graph::SKIP_NO_INTERMEDIATE,
	);

	/**
	 * 本文やpostmetaに現れうるファイル名の書き方
	 *
	 * ASCII以外を含む名前は、JSONでエスケープした形（写真.jpg →
	 * 写真.jpg）も返す。wp_json_encode()の既定はこの形で保存するため
	 * （Elementorの_elementor_data、wp_global_stylesの本文など）、探さないと
	 * 参照が残っていても隔離してしまう。返す値はLIKEの前にesc_like()を通すので、
	 * バックスラッシュはそのままでよい。
	 *
	 * @param string $name ファイル名。
	 * @return string[] そのままの形と、パーセントエンコードした形（違う場合のみ）と、
	 *                  JSONでエスケープした形（ASCII以外を含む場合のみ）。
	 */
	public static function variants( string $name ): array {
		$variants = array( $name );
		$encoded  = rawurlencode( $name );

		if ( $encoded !== $name ) {
			$variants[] = $encoded;
		}

		if ( preg_match( '/[^\x00-\x7F]/', $name ) ) {
			$json = trim( (string) wp_json_encode( $name ), '"' );

			if ( '' !== $json && $json !== $name ) {
				$variants[] = $json;
			}
		}

		return $variants;
	}

	/**
	 * 候補記事の数（計画の進捗表示用）
	 *
	 * @param string[] $names 対象添付のファイル名。
	 */
	public static function count_candidates( array $names ): int {
		global $wpdb;

		if ( empty( $names ) ) {
			return 0;
		}

		list( $types_in, $statuses_in, $scope ) = Scanner::scope_placeholders();
		list( $like_sql, $like_params )         = self::candidate_like( $names );

		$sql = "SELECT COUNT(*) FROM {$wpdb->posts}
			WHERE post_type IN ($types_in) AND post_status IN ($statuses_in) AND $like_sql";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- IN句とLIKE句はプレースホルダのみで組み立て、値はすべてprepare()に渡している。
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( $scope, $like_params ) ) );
	}

	/**
	 * カーソル以降の候補記事ID
	 *
	 * @param string[] $names    対象添付のファイル名。
	 * @param int      $after_id このIDより大きい記事から。
	 * @param int      $limit    件数。
	 * @return int[]
	 */
	public static function candidate_post_ids( array $names, int $after_id, int $limit ): array {
		global $wpdb;

		if ( empty( $names ) ) {
			return array();
		}

		list( $types_in, $statuses_in, $scope ) = Scanner::scope_placeholders();
		list( $like_sql, $like_params )         = self::candidate_like( $names );

		$sql = "SELECT ID FROM {$wpdb->posts}
			WHERE post_type IN ($types_in) AND post_status IN ($statuses_in) AND $like_sql AND ID > %d
			ORDER BY ID LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- 上と同じ。
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, array_merge( $scope, $like_params, array( $after_id, $limit ) ) ) );

		return array_map( 'intval', $ids );
	}

	/**
	 * 候補のLIKE句
	 *
	 * @param string[] $names ファイル名。
	 * @return array{0: string, 1: array} SQL片とbind値。
	 */
	private static function candidate_like( array $names ): array {
		global $wpdb;

		$likes  = array();
		$params = array();

		foreach ( $names as $name ) {
			foreach ( self::variants( (string) $name ) as $variant ) {
				$likes[]  = 'post_content LIKE %s';
				$params[] = '%' . $wpdb->esc_like( $variant ) . '%';
			}
		}

		return array( '( ' . implode( ' OR ', $likes ) . ' )', $params );
	}

	/**
	 * 局所スキャンの行を、書き換え対象とスキップに分ける
	 *
	 * 書き換え対象にするのは次をすべて満たす行だけ（NFR-1.1）。
	 *
	 * 1. 添付IDが対象と完全一致する（FR-4.4）
	 * 2. 参照ファイル名が、対象添付の現在のファイル名のどれかに完全一致する
	 * 3. 既存の判定の理由が、書き換えてよいもの（REWRITABLE）である
	 * 4. URLのディレクトリが添付の年月ディレクトリと一致する
	 *
	 * @param array    $rows          Scanner::scan_post()の戻り値。
	 * @param int      $attachment_id 対象の添付ID。
	 * @param string   $subdir        添付の年月ディレクトリ。
	 * @param string[] $names         対象添付の現在のファイル名。
	 * @return array{targets: array, skips: array}
	 */
	public static function classify( array $rows, int $attachment_id, string $subdir, array $names ): array {
		$resolver = new Reference_Resolver();
		$targets  = array();
		$skips    = array();

		foreach ( $rows as $row ) {
			$url     = (string) ( $row['url'] ?? '' );
			$name    = $resolver->extract_filename( $url );
			$row_att = (int) ( $row['attachment_id'] ?? 0 );
			$post_id = (int) ( $row['post_id'] ?? 0 );
			$in_set  = '' !== $name && in_array( $name, $names, true );

			if ( $row_att !== $attachment_id ) {
				// 添付IDが取れない参照（postmeta・クラスのないimg等）が対象のファイルを
				// 指している場合は、書き換えずに報告する。別の添付の参照は扱わない
				if ( 0 === $row_att && $in_set ) {
					$reason  = (string) ( $row['skip_reason'] ?? '' );
					$skips[] = self::skip( $post_id, $url, $name, '' === $reason ? Reference_Graph::SKIP_OUT_OF_SCOPE : $reason );
				}

				continue;
			}

			if ( ! $in_set ) {
				$skips[] = self::skip( $post_id, $url, $name, self::SKIP_NOT_IN_METADATA );
				continue;
			}

			$reason = (string) ( $row['skip_reason'] ?? '' );

			if ( ! in_array( $reason, self::REWRITABLE, true ) ) {
				$skips[] = self::skip( $post_id, $url, $name, $reason );
				continue;
			}

			if ( ! self::location_matches( $url, $subdir, $name ) ) {
				$skips[] = self::skip( $post_id, $url, $name, Reference_Graph::SKIP_FILENAME_MISMATCH );
				continue;
			}

			$details = json_decode( (string) ( $row['details'] ?? '' ), true );
			$details = is_array( $details ) ? $details : array();

			$targets[] = array(
				'post_id'       => $post_id,
				'url'           => $url,
				'name'          => $name,
				'caption_width' => isset( $details['caption_width'] ) ? (int) $details['caption_width'] : null,
				'content_hash'  => (string) ( $details['content_hash'] ?? '' ),
			);
		}

		return array(
			'targets' => $targets,
			'skips'   => $skips,
		);
	}

	/**
	 * スキップ1件
	 *
	 * @param int    $post_id 記事ID。
	 * @param string $url     参照URL。
	 * @param string $name    参照ファイル名。
	 * @param string $reason  理由。
	 */
	private static function skip( int $post_id, string $url, string $name, string $reason ): array {
		return array(
			'post_id' => $post_id,
			'url'     => $url,
			'name'    => $name,
			'reason'  => $reason,
		);
	}

	/**
	 * URLが添付の年月ディレクトリのファイルを指しているか
	 *
	 * ファイル名だけが一致する別ディレクトリの同名ファイル（別の添付）を
	 * 巻き込まないための確認。CDNのURLでもパスの末尾は同じになる。
	 *
	 * @param string $url    参照URL。
	 * @param string $subdir 年月ディレクトリ。
	 * @param string $name   ファイル名。
	 */
	private static function location_matches( string $url, string $subdir, string $name ): bool {
		$path = $url;

		foreach ( array( '#', '?' ) as $sep ) {
			$pos = strpos( $path, $sep );

			if ( false !== $pos ) {
				$path = substr( $path, 0, $pos );
			}
		}

		$path   = rawurldecode( $path );
		$suffix = '/' . ( '' === $subdir ? '' : $subdir . '/' ) . $name;

		return strlen( $path ) >= strlen( $suffix ) && substr( $path, -strlen( $suffix ) ) === $suffix;
	}

	/**
	 * ファイル名がまだDBのどこかに現れるか（設計書 §4.1）
	 *
	 * 調べる場所は、記事の本文と抜粋（リビジョンを除く全投稿タイプ）、
	 * postmeta（対象添付自身のファイル情報を除く）、options（一時データを除く）、
	 * termmeta・usermeta・commentmeta。
	 * guidは調べない。照合は大文字小文字を区別しないLIKEのため、似た名前でも
	 * 「残す」側に倒れる（安全側の誤り）。検索のクエリが失敗したときも、調べきれて
	 * いないため、そのときの対象のファイル名はすべて「まだ現れる」として返す
	 * （隔離させない側に倒す。NFR-1.1）。理由はerror_log()に残る。
	 *
	 * @param string[] $names              調べるファイル名。
	 * @param int      $attachment_id      対象の添付ID。
	 * @param bool     $outside_scope_only trueなら、走査範囲（Scanner）の記事の本文は見ない
	 *                                     （プレビューの見込みで、範囲内の本文は局所スキャンの結果を使うため）。
	 *                                     範囲内の記事の抜粋は見る。
	 * @param array    $written            フォルダを変える操作で、段3が本文に書いた新URL
	 *                                     （記事ID => 文字列の配列。設計書2026-11-12の§7）。
	 *                                     新URLも同じファイル名を含むため、載っている記事の本文は
	 *                                     SQLの検索から外し、新URLを取り除いてから調べる。
	 *                                     $outside_scope_onlyがtrueのときは使わない。
	 * @return string[] 現れたファイル名（検索に失敗した分を含む）。
	 */
	public static function still_referenced( array $names, int $attachment_id, bool $outside_scope_only = false, array $written = array() ): array {
		$names    = array_values( array_unique( array_filter( array_map( 'strval', $names ), 'strlen' ) ) );
		$post_ids = $outside_scope_only ? array() : array_values( array_filter( array_map( 'intval', array_keys( $written ) ) ) );
		$found    = array();

		foreach ( array_chunk( $names, 10 ) as $chunk ) {
			$found = array_merge(
				$found,
				self::search_posts( $chunk, $outside_scope_only, $post_ids ),
				self::search_postmeta( $chunk, $attachment_id ),
				self::search_options( $chunk ),
				self::search_other_meta( $chunk )
			);
		}

		if ( ! empty( $names ) && ! empty( $post_ids ) ) {
			$found = array_merge( $found, self::search_written( $names, $written, $post_ids ) );
		}

		return array_values( array_unique( $found ) );
	}

	/**
	 * ほかの添付が自分のファイルとして使っているファイル名
	 *
	 * 翻訳プラグイン（WPML・Polylang）の添付の複製などは、同じファイルを
	 * _wp_attached_file・_wp_attachment_metadata・_wp_attachment_backup_sizesに
	 * 持つ。そのファイルを同名で入れ替えると、ほかの添付の表示も黙って変わるため、
	 * 入れ替えの前にここで確かめる（NFR-1.1）。
	 *
	 * 見るのは、_wp_attached_fileが同じ年月ディレクトリにある添付だけ（年月の違う
	 * 同名ファイルは別のファイル）。年月フォルダを使わない添付ではディレクトリで
	 * 絞らない。照合はファイル名の前後の区切り（/や"）まで含めたLIKEで、似た名前を
	 * 拾っても「使われている」側に倒れる。クエリが失敗したときは、渡された名前を
	 * すべて「使われている」として返し、理由をerror_log()に残す。
	 *
	 * @param string[] $names         調べるファイル名。
	 * @param int      $attachment_id 対象の添付ID（自分のファイル情報は除く）。
	 * @param string   $subdir        対象の添付の年月ディレクトリ。
	 * @return string[] ほかの添付が使っているファイル名（検索に失敗した分を含む）。
	 */
	public static function shared_names( array $names, int $attachment_id, string $subdir ): array {
		global $wpdb;

		$names = array_values( array_unique( array_filter( array_map( 'strval', $names ), 'strlen' ) ) );
		$found = array();

		foreach ( array_chunk( $names, 10 ) as $chunk ) {
			$selects = array();
			$params  = array();

			foreach ( $chunk as $i => $name ) {
				$selects[] = "MAX( ( m.meta_key = '_wp_attached_file' AND ( m.meta_value = %s OR m.meta_value LIKE %s ) )"
					. " OR ( m.meta_key <> '_wp_attached_file' AND ( m.meta_value LIKE %s OR m.meta_value LIKE %s ) ) ) AS n$i";
				$params[]  = $name;
				$params[]  = '%/' . $wpdb->esc_like( $name );
				$params[]  = '%"' . $wpdb->esc_like( $name ) . '"%';
				$params[]  = '%/' . $wpdb->esc_like( $name ) . '"%';
			}

			$where = "m.post_id <> %d AND m.meta_key IN ('_wp_attached_file', '_wp_attachment_metadata', '_wp_attachment_backup_sizes')";

			$params[] = $attachment_id;

			if ( '' !== $subdir ) {
				$where   .= ' AND f.meta_value LIKE %s';
				$params[] = $wpdb->esc_like( $subdir . '/' ) . '%';
			}

			$sql = 'SELECT ' . implode( ', ', $selects ) . " FROM {$wpdb->postmeta} m
				INNER JOIN {$wpdb->postmeta} f ON f.post_id = m.post_id AND f.meta_key = '_wp_attached_file'
				WHERE $where";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- 列名とテーブル名は固定値と$wpdbのプロパティ。値はすべてprepare()に渡している。
			$row = $wpdb->get_row( $wpdb->prepare( $sql, $params ), ARRAY_N );

			if ( ! is_array( $row ) || '' !== $wpdb->last_error ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 検索の失敗は握りつぶさず、入れ替えさせない側に倒した理由として残すため
				error_log(
					sprintf(
						'Regenerate & Relink: shared file search failed; treating %1$d name(s) as used by another attachment. %2$s',
						count( $chunk ),
						'' !== $wpdb->last_error ? $wpdb->last_error : 'No row returned.'
					)
				);

				$found = array_merge( $found, $chunk );
				continue;
			}

			foreach ( $chunk as $i => $name ) {
				if ( ! empty( $row[ $i ] ) ) {
					$found[] = $name;
				}
			}
		}

		return $found;
	}

	/**
	 * 記事の本文と抜粋を調べる
	 *
	 * @param string[] $names              ファイル名。
	 * @param bool     $outside_scope_only 走査範囲の外だけを見るか。
	 * @param int[]    $skip_ids           本文を調べない記事（search_written()が調べる）。抜粋は調べる。
	 *                                     $outside_scope_onlyがtrueのときは使わない。
	 * @return string[]
	 */
	private static function search_posts( array $names, bool $outside_scope_only, array $skip_ids = array() ): array {
		global $wpdb;

		if ( ! $outside_scope_only && empty( $skip_ids ) ) {
			return self::search( $wpdb->posts, array( 'post_content', 'post_excerpt' ), 'post_type <> %s', array( 'revision' ), $names );
		}

		if ( ! $outside_scope_only ) {
			$in = implode( ', ', array_fill( 0, count( $skip_ids ), '%d' ) );

			// 外した記事の抜粋は書き換えていないので、ここで調べる
			return array_merge(
				self::search( $wpdb->posts, array( 'post_content', 'post_excerpt' ), "post_type <> %s AND ID NOT IN ($in)", array_merge( array( 'revision' ), $skip_ids ), $names ),
				self::search( $wpdb->posts, array( 'post_excerpt' ), "ID IN ($in)", $skip_ids, $names )
			);
		}

		list( $types_in, $statuses_in, $scope ) = Scanner::scope_placeholders();

		$in_scope = "post_type IN ($types_in) AND post_status IN ($statuses_in)";
		$params   = array_merge( array( 'revision' ), $scope );

		// 範囲内の記事の本文は、局所スキャン（書き換えを当てた本文）で見る。抜粋は書き換えないので、範囲内でも調べる
		return array_merge(
			self::search( $wpdb->posts, array( 'post_content', 'post_excerpt' ), "post_type <> %s AND NOT ( $in_scope )", $params, $names ),
			self::search( $wpdb->posts, array( 'post_excerpt' ), "post_type <> %s AND $in_scope", $params, $names )
		);
	}

	/**
	 * 段3が新URLを書いた記事の本文を、新URLを取り除いてから調べる（設計書2026-11-12の§7.2）
	 *
	 * フォルダを変える操作では、書いた新URLも旧ファイルと同じファイル名を含む。
	 * 書いた文字列そのものだけをstr_replace()で取り除き（大文字小文字を区別する）、
	 * 残りの本文にファイル名が現れるかを、ほかの検索と同じく大文字小文字を区別せずに
	 * 調べる。取り除けなかった新URLの名前は「現れた」になり、残す側に倒れる。
	 * クエリが失敗したときは、渡された名前をすべて「現れた」として返し、理由を
	 * error_log()に残す。
	 *
	 * @param string[] $names    ファイル名。
	 * @param array    $written  記事ID => 書いた新URLの文字列の配列。
	 * @param int[]    $post_ids 調べる記事ID（$writtenのキー）。
	 * @return string[] 現れたファイル名（検索に失敗した分を含む）。
	 */
	private static function search_written( array $names, array $written, array $post_ids ): array {
		global $wpdb;

		$found = array();

		foreach ( array_chunk( $post_ids, 50 ) as $ids ) {
			$in  = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
			$sql = "SELECT ID, post_content FROM {$wpdb->posts} WHERE ID IN ($in)";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- IN句はプレースホルダのみで組み立て、値はすべてprepare()に渡している。
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, $ids ) );

			if ( ! is_array( $rows ) || '' !== $wpdb->last_error ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 検索の失敗は握りつぶさず、隔離させない側に倒した理由として残すため
				error_log(
					sprintf(
						'Regenerate & Relink: reference search failed on rewritten posts; treating %1$d name(s) as still referenced. %2$s',
						count( $names ),
						'' !== $wpdb->last_error ? $wpdb->last_error : 'No rows returned.'
					)
				);

				return $names;
			}

			foreach ( $rows as $row ) {
				$strip   = array_values( array_filter( array_map( 'strval', (array) ( $written[ (int) $row->ID ] ?? array() ) ), 'strlen' ) );
				$content = empty( $strip ) ? (string) $row->post_content : str_replace( $strip, '', (string) $row->post_content );

				foreach ( $names as $name ) {
					if ( in_array( $name, $found, true ) ) {
						continue;
					}

					foreach ( self::variants( $name ) as $variant ) {
						if ( false !== stripos( $content, $variant ) ) {
							$found[] = $name;
							break;
						}
					}
				}
			}
		}

		return $found;
	}

	/**
	 * postmetaを調べる（対象添付自身のファイル情報は除く）
	 *
	 * @param string[] $names         ファイル名。
	 * @param int      $attachment_id 対象の添付ID。
	 * @return string[]
	 */
	private static function search_postmeta( array $names, int $attachment_id ): array {
		global $wpdb;

		return self::search(
			$wpdb->postmeta,
			array( 'meta_value' ),
			'NOT ( post_id = %d AND meta_key IN (%s, %s, %s) )',
			array( $attachment_id, '_wp_attached_file', '_wp_attachment_metadata', '_wp_attachment_backup_sizes' ),
			$names
		);
	}

	/**
	 * optionsを調べる（一時データは除く）
	 *
	 * @param string[] $names ファイル名。
	 * @return string[]
	 */
	private static function search_options( array $names ): array {
		global $wpdb;

		return self::search(
			$wpdb->options,
			array( 'option_value' ),
			'option_name NOT LIKE %s AND option_name NOT LIKE %s',
			array( $wpdb->esc_like( '_transient_' ) . '%', $wpdb->esc_like( '_site_transient_' ) . '%' ),
			$names
		);
	}

	/**
	 * term・user・commentのメタを調べる
	 *
	 * タームの画像（カテゴリーのサムネイルなど）、プロフィール画像、レビューに付けた
	 * 画像などを、プラグインがここに持つことがある。
	 *
	 * @param string[] $names ファイル名。
	 * @return string[]
	 */
	private static function search_other_meta( array $names ): array {
		global $wpdb;

		$found = array();

		foreach ( array( $wpdb->termmeta, $wpdb->usermeta, $wpdb->commentmeta ) as $table ) {
			$found = array_merge( $found, self::search( $table, array( 'meta_value' ), '', array(), $names ) );
		}

		return $found;
	}

	/**
	 * 1テーブルを1回の走査で調べ、現れたファイル名を返す
	 *
	 * 集計クエリ（GROUP BYなし）は成功すれば必ず1行を返すため、行が取れない、または
	 * クエリ直後に$wpdb->last_errorが残っているときは失敗とみなす。失敗した場合は
	 * 調べきれていないので、渡されたファイル名をすべて「現れた」として返し（残す側に
	 * 倒す）、握りつぶさずにerror_log()へ理由とテーブル名を残す。
	 *
	 * @param string   $table        テーブル名（$wpdbのプロパティ）。
	 * @param string[] $columns      調べる列（固定値）。
	 * @param string   $where        WHERE句（プレースホルダ付き）。空なら全行を調べる。
	 * @param array    $where_params WHERE句のbind値。
	 * @param string[] $names        ファイル名（0始まりの連番の配列）。
	 * @return string[] 現れたファイル名。クエリが失敗したときは$namesの全部。
	 */
	private static function search( string $table, array $columns, string $where, array $where_params, array $names ): array {
		global $wpdb;

		$selects = array();
		$params  = array();

		foreach ( $names as $i => $name ) {
			$conditions = array();

			foreach ( self::variants( $name ) as $variant ) {
				$like = '%' . $wpdb->esc_like( $variant ) . '%';

				foreach ( $columns as $column ) {
					$conditions[] = "$column LIKE %s";
					$params[]     = $like;
				}
			}

			$selects[] = 'MAX(' . implode( ' OR ', $conditions ) . ") AS n$i";
		}

		$sql = 'SELECT ' . implode( ', ', $selects ) . " FROM $table" . ( '' === $where ? '' : " WHERE $where" );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- テーブル名と列名は$wpdbのプロパティと固定値。値はすべてprepare()に渡している。
		$row = $wpdb->get_row( $wpdb->prepare( $sql, array_merge( $params, $where_params ) ), ARRAY_N );

		if ( ! is_array( $row ) || '' !== $wpdb->last_error ) {
			// last_errorは次のクエリのflush()で消えるため、呼び出し側では拾えない。ここで残す
			$message = sprintf(
				'Regenerate & Relink: reference search failed on %1$s; treating %2$d name(s) as still referenced. %3$s',
				$table,
				count( $names ),
				'' !== $wpdb->last_error ? $wpdb->last_error : 'No row returned.'
			);

			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 検索の失敗は握りつぶさず、隔離させない側に倒した理由として残すため
			error_log( $message );

			return $names;
		}

		$found = array();

		foreach ( $names as $i => $name ) {
			if ( ! empty( $row[ $i ] ) ) {
				$found[] = $name;
			}
		}

		return $found;
	}
}
