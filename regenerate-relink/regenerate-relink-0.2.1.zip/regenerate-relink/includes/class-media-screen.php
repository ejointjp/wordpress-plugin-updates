<?php
/**
 * メディア操作の入口（FR-13.5）
 *
 * 添付ファイル編集画面のメタボックス、メディア一覧（リスト表示）の
 * 行アクション、グリッド表示の詳細モーダルのリンクを置く。中身は React
 * （src/media/）が描画し、ここは殻と初期状態を出すだけにとどめる。
 * プラグインの管理画面（FR-7.1）とは別の、添付ごとの操作。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * メディア操作の入口
 */
class Media_Screen {

	/**
	 * 編集画面で自動で開くModalを渡すURLの引数
	 */
	const QUERY_ARG = 'rgrl';

	/**
	 * 自動で開けるModal
	 */
	const OPEN_VALUES = array( 'replace', 'rename' );

	/**
	 * この添付に入口を出してよいか
	 *
	 * @param int $attachment_id 添付ID。
	 */
	public static function can_use( int $attachment_id ): bool {
		return current_user_can( 'manage_options' )
			&& current_user_can( 'edit_post', $attachment_id )
			&& wp_attachment_is_image( $attachment_id );
	}

	/**
	 * メタボックスを足す（add_meta_boxes_attachment）
	 *
	 * @param WP_Post|mixed $post 添付。
	 */
	public static function add_meta_box( $post ): void {
		if ( ! $post instanceof WP_Post || ! self::can_use( $post->ID ) ) {
			return;
		}

		// メタボックスのidは、コアが外側のpostboxのidとして出す。中身をマウントする
		// #rgrl-mediaと重ならないよう、別のidにする。
		add_meta_box(
			'rgrl-media-box',
			__( 'Replace, rename or move', 'regenerate-relink' ),
			array( __CLASS__, 'render_meta_box' ),
			'attachment',
			'side'
		);
	}

	/**
	 * メタボックスの殻を描画する（中身は#rgrl-mediaにReactがマウントする）
	 */
	public static function render_meta_box(): void {
		echo '<div id="rgrl-media" class="rgrl-admin"></div>';

		printf(
			'<noscript><p>%s</p></noscript>',
			esc_html__( 'Replacing, renaming and moving need JavaScript.', 'regenerate-relink' )
		);
	}

	/**
	 * スクリプト・スタイルを読み込む（添付ファイル編集画面だけ）
	 *
	 * 依存と版はbuild/media.asset.phpから受け取る。
	 * **ファイルがないときに黙ってreturnしないこと**（ビルド漏れに気付けなくなる）。
	 *
	 * @param string $hook_suffix 現在の管理画面。
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( 'post.php' !== $hook_suffix ) {
			return;
		}

		$screen = get_current_screen();
		$post   = get_post();

		if ( ! $screen || 'attachment' !== $screen->id || ! $post instanceof WP_Post || ! self::can_use( $post->ID ) ) {
			return;
		}

		$asset_file = RGRL_DIR . 'build/media.asset.php';

		if ( ! file_exists( $asset_file ) ) {
			_doing_it_wrong(
				__METHOD__,
				'build/media.asset.php が見つかりません。pnpm build を実行してください。',
				'0.2.0'
			);
			return;
		}

		$asset = require $asset_file;

		wp_enqueue_script(
			'regenerate-relink-media',
			RGRL_URL . 'build/media.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		wp_add_inline_script(
			'regenerate-relink-media',
			'window.rgrlMedia = ' . wp_json_encode(
				array(
					'status'   => Media_Operation::status( $post->ID ),
					'autoOpen' => self::auto_open(),
				),
				JSON_HEX_TAG | JSON_HEX_AMP
			) . ';',
			'before'
		);

		wp_set_script_translations(
			'regenerate-relink-media',
			'regenerate-relink',
			RGRL_DIR . 'languages'
		);

		wp_enqueue_style( 'wp-components' );

		wp_enqueue_style(
			'regenerate-relink-media',
			RGRL_URL . 'build/media.css',
			array( 'wp-components' ),
			$asset['version']
		);
	}

	/**
	 * メディア一覧（リスト表示）の行アクション（media_row_actions）
	 *
	 * @param array         $actions 既存の行アクション。
	 * @param WP_Post|mixed $post    添付。
	 * @return array
	 */
	public static function row_actions( array $actions, $post ): array {
		if ( ! $post instanceof WP_Post || ! self::can_use( $post->ID ) ) {
			return $actions;
		}

		$edit = get_edit_post_link( $post->ID, 'raw' );

		if ( ! $edit ) {
			return $actions;
		}

		$actions['rgrl_replace'] = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( add_query_arg( self::QUERY_ARG, 'replace', $edit ) ),
			esc_html__( 'Replace', 'regenerate-relink' )
		);

		$actions['rgrl_rename'] = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( add_query_arg( self::QUERY_ARG, 'rename', $edit ) ),
			esc_html__( 'Rename or move', 'regenerate-relink' )
		);

		return $actions;
	}

	/**
	 * グリッド表示の詳細モーダルに、編集画面へのリンクを足す（attachment_fields_to_edit）
	 *
	 * Backboneのモーダルには操作UIを組み込まない（設計書 §8.3）。
	 *
	 * @param array         $fields 既存の項目。
	 * @param WP_Post|mixed $post   添付。
	 * @return array
	 */
	public static function attachment_fields( array $fields, $post ): array {
		if ( ! $post instanceof WP_Post || ! self::can_use( $post->ID ) ) {
			return $fields;
		}

		// 編集画面ではメタボックスが同じ役目を持つため出さない
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && 'attachment' === $screen->id ) {
			return $fields;
		}

		$edit = get_edit_post_link( $post->ID, 'raw' );

		if ( ! $edit ) {
			return $fields;
		}

		$fields['rgrl_media'] = array(
			'label' => __( 'Replace, rename or move', 'regenerate-relink' ),
			'input' => 'html',
			'html'  => sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $edit ),
				esc_html__( 'Open the edit screen', 'regenerate-relink' )
			),
		);

		return $fields;
	}

	/**
	 * URLの?rgrl=から、自動で開くModalを決める
	 *
	 * @return string 許可リストにある値。なければ''。
	 */
	private static function auto_open(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 開くModalを選ぶだけの読み取り専用パラメータ。状態を変更しない。
		$value = isset( $_GET[ self::QUERY_ARG ] ) ? sanitize_key( wp_unslash( $_GET[ self::QUERY_ARG ] ) ) : '';

		return in_array( $value, self::OPEN_VALUES, true ) ? $value : '';
	}
}
