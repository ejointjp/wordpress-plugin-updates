<?php
/**
 * メディア操作（差し替え・名前変更・取り消し）の記録のデータ層
 *
 * rgrl_media_opsに1操作1行で記録する。書き込みの頻度が違うものを列で分ける。
 *
 * - details: 旧状態・新状態・対応表・結果（取り消しにも使う）
 * - plan:    局所スキャンの結果（記事ごとの書き換え対象。段3で読む）
 * - journal: 段1で作ったファイル・復元した隔離行（巻き戻し用。段2が終わるまで残す）
 *
 * 処理の実装はMedia_Operationが持ち、本クラスは格納と照会に徹する
 * （Jobsと同じ役割）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- カスタムテーブルのデータ層のため $wpdb直接クエリが本務。結果の再利用は呼び出し側の責務とする。

/**
 * メディア操作の格納・照会
 */
class Media_Ops {
	/*
	 * 操作の種別
	 *
	 * 種別を増やすときは値の追加のみで済ませ、既存値の意味を変えないこと。
	 */
	const TYPE_REPLACE = 'replace';
	const TYPE_RENAME  = 'rename';
	const TYPE_UNDO    = 'undo';

	/*
	 * 操作の状態
	 *
	 * planning = 局所スキャン中（プレビューを作っている）
	 * planned  = プレビュー済み・実行待ち
	 * running  = 実行中。中断した場合もこのままで、続きから再開する
	 * complete = 完了
	 * failed   = 段1・段2で失敗・中断し、旧状態へ巻き戻して終えた（終端。段2でメタデータを
	 *            戻せなかったときは、ファイルを消さずに終える。中断中に対象の添付が消えた
	 *            操作も、巻き戻さずにここで終える）
	 * undone   = 取り消された
	 */
	const ST_PLANNING = 'planning';
	const ST_PLANNED  = 'planned';
	const ST_RUNNING  = 'running';
	const ST_COMPLETE = 'complete';
	const ST_FAILED   = 'failed';
	const ST_UNDONE   = 'undone';

	/**
	 * 操作を記録する（状態はplanning）
	 *
	 * @param int    $attachment_id 対象の添付ID。
	 * @param string $op_type       TYPE_* 定数。
	 * @param array  $details       旧状態・対応表など。
	 * @param array  $plan          局所スキャンの初期値。
	 * @param int    $undo_of       取り消しのとき、取り消す操作のop_id。
	 * @return int 新しいop_id。失敗時は0。
	 */
	public static function create( int $attachment_id, string $op_type, array $details, array $plan, int $undo_of = 0 ): int {
		global $wpdb;

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'rgrl_media_ops',
			array(
				'attachment_id' => $attachment_id,
				'op_type'       => $op_type,
				'status'        => self::ST_PLANNING,
				'undo_of'       => $undo_of,
				'created_at'    => gmdate( 'Y-m-d H:i:s' ),
				'details'       => (string) wp_json_encode( $details ),
				'plan'          => (string) wp_json_encode( $plan ),
				'journal'       => '[]',
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		return $inserted ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * 操作を1件取得する
	 *
	 * @param int $op_id 操作ID。
	 * @return object|null
	 */
	public static function get( int $op_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_media_ops WHERE op_id = %d",
				$op_id
			)
		);
	}

	/**
	 * 操作を更新する
	 *
	 * @param int   $op_id  操作ID。
	 * @param array $fields 更新するカラム。details / plan / journalは配列で渡す
	 *                      （JSON化はここで行う）。許可外のキーは無視する。
	 * @return bool クエリが成功したか（値が同じで変更行が0件でもtrue）。
	 */
	public static function update( int $op_id, array $fields ): bool {
		return false !== self::write( $op_id, $fields, array() );
	}

	/**
	 * 状態が$expectedのときだけ操作を更新する（比べて書き換える）
	 *
	 * 状態を移すときに使う。読んでから書くまでの間に、ほかの要求が状態を変えていたら
	 * 書かない（ロックの関数が使えないDBでも、同じ操作を二重に始めないように）。
	 *
	 * @param int    $op_id    操作ID。
	 * @param string $expected 今の状態（ST_* 定数）。
	 * @param array  $fields   update()と同じ。
	 * @return int|null 更新した行数（0なら状態が変わっていた）。クエリが失敗したらnull。
	 */
	public static function update_if_status( int $op_id, string $expected, array $fields ): ?int {
		$updated = self::write( $op_id, $fields, array( 'status' => $expected ) );

		return false === $updated ? null : $updated;
	}

	/**
	 * update()とupdate_if_status()の本体
	 *
	 * @param int   $op_id  操作ID。
	 * @param array $fields 更新するカラム。
	 * @param array $where  op_idのほかの条件（列 => 値。値は文字列）。
	 * @return int|false 更新した行数。書くものがない・クエリが失敗したらfalse。
	 */
	private static function write( int $op_id, array $fields, array $where ) {
		global $wpdb;

		$allowed = array(
			'status'       => '%s',
			'step'         => '%d',
			'last_post_id' => '%d',
			'finished_at'  => '%s',
			'details'      => '%s',
			'plan'         => '%s',
			'journal'      => '%s',
		);

		foreach ( array( 'details', 'plan', 'journal' ) as $key ) {
			if ( isset( $fields[ $key ] ) && is_array( $fields[ $key ] ) ) {
				$fields[ $key ] = (string) wp_json_encode( $fields[ $key ] );
			}
		}

		$data    = array();
		$formats = array();

		foreach ( $allowed as $key => $format ) {
			if ( array_key_exists( $key, $fields ) ) {
				$data[ $key ] = $fields[ $key ];
				$formats[]    = $format;
			}
		}

		if ( empty( $data ) ) {
			return false;
		}

		return $wpdb->update(
			$wpdb->prefix . 'rgrl_media_ops',
			$data,
			array_merge( array( 'op_id' => $op_id ), $where ),
			$formats,
			array_merge( array( '%d' ), array_fill( 0, count( $where ), '%s' ) )
		);
	}

	/**
	 * JSONの列を配列に戻す
	 *
	 * @param object|null $op     get()などの戻り値。
	 * @param string      $column details / plan / journal。
	 * @return array 壊れている・空の場合は空配列。
	 */
	public static function decode( $op, string $column ): array {
		if ( ! $op || empty( $op->$column ) ) {
			return array();
		}

		$value = json_decode( (string) $op->$column, true );

		return is_array( $value ) ? $value : array();
	}

	/**
	 * 巻き戻し用の記録を1件足す
	 *
	 * 段1の各ファイル操作の前に呼ぶ（先に記録してから動かす）。中断しても
	 * 次の要求で巻き戻せるよう、detailsとは別の列にすぐ書く。
	 *
	 * @param int   $op_id 操作ID。
	 * @param array $entry { type: 'created', rel_path }または{ type: 'restored', file_id }。
	 * @return bool 書けたか。
	 */
	public static function append_journal( int $op_id, array $entry ): bool {
		$journal   = self::decode( self::get( $op_id ), 'journal' );
		$journal[] = $entry;

		return self::update( $op_id, array( 'journal' => $journal ) );
	}

	/**
	 * 添付の「直前の操作」を返す
	 *
	 * 計画だけのもの（planning / planned）と、何も変えずに終えたもの（failed）は
	 * 数えない。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return object|null
	 */
	public static function latest_effective( int $attachment_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_media_ops
				WHERE attachment_id = %d AND status IN (%s, %s, %s)
				ORDER BY op_id DESC LIMIT 1",
				$attachment_id,
				self::ST_RUNNING,
				self::ST_COMPLETE,
				self::ST_UNDONE
			)
		);
	}

	/**
	 * 添付の直近の操作を返す（計画だけのもの＝planning / plannedは数えない）
	 *
	 * latest_effective()と違い、失敗したもの（failed）も数える。後始末が残った
	 * 失敗を、画面で知らせるために使う。
	 *
	 * @param int $attachment_id 添付ID。
	 * @return object|null
	 */
	public static function latest_attempt( int $attachment_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_media_ops
				WHERE attachment_id = %d AND status IN (%s, %s, %s, %s)
				ORDER BY op_id DESC LIMIT 1",
				$attachment_id,
				self::ST_RUNNING,
				self::ST_COMPLETE,
				self::ST_UNDONE,
				self::ST_FAILED
			)
		);
	}

	/**
	 * 実行中の操作を返す（サイトで同時に1つまで。NFR-2.4）
	 *
	 * 対象の添付が消えた操作は、ここで放棄してfailedにし、実行中として数えない
	 * （abandon()）。中断中に添付を削除すると、編集画面もなく再開できないまま、
	 * サイト全体のメディア操作と実行タブを止め続けるため。
	 *
	 * @return object|null
	 */
	public static function running() {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}rgrl_media_ops WHERE status = %s ORDER BY op_id DESC",
				self::ST_RUNNING
			)
		);

		foreach ( $rows as $op ) {
			if ( 'attachment' === get_post_type( (int) $op->attachment_id ) || ! self::abandon( $op ) ) {
				return $op;
			}
		}

		return null;
	}

	/**
	 * 対象の添付が消えた実行中の操作を、failedで終える
	 *
	 * 巻き戻しはしない（ファイルには触れない）。段1で作ったファイルや隔離した
	 * ファイルは、そのまま残る（隔離した行は、失敗した操作の行として一括復元から
	 * 戻せる）。
	 *
	 * 操作を進める要求と同じロックを取り、その中で操作と添付を読み直してから書く。
	 * ほかの要求が進めている操作を、横から書き換えないため。添付がないことは、
	 * get_post_type()（DBの失敗でもfalseを返す）ではなく、DBへ直接問い合わせて確かめる。
	 * DBの失敗で「添付がない」と取り違え、生きている操作を放棄しないため。
	 *
	 * @param object $op 操作（running）。
	 * @return bool 実行中でなくなったか。ロックを取れない・確かめられない・記録できない
	 *              ときはfalse（実行中のまま。排他を外さない側に倒す）。
	 */
	private static function abandon( $op ): bool {
		global $wpdb;

		$op_id = (int) $op->op_id;
		$lock  = self::lock_key( 'op_' . $op_id );
		$got   = self::lock( $lock, 0 );

		// ほかの要求が進めている
		if ( false === $got ) {
			return false;
		}

		try {
			$op = self::get( $op_id );

			if ( ! $op ) {
				return false;
			}

			// running()が読んだあとに、ほかの要求が終えていた
			if ( self::ST_RUNNING !== $op->status ) {
				return true;
			}

			$type = $wpdb->get_var( $wpdb->prepare( "SELECT post_type FROM {$wpdb->posts} WHERE ID = %d", (int) $op->attachment_id ) );

			if ( '' !== $wpdb->last_error ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 添付があるか確かめられず、操作を実行中のまま残すことを握りつぶさないため
				error_log( sprintf( 'Regenerate & Relink: could not check the attachment of media operation %1$d. %2$s', $op_id, $wpdb->last_error ) );

				return false;
			}

			if ( 'attachment' === $type ) {
				return false;
			}

			$details = self::decode( $op, 'details' );

			$details['error']     = 'attachment_missing';
			$details['abandoned'] = true;

			$updated = self::update(
				$op_id,
				array(
					'status'      => self::ST_FAILED,
					'finished_at' => gmdate( 'Y-m-d H:i:s' ),
					'details'     => $details,
				)
			);

			if ( ! $updated ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 放棄を記録できず、操作が実行中のまま残ることを握りつぶさないため
				error_log( sprintf( 'Regenerate & Relink: could not abandon media operation %d whose attachment no longer exists.', $op_id ) );
			}

			return $updated;
		} finally {
			// nullはロックの関数が使えないDB。取っていないので外さない
			if ( true === $got ) {
				self::unlock( $lock );
			}
		}
	}

	/**
	 * メディア操作のロックの名前（インストールごとに変わる）
	 *
	 * GET_LOCKの名前は、MySQLのサーバ全体で共有される。同じサーバの別のデータベースに、
	 * 同じ接頭辞（wp_など）のインストールがあってもぶつからないよう、データベース名と
	 * 接頭辞から作ったハッシュを混ぜる。
	 *
	 * @param string $suffix 操作ごとのロックはop_{op_id}、サイト全体の開始のロックはstart。
	 */
	public static function lock_key( string $suffix ): string {
		global $wpdb;

		$database = defined( 'DB_NAME' ) ? (string) DB_NAME : '';

		return 'rgrl_media_' . substr( md5( $database . '|' . $wpdb->prefix ), 0, 16 ) . '_' . $suffix;
	}

	/**
	 * サイト全体の開始のロックを持って処理する
	 *
	 * メディア操作の開始（plannedからrunningへ）と、再生成・参照更新・隔離のジョブの開始は、
	 * 「相手が実行中でないことの確認」から「実行中にする」までを、このロックで包む。
	 * 包まないと、同時に始めたとき、どちらも確認を通ってしまう（NFR-2.4、FR-13.4）。
	 * ロックの関数が使えないDBでは、ロックなしで呼ぶ（lock()と同じ扱い）。
	 *
	 * @param callable $callback ロックを持っている間に呼ぶ。
	 * @return mixed callbackの戻り値。ほかの要求が持っていて取れなければnull。
	 */
	public static function while_starting( callable $callback ) {
		$lock = self::lock_key( 'start' );
		$got  = self::lock( $lock, 5 );

		if ( false === $got ) {
			return null;
		}

		try {
			return $callback();
		} finally {
			// nullはロックの関数が使えないDB。取っていないので外さない
			if ( true === $got ) {
				self::unlock( $lock );
			}
		}
	}

	/**
	 * 名前付きロックを取る（MySQLのGET_LOCK）
	 *
	 * ロックは接続に結び付き、接続が切れる（PHPのプロセスが落ちる）と自動で外れる。
	 * そのため、ロックを取れたのに前回の途中状態が残っていれば、前回の要求は確かに
	 * 死んでいる。MySQL 5.7未満・MariaDB 10.0.2未満は同時に1つしか持てず、2つ目を取ると
	 * 先のロックが外れる（排他が弱まるだけで、従来どおりの動きになる）。
	 * 名前は64文字までのため、長いときはハッシュに置き換える。
	 *
	 * @param string $name    ロック名（lock_key()で作ること）。
	 * @param int    $timeout 待つ秒数（0なら待たない）。
	 * @return bool|null 取れたらtrue、ほかが持っていればfalse。ロックの関数が使えない
	 *                   DB（SQLiteなど）ではnull（排他なしで進める）。
	 */
	public static function lock( string $name, int $timeout ): ?bool {
		global $wpdb;

		$got = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK( %s, %d )', self::lock_name( $name ), $timeout ) );

		if ( null === $got ) {
			if ( '' !== $wpdb->last_error ) {
				// 排他が効かなくなることを握りつぶさず残す
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- ロックを取れなかった理由を残すため
				error_log( 'Regenerate & Relink: GET_LOCK failed; proceeding without a lock. ' . $wpdb->last_error );
			}

			return null;
		}

		return '1' === (string) $got;
	}

	/**
	 * lock()で取ったロックを外す
	 *
	 * 自分が持っていないロックを外そうとしても何も起きない。
	 *
	 * @param string $name lock()に渡したロック名。
	 */
	public static function unlock( string $name ): void {
		global $wpdb;

		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK( %s )', self::lock_name( $name ) ) );
	}

	/**
	 * ロック名をMySQLの上限（64文字）に収める
	 *
	 * @param string $name ロック名。
	 */
	private static function lock_name( string $name ): string {
		return strlen( $name ) > 64 ? 'rgrl_' . md5( $name ) : $name;
	}

	/**
	 * 実行されないまま古くなった計画を消す
	 *
	 * @param string $before この日時（UTC）より前に作られたplanning / planned。
	 * @return int 消した行数。
	 */
	public static function delete_stale_plans( string $before ): int {
		global $wpdb;

		$deleted = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}rgrl_media_ops WHERE status IN (%s, %s) AND created_at < %s",
				self::ST_PLANNING,
				self::ST_PLANNED,
				$before
			)
		);

		return false === $deleted ? 0 : (int) $deleted;
	}

	/**
	 * 隔離領域にファイルがあり、まだ元に戻せる見込みのある操作の数
	 *
	 * 隔離を空にすると戻せなくなる操作の件数として、確認ダイアログに出す。
	 */
	public static function count_undoable_in_quarantine(): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT q.op_id) FROM {$wpdb->prefix}rgrl_quarantine q
				INNER JOIN {$wpdb->prefix}rgrl_media_ops o ON o.op_id = q.op_id
				WHERE q.status = %s AND o.status = %s AND o.op_type <> %s",
				Quarantine::ST_QUARANTINED,
				self::ST_COMPLETE,
				self::TYPE_UNDO
			)
		);
	}
}
