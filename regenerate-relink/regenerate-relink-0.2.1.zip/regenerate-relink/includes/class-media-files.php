<?php
/**
 * メディア操作のファイル操作
 *
 * 差し替え・名前変更・取り消し（FR-11〜13）が行うファイルの複製・移動・
 * 隔離・復元を1か所にまとめる。パスはuploads相対で受け取り、実パスで
 * uploads配下にあることを確かめてから触る（NFR-1.4 / NFR-5.5。検証は
 * Cleanupと同じ関数）。既存のファイルを上書きする操作は持たない。
 *
 * 隔離はCleanupと同じrgrl_quarantineの行と隔離ディレクトリに乗せ、
 * op_id列に操作を記録する。行を先に書いてからファイルを動かすので、
 * 途中で止まっても行から元の場所を辿れる（NFR-1.6）。
 *
 * @package Regenerate_Relink
 */

namespace Regenerate_Relink;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * メディア操作のファイル操作
 */
class Media_Files {

	/**
	 * ファイル名に使う乱数の文字列（英小文字と数字）
	 *
	 * wp_generate_password()はrandom_passwordフィルタで中身が変わりうるため使わない
	 * （区切りの文字が入るとパスが壊れ、形の確認も通らなくなる）。
	 *
	 * @param int $bytes 乱数のバイト数（文字数はその2倍）。
	 * @return string|null 作れなければnull。
	 */
	public static function token( int $bytes ): ?string {
		try {
			return bin2hex( random_bytes( $bytes ) );
		} catch ( \Exception $e ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 乱数を作れずに操作を止める理由を握りつぶさないため
			error_log( 'Regenerate & Relink: could not generate a random file name. ' . $e->getMessage() );

			return null;
		}
	}

	/**
	 * uploads相対パスを組み立てる
	 *
	 * @param string $subdir 年月ディレクトリ（なければ空文字）。
	 * @param string $name   ファイル名。
	 */
	public static function rel_path( string $subdir, string $name ): string {
		return '' === $subdir ? $name : $subdir . '/' . $name;
	}

	/**
	 * 実在するファイルの検証済み絶対パス
	 *
	 * @param string $rel_path uploads相対パス。
	 * @return string|null 検証に通らない・ファイルがなければnull。
	 */
	public static function abs_existing( string $rel_path ): ?string {
		$path = Cleanup::resolve_uploads_path( $rel_path );

		return null !== $path && is_file( $path ) ? $path : null;
	}

	/**
	 * ファイルがあるか
	 *
	 * @param string $rel_path uploads相対パス。
	 */
	public static function exists( string $rel_path ): bool {
		return null !== self::abs_existing( $rel_path );
	}

	/**
	 * パスが使えないか（何かがある、または検証に通らない）
	 *
	 * @param string $rel_path uploads相対パス。
	 */
	public static function occupied( string $rel_path ): bool {
		$path = Cleanup::resolve_restore_path( $rel_path );

		return null === $path || file_exists( $path );
	}

	/**
	 * パスに何かがあるか（親ディレクトリを作らずに確かめる）
	 *
	 * occupied()は検証のために親ディレクトリを作る。フォルダの変更のプレビューは
	 * 何も作ってはならない（FR-6.1）ので、移動先の衝突はこちらで確かめる。
	 * パスの検証はしない。先にfolder_inside_uploads()を通したフォルダに使うこと。
	 *
	 * @param string $rel_path uploads相対パス。
	 */
	public static function taken( string $rel_path ): bool {
		$path = trailingslashit( wp_get_upload_dir()['basedir'] ) . $rel_path;

		return file_exists( $path ) || is_link( $path );
	}

	/**
	 * フォルダが、実パスでuploadsの中に解決されるか（NFR-1.4。FR-12.6）
	 *
	 * まだないフォルダは、存在する最も深い親ディレクトリの実パスで確かめる。
	 * 途中にuploadsの外を指すシンボリックリンクや、同名のファイルがあればfalse。
	 * 何も作らない。
	 *
	 * @param string $subdir uploadsからの相対パス（uploads直下なら空文字）。
	 */
	public static function folder_inside_uploads( string $subdir ): bool {
		$root    = (string) wp_get_upload_dir()['basedir'];
		$basedir = realpath( $root );

		if ( false === $basedir ) {
			return false;
		}

		if ( '' === $subdir ) {
			return true;
		}

		if ( ! Cleanup::rel_path_shape_ok( $subdir ) ) {
			return false;
		}

		$path = trailingslashit( $root ) . $subdir;

		while ( ! file_exists( $path ) && ! is_link( $path ) ) {
			$parent = dirname( $path );

			if ( $parent === $path ) {
				return false;
			}

			$path = $parent;
		}

		$real = realpath( $path );

		if ( false === $real || ! is_dir( $real ) ) {
			return false;
		}

		return $real === $basedir || 0 === strpos( $real, $basedir . DIRECTORY_SEPARATOR );
	}

	/**
	 * 移動先のフォルダを用意する（なければ作る。FR-12.6）
	 *
	 * 作る前に、uploadsの中に解決されることを確かめる（外へは掘らない）。
	 * 作ったあとにも確かめる。作ったフォルダは、あとで空になっても消さない。
	 *
	 * @param string $subdir uploadsからの相対パス（uploads直下なら空文字）。
	 * @return bool 使える状態になったか。
	 */
	public static function ensure_folder( string $subdir ): bool {
		if ( ! self::folder_inside_uploads( $subdir ) ) {
			return false;
		}

		if ( '' === $subdir ) {
			return true;
		}

		$path = trailingslashit( (string) wp_get_upload_dir()['basedir'] ) . $subdir;

		if ( ! is_dir( $path ) && ! wp_mkdir_p( $path ) ) {
			return false;
		}

		return self::folder_inside_uploads( $subdir );
	}

	/**
	 * ファイルを新しい名前で複製する（元は残す）
	 *
	 * @param string $from_rel 複製元のuploads相対パス。
	 * @param string $to_rel   複製先のuploads相対パス（存在しないこと）。
	 * @return bool 複製できたか。
	 */
	public static function copy( string $from_rel, string $to_rel ): bool {
		$from = self::abs_existing( $from_rel );
		$to   = Cleanup::resolve_restore_path( $to_rel );

		if ( null === $from || null === $to || file_exists( $to ) ) {
			return false;
		}

		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged -- 失敗は戻り値で検出する。WP_Filesystemの資格情報要求はRESTの文脈では使えない。
		if ( ! @copy( $from, $to ) ) {
			if ( is_file( $to ) ) {
				wp_delete_file( $to );
			}

			return false;
		}

		return true;
	}

	/**
	 * 作業用ディレクトリのファイルをuploadsへ置く
	 *
	 * @param string $from_abs 作業用ディレクトリ内の絶対パス。
	 * @param string $to_rel   置き先のuploads相対パス（存在しないこと）。
	 * @return bool 置けたか。
	 */
	public static function move_into_uploads( string $from_abs, string $to_rel ): bool {
		$to = Cleanup::resolve_restore_path( $to_rel );

		if ( null === $to || file_exists( $to ) || ! self::inside_quarantine( $from_abs ) || ! is_file( $from_abs ) ) {
			return false;
		}

		return self::move( $from_abs, $to );
	}

	/**
	 * 自分が作ったファイルを消す（段1の巻き戻し専用）
	 *
	 * @param string $rel_path uploads相対パス。
	 * @return bool 消えている（初めからない場合もtrue）。
	 */
	public static function delete_own( string $rel_path ): bool {
		$path = self::abs_existing( $rel_path );

		if ( null === $path ) {
			return true;
		}

		wp_delete_file( $path );

		return ! is_file( $path );
	}

	/**
	 * ファイルを隔離する
	 *
	 * @param int    $attachment_id 添付ID。
	 * @param string $rel_path      uploads相対パス。
	 * @param string $reason        Quarantine::REASON_REPLACED / RENAMED / UNDONE。
	 * @param int    $op_id         操作ID。
	 * @return int|null 行ID。隔離できなければnull（ファイルは元の場所に残る）。
	 */
	public static function quarantine( int $attachment_id, string $rel_path, string $reason, int $op_id ): ?int {
		$path  = self::abs_existing( $rel_path );
		$qdir  = Quarantine::ensure_dir();
		$token = self::token( 4 );

		if ( null === $path || null === $qdir || null === $token ) {
			return null;
		}

		$stored  = sprintf( 'op%d-%s-%s', $op_id, $token, wp_basename( $rel_path ) );
		$file_id = Quarantine::add_row(
			array(
				'attachment_id'  => $attachment_id,
				'rel_path'       => $rel_path,
				'bytes'          => (int) filesize( $path ),
				'status'         => Quarantine::ST_QUARANTINED,
				'reason'         => $reason,
				'stored_name'    => $stored,
				'quarantined_at' => gmdate( 'Y-m-d H:i:s' ),
				'op_id'          => $op_id,
			)
		);

		if ( $file_id < 1 ) {
			return null;
		}

		if ( ! self::move( $path, trailingslashit( $qdir ) . $stored ) ) {
			Quarantine::delete_row( $file_id );
			return null;
		}

		return $file_id;
	}

	/**
	 * 隔離した行を元の場所へ戻す
	 *
	 * @param int $file_id 行ID（quarantinedであること）。
	 * @return bool 戻せたか。元の場所に何かあれば戻さない。
	 */
	public static function restore( int $file_id ): bool {
		$row  = Quarantine::get_row( $file_id );
		$qdir = Quarantine::dir();

		if ( ! $row || Quarantine::ST_QUARANTINED !== $row->status || null === $qdir || '' === (string) $row->stored_name ) {
			return false;
		}

		$src  = trailingslashit( $qdir ) . (string) $row->stored_name;
		$dest = Cleanup::resolve_restore_path( (string) $row->rel_path );

		if ( ! is_file( $src ) || null === $dest || file_exists( $dest ) ) {
			return false;
		}

		if ( ! self::move( $src, $dest ) ) {
			return false;
		}

		Quarantine::update_row( $file_id, array( 'status' => Quarantine::ST_RESTORED ) );

		return true;
	}

	/**
	 * restore()を巻き戻す（もう一度隔離領域へ入れる）
	 *
	 * @param int $file_id 行ID（restoredであること）。
	 * @return bool 戻せたか。
	 */
	public static function requarantine( int $file_id ): bool {
		$row  = Quarantine::get_row( $file_id );
		$qdir = Quarantine::dir();

		if ( ! $row || Quarantine::ST_RESTORED !== $row->status || null === $qdir ) {
			return false;
		}

		$src  = self::abs_existing( (string) $row->rel_path );
		$dest = trailingslashit( $qdir ) . (string) $row->stored_name;

		if ( null === $src || file_exists( $dest ) || ! self::move( $src, $dest ) ) {
			return false;
		}

		Quarantine::update_row( $file_id, array( 'status' => Quarantine::ST_QUARANTINED ) );

		return true;
	}

	/**
	 * quarantine()を取り消す（段1の巻き戻し用）
	 *
	 * 行を書いたあと、ファイルを動かす前に止まった場合も扱う。
	 *
	 * @param object $row 行（quarantined）。
	 * @return bool 元の場所にファイルがある状態に戻せたか。
	 */
	public static function return_row( $row ): bool {
		$qdir = Quarantine::dir();
		$src  = null === $qdir ? '' : trailingslashit( $qdir ) . (string) $row->stored_name;

		if ( '' !== $src && is_file( $src ) ) {
			return self::restore( (int) $row->file_id );
		}

		if ( self::exists( (string) $row->rel_path ) ) {
			Quarantine::delete_row( (int) $row->file_id );
			return true;
		}

		return false;
	}

	/**
	 * 隔離中で、隔離領域にファイルが残っているか
	 *
	 * @param int $file_id 行ID。
	 */
	public static function is_quarantined( int $file_id ): bool {
		$row  = Quarantine::get_row( $file_id );
		$qdir = Quarantine::dir();

		return $row
			&& Quarantine::ST_QUARANTINED === $row->status
			&& null !== $qdir
			&& '' !== (string) $row->stored_name
			&& is_file( trailingslashit( $qdir ) . (string) $row->stored_name );
	}

	/**
	 * 操作の作業用ディレクトリ（差し替えの生成先）
	 *
	 * @param int $op_id 操作ID。
	 * @return string|null 絶対パス。作れなければnull。
	 */
	public static function staging_dir( int $op_id ): ?string {
		$qdir = Quarantine::ensure_dir();

		if ( null === $qdir ) {
			return null;
		}

		$dir = trailingslashit( $qdir ) . 'staging-' . $op_id;

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return null;
		}

		return $dir;
	}

	/**
	 * 一時アップロードを作業用ディレクトリへ移す
	 *
	 * @param string $from_abs 一時アップロードの絶対パス（隔離ディレクトリの下）。
	 * @param string $to_abs   作業用ディレクトリ内の絶対パス（存在しないこと）。
	 * @return bool 移せたか。
	 */
	public static function stage_upload( string $from_abs, string $to_abs ): bool {
		if ( ! self::inside_quarantine( $from_abs ) || ! self::inside_quarantine( $to_abs ) || ! is_file( $from_abs ) || file_exists( $to_abs ) ) {
			return false;
		}

		return self::move( $from_abs, $to_abs );
	}

	/**
	 * 作業用ディレクトリが残っている操作のID
	 *
	 * @return int[] 操作ID。
	 */
	public static function staging_op_ids(): array {
		$qdir = Quarantine::dir();

		if ( null === $qdir ) {
			return array();
		}

		$ids = array();

		foreach ( (array) glob( trailingslashit( $qdir ) . 'staging-*', GLOB_ONLYDIR ) as $dir ) {
			if ( is_string( $dir ) && ! is_link( $dir ) && preg_match( '/^staging-([1-9][0-9]*)$/', wp_basename( $dir ), $matches ) ) {
				$ids[] = (int) $matches[1];
			}
		}

		return $ids;
	}

	/**
	 * 操作の作業用ディレクトリを中身ごと消す
	 *
	 * 作業用ディレクトリが残るのは、段1が途中で止まったときと、消せなかったとき。残った
	 * ものは、次のstep()が巻き戻してここを呼ぶか、操作が終わっていれば日次の掃除
	 * （Media_Operation::purge_stale()）で、またはアンインストールで消える。
	 * 消すのは通常のファイルだけで、先頭がドットのファイルも含める。
	 *
	 * @param int $op_id 操作ID。
	 */
	public static function remove_staging( int $op_id ): void {
		$qdir = Quarantine::dir();

		if ( null === $qdir ) {
			return;
		}

		$dir = trailingslashit( $qdir ) . 'staging-' . $op_id;

		if ( ! is_dir( $dir ) ) {
			return;
		}

		$entries = scandir( $dir );

		foreach ( is_array( $entries ) ? $entries : array() as $entry ) {
			$path = trailingslashit( $dir ) . $entry;

			if ( is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}

		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- 自分が作ったディレクトリの後始末。消せなかったときは、次のstep()か日次の掃除がもう一度ここを呼ぶか、アンインストールで消える。
		@rmdir( $dir );
	}

	/**
	 * パスが隔離ディレクトリの下にあるか（親ディレクトリを実パスで確かめる）
	 *
	 * @param string $path 絶対パス。
	 */
	private static function inside_quarantine( string $path ): bool {
		$qdir = Quarantine::dir();
		$base = null === $qdir ? false : realpath( $qdir );
		$dir  = realpath( dirname( $path ) );

		return false !== $base && false !== $dir && 0 === strpos( $dir . DIRECTORY_SEPARATOR, $base . DIRECTORY_SEPARATOR );
	}

	/**
	 * ファイルを移動する
	 *
	 * @param string $from 絶対パス。
	 * @param string $to   絶対パス。
	 * @return bool 移せたか。失敗時は元が残る。
	 */
	private static function move( string $from, string $to ): bool {
		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.rename_rename -- 失敗は戻り値で検出する。WP_Filesystemの資格情報要求はRESTの文脈では使えない。
		if ( @rename( $from, $to ) ) {
			return true;
		}

		// uploadsが複数デバイスにまたがる構成へのフォールバック
		// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink -- 上と同じ。
		if ( @copy( $from, $to ) && @unlink( $from ) ) {
			return true;
		}

		// 元は残っている。中途半端な複製だけ消す
		if ( is_file( $to ) && is_file( $from ) ) {
			wp_delete_file( $to );
		}

		return false;
	}
}
