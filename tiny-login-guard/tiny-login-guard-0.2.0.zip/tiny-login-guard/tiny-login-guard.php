<?php
/**
 * Plugin Name:       Tiny Login Guard
 * Description:       ログインの試行回数の制限、XML-RPCの停止、ユーザー名の非公開、アプリケーションパスワードの無効化で、ログインまわりを小さく守ります。
 * Version:           0.2.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tiny-login-guard
 * Update URI:        https://yuiami.jp/wp-plugins/tiny-login-guard
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TINY_LOGIN_GUARD_VERSION', '0.2.0' );
define( 'TINY_LOGIN_GUARD_FILE', __FILE__ );
define( 'TINY_LOGIN_GUARD_DIR', plugin_dir_path( __FILE__ ) );

/*
 * 機能ごとに、フィルタで切れるようにしている（設定画面は持たない）。
 * tiny_login_guard_limit_login / tiny_login_guard_block_xmlrpc /
 * tiny_login_guard_hide_usernames / tiny_login_guard_disable_application_passwords
 */
require_once TINY_LOGIN_GUARD_DIR . 'includes/limit-login.php';
require_once TINY_LOGIN_GUARD_DIR . 'includes/xmlrpc.php';
require_once TINY_LOGIN_GUARD_DIR . 'includes/hide-usernames.php';
require_once TINY_LOGIN_GUARD_DIR . 'includes/application-passwords.php';

// 自己ホストの更新チェック。定期の更新チェックはwp-cronで動くので、is_admin()の中に入れない。
require_once TINY_LOGIN_GUARD_DIR . 'includes/update-checker.php';
