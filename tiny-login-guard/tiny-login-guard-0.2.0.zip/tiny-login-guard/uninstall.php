<?php
/**
 * アンインストール時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * 後始末が必要になったら足す。**足し忘れが残骸になる**ので、
 * オプション・トランジェント・cron・カスタムテーブルを増やしたら
 * 同じコミットでここも更新すること。
 *
 * ログインの試行回数の制限が使うトランジェント（tiny_login_guard_failures_* / tiny_login_guard_lockout_*）は
 * 消さない。どれも15分で期限が切れ、期限切れのトランジェントはWordPressが毎日消すため。
 * オプションは作らない。
 */

// 更新チェックのキャッシュ（サイトのトランジェント）。
delete_site_transient( 'tiny_login_guard_update_info' );
