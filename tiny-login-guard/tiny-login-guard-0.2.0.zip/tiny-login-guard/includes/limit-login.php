<?php
/**
 * ログインの試行回数の制限
 *
 * 同じIPアドレスからログインに続けて失敗したら、一定時間そのIPアドレスからのログインを受け付けない。
 * 数えるのはこのサイトでの失敗だけで、外部のIPリストは使わない。
 * ログイン画面そのものは誰にでも表示し、止めるのは送信だけ。cookieでログイン済みの人には影響しない。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 何回続けて失敗したらロックするか。
define( 'TINY_LOGIN_GUARD_MAX_FAILURES', 5 );

// ロックする時間（秒）。失敗を覚えておく時間も同じで、最後の失敗からこの時間が過ぎると数え直す。
define( 'TINY_LOGIN_GUARD_LOCKOUT_DURATION', 15 * MINUTE_IN_SECONDS );

// ロック中に返すエラーのコード。
define( 'TINY_LOGIN_GUARD_LOCKED', 'tiny_login_guard_locked' );

/**
 * ログインの試行回数の制限を使うか
 *
 * @return bool
 */
function tiny_login_guard_limit_login_enabled() {
	/**
	 * ログインの試行回数の制限を使うか。
	 *
	 * @param bool $enabled 既定はtrue。
	 */
	return (bool) apply_filters( 'tiny_login_guard_limit_login', true );
}

/**
 * 失敗を数える単位（IPアドレス）を返す
 *
 * IPv6は/64ごとにまとめる。1つの回線に/64が割り当てられるのが普通で、アドレスを1つずつ数えると、
 * 同じ回線のままアドレスを切り替えるだけで制限をすり抜けられるため。
 *
 * @return string IPアドレス。分からなければ空文字（そのときは制限しない）。
 */
function tiny_login_guard_client_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

	/**
	 * ログインの試行を数えるIPアドレス。
	 *
	 * 既定はREMOTE_ADDR。X-Forwarded-Forなどのヘッダは偽装できるので見ない。
	 * CDNや中継を挟むサイトでは、全員が中継のIPアドレスに見えてまとめてロックされるので、
	 * このフィルタで本来のIPアドレスを返す。
	 *
	 * @param string $ip REMOTE_ADDRの値。
	 */
	$ip = (string) apply_filters( 'tiny_login_guard_client_ip', $ip );

	if ( false === filter_var( $ip, FILTER_VALIDATE_IP ) ) {
		return '';
	}

	if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
		return $ip;
	}

	$packed = inet_pton( $ip );

	// IPv4をIPv6の形で受け取るサーバーがある（::ffff:192.0.2.1）。/64でまとめると全員が同じ単位になるので、IPv4に戻す。
	if ( 0 === strpos( $packed, str_repeat( "\0", 10 ) . "\xff\xff" ) ) {
		return inet_ntop( substr( $packed, 12 ) );
	}

	return inet_ntop( substr( $packed, 0, 8 ) . str_repeat( "\0", 8 ) ) . '/64';
}

/**
 * トランジェントの名前を返す
 *
 * @param string $type 'failures'（失敗の回数）か'lockout'（ロックが解ける時刻）。
 * @param string $key  tiny_login_guard_client_key()の値。
 * @return string
 */
function tiny_login_guard_transient_name( $type, $key ) {
	return 'tiny_login_guard_' . $type . '_' . md5( $key );
}

/**
 * ロックが解ける時刻を返す
 *
 * @param string $key tiny_login_guard_client_key()の値。
 * @return int Unix時刻。ロックしていなければ0。
 */
function tiny_login_guard_locked_until( $key ) {
	$until = (int) get_transient( tiny_login_guard_transient_name( 'lockout', $key ) );

	return $until > time() ? $until : 0;
}

/**
 * ロックが解けるまでの分数を返す
 *
 * @param int $until ロックが解ける時刻。
 * @return int 1以上。
 */
function tiny_login_guard_minutes_left( $until ) {
	return max( 1, (int) ceil( ( $until - time() ) / MINUTE_IN_SECONDS ) );
}

/**
 * このリクエストでロックしたかを記録して返す
 *
 * ロックするのは失敗を数えたあとなので、そのリクエストのエラーはWordPressの「パスワードが違います」のまま。
 * ログイン画面にロックしたことを書き足すために覚えておく。
 *
 * @param bool|null $locked trueで記録する。nullなら読むだけ。
 * @return bool
 */
function tiny_login_guard_just_locked( $locked = null ) {
	static $just_locked = false;

	if ( null !== $locked ) {
		$just_locked = (bool) $locked;
	}

	return $just_locked;
}

/**
 * ロック中ならエラーを返す（パスワードを照合する前）
 *
 * ロック中の総当たりで、パスワードの照合（重い計算）をさせないため。
 * ユーザー名が見つかったときだけ呼ばれる。
 *
 * @param WP_User|WP_Error $user ユーザー名から見つかったユーザー。
 * @return WP_User|WP_Error
 */
function tiny_login_guard_check_before_password( $user ) {
	return tiny_login_guard_lockout_error_or( $user );
}
add_filter( 'wp_authenticate_user', 'tiny_login_guard_check_before_password', 99999 );

/**
 * ロック中ならエラーを返す（認証の最終結果）
 *
 * 存在しないユーザー名や、他のプラグインの認証で通った場合も含めて、ロック中は通さない。
 *
 * @param WP_User|WP_Error|null $user 認証の結果。
 * @return WP_User|WP_Error|null
 */
function tiny_login_guard_check_result( $user ) {
	return tiny_login_guard_lockout_error_or( $user );
}
add_filter( 'authenticate', 'tiny_login_guard_check_result', 99999 );

/**
 * ロック中ならロックのエラーを、そうでなければ受け取った値をそのまま返す
 *
 * @param mixed $user 認証の途中の値。
 * @return mixed
 */
function tiny_login_guard_lockout_error_or( $user ) {
	if ( ! tiny_login_guard_limit_login_enabled() ) {
		return $user;
	}

	$key = tiny_login_guard_client_key();
	if ( '' === $key ) {
		return $user;
	}

	$until = tiny_login_guard_locked_until( $key );
	if ( ! $until ) {
		return $user;
	}

	return new WP_Error(
		TINY_LOGIN_GUARD_LOCKED,
		sprintf(
			'<strong>エラー:</strong> ログインの失敗が続いたため、ログインを一時的に止めています。%d分ほど待ってから、もう一度お試しください。',
			tiny_login_guard_minutes_left( $until )
		)
	);
}

/**
 * ログインの失敗を数え、続いたらロックする
 *
 * @param string        $username 入力されたユーザー名。
 * @param WP_Error|null $error    失敗の理由。
 */
function tiny_login_guard_record_failure( $username, $error = null ) {
	if ( ! tiny_login_guard_limit_login_enabled() ) {
		return;
	}

	// ロック中の試行は数えない（ロックを延ばさない）。
	if ( $error instanceof WP_Error && in_array( TINY_LOGIN_GUARD_LOCKED, $error->get_error_codes(), true ) ) {
		return;
	}

	$key = tiny_login_guard_client_key();
	if ( '' === $key || tiny_login_guard_locked_until( $key ) ) {
		return;
	}

	$name     = tiny_login_guard_transient_name( 'failures', $key );
	$failures = (int) get_transient( $name ) + 1;

	if ( $failures < TINY_LOGIN_GUARD_MAX_FAILURES ) {
		set_transient( $name, $failures, TINY_LOGIN_GUARD_LOCKOUT_DURATION );
		return;
	}

	set_transient(
		tiny_login_guard_transient_name( 'lockout', $key ),
		time() + TINY_LOGIN_GUARD_LOCKOUT_DURATION,
		TINY_LOGIN_GUARD_LOCKOUT_DURATION
	);
	delete_transient( $name );
	tiny_login_guard_just_locked( true );
}
add_action( 'wp_login_failed', 'tiny_login_guard_record_failure', 10, 2 );

/**
 * ログインに成功したら、失敗の回数を数え直す
 *
 * 2段階認証のプラグイン（two-factor）は、パスワードが通ったあとのwp_loginで2段階目の画面を出して処理を終えるので、
 * それより先に動くよう優先度を1にしている。
 */
function tiny_login_guard_clear_failures() {
	$key = tiny_login_guard_client_key();
	if ( '' === $key ) {
		return;
	}

	delete_transient( tiny_login_guard_transient_name( 'failures', $key ) );
}
add_action( 'wp_login', 'tiny_login_guard_clear_failures', 1 );

/**
 * ログイン画面のエラーに、あと何回でロックするか（またはロックしたこと）を書き足す
 *
 * 利用者が、知らないうちにロックされて戸惑わないようにするため。
 *
 * @param string $errors ログイン画面に出すエラーのHTML。
 * @return string
 */
function tiny_login_guard_login_errors( $errors ) {
	if ( ! tiny_login_guard_limit_login_enabled() ) {
		return $errors;
	}

	$key = tiny_login_guard_client_key();
	if ( '' === $key ) {
		return $errors;
	}

	$until = tiny_login_guard_locked_until( $key );

	if ( tiny_login_guard_just_locked() && $until ) {
		return $errors . '<br>' . sprintf(
			'ログインの失敗が続いたため、%d分間ログインできなくなりました。',
			tiny_login_guard_minutes_left( $until )
		);
	}

	// ロック中のエラーには、すでに待つ時間を書いている。
	if ( $until ) {
		return $errors;
	}

	$failures = (int) get_transient( tiny_login_guard_transient_name( 'failures', $key ) );
	if ( $failures < 1 ) {
		return $errors;
	}

	return $errors . '<br>' . sprintf(
		'あと%d回失敗すると、%d分間ログインできなくなります。',
		TINY_LOGIN_GUARD_MAX_FAILURES - $failures,
		(int) ( TINY_LOGIN_GUARD_LOCKOUT_DURATION / MINUTE_IN_SECONDS )
	);
}
add_filter( 'login_errors', 'tiny_login_guard_login_errors' );

/**
 * ロックのエラーでも、ログイン画面のフォームを揺らす
 *
 * @param string[] $codes フォームを揺らすエラーのコード。
 * @return string[]
 */
function tiny_login_guard_shake_error_codes( $codes ) {
	$codes[] = TINY_LOGIN_GUARD_LOCKED;

	return $codes;
}
add_filter( 'shake_error_codes', 'tiny_login_guard_shake_error_codes' );
