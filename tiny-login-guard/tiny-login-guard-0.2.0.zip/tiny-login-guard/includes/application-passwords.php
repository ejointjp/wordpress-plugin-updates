<?php
/**
 * アプリケーションパスワードの無効化
 *
 * アプリケーションパスワードは、2段階認証を通らずにREST APIからログインできる入口になる。
 * 使っていないサイトでは止めておく。
 * 止めると、発行済みのアプリケーションパスワードも使えなくなる。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * アプリケーションパスワードを使えなくする
 *
 * @param bool $available アプリケーションパスワードを使えるか。
 * @return bool
 */
function tiny_login_guard_disable_application_passwords( $available ) {
	/**
	 * アプリケーションパスワードを無効にするか。
	 *
	 * 外部のサービスやアプリからREST APIでログインさせるサイトでは false を返す。
	 *
	 * @param bool $disable 既定はtrue。
	 */
	if ( ! apply_filters( 'tiny_login_guard_disable_application_passwords', true ) ) {
		return $available;
	}

	return false;
}
add_filter( 'wp_is_application_passwords_available', 'tiny_login_guard_disable_application_passwords' );
