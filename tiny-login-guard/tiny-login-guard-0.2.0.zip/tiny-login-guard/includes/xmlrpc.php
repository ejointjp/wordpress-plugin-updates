<?php
/**
 * XML-RPCの停止
 *
 * xmlrpc.phpは1回のリクエストで数百個のパスワードを試せるので、総当たりの入口になる。
 * Jetpackや古い投稿アプリを使わないサイトでは要らないので、丸ごと拒否する。
 * ピンバックを受け取りたいサイトは、フィルタtiny_login_guard_allow_pingbackで、ピンバックの受信だけを残せる。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * xmlrpc.phpへのリクエストを拒否し、ピンバックの案内を消す
 *
 * テーマのfunctions.phpで足したフィルタも効くように、initで判断する。
 */
function tiny_login_guard_block_xmlrpc() {
	/**
	 * xmlrpc.phpを拒否するか。
	 *
	 * XML-RPCを使うサイト（Jetpack、XML-RPCで投稿するアプリなど）では false を返す。
	 *
	 * @param bool $block 既定はtrue。
	 */
	if ( ! apply_filters( 'tiny_login_guard_block_xmlrpc', true ) ) {
		return;
	}

	// 投稿アプリなどに向けた案内（RSD）は、ピンバックだけを残すときも要らない。
	remove_action( 'wp_head', 'rsd_link' );

	/**
	 * ピンバックの受信だけは受け付けるか。
	 *
	 * true にすると、xmlrpc.phpはピンバックの受信（pingback.ping）にだけ答える。
	 * パスワードを使う操作と、まとめて呼び出すsystem.multicallは止めたまま。
	 * ピンバックはスパムの入口になり、受け取るたびにリンク元のページを取りに行くので、既定では止める。
	 *
	 * @param bool $allow 既定はfalse。
	 */
	if ( apply_filters( 'tiny_login_guard_allow_pingback', false ) ) {
		add_filter( 'wp_xmlrpc_server_class', 'tiny_login_guard_pingback_server_class' );
		return;
	}

	if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
		status_header( 403 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=UTF-8' );
		echo 'XML-RPC is disabled on this site.';
		exit;
	}

	// 拒否する入口を、自分から案内しない。
	add_filter( 'wp_headers', 'tiny_login_guard_remove_pingback_header' );
}
add_action( 'init', 'tiny_login_guard_block_xmlrpc', 0 );

/**
 * xmlrpc.phpのサーバーを、ピンバックの受信だけに答えるものに差し替える
 *
 * このフィルタはxmlrpc.phpがclass-wp-xmlrpc-server.phpを読み込んだあとに呼ばれるので、ここで継承したクラスを読み込む。
 *
 * @return string サーバーのクラス名。
 */
function tiny_login_guard_pingback_server_class() {
	require_once TINY_LOGIN_GUARD_DIR . 'includes/class-tiny-login-guard-pingback-server.php';

	return 'Tiny_Login_Guard_Pingback_Server';
}

/**
 * レスポンスヘッダからX-Pingbackを消す
 *
 * @param array $headers レスポンスヘッダ。
 * @return array
 */
function tiny_login_guard_remove_pingback_header( $headers ) {
	unset( $headers['X-Pingback'] );

	return $headers;
}
