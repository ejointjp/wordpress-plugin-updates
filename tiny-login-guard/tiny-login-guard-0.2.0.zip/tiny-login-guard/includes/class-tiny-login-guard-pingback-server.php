<?php
/**
 * ピンバックの受信だけに答えるXML-RPCのサーバー
 *
 * フィルタtiny_login_guard_allow_pingbackをtrueにしたサイトで、xmlrpc.phpのサーバーをこれに差し替える。
 * xmlrpc.phpがclass-wp-xmlrpc-server.phpを読み込んだあと（フィルタwp_xmlrpc_server_class）にだけ読み込むこと。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ピンバックの受信（pingback.ping）だけに答える
 */
class Tiny_Login_Guard_Pingback_Server extends wp_xmlrpc_server {

	/**
	 * 答えるメソッドをpingback.pingだけにする
	 *
	 * パスワードを使う操作（wp.* など）は、ここで外れる。
	 */
	public function __construct() {
		parent::__construct();

		$this->methods = array_intersect_key( $this->methods, array( 'pingback.ping' => true ) );
	}

	/**
	 * system.multicall / system.listMethods / system.getCapabilitiesを登録しない
	 *
	 * IXR_Serverは、xmlrpc_methodsフィルタを通ったあとにこの3つを足す。system.multicallは1回のリクエストで
	 * 何百回も呼び出せるので、ピンバックだけにしても、まとめて送りつけられる入口になる。
	 */
	public function setCallbacks() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid -- 親のIXR_Serverのメソッドを上書きするため
	}
}
