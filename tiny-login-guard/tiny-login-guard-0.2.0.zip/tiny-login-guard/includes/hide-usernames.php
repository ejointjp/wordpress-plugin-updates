<?php
/**
 * ユーザー名の非公開
 *
 * 総当たりする側は、まずユーザー名を集める。WordPressは次の場所から、URL用の名前（user_nicename）を誰にでも見せる。
 * URL用の名前は、変えていなければログイン名と同じなので、ログイン名を教えているのと同じになる。
 *
 * - REST APIのユーザー一覧（/wp-json/wp/v2/users）
 * - ?author=N（著者アーカイブのURLへリダイレクトされ、その中に名前が出る）
 * - コアのサイトマップのユーザー（wp-sitemap-users-1.xml）
 * - oEmbedの著者のURL
 *
 * 著者アーカイブを公開しているサイトでは、そのURL自体に名前が出るので、この対策の意味は薄い。
 *
 * @package tiny-login-guard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ユーザー名を隠すか
 *
 * @return bool
 */
function tiny_login_guard_hide_usernames_enabled() {
	/**
	 * ログインしていない人にユーザー名を見せないようにするか。
	 *
	 * 著者アーカイブを公開していて、REST APIのユーザー一覧などを外部に使わせたいサイトでは false を返す。
	 *
	 * @param bool $hide 既定はtrue。
	 */
	return (bool) apply_filters( 'tiny_login_guard_hide_usernames', true );
}

/**
 * ログインしていない人には、REST APIのユーザーのエンドポイントを出さない
 *
 * ブロックエディターの著者の選択などはログインした状態で使うので、影響しない。
 *
 * @param array $endpoints ルートごとのエンドポイント。
 * @return array
 */
function tiny_login_guard_hide_rest_users( $endpoints ) {
	if ( is_user_logged_in() || ! tiny_login_guard_hide_usernames_enabled() ) {
		return $endpoints;
	}

	foreach ( array_keys( $endpoints ) as $route ) {
		if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
			unset( $endpoints[ $route ] );
		}
	}

	return $endpoints;
}
add_filter( 'rest_endpoints', 'tiny_login_guard_hide_rest_users' );

/**
 * ログインしていない人の?author=Nを、トップページへ転送する
 *
 * WordPressの正規化のリダイレクト（優先度10）より先に動かす。
 * パーマリンク設定が「基本」のサイトでは、これが著者アーカイブの唯一のURLなので、
 * 著者アーカイブを使うならフィルタtiny_login_guard_hide_usernamesで切る。
 */
function tiny_login_guard_block_author_query() {
	global $wp;

	if ( empty( $wp->query_vars['author'] ) || is_user_logged_in() || ! tiny_login_guard_hide_usernames_enabled() ) {
		return;
	}

	wp_safe_redirect( home_url( '/' ) );
	exit;
}
add_action( 'template_redirect', 'tiny_login_guard_block_author_query', 1 );

/**
 * コアのサイトマップから、ユーザーのサイトマップを外す
 *
 * サイトマップは検索エンジン向けにログインの有無で変えないものなので、ログインしていても外す。
 *
 * @param WP_Sitemaps_Provider|false $provider サイトマップのプロバイダ。
 * @param string                     $name     プロバイダの名前。
 * @return WP_Sitemaps_Provider|false
 */
function tiny_login_guard_remove_users_sitemap( $provider, $name ) {
	if ( 'users' === $name && tiny_login_guard_hide_usernames_enabled() ) {
		return false;
	}

	return $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'tiny_login_guard_remove_users_sitemap', 10, 2 );

/**
 * oEmbedの応答から著者の名前とURLを外す
 *
 * 埋め込み先にキャッシュされるので、ログインの有無で変えない。
 *
 * @param array $data oEmbedの応答。
 * @return array
 */
function tiny_login_guard_remove_oembed_author( $data ) {
	if ( tiny_login_guard_hide_usernames_enabled() ) {
		unset( $data['author_name'], $data['author_url'] );
	}

	return $data;
}
add_filter( 'oembed_response_data', 'tiny_login_guard_remove_oembed_author' );
