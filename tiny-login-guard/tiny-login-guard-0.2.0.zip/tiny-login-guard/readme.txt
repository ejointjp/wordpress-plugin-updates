=== Tiny Login Guard ===
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

ログインまわりの攻撃を、設定なしの小さな対策で防ぐプラグイン。

== Description ==

有効にするだけで、次の対策が働きます。設定画面はありません。

* **ログインの試行回数の制限**: 同じIPアドレスからログインに5回続けて失敗すると、15分間そのIPアドレスからのログインを受け付けません。数えるのはこのサイトでの失敗だけで、外部のIPアドレスのリストは使いません。ログイン画面には、あと何回失敗するとログインできなくなるかを表示します。ログイン画面そのものはいつでも開け、ログイン済みの人にも影響しません
* **XML-RPCの停止**: `xmlrpc.php`へのアクセスを拒否します。ピンバックの受信も止まります
* **ユーザー名の非公開**: ログインしていない人に、REST APIのユーザー一覧と`?author=N`を見せません。サイトマップのユーザーと、oEmbedの著者も出しません
* **アプリケーションパスワードの無効化**: パスワードの代わりにREST APIからログインする仕組みを止めます。発行済みのアプリケーションパスワードも使えなくなります

更新の確認のために、配布元のGitHub（`raw.githubusercontent.com`）から小さなファイル（`info.json`）を取得します。サイトのURLやデータは送りません。

== Frequently Asked Questions ==

= 一部の対策だけ止めたい =

テーマの`functions.php`などで、対策ごとにフィルタで止められます。

* ログインの試行回数の制限: `add_filter( 'tiny_login_guard_limit_login', '__return_false' );`
* XML-RPCの停止（Jetpackや、XML-RPCで投稿するアプリを使うとき）: `add_filter( 'tiny_login_guard_block_xmlrpc', '__return_false' );`
* ピンバックの受信だけは受け付ける: `add_filter( 'tiny_login_guard_allow_pingback', '__return_true' );`（パスワードを使う操作と`system.multicall`は止めたまま）
* ユーザー名の非公開: `add_filter( 'tiny_login_guard_hide_usernames', '__return_false' );`
* アプリケーションパスワードの無効化: `add_filter( 'tiny_login_guard_disable_application_passwords', '__return_false' );`

= CDNや中継（Cloudflareなど）を挟んでいる =

既定では、IPアドレスに`REMOTE_ADDR`だけを使います。中継を挟むと全員が中継のIPアドレスに見え、まとめてロックされます。フィルタ`tiny_login_guard_client_ip`で、本来のIPアドレスを返してください。

== Changelog ==

= 0.2.0 =
* 更新チェックを追加しました。新しい版がプラグイン一覧に通知され、そこから更新できます。
* ピンバックの受信だけを受け付けるフィルタ（tiny_login_guard_allow_pingback）を追加しました。

= 0.1.0 =
* 最初の版。
