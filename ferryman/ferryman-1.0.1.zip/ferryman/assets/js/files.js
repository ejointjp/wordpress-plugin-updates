/* global FerrymanCtrl, jQuery */
/* Ferryman ファイル同期（uploads pull）ドライバ。FerrymanCtrl（ajaxUrl/nonce）を admin.js と共用する。 */
( function ( $ ) {
	'use strict';

	if ( ! window.FerrymanCtrl ) {
		return;
	}

	let running = false;

	/**
	 * 管理画面標準の通知（.notice）を、操作した場所の結果欄に出す（admin.js と同じ）。
	 *
	 * @param {jQuery} $box    通知を入れる要素。中身は置き換える。
	 * @param {string} message 文言（テキストとして入れる）。
	 * @param {string} type    'error' | 'warning' | 'success' | 'info'
	 */
	function showNotice( $box, message, type ) {
		const $notice = $(
			'<div class="notice inline"><p></p></div>'
		).addClass( 'notice-' + type );
		$notice.find( 'p' ).text( message );
		$box.show().empty().append( $notice );
		wp.a11y.speak( message, 'error' === type ? 'assertive' : 'polite' );
	}

	/**
	 * AJAX が失敗したときの文言を組み立てる（admin.js と同じ）。
	 *
	 * @param {string} what  失敗した操作（例: 'スキャン'）。
	 * @param {jqXHR}  jqXHR 失敗した要求。
	 * @return {string} 何が失敗したかと、次にすることを書いた文言。
	 */
	function failMessage( what, jqXHR ) {
		const status = jqXHR ? jqXHR.status : 0;
		if ( ! status ) {
			return (
				what +
				'の通信に失敗しました。サーバーに接続できません。ネットワーク接続を確認して、もう一度お試しください。'
			);
		}
		// admin-ajax はログイン切れを 400、nonce の失効を 403 で返す。
		if ( 400 === status || 403 === status ) {
			return (
				what +
				'の要求が拒否されました（HTTP ' +
				status +
				'）。ログインの有効期限が切れた可能性があります。ページを再読み込みしてから、もう一度お試しください。'
			);
		}
		// 200 番台で失敗扱いになるのは、応答が JSON として読めなかったとき。
		if ( status >= 200 && status < 300 ) {
			return (
				what +
				'の応答を読み取れませんでした。サーバーのPHPエラーログを確認してください。'
			);
		}
		return (
			what +
			'に失敗しました（HTTP ' +
			status +
			'）。時間をおいてもう一度お試しください。続く場合はサーバーのPHPエラーログを確認してください。'
		);
	}

	function ajax( action, data ) {
		return $.post(
			FerrymanCtrl.ajaxUrl,
			$.extend( { action, nonce: FerrymanCtrl.nonce }, data || {} )
		);
	}

	function esc( s ) {
		return String( s ?? '' )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#039;' );
	}

	function humanBytes( n ) {
		n = parseInt( n, 10 ) || 0;
		const units = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
		let i = 0;
		while ( n >= 1024 && i < units.length - 1 ) {
			n /= 1024;
			i++;
		}
		return ( i === 0 ? n : n.toFixed( 1 ) ) + ' ' + units[ i ];
	}

	function log( msg ) {
		const $log = $( '#ferryman-files-log' );
		$log.append( esc( msg ) + '\n' );
		$log.scrollTop( $log[ 0 ].scrollHeight );
	}

	function showProgress( title ) {
		$( '#ferryman-files-progress' ).show();
		$( '#ferryman-files-progress-title' ).text( title );
		$( '#ferryman-files-log' ).text( '' );
	}

	function updateProgress( p ) {
		if ( ! p ) {
			return;
		}
		$( '#ferryman-files-bar-fill' )
			.css( 'width', ( p.percent || 0 ) + '%' )
			.text( ( p.percent || 0 ) + '%' );
		const scope = p.groups_count
			? p.groups_count + ' フォルダ'
			: '全フォルダ';
		const txt =
			'状態: ' +
			p.status +
			' / 対象: ' +
			scope +
			' / ファイル: ' +
			( p.current_file || '-' ) +
			' (' +
			p.files_done +
			'/' +
			p.files_total +
			')' +
			' / ' +
			humanBytes( p.bytes_done ) +
			' / ' +
			humanBytes( p.bytes_total );
		$( '#ferryman-files-progress-text' ).text( txt );
	}

	function summaryHtml( s ) {
		let html = '<strong>差分スキャン結果:</strong>';
		html +=
			'<table class="widefat striped" style="margin-top:8px;max-width:520px;"><tbody>';
		html += row(
			'本番の総ファイル数',
			s.scanned_total.toLocaleString() +
				' 件 (' +
				humanBytes( s.scanned_bytes ) +
				')'
		);
		html += row(
			'転送対象（追加・更新）',
			s.files_total.toLocaleString() +
				' 件 (' +
				humanBytes( s.bytes_total ) +
				')'
		);
		html += row(
			'スキップ（最新で一致）',
			s.skipped.toLocaleString() + ' 件'
		);
		html += '</tbody></table>';
		return html;
	}

	function row( k, v ) {
		return (
			'<tr><th style="width:220px;">' +
			esc( k ) +
			'</th><td>' +
			esc( v ) +
			'</td></tr>'
		);
	}

	function selectedGroups() {
		const keys = [];
		$( '#ferryman-files-groups input.ferryman-files-group:checked' ).each(
			function () {
				keys.push( $( this ).val() );
			}
		);
		return keys;
	}

	function hasGroupTable() {
		return (
			$( '#ferryman-files-groups input.ferryman-files-group' ).length > 0
		);
	}

	function groupsHtml( groups, selected ) {
		if ( ! groups || ! groups.length ) {
			return '<p>本番の uploads にファイルがありません。</p>';
		}
		// 保存済み選択があればそれを、無ければ全選択を初期状態にする。
		const sel = Object.create( null );
		const hasSaved = !! ( selected && selected.length );
		if ( hasSaved ) {
			for ( let i = 0; i < selected.length; i++ ) {
				sel[ String( selected[ i ] ) ] = true;
			}
		}
		let html =
			'<table class="widefat striped"><thead><tr>' +
			'<th style="width:32px;"></th><th>フォルダ</th>' +
			'<th style="width:110px;">差分</th><th style="width:110px;">差分サイズ</th>' +
			'<th style="width:90px;">総数</th></tr></thead><tbody>';
		groups.forEach( function ( g ) {
			const key = String( g.key );
			const label = key === '' ? '(直下)' : key;
			const diff = parseInt( g.diff, 10 ) || 0;
			const diffCell =
				diff > 0
					? esc( diff.toLocaleString() + ' 件' )
					: '<span class="ferryman-zero">0 件</span>';
			html +=
				'<tr>' +
				'<td><input type="checkbox" class="ferryman-files-group" value="' +
				esc( key ) +
				'"' +
				( ! hasSaved || sel[ key ] ? ' checked' : '' ) +
				' /></td>' +
				'<td>' +
				esc( label ) +
				'</td>' +
				'<td>' +
				diffCell +
				'</td>' +
				'<td>' +
				esc( humanBytes( g.diff_bytes ) ) +
				'</td>' +
				'<td>' +
				esc( ( parseInt( g.total, 10 ) || 0 ).toLocaleString() ) +
				'</td>' +
				'</tr>';
		} );
		html += '</tbody></table>';
		return html;
	}

	// 引数は ajax 応答の data 部分（res.data）を渡す。
	function renderGroups( data ) {
		if ( ! data || ! data.groups ) {
			return;
		}
		$( '#ferryman-files-groups' ).html(
			groupsHtml( data.groups, data.selected )
		);
		$( '#ferryman-files-groups-box' ).show();
	}

	function isAuthExpired( res ) {
		return (
			! res ||
			typeof res !== 'object' ||
			typeof res.success === 'undefined'
		);
	}

	function authExpired( where ) {
		running = false;
		setButtons( false );
		log(
			'認証の有効期限が切れたため通信が拒否されました（' +
				where +
				'）。進捗は保存済みです。'
		);
		showReloadNotice();
	}

	function showReloadNotice() {
		if ( $( '#ferryman-files-auth-expired' ).length ) {
			return;
		}
		const $notice = $(
			'<div id="ferryman-files-auth-expired" class="notice notice-warning">' +
				'<p>ログインセッション（nonce）の有効期限が切れたため、サーバーが通信を拒否しました。' +
				'同期の進捗はサーバーに保存されています。ページを再読み込みして「再開する」を押すと続きから再開できます。</p>' +
				'<p><button type="button" class="button button-primary" id="ferryman-files-reload-btn">ページを再読み込み</button></p>' +
				'</div>'
		);
		$( '#ferryman-files-progress' ).before( $notice );
		$( '#ferryman-files-reload-btn' ).on( 'click', function () {
			window.location.reload();
		} );
	}

	function finish() {
		running = false;
		setButtons( false );
	}

	function setButtons( disabled ) {
		$( '#ferryman-files-scan-btn, #ferryman-files-run-btn' ).prop(
			'disabled',
			disabled
		);
	}

	/* ---------------------------------------------------------------- */
	/* スキャン（差分確認のみ）                                          */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-files-scan-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		setButtons( true );
		const $out = $( '#ferryman-files-summary' )
			.show()
			.html( 'スキャン中…' );
		ajax( 'ferryman_files_scan', {
			mode: 'dryrun',
			groups: selectedGroups(),
		} )
			.done( function ( res ) {
				if ( ! res || ! res.success ) {
					showNotice(
						$out,
						res && res.data && res.data.message
							? res.data.message
							: 'スキャンの結果を受け取れませんでした。ページを再読み込みしてから、もう一度お試しください。',
						'error'
					);
					return;
				}
				renderGroups( res.data );
				$out.html( summaryHtml( res.data.summary ) );
			} )
			.fail( function ( jqXHR ) {
				showNotice( $out, failMessage( 'スキャン', jqXHR ), 'error' );
			} )
			.always( function () {
				setButtons( false );
			} );
	} );

	/* ---------------------------------------------------------------- */
	/* 実行（取得）                                                      */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-files-run-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		const groups = selectedGroups();
		// 表が出ているのに 1 つも選択が無い場合、空配列はサーバ側で「全件」と
		// 解釈されてしまうため送らずに止める。
		if ( hasGroupTable() && ! groups.length ) {
			showNotice(
				$( '#ferryman-files-summary' ),
				'対象フォルダが1つも選択されていません。取得するフォルダにチェックを入れてください。',
				'error'
			);
			return;
		}
		running = true;
		setButtons( true );
		showProgress( '実行（uploads pull）' );
		log( '差分をスキャンしています…' );

		ajax( 'ferryman_files_scan', { mode: 'run', groups } )
			.done( function ( res ) {
				if ( isAuthExpired( res ) ) {
					authExpired( 'scan' );
					return;
				}
				if ( ! res.success ) {
					log( 'エラー: ' + res.data.message );
					finish();
					return;
				}
				renderGroups( res.data );
				if ( res.data.summary ) {
					$( '#ferryman-files-summary' )
						.show()
						.html( summaryHtml( res.data.summary ) );
				}
				if ( ! res.data.progress ) {
					log( res.data.message || '転送対象はありません。' );
					finish();
					return;
				}
				updateProgress( res.data.progress );
				log(
					'転送開始: ' +
						res.data.progress.files_total +
						' ファイル / ' +
						humanBytes( res.data.progress.bytes_total )
				);
				stepLoop();
			} )
			.fail( function ( jqXHR ) {
				if ( jqXHR && 403 === jqXHR.status ) {
					authExpired( 'scan' );
					return;
				}
				log( failMessage( '差分のスキャン', jqXHR ) );
				finish();
			} );
	} );

	function stepLoop() {
		ajax( 'ferryman_files_step' )
			.done( function ( res ) {
				if ( isAuthExpired( res ) ) {
					authExpired( 'step' );
					return;
				}
				const p = res.success
					? res.data.progress
					: res.data && res.data.progress;
				updateProgress( p );
				if ( ! res.success ) {
					log( 'エラー: ' + ( res.data && res.data.message ) );
					finish();
					return;
				}
				if ( ! p || p.status === 'done' ) {
					log(
						'完了。取得 ' +
							( p ? p.files_done : 0 ) +
							' ファイル / ' +
							humanBytes( p ? p.bytes_done : 0 ) +
							'（スキップ ' +
							( p ? p.skipped : 0 ) +
							'）'
					);
					finish();
					return;
				}
				if ( p.status === 'error' ) {
					log( 'エラーで停止しました。' );
					finish();
					return;
				}
				log(
					'… ' +
						p.current_file +
						' (' +
						p.files_done +
						'/' +
						p.files_total +
						')'
				);
				stepLoop();
			} )
			.fail( function ( jqXHR ) {
				if ( jqXHR && 403 === jqXHR.status ) {
					authExpired( 'step' );
					return;
				}
				log( failMessage( 'ファイル取得の続き', jqXHR ) );
				log(
					'進捗はサーバーに保存されています。ページを再読み込みして「再開する」を押すと、続きから再開できます。'
				);
				finish();
			} );
	}

	$( '#ferryman-files-select-all' ).on( 'change', function () {
		$( '#ferryman-files-groups input.ferryman-files-group' ).prop(
			'checked',
			this.checked
		);
	} );

	/* ---------------------------------------------------------------- */
	/* 再開・破棄                                                        */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-files-resume-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		running = true;
		setButtons( true );
		showProgress( '再開（uploads pull）' );
		log( '中断したファイル同期を再開します。' );
		stepLoop();
	} );

	$( '#ferryman-files-discard-btn' ).on( 'click', function () {
		ajax( 'ferryman_files_cancel' )
			.done( function () {
				$( '.ferryman-files-resume' ).fadeOut();
			} )
			.fail( function ( jqXHR ) {
				let $box = $( '#ferryman-files-discard-result' );
				if ( ! $box.length ) {
					$box = $(
						'<div id="ferryman-files-discard-result"></div>'
					).insertAfter( '.ferryman-files-resume' );
				}
				showNotice(
					$box,
					failMessage( 'ファイル同期の破棄', jqXHR ),
					'error'
				);
			} );
	} );
} )( jQuery );
