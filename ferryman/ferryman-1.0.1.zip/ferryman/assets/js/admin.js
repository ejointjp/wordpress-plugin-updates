/* global FerrymanCtrl, jQuery */
( function ( $ ) {
	'use strict';

	let running = false;

	/**
	 * 管理画面標準の通知（.notice）を、操作した場所の結果欄に出す。
	 *
	 * 結果欄の中身は通知で置き換える。画面の上端ではない場所に出るので、
	 * スクリーンリーダーにも読み上げさせる。
	 *
	 * @param {jQuery} $box    通知を入れる要素。
	 * @param {string} message 文言（テキストとして入れる）。
	 * @param {string} type    'error' | 'warning' | 'success' | 'info'
	 */
	function showNotice( $box, message, type ) {
		const $notice = $(
			'<div class="notice inline"><p></p></div>'
		).addClass( 'notice-' + type );
		$notice.find( 'p' ).text( message );
		$box.show().empty().append( $notice );
		wp.a11y.speak( message, 'error' === type ? 'assertive' : 'polite' );
	}

	/**
	 * AJAX が失敗したときの文言を組み立てる。
	 *
	 * @param {string} what  失敗した操作（例: '接続テスト'）。
	 * @param {jqXHR}  jqXHR 失敗した要求。
	 * @return {string} 何が失敗したかと、次にすることを書いた文言。
	 */
	function failMessage( what, jqXHR ) {
		const status = jqXHR ? jqXHR.status : 0;
		if ( ! status ) {
			return (
				what +
				'の通信に失敗しました。サーバーに接続できません。ネットワーク接続を確認して、もう一度お試しください。'
			);
		}
		// admin-ajax はログイン切れを 400、nonce の失効を 403 で返す。
		if ( 400 === status || 403 === status ) {
			return (
				what +
				'の要求が拒否されました（HTTP ' +
				status +
				'）。ログインの有効期限が切れた可能性があります。ページを再読み込みしてから、もう一度お試しください。'
			);
		}
		// 200 番台で失敗扱いになるのは、応答が JSON として読めなかったとき。
		if ( status >= 200 && status < 300 ) {
			return (
				what +
				'の応答を読み取れませんでした。サーバーのPHPエラーログを確認してください。'
			);
		}
		return (
			what +
			'に失敗しました（HTTP ' +
			status +
			'）。時間をおいてもう一度お試しください。続く場合はサーバーのPHPエラーログを確認してください。'
		);
	}

	/**
	 * admin-ajax への POST。
	 *
	 * @param {string} action アクション名。
	 * @param {Object} data   追加データ。
	 * @return {jQuery.jqXHR} 応答を待つjqXHR。
	 */
	function ajax( action, data ) {
		return $.post(
			FerrymanCtrl.ajaxUrl,
			$.extend( { action, nonce: FerrymanCtrl.nonce }, data || {} )
		);
	}

	function direction() {
		return $( 'input[name="ferryman_direction"]:checked' ).val() || 'pull';
	}

	function selectedTables() {
		const tables = [];
		$( '#ferryman-tables input.ferryman-table:checked' ).each( function () {
			tables.push( $( this ).val() );
		} );
		return tables;
	}

	function esc( s ) {
		return String( s ?? '' )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#039;' );
	}

	function log( msg ) {
		const $log = $( '#ferryman-log' );
		$log.append( esc( msg ) + '\n' );
		$log.scrollTop( $log[ 0 ].scrollHeight );
	}

	function showProgress( title ) {
		$( '#ferryman-progress' ).show();
		$( '#ferryman-progress-title' ).text( title );
		$( '#ferryman-log' ).text( '' );
	}

	function updateProgress( p ) {
		if ( ! p ) {
			return;
		}
		$( '#ferryman-bar-fill' )
			.css( 'width', ( p.percent || 0 ) + '%' )
			.text( ( p.percent || 0 ) + '%' );
		const txt =
			'状態: ' +
			p.status +
			' / テーブル: ' +
			( p.current_table || '-' ) +
			' (' +
			( p.table_index + 1 ) +
			'/' +
			p.tables_count +
			')' +
			' / 行: ' +
			p.rows_done +
			' / ' +
			p.rows_total +
			' / 置換: ' +
			p.replace_count +
			' 件';
		$( '#ferryman-progress-text' ).text( txt );
	}

	/* ---------------------------------------------------------------- */
	/* 接続テスト                                                        */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-test-btn' ).on( 'click', function () {
		const $btn = $( this ).prop( 'disabled', true );
		const $out = $( '#ferryman-test-result' ).show().html( '接続中…' );
		ajax( 'ferryman_test' )
			.done( function ( res ) {
				if ( ! res.success ) {
					showNotice( $out, res.data.message, 'error' );
					return;
				}
				const d = res.data;
				let html = '<table class="widefat striped"><tbody>';
				html += row( 'siteurl', d.remote.siteurl );
				html += row( 'home', d.remote.home );
				html += row( 'abspath', d.remote.abspath );
				html += row( 'table_prefix（本番）', d.remote.table_prefix );
				html += row( 'table_prefix（ローカル）', d.local.table_prefix );
				html += row( '文字コード（本番）', charsetLabel( d.remote ) );
				html += row(
					'文字コード（ローカル）',
					charsetLabel( d.local )
				);
				html += row( 'WP バージョン', d.remote.wp_version );
				html += row( 'プラグイン', d.remote.plugin_version );
				html += row( 'pull 許可', d.remote.allow_pull ? '✔' : '✘' );
				html += row( 'push 許可', d.remote.allow_push ? '✔' : '✘' );
				html += row(
					'ファイル pull 許可',
					d.remote.allow_file_pull ? '✔' : '✘'
				);
				html += '</tbody></table>';
				html +=
					'<p>' +
					( d.prefix_ok
						? '<span class="ferryman-ok">✔ table_prefix 一致</span>'
						: '<span class="ferryman-danger">✘ table_prefix 不一致（移行不可）</span>' ) +
					'</p>';
				if ( ! d.charset_ok ) {
					html +=
						'<p class="ferryman-danger">⚠ テーブルの文字コードが本番とローカルで異なります。</p>';
				}
				$out.html( html );
			} )
			.fail( function ( jqXHR ) {
				showNotice( $out, failMessage( '接続テスト', jqXHR ), 'error' );
			} )
			.always( function () {
				$btn.prop( 'disabled', false );
			} );
	} );

	function row( k, v ) {
		return (
			'<tr><th style="width:200px;">' +
			esc( k ) +
			'</th><td><code>' +
			esc( v ) +
			'</code></td></tr>'
		);
	}

	// テーブル実体の文字コードを主として表示し、wp-config.php の宣言を括弧で添える。
	// 判定に使うのは実体側だが、両者が食い違っている状況自体を見えるようにする。
	function charsetLabel( meta ) {
		if ( ! meta.table_charset ) {
			return meta.db_charset || '不明';
		}
		if (
			meta.db_charset &&
			meta.db_charset.toLowerCase() !== meta.table_charset.toLowerCase()
		) {
			return (
				meta.table_charset + '（wp-config: ' + meta.db_charset + '）'
			);
		}
		return meta.table_charset;
	}

	/* ---------------------------------------------------------------- */
	/* テーブル一覧                                                      */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-load-tables' ).on( 'click', function () {
		const $btn = $( this ).prop( 'disabled', true );
		const $box = $( '#ferryman-tables' ).html( '取得中…' );
		ajax( 'ferryman_tables', { direction: direction() } )
			.done( function ( res ) {
				if ( ! res.success ) {
					showNotice( $box, res.data.message, 'error' );
					return;
				}
				const tables = res.data.tables || [];
				if ( ! tables.length ) {
					$box.html( '<p>テーブルが見つかりません。</p>' );
					return;
				}
				let html = '';
				tables.forEach( function ( t ) {
					html +=
						'<label class="ferryman-table-row">' +
						'<input type="checkbox" class="ferryman-table" value="' +
						esc( t.name ) +
						'" checked /> ' +
						esc( t.name ) +
						' <span class="description">(~' +
						esc( t.rows ) +
						' 行)</span></label>';
				} );
				$box.html( html );
				$( '#ferryman-tables-source' ).text(
					'ソース: ' +
						( res.data.source === 'remote' ? '本番' : 'ローカル' )
				);
			} )
			.fail( function ( jqXHR ) {
				showNotice(
					$box,
					failMessage( 'テーブル一覧の取得', jqXHR ),
					'error'
				);
			} )
			.always( function () {
				$btn.prop( 'disabled', false );
			} );
	} );

	$( '#ferryman-select-all' ).on( 'change', function () {
		$( '#ferryman-tables input.ferryman-table' ).prop(
			'checked',
			this.checked
		);
	} );

	/* ---------------------------------------------------------------- */
	/* 開始・ステップループ                                              */
	/* ---------------------------------------------------------------- */
	function start( mode ) {
		if ( running ) {
			return;
		}
		const tables = selectedTables();
		if ( ! tables.length ) {
			showNotice(
				$( '#ferryman-summary' ),
				'対象テーブルが選択されていません。「テーブル一覧を取得」で一覧を出し、移行するテーブルにチェックを入れてください。',
				'error'
			);
			return;
		}
		running = true;
		setButtons( true );
		// 前回の結果や「未選択」の通知を残したまま始めない。
		$( '#ferryman-summary' ).hide().empty();
		showProgress(
			( mode === 'dryrun' ? 'Dry run' : '実行' ) +
				'（' +
				direction() +
				'）'
		);
		log(
			'開始: ' +
				direction() +
				' / ' +
				mode +
				' / ' +
				tables.length +
				' テーブル'
		);

		ajax( 'ferryman_start', {
			direction: direction(),
			mode,
			tables,
		} )
			.done( function ( res ) {
				if ( isAuthExpired( res ) ) {
					authExpired( 'start' );
					return;
				}
				if ( ! res.success ) {
					log( 'エラー: ' + res.data.message );
					finish();
					return;
				}
				if ( res.data.warning ) {
					log( res.data.warning );
				}
				if ( res.data.summary ) {
					$( '#ferryman-summary' )
						.show()
						.html( summaryHtml( res.data.summary ) );
				}
				if ( res.data.progress && res.data.progress.backup_id ) {
					log(
						'バックアップ作成済み: ' + res.data.progress.backup_id
					);
				}
				updateProgress( res.data.progress );
				stepLoop();
			} )
			.fail( function ( jqXHR ) {
				if ( jqXHR && 403 === jqXHR.status ) {
					authExpired( 'start' );
					return;
				}
				log( failMessage( '移行の開始', jqXHR ) );
				finish();
			} );
	}

	function summaryHtml( pairs ) {
		let html = '<strong>置換マップ（主要）:</strong><ul>';
		pairs.forEach( function ( p ) {
			html +=
				'<li><code>' +
				esc( p.from ) +
				'</code> → <code>' +
				esc( p.to ) +
				'</code></li>';
		} );
		html += '</ul>';
		return html;
	}

	function stepLoop() {
		ajax( 'ferryman_step' )
			.done( function ( res ) {
				if ( isAuthExpired( res ) ) {
					authExpired( 'step' );
					return;
				}
				const p = res.success
					? res.data.progress
					: res.data && res.data.progress;
				updateProgress( p );
				if ( ! res.success ) {
					log( 'エラー: ' + ( res.data && res.data.message ) );
					finish();
					return;
				}
				if ( ! p || p.status === 'done' ) {
					log(
						'完了。処理行数 ' +
							( p ? p.rows_done : 0 ) +
							' / 置換 ' +
							( p ? p.replace_count : 0 ) +
							' 件'
					);
					if ( p && p.mode === 'dryrun' ) {
						log(
							'これは Dry run です。実際の書き込みは行っていません。'
						);
					}
					if ( p ) {
						showReplaceTable( p );
					}
					finish();
					return;
				}
				if ( p.status === 'error' ) {
					log( 'エラーで停止しました。' );
					finish();
					return;
				}
				log( '… ' + p.current_table + ' / ' + p.rows_done + ' 行' );
				stepLoop();
			} )
			.fail( function ( jqXHR ) {
				if ( jqXHR && 403 === jqXHR.status ) {
					authExpired( 'step' );
					return;
				}
				log( failMessage( '移行の続き', jqXHR ) );
				log(
					'進捗はサーバーに保存されています。ページを再読み込みして「再開する」を押すと、続きから再開できます。'
				);
				finish();
			} );
	}

	/**
	 * テーブルごとの行数・置換件数を summary エリアに表示する。
	 *
	 * @param {Object} p progress オブジェクト。
	 */
	function showReplaceTable( p ) {
		const tables = p.tables || [];
		const meta = p.tables_meta || {};
		const counts = p.tables_replace_count || {};
		if ( ! tables.length ) {
			return;
		}
		let html =
			'<strong>テーブル別集計' +
			( p.mode === 'dryrun' ? '（Dry run）' : '' ) +
			':</strong>';
		html +=
			'<table class="widefat striped" style="margin-top:8px;"><thead><tr>' +
			'<th>テーブル</th><th style="text-align:right;">行数</th><th style="text-align:right;">置換件数</th>' +
			'</tr></thead><tbody>';
		let totalRows = 0,
			totalReplace = 0;
		tables.forEach( function ( t ) {
			const rows =
				meta[ t ] !== undefined ? parseInt( meta[ t ], 10 ) : '-';
			const replace =
				counts[ t ] !== undefined ? parseInt( counts[ t ], 10 ) : 0;
			if ( typeof rows === 'number' ) {
				totalRows += rows;
			}
			totalReplace += replace;
			html +=
				'<tr>' +
				'<td><code>' +
				esc( t ) +
				'</code></td>' +
				'<td style="text-align:right;">' +
				( typeof rows === 'number' ? rows.toLocaleString() : rows ) +
				'</td>' +
				'<td style="text-align:right;">' +
				replace.toLocaleString() +
				'</td>' +
				'</tr>';
		} );
		html +=
			'<tr style="font-weight:bold;border-top:2px solid #c3c4c7;">' +
			'<td>合計</td>' +
			'<td style="text-align:right;">' +
			totalRows.toLocaleString() +
			'</td>' +
			'<td style="text-align:right;">' +
			totalReplace.toLocaleString() +
			'</td>' +
			'</tr>';
		html += '</tbody></table>';
		$( '#ferryman-summary' ).show().html( html );
	}

	/**
	 * 応答が正常な wp_send_json エンベロープか判定する。
	 * nonce 失効・ログイン切れ時、admin-ajax はハンドラ実行前に
	 * -1 や 0 を返すため success プロパティを持たない。これを認証切れとみなす。
	 *
	 * @param {Object|string} res 応答。
	 * @return {boolean} 認証切れとみなせるなら true。
	 */
	function isAuthExpired( res ) {
		return (
			! res ||
			typeof res !== 'object' ||
			typeof res.success === 'undefined'
		);
	}

	/**
	 * 認証切れ時の復帰導線。セッションはサーバーに永続化されているため、
	 * 再読み込みで最新 nonce を取得し「再開する」で続行できる。
	 *
	 * @param {string} where 発生箇所（ログ用）。
	 */
	function authExpired( where ) {
		running = false;
		setButtons( false );
		log(
			'認証の有効期限が切れたため通信が拒否されました（' +
				where +
				'）。進捗は保存済みです。'
		);
		showReloadNotice();
	}

	/**
	 * 再読み込みを促す通知を進捗領域の前に1度だけ挿入する。
	 */
	function showReloadNotice() {
		if ( $( '#ferryman-auth-expired' ).length ) {
			return;
		}
		const $notice = $(
			'<div id="ferryman-auth-expired" class="notice notice-warning">' +
				'<p>ログインセッション（nonce）の有効期限が切れたため、サーバーが通信を拒否しました。' +
				'移行の進捗はサーバーに保存されています。ページを再読み込みして「再開する」を押すと、続きから再開できます。</p>' +
				'<p><button type="button" class="button button-primary" id="ferryman-reload-btn">ページを再読み込み</button></p>' +
				'</div>'
		);
		$( '#ferryman-progress' ).before( $notice );
		$( '#ferryman-reload-btn' ).on( 'click', function () {
			window.location.reload();
		} );
	}

	function finish() {
		running = false;
		setButtons( false );
	}

	function setButtons( disabled ) {
		$(
			'#ferryman-run-btn, #ferryman-dryrun-btn, #ferryman-load-tables'
		).prop( 'disabled', disabled );
	}

	$( '#ferryman-dryrun-btn' ).on( 'click', function () {
		start( 'dryrun' );
	} );

	$( '#ferryman-run-btn' ).on( 'click', function () {
		if ( direction() === 'push' ) {
			openModal();
		} else {
			start( 'run' );
		}
	} );

	/* ---------------------------------------------------------------- */
	/* push 確認モーダル                                                 */
	/* ---------------------------------------------------------------- */
	function openModal() {
		$( '#ferryman-consent' ).prop( 'checked', false );
		$( '#ferryman-modal-confirm' ).prop( 'disabled', true );
		$( '#ferryman-modal' ).show();
	}

	$( '#ferryman-consent' ).on( 'change', function () {
		$( '#ferryman-modal-confirm' ).prop( 'disabled', ! this.checked );
	} );

	$( '#ferryman-modal-cancel' ).on( 'click', function () {
		$( '#ferryman-modal' ).hide();
	} );

	$( '#ferryman-modal-confirm' ).on( 'click', function () {
		$( '#ferryman-modal' ).hide();
		start( 'run' );
	} );

	/* ---------------------------------------------------------------- */
	/* 再開・破棄                                                        */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-resume-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		running = true;
		setButtons( true );
		showProgress( '再開' );
		log( '中断したセッションを再開します。' );
		stepLoop();
	} );

	$( '#ferryman-discard-btn' ).on( 'click', function () {
		ajax( 'ferryman_cancel' )
			.done( function () {
				$( '.ferryman-resume' ).fadeOut();
			} )
			.fail( function ( jqXHR ) {
				let $box = $( '#ferryman-discard-result' );
				if ( ! $box.length ) {
					$box = $(
						'<div id="ferryman-discard-result"></div>'
					).insertAfter( '.ferryman-resume' );
				}
				showNotice(
					$box,
					failMessage( 'セッションの破棄', jqXHR ),
					'error'
				);
			} );
	} );
} )( jQuery );
