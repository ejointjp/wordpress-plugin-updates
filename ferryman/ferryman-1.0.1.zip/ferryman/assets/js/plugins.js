/* global FerrymanPlugins, jQuery */
/* Ferrymanプラグイン同期ドライバ。差分表の描画と、1行ずつのインストール・有効化を行う。 */
( function ( $ ) {
	'use strict';

	if ( ! window.FerrymanPlugins ) {
		return;
	}

	let running = false;
	let rows = []; // 直近に描画した差分行（サーバの応答そのまま）。

	function esc( s ) {
		return String( s ?? '' )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#039;' );
	}

	function ajax( action, data ) {
		return $.post(
			FerrymanPlugins.ajaxUrl,
			$.extend( { action, nonce: FerrymanPlugins.nonce }, data || {} )
		);
	}

	// htmlは呼び出し側でエスケープ済みのものを渡す。
	function message( html, type ) {
		const $box = $( '#ferryman-plugins-message' );
		$box.html(
			html
				? '<div class="notice notice-' +
						( type || 'info' ) +
						' inline"><p>' +
						html +
						'</p></div>'
				: ''
		);
		// 失敗は画面の上端ではない場所に出るので、スクリーンリーダーにも読み上げさせる。
		if ( html && ( 'error' === type || 'warning' === type ) ) {
			wp.a11y.speak( $box.text(), 'assertive' );
		}
	}

	/**
	 * AJAX が失敗したときの文言を組み立てる（admin.js と同じ）。
	 *
	 * @param {string} what  失敗した操作（例: '本番からの取得'）。
	 * @param {jqXHR}  jqXHR 失敗した要求。
	 * @return {string} 何が失敗したかと、次にすることを書いた文言。
	 */
	function failMessage( what, jqXHR ) {
		const status = jqXHR ? jqXHR.status : 0;
		if ( ! status ) {
			return (
				what +
				'の通信に失敗しました。サーバーに接続できません。ネットワーク接続を確認して、もう一度お試しください。'
			);
		}
		// admin-ajax はログイン切れを 400、nonce の失効を 403 で返す。
		if ( 400 === status || 403 === status ) {
			return (
				what +
				'の要求が拒否されました（HTTP ' +
				status +
				'）。ログインの有効期限が切れた可能性があります。ページを再読み込みしてから、もう一度お試しください。'
			);
		}
		// 200 番台で失敗扱いになるのは、応答が JSON として読めなかったとき。
		if ( status >= 200 && status < 300 ) {
			return (
				what +
				'の応答を読み取れませんでした。サーバーのPHPエラーログを確認してください。'
			);
		}
		return (
			what +
			'に失敗しました（HTTP ' +
			status +
			'）。時間をおいてもう一度お試しください。続く場合はサーバーのPHPエラーログを確認してください。'
		);
	}

	function log( msg ) {
		const $log = $( '#ferryman-plugins-log' ).show();
		$log.append( esc( msg ) + '\n' );
		$log.scrollTop( $log[ 0 ].scrollHeight );
	}

	function setButtons( disabled ) {
		$(
			'#ferryman-plugins-fetch-btn, #ferryman-plugins-import-btn, #ferryman-plugins-run-btn'
		).prop( 'disabled', disabled );
	}

	const STATUS_LABEL = {
		missing: '未設置',
		needs_activate: '要有効化',
		local_active: 'このサイトだけ有効',
		version_diff: '版違い',
		same: '一致',
		local_only: 'このサイトのみ',
	};

	function verCell( e ) {
		if ( ! e ) {
			return '<span class="ferryman-zero">—</span>';
		}
		return (
			esc( e.version || '?' ) +
			' / ' +
			( e.active ? '<span class="ferryman-ok">有効</span>' : '無効' )
		);
	}

	function tableHtml( list ) {
		let html =
			'<table class="widefat striped ferryman-plugins-table"><thead><tr>' +
			'<th style="width:32px;"></th><th>プラグイン</th><th>slug</th>' +
			'<th>取込元（版 / 状態）</th><th>このサイト（版 / 状態）</th><th>差分</th><th>結果</th>' +
			'</tr></thead><tbody>';
		list.forEach( function ( r, i ) {
			const src = r.source;
			const loc = r.local;
			const plugin = src || loc;
			const name = plugin ? plugin.name : r.key;
			const file = plugin ? plugin.file : '';
			const slug = src ? src.slug : r.key;
			const check = r.checkable
				? '<input type="checkbox" class="ferryman-plugins-pick" data-index="' +
					i +
					'"' +
					( r.checked ? ' checked' : '' ) +
					' />'
				: '';
			const note = r.note
				? '<br /><span class="ferryman-zero">' +
					esc( r.note ) +
					'</span>'
				: '';
			html +=
				'<tr id="ferryman-plugins-row-' +
				i +
				'">' +
				'<td>' +
				check +
				'</td>' +
				'<td>' +
				esc( name ) +
				'<br /><code>' +
				esc( file ) +
				'</code></td>' +
				'<td>' +
				esc( slug ) +
				'</td>' +
				'<td>' +
				verCell( src ) +
				'</td>' +
				'<td>' +
				verCell( loc ) +
				'</td>' +
				'<td>' +
				esc( STATUS_LABEL[ r.status ] || r.status ) +
				note +
				'</td>' +
				'<td class="ferryman-plugins-result"></td>' +
				'</tr>';
		} );
		html += '</tbody></table>';
		return html;
	}

	// 引数はajax応答のdata部分（res.data）。
	function renderDiff( data ) {
		rows = data.rows || [];
		const m = data.manifest || {};
		$( '#ferryman-plugins-source' ).text(
			'取込元: ' +
				( m.site || '(不明)' ) +
				' / WP ' +
				( m.wp_version || '?' ) +
				' / 生成: ' +
				( m.generated_at || '?' ) +
				' / ' +
				( m.count || 0 ) +
				'プラグイン'
		);
		$( '#ferryman-plugins-table' ).html( tableHtml( rows ) );
		$( '#ferryman-plugins-select-all' ).prop( 'checked', false );
		$( '#ferryman-plugins-log' ).hide().text( '' );
		$( '#ferryman-plugins-box' ).show();
	}

	function handleDiffResponse( res ) {
		if (
			! res ||
			typeof res !== 'object' ||
			typeof res.success === 'undefined'
		) {
			message(
				'ログインセッション（nonce）の有効期限が切れました。ページを再読み込みしてください。',
				'warning'
			);
			return;
		}
		if ( ! res.success ) {
			message(
				esc(
					res.data && res.data.message
						? res.data.message
						: 'プラグイン一覧を読み込めませんでした。ページを再読み込みしてから、もう一度お試しください。'
				),
				'error'
			);
			return;
		}
		message( '' );
		renderDiff( res.data );
	}

	/* ---------------------------------------------------------------- */
	/* 本番から取得                                                      */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-plugins-fetch-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		setButtons( true );
		message( '本番から取得中…' );
		ajax( 'ferryman_plugins_fetch_remote' )
			.done( handleDiffResponse )
			.fail( function ( jqXHR ) {
				message(
					esc( failMessage( '本番からの取得', jqXHR ) ),
					'error'
				);
			} )
			.always( function () {
				setButtons( false );
			} );
	} );

	/* ---------------------------------------------------------------- */
	/* JSON読み込み                                                      */
	/* ---------------------------------------------------------------- */
	$( '#ferryman-plugins-import-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		const input = document.getElementById( 'ferryman-plugins-file' );
		if ( ! input || ! input.files || ! input.files.length ) {
			message( 'JSONファイルを選択してください。', 'error' );
			return;
		}
		const fd = new FormData();
		fd.append( 'action', 'ferryman_plugins_import_json' );
		fd.append( 'nonce', FerrymanPlugins.nonce );
		fd.append( 'manifest', input.files[ 0 ] );

		setButtons( true );
		message( '読み込み中…' );
		$.ajax( {
			url: FerrymanPlugins.ajaxUrl,
			method: 'POST',
			data: fd,
			processData: false,
			contentType: false,
		} )
			.done( handleDiffResponse )
			.fail( function ( jqXHR ) {
				message(
					esc( failMessage( 'JSONの読み込み', jqXHR ) ),
					'error'
				);
			} )
			.always( function () {
				setButtons( false );
			} );
	} );

	/* ---------------------------------------------------------------- */
	/* 実行: インストール → 有効化 → 失敗分を1回再試行                   */
	/* ---------------------------------------------------------------- */
	function selectedRows() {
		const out = [];
		$( '#ferryman-plugins-table input.ferryman-plugins-pick:checked' ).each(
			function () {
				const i = parseInt( $( this ).attr( 'data-index' ), 10 );
				if ( rows[ i ] && rows[ i ].source ) {
					out.push( { index: i, row: rows[ i ] } );
				}
			}
		);
		return out;
	}

	function setResult( index, text, ok ) {
		$(
			'#ferryman-plugins-row-' + index + ' .ferryman-plugins-result'
		).html(
			'<span class="' +
				( ok ? 'ferryman-ok' : 'ferryman-danger' ) +
				'">' +
				esc( text ) +
				'</span>'
		);
	}

	// 1行分の入力。fileは設置後のベースネームで上書きできる。
	function entryData( row, file ) {
		const s = row.source;
		return {
			file: file || s.file,
			slug: s.slug,
			version: s.version,
			active: s.active ? '1' : '0',
		};
	}

	function isAuthExpired( res ) {
		return (
			! res ||
			typeof res !== 'object' ||
			typeof res.success === 'undefined'
		);
	}

	function finishRun() {
		running = false;
		setButtons( false );
		log( '完了。' );
	}

	function abortRun( why ) {
		running = false;
		setButtons( false );
		log( '中断: ' + why );
		message( esc( why ), 'warning' );
	}

	// 認証切れ（JSONでない応答）なら行に記録して実行全体を止め、trueを返す。
	function abortIfAuthExpired( res, index ) {
		if ( ! isAuthExpired( res ) ) {
			return false;
		}
		setResult( index, '認証切れ', false );
		abortRun(
			'ログインセッション（nonce）の有効期限が切れました。ページを再読み込みしてください。'
		);
		return true;
	}

	// HTTP 403（権限・nonceの拒否）か、ログアウト状態のHTTP 400（admin-ajaxが本文0で返す）なら、
	// 行に記録して実行全体を止め、trueを返す。
	function abortIfAuthRejected( jqXHR, index ) {
		if ( ! jqXHR || ( 403 !== jqXHR.status && 400 !== jqXHR.status ) ) {
			return false;
		}
		setResult( index, '認証切れ', false );
		abortRun( '認証が拒否されました。ページを再読み込みしてください。' );
		return true;
	}

	$( '#ferryman-plugins-run-btn' ).on( 'click', function () {
		if ( running ) {
			return;
		}
		const picked = selectedRows();
		if ( ! picked.length ) {
			message( '対象が選択されていません。', 'error' );
			return;
		}
		running = true;
		setButtons( true );
		message( '' );
		$( '#ferryman-plugins-log' ).show().text( '' );

		const policy =
			$( 'input[name="ferryman-plugins-version"]:checked' ).val() ||
			'same';
		const installQueue = picked.slice();
		const toActivate = []; // { index, row, file }

		log(
			'開始: ' +
				picked.length +
				'件（版の方針: ' +
				( policy === 'latest' ? '最新' : '取込元と同じ版' ) +
				'）'
		);

		function nextInstall() {
			const item = installQueue.shift();
			if ( ! item ) {
				activatePhase();
				return;
			}
			const row = item.row;
			if ( row.status !== 'missing' ) {
				// 既に入っている行は有効化だけ。
				if ( row.source.active ) {
					toActivate.push( {
						index: item.index,
						row,
						file: row.local ? row.local.file : row.source.file,
					} );
				}
				nextInstall();
				return;
			}
			setResult( item.index, 'インストール中…', true );
			ajax(
				'ferryman_plugins_install',
				$.extend( entryData( row ), { version_policy: policy } )
			)
				.done( function ( res ) {
					if ( abortIfAuthExpired( res, item.index ) ) {
						return;
					}
					if ( ! res.success ) {
						setResult( item.index, res.data.message, false );
						log(
							'エラー: ' +
								row.source.slug +
								' — ' +
								res.data.message
						);
						nextInstall();
						return;
					}
					setResult( item.index, res.data.message, true );
					log(
						'インストール: ' +
							row.source.slug +
							' — ' +
							res.data.message
					);
					if ( row.source.active ) {
						toActivate.push( {
							index: item.index,
							row,
							file: res.data.file || row.source.file,
						} );
					}
					nextInstall();
				} )
				.fail( function ( jqXHR ) {
					if ( abortIfAuthRejected( jqXHR, item.index ) ) {
						return;
					}
					const why =
						'サーバエラー（応答が壊れています。HTTP ' +
						( jqXHR ? jqXHR.status : '?' ) +
						'）';
					setResult( item.index, why, false );
					log( 'エラー: ' + row.source.slug + ' — ' + why );
					nextInstall();
				} );
		}

		function activatePhase() {
			let queue = toActivate.slice();
			let retry = [];
			if ( ! queue.length ) {
				finishRun();
				return;
			}
			log( '有効化: ' + queue.length + '件' );

			function next( pass ) {
				const item = queue.shift();
				if ( ! item ) {
					if ( pass === 1 && retry.length ) {
						// 依存（Requires Plugins）が後ろの行で満たされたケースを拾う。
						queue = retry;
						retry = [];
						log(
							'有効化に失敗した' +
								queue.length +
								'件を再試行します。'
						);
						next( 2 );
						return;
					}
					finishRun();
					return;
				}
				setResult( item.index, '有効化中…', true );
				ajax(
					'ferryman_plugins_activate',
					entryData( item.row, item.file )
				)
					.done( function ( res ) {
						if ( abortIfAuthExpired( res, item.index ) ) {
							return;
						}
						if ( ! res.success ) {
							setResult( item.index, res.data.message, false );
							log(
								'エラー: ' +
									item.row.source.slug +
									' — ' +
									res.data.message
							);
							if ( pass === 1 ) {
								retry.push( item );
							}
							next( pass );
							return;
						}
						setResult( item.index, res.data.message, true );
						log( '有効化: ' + item.row.source.slug );
						next( pass );
					} )
					.fail( function ( jqXHR ) {
						if ( abortIfAuthRejected( jqXHR, item.index ) ) {
							return;
						}
						// 致命的エラーでPHPが落ちた行は再試行しない。
						const why =
							'有効化中に致命的エラー（応答が壊れています。HTTP ' +
							( jqXHR ? jqXHR.status : '?' ) +
							'）';
						setResult( item.index, why, false );
						log( 'エラー: ' + item.row.source.slug + ' — ' + why );
						next( pass );
					} );
			}
			next( 1 );
		}

		nextInstall();
	} );
	$( '#ferryman-plugins-select-all' ).on( 'change', function () {
		$( '#ferryman-plugins-table input.ferryman-plugins-pick' ).prop(
			'checked',
			this.checked
		);
	} );
} )( jQuery );
