<?php
/**
 * uploads ファイル同期（pull 専用・非破壊）のオーケストレーション。
 * admin-ajax でチャンクを反復ドライブする。
 *
 * 本番(uploads) --HTTP(base64)--> ローカル(uploads) に追加・更新のみ書き込む。
 * ソースに無いローカルファイルは削除しない（非破壊）。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * ファイル同期エンジン。
 */
class Ferryman_Ctrl_Files {

	const CAPABILITY = 'manage_options';

	/**
	 * 1 チャンクで取得するバイト数（base64 化前）。DB チャンクと同値。
	 */
	const FILE_CHUNK_BYTES = FERRYMAN_CHUNK_BYTES;

	/**
	 * 一時ファイルの接尾辞（rename 前）。
	 */
	const PART_SUFFIX = '.ferryman-part';

	/**
	 * 選択フォルダを保存する option キー。
	 */
	const OPTION_GROUPS = 'ferryman_files_groups';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Ctrl_Settings
	 */
	private $settings;

	/**
	 * セッション。
	 *
	 * @var Ferryman_Ctrl_Files_Session
	 */
	private $session;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Ctrl_Settings $settings 設定。
	 */
	public function __construct( Ferryman_Ctrl_Settings $settings ) {
		$this->settings = $settings;
		$this->session  = new Ferryman_Ctrl_Files_Session();
	}

	/**
	 * ajax フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'wp_ajax_ferryman_files_scan', array( $this, 'ajax_scan' ) );
		add_action( 'wp_ajax_ferryman_files_step', array( $this, 'ajax_step' ) );
		add_action( 'wp_ajax_ferryman_files_status', array( $this, 'ajax_status' ) );
		add_action( 'wp_ajax_ferryman_files_cancel', array( $this, 'ajax_cancel' ) );
	}

	/**
	 * セッションアクセサ（admin から参照）。
	 *
	 * @return Ferryman_Ctrl_Files_Session
	 */
	public function session() {
		return $this->session;
	}

	/*
	 * =====================================================================
	 * ajax ハンドラ
	 * =====================================================================
	 */

	/**
	 * スキャン（差分確認 / 実行開始）。
	 *
	 * mode=dryrun: 差分の集計のみ返す（セッションは作らない）。
	 * mode=run:    差分を確定してセッションを開始し、進捗を返す。
	 *
	 * @return void
	 */
	public function ajax_scan() {
		$this->guard();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- guard()で検証済み。
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		}

		$mode = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'dryrun';
		if ( ! in_array( $mode, array( 'run', 'dryrun' ), true ) ) {
			$mode = 'dryrun';
		}

		// 選択フォルダ。POST があればそれを保存し、無ければ保存済みを使う。
		// 空配列は「全件」を意味する（後方互換）。
		if ( isset( $_POST['groups'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitize_groups() で検証する。
			$groups = self::sanitize_groups( wp_unslash( $_POST['groups'] ) );
			$this->save_groups( $groups );
		} else {
			$groups = $this->saved_groups();
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// 二重起動防止（実行時のみ）。
		if ( 'run' === $mode ) {
			$existing = $this->session->get();
			if ( $existing && isset( $existing['status'] ) && 'running' === $existing['status'] ) {
				wp_send_json_error( array( 'message' => '別のファイル同期が進行中です。完了するか「破棄」してから開始してください。' ) );
			}
		}

		$client    = $this->client();
		$handshake = $client->handshake();
		if ( is_wp_error( $handshake ) ) {
			wp_send_json_error( array( 'message' => '接続に失敗しました: ' . $handshake->get_error_message() ) );
		}
		if ( empty( $handshake['allow_file_pull'] ) ) {
			wp_send_json_error( array( 'message' => '本番側でファイル pull（uploads 取得）が許可されていません。' ) );
		}

		// 本番 manifest を全取得。
		$remote = $this->fetch_remote_manifest( $client );
		if ( is_wp_error( $remote ) ) {
			wp_send_json_error( array( 'message' => 'ファイル一覧の取得に失敗: ' . $remote->get_error_message() ) );
		}

		// ローカル stat と差分。
		$base        = $this->local_uploads_basedir();
		$local_index = array();
		foreach ( $remote as $entry ) {
			$stat = $this->local_stat( $base, $entry['path'] );
			if ( null !== $stat ) {
				$local_index[ $entry['path'] ] = $stat;
			}
		}
		// フォルダ一覧は絞り込み「前」の全体から作る（選択外も一覧に出すため）。
		$group_rows = self::summarize_groups( $remote, $local_index );

		// 差分サマリは絞り込み「後」から作る（今の選択で何件転送されるかを示すため）。
		$selected_manifest = self::filter_by_groups( $remote, $groups );
		$diff              = self::diff_manifest( $selected_manifest, $local_index );

		// 本番の総数は絞り込み前のまま（「本番にあるファイル数」の意味を変えない）。
		$scanned_total = count( $remote );
		$scanned_bytes = 0;
		foreach ( $remote as $e ) {
			$scanned_bytes += (int) $e['size'];
		}
		$bytes_total = 0;
		foreach ( $diff['worklist'] as $e ) {
			$bytes_total += (int) $e['size'];
		}

		$summary = array(
			'scanned_total' => $scanned_total,
			'scanned_bytes' => $scanned_bytes,
			'files_total'   => count( $diff['worklist'] ),
			'bytes_total'   => $bytes_total,
			'skipped'       => $diff['skipped'],
		);

		if ( 'dryrun' === $mode ) {
			wp_send_json_success(
				array(
					'mode'     => 'dryrun',
					'summary'  => $summary,
					'groups'   => $group_rows,
					'selected' => $groups,
				)
			);
		}

		// 実行: 転送対象が無ければセッションを作らず完了扱い。
		if ( empty( $diff['worklist'] ) ) {
			wp_send_json_success(
				array(
					'mode'     => 'run',
					'summary'  => $summary,
					'groups'   => $group_rows,
					'selected' => $groups,
					'progress' => null,
					'message'  => '転送対象はありません（すべて最新です）。',
				)
			);
		}

		$state = $this->session->start(
			array(
				'mode'          => 'run',
				'worklist'      => array_values( $diff['worklist'] ),
				'files_total'   => count( $diff['worklist'] ),
				'bytes_total'   => $bytes_total,
				'scanned_total' => $scanned_total,
				'scanned_bytes' => $scanned_bytes,
				'skipped'       => $diff['skipped'],
				'groups'        => $groups,
			)
		);

		wp_send_json_success(
			array(
				'mode'     => 'run',
				'summary'  => $summary,
				'groups'   => $group_rows,
				'selected' => $groups,
				'progress' => $this->session->progress( $state ),
			)
		);
	}

	/**
	 * 1 チャンク処理。
	 *
	 * @return void
	 */
	public function ajax_step() {
		$this->guard();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		}

		$state = $this->session->get();
		if ( null === $state || 'running' !== $state['status'] ) {
			wp_send_json_success( array( 'progress' => $state ? $this->session->progress( $state ) : null ) );
		}

		$file = $this->session->current_file( $state );
		if ( null === $file ) {
			$state = $this->session->update( array( 'status' => 'done' ) );
			wp_send_json_success( array( 'progress' => $this->session->progress( $state ) ) );
		}

		$result = $this->step_file( $state, $file );
		if ( is_wp_error( $result ) ) {
			$state = $this->session->update(
				array(
					'status'  => 'error',
					'message' => $result->get_error_message(),
				)
			);
			wp_send_json_error(
				array(
					'message'  => $result->get_error_message(),
					'progress' => $this->session->progress( $state ),
				)
			);
		}

		wp_send_json_success( array( 'progress' => $this->session->progress( $result ) ) );
	}

	/**
	 * 現在の進捗を返す（再開用）。
	 *
	 * @return void
	 */
	public function ajax_status() {
		$this->guard();
		$state = $this->session->get();
		wp_send_json_success( array( 'progress' => $state ? $this->session->progress( $state ) : null ) );
	}

	/**
	 * セッション破棄（残った .part を掃除）。
	 *
	 * @return void
	 */
	public function ajax_cancel() {
		$this->guard();
		$this->cleanup_parts();
		$this->session->clear();
		wp_send_json_success( array( 'message' => 'ファイル同期セッションを破棄しました。' ) );
	}

	/*
	 * =====================================================================
	 * ステップ実装
	 * =====================================================================
	 */

	/**
	 * 現在ファイルの 1 チャンクを取得・書き込みする。
	 *
	 * @param array $state ステート。
	 * @param array $file  現在ファイル {path,size,mtime}。
	 * @return array|WP_Error 更新後ステート。
	 */
	private function step_file( array $state, array $file ) {
		$client = $this->client();
		$path   = (string) $file['path'];

		// ローカルの最終パス・一時パスを確定し検証する（uploads 配下に限定）。
		$base = $this->local_uploads_basedir();
		$part = Ferryman_Paths::safe_join( $base, $path . self::PART_SUFFIX );
		$dest = Ferryman_Paths::safe_join( $base, $path );
		if ( false === $part || false === $dest
			|| ! Ferryman_Paths::within_base( $base, $part )
			|| ! Ferryman_Paths::within_base( $base, $dest ) ) {
			return new WP_Error( 'ferryman_files_bad_local_path', '不正なローカルパスです: ' . $path );
		}

		// 再開時の整合: .part が無い／オフセットに満たないなら先頭からやり直す。
		$offset = (int) $state['file_offset'];
		if ( $offset > 0 && ( ! is_file( $part ) || filesize( $part ) < $offset ) ) {
			$offset = 0;
		}

		$res = $this->remote_call(
			function () use ( $client, $path, $offset ) {
				return $client->files_get( $path, $offset, self::FILE_CHUNK_BYTES );
			}
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$bytes = (int) $res['bytes'];
		$size  = (int) $res['size'];
		$eof   = ! empty( $res['eof'] ) || ( $offset + $bytes >= $size );

		// 非 eof で 1 バイトも進まないと無限ループになるため停止する。
		if ( ! $eof && 0 === $bytes ) {
			return new WP_Error( 'ferryman_files_stalled', 'ファイル取得が進みません（0 バイト応答）: ' . $path );
		}

		// 親ディレクトリを用意。
		$parent = dirname( $part );
		if ( ! is_dir( $parent ) && ! wp_mkdir_p( $parent ) ) {
			return new WP_Error( 'ferryman_files_mkdir', 'ディレクトリを作成できません: ' . $parent );
		}

		$data = base64_decode( (string) $res['data'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $data ) {
			$data = '';
		}

		$written = $this->write_part( $part, $offset, $data );
		if ( is_wp_error( $written ) ) {
			return $written;
		}

		$state['bytes_done'] = (int) $state['bytes_done'] + $bytes;

		if ( $eof ) {
			// mtime を本番に合わせてから rename でアトミック確定。
			$mtime = isset( $res['mtime'] ) ? (int) $res['mtime'] : 0;
			if ( $mtime > 0 ) {
				@touch( $part, $mtime ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_system_operations_touch -- mtimeを本番に合わせるだけなので失敗しても続行する。書き込み中のファイルは他の処理と同じくPHPのファイル関数で直接扱う。
			}
			$final = $this->finalize_part( $part, $dest );
			if ( is_wp_error( $final ) ) {
				return $final;
			}
			$state['file_index']  = (int) $state['file_index'] + 1;
			$state['file_offset'] = 0;
			$state['files_done']  = (int) $state['files_done'] + 1;
			if ( $state['file_index'] >= (int) $state['files_total'] ) {
				$state['status'] = 'done';
			}
		} else {
			$state['file_offset'] = $offset + $bytes;
		}

		return $this->session->update( $state );
	}

	/*
	 * =====================================================================
	 * 差分（純関数）
	 * =====================================================================
	 */

	/**
	 * 本番 manifest とローカル index を比較し、転送すべきファイルを決める。
	 *
	 * 追加・更新のみ（非破壊）。ローカルに無い / サイズ相違 / 本番が新しい →
	 * 転送。サイズ・mtime とも一致 → スキップ。ソースに無いローカルファイルは
	 * 一切触れない。純関数（FS に触れない）なのでスタンドアロンで単体テスト可能。
	 *
	 * @param array $remote      本番ファイル一覧 [{path,size,mtime}]。
	 * @param array $local_index ローカル index [ path => {size,mtime} ]。
	 * @return array { worklist:[{path,size,mtime}], skipped:int }。
	 */
	public static function diff_manifest( array $remote, array $local_index ) {
		$worklist = array();
		$skipped  = 0;
		foreach ( $remote as $entry ) {
			if ( ! isset( $entry['path'] ) ) {
				continue;
			}
			$path = (string) $entry['path'];
			// 防御的に再検証（本番側でも除外・検証済みだが二重防御）。
			if ( ! Ferryman_Paths::is_safe_relpath( $path ) || Ferryman_Paths::is_excluded( $path ) ) {
				continue;
			}
			$size  = (int) ( isset( $entry['size'] ) ? $entry['size'] : 0 );
			$mtime = (int) ( isset( $entry['mtime'] ) ? $entry['mtime'] : 0 );

			$transfer = self::needs_transfer( $path, $size, $mtime, $local_index );

			if ( $transfer ) {
				$worklist[] = array(
					'path'  => $path,
					'size'  => $size,
					'mtime' => $mtime,
				);
			} else {
				++$skipped;
			}
		}
		return array(
			'worklist' => $worklist,
			'skipped'  => $skipped,
		);
	}

	/**
	 * 相対パスを選択用のフォルダキーへ写像する。
	 *
	 * 年フォルダ（4桁数字）だけ 2 階層目まで展開し、それ以外は 1 階層目で集約する。
	 * uploads 直下のファイルは空文字（UI では「(直下)」と表示）。
	 * 戻り値はキー比較にのみ使い、パス結合には使わない。
	 *
	 * @param string $path uploads 相対パス。
	 * @return string グループキー。
	 */
	public static function group_key( $path ) {
		$path  = (string) $path;
		$slash = strpos( $path, '/' );
		if ( false === $slash ) {
			return ''; // uploads 直下のファイル。
		}
		$first = substr( $path, 0, $slash );
		$rest  = substr( $path, $slash + 1 );
		if ( 1 === preg_match( '/^\d{4}$/', $first ) ) {
			$slash2 = strpos( $rest, '/' );
			if ( false === $slash2 ) {
				return $first; // 年フォルダ直下のファイル。
			}
			return $first . '/' . substr( $rest, 0, $slash2 );
		}
		return $first;
	}

	/**
	 * 1 エントリを転送すべきか判定する（追加・更新のみの非破壊ルール）。
	 *
	 * ローカルに無い / サイズ相違 / 本番が新しい → 転送。サイズ一致かつ本番が
	 * 新しくない → スキップ。diff_manifest と summarize_groups で判定が食い違わ
	 * ないよう、両者からこれを呼ぶ。
	 *
	 * @param string $path        相対パス。
	 * @param int    $size        本番のサイズ。
	 * @param int    $mtime       本番の mtime。
	 * @param array  $local_index ローカル index [ path => {size,mtime} ]。
	 * @return bool
	 */
	private static function needs_transfer( $path, $size, $mtime, array $local_index ) {
		if ( ! isset( $local_index[ $path ] ) ) {
			return true;
		}
		$local = $local_index[ $path ];
		$lsize = (int) ( isset( $local['size'] ) ? $local['size'] : -1 );
		$lmt   = (int) ( isset( $local['mtime'] ) ? $local['mtime'] : 0 );
		return ! ( $lsize === $size && $mtime <= $lmt );
	}

	/**
	 * 本番 manifest をフォルダキー別に集計する。
	 *
	 * 選択の一覧に使うため、差分が 0 件のグループも結果に残す（UI 側でチェックを
	 * 外さないため）。除外パス・不正パスはグループを作らない。
	 *
	 * @param array $remote      本番ファイル一覧 [{path,size,mtime}]。
	 * @param array $local_index ローカル index [ path => {size,mtime} ]。
	 * @return array [{key,total,total_bytes,diff,diff_bytes}] をキー昇順で。
	 */
	public static function summarize_groups( array $remote, array $local_index ) {
		$groups = array();
		foreach ( $remote as $entry ) {
			if ( ! isset( $entry['path'] ) ) {
				continue;
			}
			$path = (string) $entry['path'];
			if ( ! Ferryman_Paths::is_safe_relpath( $path ) || Ferryman_Paths::is_excluded( $path ) ) {
				continue;
			}
			$size  = (int) ( isset( $entry['size'] ) ? $entry['size'] : 0 );
			$mtime = (int) ( isset( $entry['mtime'] ) ? $entry['mtime'] : 0 );
			$key   = self::group_key( $path );

			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array(
					'key'         => $key,
					'total'       => 0,
					'total_bytes' => 0,
					'diff'        => 0,
					'diff_bytes'  => 0,
				);
			}
			++$groups[ $key ]['total'];
			$groups[ $key ]['total_bytes'] += $size;

			if ( self::needs_transfer( $path, $size, $mtime, $local_index ) ) {
				++$groups[ $key ]['diff'];
				$groups[ $key ]['diff_bytes'] += $size;
			}
		}
		ksort( $groups, SORT_STRING );
		return array_values( $groups );
	}

	/**
	 * 選択されたフォルダキーに一致するエントリだけを残す。
	 *
	 * @param array $manifest 本番ファイル一覧 [{path,size,mtime}]。
	 * @param array $keys     選択キー。空配列なら全件（後方互換）。
	 * @return array
	 */
	public static function filter_by_groups( array $manifest, array $keys ) {
		if ( empty( $keys ) ) {
			return $manifest;
		}
		$allow = array();
		foreach ( $keys as $key ) {
			$allow[] = (string) $key;
		}
		$out = array();
		foreach ( $manifest as $entry ) {
			if ( ! isset( $entry['path'] ) ) {
				continue;
			}
			if ( in_array( self::group_key( (string) $entry['path'] ), $allow, true ) ) {
				$out[] = $entry;
			}
		}
		return $out;
	}

	/**
	 * 受け取った選択キーを検証する。
	 *
	 * キーはパス結合に使わず完全一致比較にしか使わないため、想定外の値が来ても
	 * 「どのグループにも一致しない」だけで害はない。それでも option へ保存する
	 * ため、制御文字・バックスラッシュ・`..`・過長を落としておく。
	 * 数値文字列キー（年フォルダ）が int にならないよう、重複除去に配列キーを
	 * 使わず in_array で行う。
	 *
	 * @param mixed $raw 受け取った値。
	 * @return array 文字列の配列。
	 */
	public static function sanitize_groups( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $value ) {
			if ( ! is_string( $value ) && ! is_int( $value ) ) {
				continue;
			}
			$key = (string) $value;
			if ( strlen( $key ) > 255 ) {
				continue;
			}
			if ( preg_match( '/[\x00-\x1f\\\\]/', $key ) || false !== strpos( $key, '..' ) ) {
				continue;
			}
			if ( ! in_array( $key, $out, true ) ) {
				$out[] = $key;
			}
		}
		return $out;
	}

	/*
	 * =====================================================================
	 * ファイル I/O ヘルパ
	 * =====================================================================
	 */

	/**
	 * チャンクを .part ファイルへ書き込む（offset 位置に上書き）。
	 *
	 * offset=0 は truncate（古い残骸を消す）。それ以外は seek して上書き。
	 * カーソルは書き込み成功後にのみ前進するため、応答消失で同一 offset を
	 * 再取得・再書き込みしても冪等。
	 *
	 * @param string $part   .part の絶対パス。
	 * @param int    $offset 書き込み開始位置。
	 * @param string $data   生バイト。
	 * @return true|WP_Error
	 */
	private function write_part( $part, $offset, $data ) {
		$fmode  = ( 0 === $offset ) ? 'wb' : 'c+b';
		$handle = fopen( $part, $fmode ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $handle ) {
			return new WP_Error( 'ferryman_files_part_open', '一時ファイルを開けません: ' . $part );
		}
		if ( $offset > 0 && -1 === fseek( $handle, $offset ) ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new WP_Error( 'ferryman_files_part_seek', '一時ファイルのシークに失敗しました。' );
		}
		$ok = ( '' === $data ) ? true : ( false !== fwrite( $handle, $data ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $ok ) {
			return new WP_Error( 'ferryman_files_part_write', '一時ファイルへの書き込みに失敗しました。' );
		}
		return true;
	}

	/**
	 * .part を最終パスへ rename でアトミック確定する。
	 *
	 * @param string $part .part の絶対パス。
	 * @param string $dest 最終絶対パス。
	 * @return true|WP_Error
	 */
	private function finalize_part( $part, $dest ) {
		// 既存があると環境により rename が失敗するため事前に削除。
		if ( file_exists( $dest ) ) {
			wp_delete_file( $dest );
		}
		if ( ! @rename( $part, $dest ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			return new WP_Error( 'ferryman_files_rename', 'ファイルの確定（rename）に失敗しました: ' . $dest );
		}
		return true;
	}

	/**
	 * 残った .part ファイルを掃除する（破棄時）。
	 *
	 * @return void
	 */
	private function cleanup_parts() {
		$state = $this->session->get();
		if ( ! $state || empty( $state['worklist'] ) ) {
			return;
		}
		$base = $this->local_uploads_basedir();
		foreach ( (array) $state['worklist'] as $file ) {
			if ( ! isset( $file['path'] ) ) {
				continue;
			}
			$part = Ferryman_Paths::safe_join( $base, $file['path'] . self::PART_SUFFIX );
			if ( false !== $part && Ferryman_Paths::within_base( $base, $part ) && is_file( $part ) ) {
				wp_delete_file( $part );
			}
		}
	}

	/*
	 * =====================================================================
	 * ヘルパ
	 * =====================================================================
	 */

	/**
	 * 保存済みの選択フォルダを返す。
	 *
	 * @return array
	 */
	private function saved_groups() {
		$saved = get_option( self::OPTION_GROUPS, array() );
		return self::sanitize_groups( $saved );
	}

	/**
	 * 選択フォルダを保存する。
	 *
	 * @param array $groups 選択キー。
	 * @return void
	 */
	private function save_groups( array $groups ) {
		update_option( self::OPTION_GROUPS, $groups, false );
	}

	/**
	 * ローカル uploads ベースディレクトリ（末尾スラッシュ無し）。
	 *
	 * @return string
	 */
	private function local_uploads_basedir() {
		$uploads = wp_upload_dir();
		$dir     = isset( $uploads['basedir'] ) ? $uploads['basedir'] : '';
		return untrailingslashit( wp_normalize_path( $dir ) );
	}

	/**
	 * ローカルの相対パスの stat を返す（安全・実ファイルのみ）。
	 *
	 * @param string $base ベース。
	 * @param string $rel  相対パス。
	 * @return array|null { size, mtime } または null。
	 */
	private function local_stat( $base, $rel ) {
		$abs = Ferryman_Paths::safe_join( $base, $rel );
		if ( false === $abs || ! Ferryman_Paths::within_base( $base, $abs ) ) {
			return null;
		}
		if ( is_link( $abs ) || ! is_file( $abs ) ) {
			return null;
		}
		return array(
			'size'  => (int) filesize( $abs ),
			'mtime' => (int) filemtime( $abs ),
		);
	}

	/**
	 * 本番の manifest を全ページ取得して 1 配列にまとめる。
	 *
	 * @param Ferryman_Ctrl_Client $client クライアント。
	 * @return array|WP_Error [{path,size,mtime}]。
	 */
	private function fetch_remote_manifest( Ferryman_Ctrl_Client $client ) {
		$all    = array();
		$cursor = null;
		$guard  = 0;
		do {
			$res = $this->remote_call(
				function () use ( $client, $cursor ) {
					return $client->files_list( $cursor, null );
				}
			);
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			$files = isset( $res['files'] ) && is_array( $res['files'] ) ? $res['files'] : array();
			foreach ( $files as $f ) {
				if ( isset( $f['path'] ) ) {
					$all[] = array(
						'path'  => (string) $f['path'],
						'size'  => (int) ( isset( $f['size'] ) ? $f['size'] : 0 ),
						'mtime' => (int) ( isset( $f['mtime'] ) ? $f['mtime'] : 0 ),
					);
				}
			}
			$cursor = isset( $res['next_cursor'] ) ? $res['next_cursor'] : null;
			$done   = ! empty( $res['done'] ) || null === $cursor;
			++$guard;
		} while ( ! $done && $guard < 100000 );

		return $all;
	}

	/**
	 * クライアント生成。
	 *
	 * @return Ferryman_Ctrl_Client
	 */
	private function client() {
		return new Ferryman_Ctrl_Client( $this->settings->get_remote_url(), $this->settings->get_secret() );
	}

	/**
	 * リトライ付きでリモート呼び出し（指数バックオフ）。403/400 は即時失敗。
	 *
	 * @param callable $callback 呼び出し。
	 * @param int      $attempts 最大試行回数。
	 * @return array|WP_Error
	 */
	private function remote_call( $callback, $attempts = 3 ) {
		$delay = 1;
		$res   = null;
		for ( $i = 0; $i < $attempts; $i++ ) {
			$res = call_user_func( $callback );
			if ( ! is_wp_error( $res ) ) {
				return $res;
			}
			$data   = $res->get_error_data();
			$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
			if ( 403 === $status || 400 === $status || 404 === $status ) {
				return $res; // 認証・リクエスト不正・不存在はリトライしない。
			}
			if ( $i < $attempts - 1 ) {
				sleep( $delay );
				$delay *= 2;
			}
		}
		return $res;
	}

	/**
	 * 権限・nonce 検証（DB 移行と同じ nonce を共用）。
	 *
	 * @return void
	 */
	private function guard() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => '権限がありません。' ), 403 );
		}
		check_ajax_referer( Ferryman_Ctrl_Migrator::NONCE_ACTION, 'nonce' );
	}
}
