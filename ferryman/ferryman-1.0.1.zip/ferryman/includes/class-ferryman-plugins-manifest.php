<?php
/**
 * プラグイン同期のマニフェスト（純関数）。
 *
 * get_plugins()の配列・active_plugins・update_plugins transientからマニフェストを組み立て、
 * 取り込んだJSONを検証し、取込元と取込先の差分を判定する。WPの関数には触れないため
 * tests/test-plugins-manifest.phpでスタンドアロン検証できる。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * マニフェストの組み立て・検証・差分判定。
 */
class Ferryman_Plugins_Manifest {

	const FORMAT = 'ferryman-plugins/1';

	// 入力検証（取込側）。slugはwordpress.orgの形式。fileは「dir/x.php」か「x.php」で、
	// 各セグメントはドットで始まらず、/・\・:・制御文字を含まない（../x.phpを弾く。
	// スペースや日本語を含む実在のフォルダ名は通す）。versionは印字可能なASCII。
	// $は末尾の改行を通してしまうため、終端は\zで判定する。
	const RE_SLUG    = '/^[a-z0-9-]{1,100}\z/';
	const RE_FILE    = '#^[^./\\\\:\x00-\x1f\x7f][^/\\\\:\x00-\x1f\x7f]*(?:/[^./\\\\:\x00-\x1f\x7f][^/\\\\:\x00-\x1f\x7f]*)?\.php\z#u';
	const RE_VERSION = '/^[\x20-\x7e]{1,50}\z/';

	const FILE_MAX_BYTES = 200;
	const NAME_MAX_BYTES = 200;

	// フォルダ名からslugを作れないとき（日本語だけのフォルダ名など）に入れるslug。
	// wordpress.orgで解決できないため、このときはwporgをfalse（手動扱い）にする。
	const FALLBACK_SLUG = 'plugin';

	// 差分の状態。
	const STATUS_MISSING        = 'missing';        // 未設置。
	const STATUS_NEEDS_ACTIVATE = 'needs_activate'; // 有効状態違い（要有効化）。
	const STATUS_LOCAL_ACTIVE   = 'local_active';   // 有効状態違い（取込先だけ有効）。
	const STATUS_VERSION_DIFF   = 'version_diff';   // 版違い。
	const STATUS_SAME           = 'same';           // 一致。
	const STATUS_LOCAL_ONLY     = 'local_only';     // 取込先のみ。

	/**
	 * マニフェストのエントリ配列を組み立てる。
	 *
	 * @param array        $plugins get_plugins()の戻り値（file => ヘッダ配列）。
	 * @param array        $active  active_plugins（fileの配列）。
	 * @param object|false $update  get_site_transient( 'update_plugins' )の戻り値。
	 * @return array エントリの配列（file昇順）。
	 */
	public static function build( array $plugins, array $active, $update ) {
		$active_map = array_fill_keys( array_filter( $active, 'is_string' ), true );
		$entries    = array();
		foreach ( $plugins as $file => $headers ) {
			$file    = (string) $file;
			$headers = is_array( $headers ) ? $headers : array();
			$hint    = self::update_hint( $file, $update );
			$slug    = $hint['slug'];
			$wporg   = $hint['wporg'];
			if ( ! preg_match( self::RE_SLUG, $slug ) ) {
				$slug = self::default_slug( $file );
			}
			if ( '' === $slug ) {
				$slug  = self::FALLBACK_SLUG;
				$wporg = false;
			}
			$entries[] = array(
				'file'    => $file,
				'slug'    => $slug,
				'name'    => isset( $headers['Name'] ) && '' !== (string) $headers['Name'] ? (string) $headers['Name'] : $file,
				'version' => isset( $headers['Version'] ) ? (string) $headers['Version'] : '',
				'active'  => isset( $active_map[ $file ] ),
				'wporg'   => $wporg,
			);
		}
		usort( $entries, array( __CLASS__, 'compare_file' ) );
		return $entries;
	}

	/**
	 * エントリ配列にメタ情報を付けてマニフェストにする。
	 *
	 * @param array  $entries      エントリ配列。
	 * @param string $site         取込元サイトのURL。
	 * @param string $wp_version   WPの版。
	 * @param string $generated_at 生成日時（ISO 8601）。
	 * @return array
	 */
	public static function wrap( array $entries, $site, $wp_version, $generated_at ) {
		return array(
			'format'       => self::FORMAT,
			'generated_at' => (string) $generated_at,
			'site'         => (string) $site,
			'wp_version'   => (string) $wp_version,
			'plugins'      => array_values( $entries ),
		);
	}

	/**
	 * 照合キー。fileのディレクトリ名（単一ファイルプラグインは拡張子を除いたファイル名）。
	 *
	 * wordpress.orgからのインストールはディレクトリ名がslugになるため、
	 * 「入っているか」はディレクトリの有無で判定する。
	 *
	 * @param string $file プラグインベースネーム。
	 * @return string
	 */
	public static function dir_key( $file ) {
		$file = (string) $file;
		$pos  = strpos( $file, '/' );
		if ( false === $pos ) {
			return preg_replace( '/\.php\z/', '', $file );
		}
		return substr( $file, 0, $pos );
	}

	/**
	 * JSONデコード済みの配列を検証し、正規化したマニフェストを返す。
	 *
	 * fileかslugが不正なエントリが1つでもあれば全体を拒否する（何番目かをメッセージに含める）。
	 * 未知のキーは落とす。メタ情報はなくてもよい。
	 *
	 * @param mixed $decoded json_decode( $json, true )の戻り値。
	 * @return array|WP_Error
	 */
	public static function validate( $decoded ) {
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'ferryman_plugins_bad_json', 'JSONの形式が不正です。' );
		}
		if ( ! isset( $decoded['format'] ) || self::FORMAT !== $decoded['format'] ) {
			return new WP_Error( 'ferryman_plugins_bad_format', 'Ferrymanのプラグイン一覧ではありません（formatが「' . self::FORMAT . '」ではない）。' );
		}
		if ( ! isset( $decoded['plugins'] ) || ! is_array( $decoded['plugins'] ) ) {
			return new WP_Error( 'ferryman_plugins_no_plugins', 'plugins配列がありません。' );
		}

		$entries = array();
		$index   = 0;
		foreach ( $decoded['plugins'] as $raw ) {
			++$index;
			$entry = self::validate_entry( $raw );
			if ( is_wp_error( $entry ) ) {
				return new WP_Error( 'ferryman_plugins_bad_entry', $index . '番目のエントリが不正です: ' . $entry->get_error_message() );
			}
			$entries[] = $entry;
		}
		usort( $entries, array( __CLASS__, 'compare_file' ) );

		return array(
			'format'       => self::FORMAT,
			'generated_at' => self::meta_string( $decoded, 'generated_at', 40 ),
			'site'         => self::meta_string( $decoded, 'site', 200 ),
			'wp_version'   => self::meta_string( $decoded, 'wp_version', 20 ),
			'plugins'      => $entries,
		);
	}

	/**
	 * 1エントリを検証し、正規化して返す。
	 *
	 * AJAXで1行ずつ受け取る入力の検証にも使う。fileとslugは不正なら拒否する。
	 * versionは表示と「同じ版」の選択にしか使わないため、形式が合わなければ拒否せず空文字（不明）にする。
	 * nameは表示専用のため、長すぎれば切り詰め、不正なUTF-8ならfileで代替する。
	 *
	 * @param mixed $raw エントリ（連想配列を期待）。
	 * @return array|WP_Error
	 */
	public static function validate_entry( $raw ) {
		if ( ! is_array( $raw ) ) {
			return new WP_Error( 'ferryman_plugins_entry_not_object', 'オブジェクトではありません。' );
		}
		$file = isset( $raw['file'] ) && is_string( $raw['file'] ) ? $raw['file'] : '';
		if ( strlen( $file ) > self::FILE_MAX_BYTES || ! preg_match( self::RE_FILE, $file ) ) {
			return new WP_Error( 'ferryman_plugins_bad_file', 'fileが不正です。' );
		}
		$slug = isset( $raw['slug'] ) && is_string( $raw['slug'] ) ? $raw['slug'] : '';
		if ( ! preg_match( self::RE_SLUG, $slug ) ) {
			return new WP_Error( 'ferryman_plugins_bad_slug', 'slugが不正です。' );
		}
		$version = isset( $raw['version'] ) && is_scalar( $raw['version'] ) ? (string) $raw['version'] : '';
		if ( ! preg_match( self::RE_VERSION, $version ) ) {
			$version = '';
		}
		$name = isset( $raw['name'] ) && is_string( $raw['name'] ) ? self::truncate_bytes( $raw['name'], self::NAME_MAX_BYTES ) : '';
		// 元から不正なUTF-8の場合はfileで代替する。
		if ( '' === $name || ! preg_match( '//u', $name ) ) {
			$name = $file;
		}
		$wporg = array_key_exists( 'wporg', $raw ) && is_bool( $raw['wporg'] ) ? $raw['wporg'] : null;

		return array(
			'file'    => $file,
			'slug'    => $slug,
			'name'    => $name,
			'version' => $version,
			'active'  => ! empty( $raw['active'] ),
			'wporg'   => $wporg,
		);
	}

	/**
	 * 取込元のマニフェストと取込先の一覧を突き合わせ、状態を付けた行を返す。
	 *
	 * 照合はfileの完全一致を優先し、なければディレクトリ名（dir_key）、それもなければ
	 * 取込元のslugと一致する取込先のディレクトリを探す（wordpress.orgからのインストールは
	 * slugがディレクトリ名になるため）。同じディレクトリに複数のプラグインファイルがある場合、
	 * ディレクトリ名とslugでの照合には先頭（file昇順）のものを使う。
	 * 取込元の行を取込元の順で並べ、その後ろに、どの取込元とも照合しなかった取込先の行を
	 * 取込先の順で並べる（取込先のファイルは1つも落とさない）。
	 *
	 * @param array $source_entries 取込元のエントリ配列（validate済み）。
	 * @param array $local_entries  取込先のエントリ配列（build済み）。
	 * @return array 行の配列。
	 */
	public static function diff( array $source_entries, array $local_entries ) {
		$local_by_file = array();
		$local_by_key  = array();
		foreach ( $local_entries as $local ) {
			$key = self::dir_key( $local['file'] );
			if ( ! isset( $local_by_key[ $key ] ) ) {
				$local_by_key[ $key ] = $local;
			}
			$local_by_file[ $local['file'] ] = $local;
		}

		$rows = array();
		$used = array();
		foreach ( $source_entries as $source ) {
			$key   = self::dir_key( $source['file'] );
			$local = null;
			if ( isset( $local_by_file[ $source['file'] ] ) ) {
				$local = $local_by_file[ $source['file'] ];
			} elseif ( isset( $local_by_key[ $key ] ) ) {
				$local = $local_by_key[ $key ];
			} elseif ( isset( $local_by_key[ $source['slug'] ] ) ) {
				$local = $local_by_key[ $source['slug'] ];
			}
			if ( null !== $local ) {
				$used[ $local['file'] ] = true;
			}
			$rows[] = self::diff_row( $key, $source, $local );
		}

		foreach ( $local_entries as $local ) {
			if ( isset( $used[ $local['file'] ] ) ) {
				continue;
			}
			$rows[] = array(
				'key'       => self::dir_key( $local['file'] ),
				'status'    => self::STATUS_LOCAL_ONLY,
				'source'    => null,
				'local'     => $local,
				'checkable' => false,
				'checked'   => false,
				'note'      => '',
			);
		}
		return $rows;
	}

	/**
	 * 取込元の1エントリの行を作る。
	 *
	 * @param string     $key    照合キー。
	 * @param array      $source 取込元のエントリ。
	 * @param array|null $local  取込先のエントリ（なければnull）。
	 * @return array
	 */
	private static function diff_row( $key, array $source, $local ) {
		$row = array(
			'key'       => $key,
			'status'    => '',
			'source'    => $source,
			'local'     => $local,
			'checkable' => false,
			'checked'   => false,
			'note'      => '',
		);

		if ( null === $local ) {
			$row['status'] = self::STATUS_MISSING;
			if ( true === $source['wporg'] ) {
				$row['checkable'] = true;
				$row['checked']   = true;
			} elseif ( null === $source['wporg'] ) {
				$row['checkable'] = true;
				$row['note']      = 'wordpress.orgにあるか不明。実行時に確認します';
			} else {
				$row['note'] = 'wordpress.org外。手動でインストールしてください';
			}
			return $row;
		}

		$version_differs = ( $source['version'] !== $local['version'] );
		if ( $source['active'] && ! $local['active'] ) {
			$row['status']    = self::STATUS_NEEDS_ACTIVATE;
			$row['checkable'] = true;
			$row['checked']   = true;
			if ( $version_differs ) {
				$row['note'] = '版も異なります（版はそろえません）';
			}
			return $row;
		}
		if ( ! $source['active'] && $local['active'] ) {
			$row['status'] = self::STATUS_LOCAL_ACTIVE;
			if ( $version_differs ) {
				$row['note'] = '版も異なります';
			}
			return $row;
		}
		$row['status'] = $version_differs ? self::STATUS_VERSION_DIFF : self::STATUS_SAME;
		return $row;
	}

	/**
	 * plugins_apiのversionsマップから使うzipのURLを選ぶ。
	 *
	 * 取込元と同じ版を優先する場合はその版のURL、なければdownload_link（最新）。
	 * どちらもwordpress.orgの配布URLでなければ使わない。
	 *
	 * @param array  $versions      版 => URL（plugins_apiのversions）。
	 * @param string $download_link 最新版のURL（plugins_apiのdownload_link）。
	 * @param string $version       取込元の版（空可）。
	 * @param bool   $prefer_same   取込元と同じ版を優先するか。
	 * @return array [ 'url' => string, 'version' => string, 'fallback' => bool ] urlが空なら候補なし。
	 */
	public static function pick_package( array $versions, $download_link, $version, $prefer_same ) {
		$version = (string) $version;
		$wanted  = ( $prefer_same && '' !== $version );

		if ( $wanted && isset( $versions[ $version ] ) && self::is_wporg_package_url( $versions[ $version ] ) ) {
			return array(
				'url'      => (string) $versions[ $version ],
				'version'  => $version,
				'fallback' => false,
			);
		}

		return array(
			'url'      => self::is_wporg_package_url( $download_link ) ? (string) $download_link : '',
			'version'  => '',
			'fallback' => $wanted,
		);
	}

	/**
	 * wordpress.orgの配布URLか。
	 *
	 * @param mixed $url URL。
	 * @return bool
	 */
	public static function is_wporg_package_url( $url ) {
		return is_string( $url ) && 0 === strpos( $url, 'https://downloads.wordpress.org/' );
	}

	/**
	 * メタ情報の文字列を取り出す（文字列以外は空文字、長さ制限あり）。
	 *
	 * @param array  $decoded マニフェスト。
	 * @param string $key     キー。
	 * @param int    $max     最大バイト数。
	 * @return string
	 */
	private static function meta_string( array $decoded, $key, $max ) {
		if ( ! isset( $decoded[ $key ] ) || ! is_string( $decoded[ $key ] ) ) {
			return '';
		}
		$value = self::truncate_bytes( $decoded[ $key ], $max );
		return preg_match( '//u', $value ) ? $value : '';
	}

	/**
	 * 最大バイト数で切り詰める。マルチバイト文字の途中で切れた場合は、壊れた末尾のバイト（最大3バイト）を落とす。
	 *
	 * 切り詰めが要らない文字列はそのまま返す。元から不正なUTF-8の文字列は不正なまま返すので、
	 * 判定は呼び出し側で行う。
	 *
	 * @param string $value 文字列。
	 * @param int    $max   最大バイト数。
	 * @return string
	 */
	private static function truncate_bytes( $value, $max ) {
		if ( strlen( $value ) <= $max ) {
			return $value;
		}
		$cut = substr( $value, 0, $max );
		for ( $i = 0; $i < 3 && ! preg_match( '//u', $cut ); $i++ ) { // phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed -- 1バイト削るたびにUTF-8として正しいかを判定し直す。
			$cut = substr( $cut, 0, -1 );
		}
		return $cut;
	}

	/**
	 * update_plugins transientからslugとwporgのヒントを取る。
	 *
	 * response（更新あり）とno_update（最新）の両方を見る。wordpress.org由来のエントリは
	 * idが「w.org/plugins/」で始まる。自前の更新サーバを持つプラグインはエントリはあるが
	 * idが違う（またはない）。どちらにもなければ不明（null）。
	 *
	 * @param string       $file   プラグインベースネーム。
	 * @param object|false $update transient。
	 * @return array [ 'slug' => string, 'wporg' => bool|null ]
	 */
	private static function update_hint( $file, $update ) {
		$hint = array(
			'slug'  => '',
			'wporg' => null,
		);
		if ( ! is_object( $update ) ) {
			return $hint;
		}
		foreach ( array( 'response', 'no_update' ) as $bucket ) {
			$list = isset( $update->{$bucket} ) && is_array( $update->{$bucket} ) ? $update->{$bucket} : array();
			if ( ! isset( $list[ $file ] ) ) {
				continue;
			}
			$item          = (array) $list[ $file ];
			$id            = isset( $item['id'] ) && is_string( $item['id'] ) ? $item['id'] : '';
			$hint['slug']  = isset( $item['slug'] ) && is_string( $item['slug'] ) ? $item['slug'] : '';
			$hint['wporg'] = ( 0 === strpos( $id, 'w.org/plugins/' ) );
			return $hint;
		}
		return $hint;
	}

	/**
	 * fileからslugを作る（transientにヒントがないとき）。
	 *
	 * ディレクトリ名を小文字化し、使えない文字はハイフンにする。作れなければ空文字を返す。
	 *
	 * @param string $file プラグインベースネーム。
	 * @return string
	 */
	private static function default_slug( $file ) {
		$slug = strtolower( self::dir_key( $file ) );
		$slug = preg_replace( '/[^a-z0-9-]+/', '-', $slug );
		$slug = trim( (string) $slug, '-' );
		$slug = substr( $slug, 0, 100 );
		return $slug;
	}

	/**
	 * usort用。fileの昇順。
	 *
	 * @param array $a エントリ。
	 * @param array $b エントリ。
	 * @return int
	 */
	private static function compare_file( array $a, array $b ) {
		return strcmp( $a['file'], $b['file'] );
	}
}
