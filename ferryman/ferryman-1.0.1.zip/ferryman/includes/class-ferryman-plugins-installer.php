<?php
/**
 * プラグイン同期のWP依存層。
 *
 * このサイトのマニフェストの組み立て、wordpress.orgからのインストール、有効化を行う。
 * 判定ロジックはFerryman_Plugins_Manifest（純関数）に置き、ここではWPのAPIを呼ぶだけにする。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * インストーラ。
 */
class Ferryman_Plugins_Installer {

	/**
	 * このサイトのマニフェストを組み立てる。
	 *
	 * @param bool $refresh update_plugins transientを更新してから判定するか。
	 *                      wordpress.org掲載の判定に使うため、書き出し・REST応答ではtrueにする。
	 *                      取込先の一覧（差分の右側）では不要なのでfalseでよい。
	 * @return array
	 */
	public function local_manifest( $refresh = true ) {
		$this->load_plugin_functions();
		if ( $refresh ) {
			// 12時間以内に確認済みならWP側でスキップされる。
			wp_update_plugins();
		}
		$entries = Ferryman_Plugins_Manifest::build(
			get_plugins(),
			(array) get_option( 'active_plugins', array() ),
			get_site_transient( 'update_plugins' )
		);
		return Ferryman_Plugins_Manifest::wrap( $entries, home_url(), get_bloginfo( 'version' ), wp_date( 'c' ) );
	}

	/**
	 * wordpress.orgから1プラグインをインストールする。
	 *
	 * zipのURLはslugからplugins_api()で解決したものだけを使う。
	 * 既にディレクトリがある場合は上書きしない（WP_Errorを返す）。
	 *
	 * @param string $slug        slug。
	 * @param string $version     取込元の版（空可）。
	 * @param bool   $prefer_same 取込元と同じ版を優先するか。
	 * @return array|WP_Error [ 'file' => string, 'version' => string, 'fallback' => bool ]
	 */
	public function install( $slug, $version, $prefer_same ) {
		$this->load_upgrader();

		$api = plugins_api(
			'plugin_information',
			array(
				'slug'   => $slug,
				'fields' => array(
					'versions'    => true,
					'sections'    => false,
					'reviews'     => false,
					'banners'     => false,
					'icons'       => false,
					'screenshots' => false,
				),
			)
		);
		if ( is_wp_error( $api ) ) {
			return new WP_Error( 'ferryman_plugins_not_found', 'wordpress.orgで見つかりません: ' . $api->get_error_message() );
		}
		$versions = isset( $api->versions ) ? (array) $api->versions : array();
		$link     = isset( $api->download_link ) ? (string) $api->download_link : '';
		$pick     = Ferryman_Plugins_Manifest::pick_package( $versions, $link, $version, $prefer_same );
		if ( '' === $pick['url'] ) {
			return new WP_Error( 'ferryman_plugins_no_package', 'wordpress.orgの配布URLが得られませんでした。' );
		}

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $pick['url'] );

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$errors = $skin->get_errors();
		if ( is_wp_error( $errors ) && $errors->has_errors() ) {
			return new WP_Error( 'ferryman_plugins_install_failed', $skin->get_error_messages() );
		}
		if ( true !== $result ) {
			// fs_connectに失敗するとfalseが返る（FTP資格情報が必要な環境など）。
			return new WP_Error( 'ferryman_plugins_fs_failed', 'ファイルシステムに書き込めませんでした（FTP資格情報が必要な環境ではインストールできません）。' );
		}

		$file      = $upgrader->plugin_info();
		$installed = '';
		if ( $file ) {
			$data      = get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false );
			$installed = isset( $data['Version'] ) ? (string) $data['Version'] : '';
		}
		return array(
			'file'     => $file ? (string) $file : '',
			'version'  => $installed,
			'fallback' => (bool) $pick['fallback'],
		);
	}

	/**
	 * プラグインを有効化する。
	 *
	 * activate_plugin()はプラグインの存在を検証し、想定外の出力や依存未充足ならWP_Errorを返す。
	 * プラグインの読み込みで致命的エラーが起きた場合はPHPごと落ちるため、呼び出し側（JS）が
	 * 壊れた応答として扱う。
	 *
	 * @param string $file プラグインベースネーム。
	 * @return array|WP_Error [ 'already' => bool ]
	 */
	public function activate( $file ) {
		$this->load_plugin_functions();
		if ( is_plugin_active( $file ) ) {
			return array( 'already' => true );
		}
		$result = activate_plugin( $file );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array( 'already' => false );
	}

	/**
	 * get_plugins()等を使えるようにする。
	 *
	 * @return void
	 */
	private function load_plugin_functions() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	}

	/**
	 * plugins_api()とPlugin_Upgraderを使えるようにする。
	 *
	 * @return void
	 */
	private function load_upgrader() {
		$this->load_plugin_functions();
		if ( ! function_exists( 'plugins_api' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		}
		if ( ! function_exists( 'request_filesystem_credentials' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( ! class_exists( 'Plugin_Upgrader' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}
	}
}
