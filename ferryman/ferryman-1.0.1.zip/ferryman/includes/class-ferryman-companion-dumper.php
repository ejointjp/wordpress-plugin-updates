<?php
/**
 * PHP 自前ダンプ（テーブル列挙・export カーソル・SQL ファイル生成）。
 * 変換は一切行わず、生データのみを扱う。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * テーブルの読み出しと SQL 整形。
 */
class Ferryman_Companion_Dumper {

	/**
	 * export 1 バッチで取得する行数。
	 */
	const BATCH_ROWS = 500;

	/**
	 * 接続文字コードを utf8mb4 に明示設定する。
	 *
	 * @return void
	 */
	public function ensure_charset() {
		global $wpdb;
		// 設定済みなら冪等。バイナリセーフのため明示設定する。
		$wpdb->query( 'SET NAMES utf8mb4' ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 接続の文字コード設定。コアAPIはない。
	}

	/**
	 * prefix 配下のテーブルが実際に使っている文字コードを返す。
	 *
	 * wp-config.php の DB_CHARSET は接続時の宣言でしかなく、テーブル実体の
	 * 文字コードとは一致しないことがある（utf8 宣言のまま utf8mb4 で作成された等）。
	 * 移行の安全性を左右するのは実体側なので、そちらを見て判定できるようにする。
	 *
	 * @return string 例 'utf8mb4'。複数混在時はカンマ区切り。取得不能時は空文字。
	 */
	public function table_charset() {
		global $wpdb;
		$like = $wpdb->esc_like( $wpdb->prefix ) . '%';
		$sql  = $wpdb->prepare(
			'SELECT DISTINCT CCSA.CHARACTER_SET_NAME AS charset
			 FROM information_schema.TABLES T
			 JOIN information_schema.COLLATION_CHARACTER_SET_APPLICABILITY CCSA
			   ON CCSA.COLLATION_NAME = T.TABLE_COLLATION
			 WHERE T.TABLE_SCHEMA = %s AND T.TABLE_NAME LIKE %s AND T.TABLE_TYPE = %s
			 ORDER BY charset',
			DB_NAME,
			$like,
			'BASE TABLE'
		);
		$rows = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。information_schemaの参照にコアAPIはなく、判定には最新の値が要る。
		if ( ! $rows ) {
			return '';
		}
		return implode( ',', array_map( 'strtolower', $rows ) );
	}

	/**
	 * $table_prefix で始まるテーブル名と概算行数を返す。
	 *
	 * @return array<int,array{name:string,rows:int}>
	 */
	public function list_tables() {
		global $wpdb;
		$prefix = $wpdb->prefix;
		$like   = $wpdb->esc_like( $prefix ) . '%';
		// information_schema は概算行数を持つ（高速）。
		$sql  = $wpdb->prepare(
			'SELECT TABLE_NAME AS name, TABLE_ROWS AS rows_count
			 FROM information_schema.TABLES
			 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s AND TABLE_TYPE = %s
			 ORDER BY TABLE_NAME',
			DB_NAME,
			$like,
			'BASE TABLE'
		);
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。information_schemaの参照にコアAPIはなく、判定には最新の値が要る。
		$out  = array();
		if ( $rows ) {
			foreach ( $rows as $r ) {
				$out[] = array(
					'name' => $r['name'],
					'rows' => (int) $r['rows_count'],
				);
			}
		}
		return $out;
	}

	/**
	 * テーブル名が prefix 配下に存在するか検証する。
	 *
	 * @param string $table テーブル名。
	 * @return bool
	 */
	public function is_valid_table( $table ) {
		global $wpdb;
		if ( 0 !== strpos( $table, $wpdb->prefix ) ) {
			return false;
		}
		foreach ( $this->list_tables() as $t ) {
			if ( $t['name'] === $table ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * SHOW CREATE TABLE の結果を返す。
	 *
	 * @param string $table テーブル名。
	 * @return string
	 */
	public function get_create_sql( $table ) {
		global $wpdb;
		$row = $wpdb->get_row( 'SHOW CREATE TABLE `' . $this->ident( $table ) . '`', ARRAY_N ); // phpcs:ignore WordPress.DB
		return ( $row && isset( $row[1] ) ) ? (string) $row[1] : '';
	}

	/**
	 * カラム名一覧（テーブル定義順）を返す。
	 *
	 * @param string $table テーブル名。
	 * @return string[]
	 */
	public function get_columns( $table ) {
		global $wpdb;
		$cols = $wpdb->get_results( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '`', ARRAY_A ); // phpcs:ignore WordPress.DB
		$out  = array();
		if ( $cols ) {
			foreach ( $cols as $c ) {
				$out[] = $c['Field'];
			}
		}
		return $out;
	}

	/**
	 * 生成カラム（GENERATED / VIRTUAL / STORED）の名前一覧を返す。
	 *
	 * 生成列は値を INSERT できない（strict mode でエラー）ため、書き込み対象から外す。
	 *
	 * @param string $table テーブル名。
	 * @return string[]
	 */
	public function get_generated_columns( $table ) {
		global $wpdb;
		$cols = $wpdb->get_results( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '`', ARRAY_A ); // phpcs:ignore WordPress.DB
		$out  = array();
		if ( $cols ) {
			foreach ( $cols as $c ) {
				$extra = isset( $c['Extra'] ) ? strtoupper( $c['Extra'] ) : '';
				if ( false !== strpos( $extra, 'GENERATED' ) ) {
					$out[] = $c['Field'];
				}
			}
		}
		return $out;
	}

	/**
	 * 単一カラムの主キー名を返す。複合 PK / PK 無しは null。
	 *
	 * @param string $table テーブル名。
	 * @return string|null
	 */
	public function get_primary_key( $table ) {
		global $wpdb;
		$keys = $wpdb->get_results( 'SHOW KEYS FROM `' . $this->ident( $table ) . '` WHERE Key_name = "PRIMARY"', ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $keys || count( $keys ) !== 1 ) {
			return null; // 無し or 複合。
		}
		return $keys[0]['Column_name'];
	}

	/**
	 * カーソル比較・整列に使う PK 式を返す。
	 *
	 * 数値 PK はそのまま（MySQL が数値比較）。文字列 PK は BINARY で包み、
	 * 大文字小文字を区別しない照合順序による行スキップ（WHERE pk > x と ORDER BY の不一致）を防ぐ。
	 *
	 * @param string $table テーブル名。
	 * @param string $pk    主キーカラム名。
	 * @return string
	 */
	public function pk_expr( $table, $pk ) {
		$col = '`' . $this->ident( $pk ) . '`';
		return $this->is_numeric_pk( $table, $pk ) ? $col : 'BINARY ' . $col;
	}

	/**
	 * PK が数値型か。
	 *
	 * @param string $table テーブル名。
	 * @param string $pk    主キーカラム名。
	 * @return bool
	 */
	public function is_numeric_pk( $table, $pk ) {
		global $wpdb;
		$row  = $wpdb->get_row( $wpdb->prepare( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '` LIKE %s', $wpdb->esc_like( $this->ident( $pk ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$type = ( $row && isset( $row['Type'] ) ) ? strtolower( $row['Type'] ) : '';
		return (bool) preg_match( '/^(tinyint|smallint|mediumint|int|integer|bigint|decimal|dec|numeric|fixed|float|double|real|bit|year)\b/', $type );
	}

	/**
	 * 行数を返す。
	 *
	 * @param string $table テーブル名。
	 * @return int
	 */
	public function count_rows( $table ) {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . $this->ident( $table ) . '`' ); // phpcs:ignore WordPress.DB
	}

	/**
	 * export チャンクを取得する。
	 *
	 * セル値は base64（NULL は JSON null）でバイナリセーフに返す。
	 *
	 * @param string     $table       テーブル名。
	 * @param array|null $cursor      { last_pk } または { offset }。null は先頭。
	 * @param int        $limit_bytes 1 チャンクの目安バイト数。
	 * @return array チャンク（table, create_sql, columns, rows, next_cursor, done）。
	 */
	public function export_chunk( $table, $cursor, $limit_bytes ) {
		global $wpdb;
		$this->ensure_charset();

		$ident       = $this->ident( $table );
		$columns     = $this->get_columns( $table );
		$pk          = $this->get_primary_key( $table );
		$is_first    = empty( $cursor );
		$rows_out    = array();
		$bytes       = 0;
		$next_cursor = null;
		$done        = false;

		if ( $pk ) {
			$pk_expr = $this->pk_expr( $table, $pk );
			$last_pk = ( $cursor && isset( $cursor['last_pk'] ) ) ? $cursor['last_pk'] : null;
			while ( true ) {
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- テーブル名とPK列はident()でバッククォートを除いてから囲んだ識別子。値は%s/%dで渡す。
				if ( null === $last_pk ) {
					$sql = $wpdb->prepare(
						"SELECT * FROM `$ident` ORDER BY {$pk_expr} ASC LIMIT %d",
						self::BATCH_ROWS
					);
				} else {
					$sql = $wpdb->prepare(
						"SELECT * FROM `$ident` WHERE {$pk_expr} > %s ORDER BY {$pk_expr} ASC LIMIT %d",
						$last_pk,
						self::BATCH_ROWS
					);
				}
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$batch = $wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。テーブルの全行を移行用に読み出すため、コアAPIもキャッシュも使えない。
				if ( empty( $batch ) ) {
					$done = true;
					break;
				}
				$pk_index = array_search( $pk, $columns, true );
				foreach ( $batch as $row ) {
					$rows_out[] = $this->encode_row( $row, $bytes );
					$last_pk    = $row[ $pk_index ];
				}
				if ( count( $batch ) < self::BATCH_ROWS ) {
					$done = true;
					break;
				}
				if ( $bytes >= $limit_bytes ) {
					break;
				}
			}
			if ( ! $done ) {
				$next_cursor = array(
					'table'   => $table,
					'last_pk' => $last_pk,
				);
			}
		} else {
			// PK 無し → OFFSET フォールバック。
			$offset = ( $cursor && isset( $cursor['offset'] ) ) ? (int) $cursor['offset'] : 0;
			while ( true ) {
				$sql   = $wpdb->prepare(
					"SELECT * FROM `$ident` LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- テーブル名はident()でバッククォートを除いてから囲んだ識別子。
					self::BATCH_ROWS,
					$offset
				);
				$batch = $wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。テーブルの全行を移行用に読み出すため、コアAPIもキャッシュも使えない。
				if ( empty( $batch ) ) {
					$done = true;
					break;
				}
				foreach ( $batch as $row ) {
					$rows_out[] = $this->encode_row( $row, $bytes );
					++$offset;
				}
				if ( count( $batch ) < self::BATCH_ROWS ) {
					$done = true;
					break;
				}
				if ( $bytes >= $limit_bytes ) {
					break;
				}
			}
			if ( ! $done ) {
				$next_cursor = array(
					'table'  => $table,
					'offset' => $offset,
				);
			}
		}

		return array(
			'table'       => $table,
			'create_sql'  => $is_first ? $this->get_create_sql( $table ) : '',
			'columns'     => $columns,
			'rows'        => $rows_out,
			'next_cursor' => $next_cursor,
			'done'        => $done,
		);
	}

	/**
	 * 行をエンコードする（NULL は null、それ以外は base64）。累積バイトを加算。
	 *
	 * @param array $row    ARRAY_N の行。
	 * @param int   $bytes  累積バイト（参照渡しで加算）。
	 * @return array
	 */
	private function encode_row( $row, &$bytes ) {
		$out = array();
		foreach ( $row as $cell ) {
			if ( null === $cell ) {
				$out[] = null;
			} else {
				$bytes += strlen( $cell );
				$out[]  = base64_encode( $cell ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
			}
		}
		return $out;
	}

	/*
	 * ---------------------------------------------------------------------
	 * バックアップ用 SQL ファイル生成
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 1 テーブルを SQL（DROP/CREATE + INSERT）としてストリーム書き出しする。
	 *
	 * @param string   $table  テーブル名。
	 * @param resource $handle 書き込み先ファイルハンドル。
	 * @return void
	 */
	public function write_table_sql( $table, $handle ) {
		global $wpdb;
		$this->ensure_charset();
		$ident = $this->ident( $table );

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- ダンプは大きくなるため、全体をメモリに載せるWP_Filesystem::put_contents()ではなく呼び出し元が開いたストリームへ逐次書き込む。
		fwrite( $handle, "\n-- ----------------------------\n" );
		fwrite( $handle, "-- Table: `{$table}`\n" );
		fwrite( $handle, "-- ----------------------------\n" );
		fwrite( $handle, "DROP TABLE IF EXISTS `{$table}`;\n" );
		fwrite( $handle, $this->get_create_sql( $table ) . ";\n\n" );

		$columns   = $this->get_columns( $table );
		$generated = $this->get_generated_columns( $table );
		// 生成列は INSERT 対象から除外する（インデックスで管理）。
		$skip       = array();
		$col_idents = array();
		foreach ( $columns as $i => $c ) {
			if ( in_array( $c, $generated, true ) ) {
				$skip[ $i ] = true;
				continue;
			}
			$col_idents[] = '`' . $this->ident( $c ) . '`';
		}
		$col_sql = implode( ', ', $col_idents );
		$pk      = $this->get_primary_key( $table );
		$pk_expr = $pk ? $this->pk_expr( $table, $pk ) : '';
		$last_pk = null;
		$offset  = 0;

		while ( true ) {
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- テーブル名とPK列はident()でバッククォートを除いてから囲んだ識別子。値は%s/%dで渡す。
			if ( $pk ) {
				if ( null === $last_pk ) {
					$sql = $wpdb->prepare( "SELECT * FROM `$ident` ORDER BY {$pk_expr} ASC LIMIT %d", self::BATCH_ROWS );
				} else {
					$sql = $wpdb->prepare( "SELECT * FROM `$ident` WHERE {$pk_expr} > %s ORDER BY {$pk_expr} ASC LIMIT %d", $last_pk, self::BATCH_ROWS );
				}
			} else {
				$sql = $wpdb->prepare( "SELECT * FROM `$ident` LIMIT %d OFFSET %d", self::BATCH_ROWS, $offset );
			}
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$batch = $wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。テーブルの全行を移行用に読み出すため、コアAPIもキャッシュも使えない。
			if ( empty( $batch ) ) {
				break;
			}
			$pk_index = $pk ? array_search( $pk, $columns, true ) : false;
			foreach ( $batch as $row ) {
				$values = array();
				foreach ( $row as $i => $cell ) {
					if ( isset( $skip[ $i ] ) ) {
						continue; // 生成列は書き出さない。
					}
					if ( null === $cell ) {
						$values[] = 'NULL';
					} else {
						$values[] = $wpdb->prepare( '%s', $cell );
					}
				}
				fwrite( $handle, "INSERT INTO `{$table}` ({$col_sql}) VALUES (" . implode( ', ', $values ) . ");\n" );
				if ( false !== $pk_index ) {
					$last_pk = $row[ $pk_index ];
				}
				++$offset;
			}
			if ( count( $batch ) < self::BATCH_ROWS ) {
				break;
			}
		}
		fwrite( $handle, "\n" );
		// phpcs:enable WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
	}

	/**
	 * 識別子（テーブル名・カラム名）からバッククォートを除去してサニタイズする。
	 *
	 * @param string $name 識別子。
	 * @return string
	 */
	private function ident( $name ) {
		return str_replace( '`', '', (string) $name );
	}
}
