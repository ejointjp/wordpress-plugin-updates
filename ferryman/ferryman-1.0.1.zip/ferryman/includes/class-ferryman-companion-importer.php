<?php
/**
 * 受け取った生データを変換せずそのまま本番 DB へ書き込む。
 * 一時テーブルに書き込み、finalize で RENAME 切替する（中断時の半壊を防ぐ）。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * raw import（一時テーブルへ REPLACE INTO → finalize でアトミック切替）。
 */
class Ferryman_Companion_Importer {

	/**
	 * チャンク連番の保持期間（秒）。移行完了まで十分な長さ。
	 */
	const SEQ_TTL = 604800; // 7日。

	/**
	 * ダンパー（テーブル検証・カラム取得に流用）。
	 *
	 * @var Ferryman_Companion_Dumper
	 */
	private $dumper;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Companion_Dumper $dumper ダンパー。
	 */
	public function __construct( Ferryman_Companion_Dumper $dumper ) {
		$this->dumper = $dumper;
	}

	/**
	 * 1 チャンクを一時テーブルへ import する。
	 *
	 * @param string $table      テーブル名。
	 * @param string $create_sql テーブル最初のチャンクのみ非空（一時テーブル準備に使用）。
	 * @param array  $columns    カラム名一覧。
	 * @param array  $rows       行（セルは base64 / NULL は null）。
	 * @param string $session_id セッション ID（連番 dedup 用。空なら dedup 無効）。
	 * @param int    $chunk_seq  テーブル単位の単調増加チャンク連番（0 なら dedup 無効）。
	 * @return array|WP_Error { written:int, skipped?:bool }。
	 */
	public function import( $table, $create_sql, array $columns, array $rows, $session_id = '', $chunk_seq = 0 ) {
		global $wpdb;

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		}
		$wpdb->query( 'SET NAMES utf8mb4' ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 接続の文字コード設定。コアAPIはない。

		$ident = $this->validate( $table );
		if ( is_wp_error( $ident ) ) {
			return $ident;
		}
		$temp = $this->temp_name( $ident );

		// 連番による重複再送の検出。応答消失や再開で同一チャンクが再送された
		// 場合、PK の無いテーブルでは REPLACE が INSERT 化して重複するため、
		// 適用済み連番以下なら一時テーブルの準備・書き込みを一切行わず冪等に返す。
		$dedup = ( '' !== (string) $session_id && (int) $chunk_seq > 0 );
		if ( $dedup && (int) $chunk_seq <= $this->applied_seq( $session_id, $ident ) ) {
			return array(
				'written' => 0,
				'skipped' => true,
			);
		}

		// 先頭チャンク（create_sql あり）なら一時テーブルを用意する。
		if ( '' !== (string) $create_sql ) {
			$prepared = $this->prepare_temp_table( $ident, $create_sql );
			if ( is_wp_error( $prepared ) ) {
				return $prepared;
			}
		}

		if ( empty( $rows ) ) {
			if ( $dedup ) {
				$this->record_seq( $session_id, $ident, (int) $chunk_seq );
			}
			return array( 'written' => 0 );
		}
		if ( empty( $columns ) ) {
			return new WP_Error( 'ferryman_import_no_columns', 'カラム指定がありません。', array( 'status' => 400 ) );
		}

		// 生成列（GENERATED）は INSERT できないため書き込み対象から外す。
		$generated  = $this->dumper->get_generated_columns( $ident );
		$skip       = array();
		$col_idents = array();
		foreach ( $columns as $i => $c ) {
			if ( in_array( $c, $generated, true ) ) {
				$skip[ $i ] = true;
				continue;
			}
			$col_idents[] = '`' . str_replace( '`', '', $c ) . '`';
		}
		$col_sql = implode( ', ', $col_idents );

		// VALUES 句を組み立てる（NULL はリテラル、それ以外は prepare で安全にエスケープ）。
		$tuples = array();
		foreach ( $rows as $row ) {
			$cells = array();
			foreach ( $row as $i => $cell ) {
				if ( isset( $skip[ $i ] ) ) {
					continue; // 生成列セルは送らない。
				}
				if ( null === $cell ) {
					$cells[] = 'NULL';
				} else {
					$decoded = base64_decode( $cell, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
					if ( false === $decoded ) {
						$decoded = '';
					}
					$cells[] = $wpdb->prepare( '%s', $decoded );
				}
			}
			$tuples[] = '(' . implode( ', ', $cells ) . ')';
		}

		// 本物のテーブルには触れず、一時テーブルへ書く。
		$sql    = "REPLACE INTO `{$temp}` ({$col_sql}) VALUES " . implode( ', ', $tuples );
		$result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 値は1セルずつprepare('%s')済み、識別子はバッククォートを除いてから囲んでいる。一時テーブルへの一括書き込みにコアAPIはない。

		if ( false === $result ) {
			return new WP_Error(
				'ferryman_import_write',
				'DB 書き込みエラー: ' . $wpdb->last_error,
				array( 'status' => 500 )
			);
		}

		// 書き込み成功後に連番を記録する（以後の同一・過去連番の再送をスキップ）。
		if ( $dedup ) {
			$this->record_seq( $session_id, $ident, (int) $chunk_seq );
		}

		return array( 'written' => count( $rows ) );
	}

	/**
	 * (session_id, table) ごとの連番記録用 transient キー。
	 *
	 * @param string $session_id セッション ID。
	 * @param string $ident      テーブル名。
	 * @return string
	 */
	private function seq_key( $session_id, $ident ) {
		return 'ferryman_seq_' . md5( $session_id . '|' . $ident );
	}

	/**
	 * このテーブルで最後に適用したチャンク連番（未記録なら 0）。
	 *
	 * @param string $session_id セッション ID。
	 * @param string $ident      テーブル名。
	 * @return int
	 */
	private function applied_seq( $session_id, $ident ) {
		$v = get_transient( $this->seq_key( $session_id, $ident ) );
		return false === $v ? 0 : (int) $v;
	}

	/**
	 * チャンク連番を適用済みとして記録する。
	 *
	 * @param string $session_id セッション ID。
	 * @param string $ident      テーブル名。
	 * @param int    $seq        連番。
	 * @return void
	 */
	private function record_seq( $session_id, $ident, $seq ) {
		set_transient( $this->seq_key( $session_id, $ident ), (int) $seq, self::SEQ_TTL );
	}

	/**
	 * 一時テーブルを本番テーブルへアトミックに切り替える（セッション完了時）。
	 *
	 * @param string $table テーブル名。
	 * @return array|WP_Error
	 */
	public function finalize( $table ) {
		global $wpdb;
		$ident = $this->validate( $table );
		if ( is_wp_error( $ident ) ) {
			return $ident;
		}
		$temp = $this->temp_name( $ident );
		$old  = $ident . '_fmold';

		$temp_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $temp ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( ! $temp_exists ) {
			// 一時テーブルが無い = 既に切替済み（冪等に成功扱い）。
			return array(
				'finalized' => true,
				'note'      => 'no_temp',
			);
		}

		$wpdb->query( "DROP TABLE IF EXISTS `{$old}`" ); // phpcs:ignore WordPress.DB

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $ident ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( $exists ) {
			$wpdb->query( "RENAME TABLE `{$ident}` TO `{$old}`, `{$temp}` TO `{$ident}`" ); // phpcs:ignore WordPress.DB
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'ferryman_finalize_rename', 'テーブル切替失敗: ' . $wpdb->last_error, array( 'status' => 500 ) );
			}
			$wpdb->query( "DROP TABLE IF EXISTS `{$old}`" ); // phpcs:ignore WordPress.DB
		} else {
			$wpdb->query( "RENAME TABLE `{$temp}` TO `{$ident}`" ); // phpcs:ignore WordPress.DB
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'ferryman_finalize_rename', 'テーブル切替失敗: ' . $wpdb->last_error, array( 'status' => 500 ) );
			}
		}
		return array( 'finalized' => true );
	}

	/**
	 * 一時テーブルを削除する（push 中断・キャンセル時の掃除用）。
	 *
	 * 冪等。一時テーブルが無くても成功扱い（既に finalize 済み or 未作成）。
	 *
	 * @param string $table テーブル名。
	 * @return array|WP_Error
	 */
	public function drop_temp_table( $table ) {
		global $wpdb;
		$ident = $this->validate( $table );
		if ( is_wp_error( $ident ) ) {
			return $ident;
		}
		$temp = $this->temp_name( $ident );
		$wpdb->query( "DROP TABLE IF EXISTS `{$temp}`" ); // phpcs:ignore WordPress.DB
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_cleanup_drop', '一時テーブル削除失敗: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'dropped' => true );
	}

	/**
	 * テーブル名を検証して返す（prefix 配下＋安全な文字種）。
	 *
	 * @param string $table テーブル名。
	 * @return string|WP_Error
	 */
	private function validate( $table ) {
		global $wpdb;
		if ( 0 !== strpos( $table, $wpdb->prefix ) || ! preg_match( '/^[A-Za-z0-9_]+$/', $table ) ) {
			return new WP_Error( 'ferryman_import_bad_table', '不正なテーブル名は拒否します: ' . $table, array( 'status' => 400 ) );
		}
		return $table;
	}

	/**
	 * 一時テーブル名。
	 *
	 * @param string $ident テーブル名。
	 * @return string
	 */
	private function temp_name( $ident ) {
		return $ident . '_fmtmp';
	}

	/**
	 * 一時テーブルを用意する（DROP+CREATE）。元テーブルがあれば LIKE、無ければ create_sql。
	 *
	 * @param string $ident      テーブル名。
	 * @param string $create_sql CREATE TABLE 文。
	 * @return true|WP_Error
	 */
	private function prepare_temp_table( $ident, $create_sql ) {
		global $wpdb;
		$temp = $this->temp_name( $ident );

		$wpdb->query( "DROP TABLE IF EXISTS `{$temp}`" ); // phpcs:ignore WordPress.DB
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_temp_drop', '一時テーブル削除失敗: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $ident ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( $exists ) {
			$wpdb->query( "CREATE TABLE `{$temp}` LIKE `{$ident}`" ); // phpcs:ignore WordPress.DB
		} elseif ( '' !== (string) $create_sql ) {
			$wpdb->query( $this->rewrite_create_name( $create_sql, $ident, $temp ) ); // phpcs:ignore WordPress.DB
		} else {
			return new WP_Error( 'ferryman_temp_nocreate', '一時テーブルを作成できません: ' . $ident, array( 'status' => 400 ) );
		}
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_temp_create', '一時テーブル作成失敗: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return true;
	}

	/**
	 * CREATE TABLE 文の先頭テーブル名を一時テーブル名へ書き換える。
	 *
	 * @param string $create_sql CREATE 文。
	 * @param string $ident      元テーブル名。
	 * @param string $temp       一時テーブル名。
	 * @return string
	 */
	private function rewrite_create_name( $create_sql, $ident, $temp ) {
		return preg_replace(
			'/^(\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?)`' . preg_quote( $ident, '/' ) . '`/i',
			'${1}`' . $temp . '`',
			$create_sql,
			1
		);
	}
}
