<?php
/**
 * コンパニオン REST API（ferryman/v1）。
 * handshake / tables / export / import / backup / files / plugins を提供する。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST ルートの登録とハンドラ。
 */
class Ferryman_Companion_REST {

	/**
	 * 設定。
	 *
	 * @var Ferryman_Companion_Settings
	 */
	private $settings;

	/**
	 * 認証。
	 *
	 * @var Ferryman_Companion_Auth
	 */
	private $auth;

	/**
	 * ダンパー。
	 *
	 * @var Ferryman_Companion_Dumper
	 */
	private $dumper;

	/**
	 * インポーター。
	 *
	 * @var Ferryman_Companion_Importer
	 */
	private $importer;

	/**
	 * バックアップ。
	 *
	 * @var Ferryman_Companion_Backup
	 */
	private $backup;

	/**
	 * ファイルリーダ（uploads）。
	 *
	 * @var Ferryman_Companion_Files
	 */
	private $files;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Companion_Settings $settings 設定。
	 * @param Ferryman_Companion_Auth     $auth     認証。
	 */
	public function __construct( Ferryman_Companion_Settings $settings, Ferryman_Companion_Auth $auth ) {
		$this->settings = $settings;
		$this->auth     = $auth;
		$this->dumper   = new Ferryman_Companion_Dumper();
		$this->importer = new Ferryman_Companion_Importer( $this->dumper );
		$this->backup   = new Ferryman_Companion_Backup( $settings, $this->dumper );
		$this->files    = new Ferryman_Companion_Files();
	}

	/**
	 * ルート登録。
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/handshake',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_handshake' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, '' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/tables',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_tables' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'pull' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_export' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'pull' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_import' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'push' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/finalize',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_finalize' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'push' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/backup',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_backup' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'push' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/cleanup',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_cleanup' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'push' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/files/list',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_files_list' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'file_pull' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/files/get',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_files_get' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'file_pull' );
				},
			)
		);

		register_rest_route(
			FERRYMAN_NAMESPACE,
			'/plugins/list',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_plugins_list' ),
				'permission_callback' => function ( $request ) {
					return $this->auth->verify( $request, 'pull' );
				},
			)
		);
	}

	/**
	 * GET /handshake。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response
	 */
	public function handle_handshake( WP_REST_Request $request ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- RESTのコールバックとして他のハンドラと同じ引数を受け取る。
		global $wpdb;
		$this->settings->log( 'handshake', 'ok' );

		return new WP_REST_Response(
			array(
				'siteurl'         => get_option( 'siteurl' ),
				'home'            => get_option( 'home' ),
				'abspath'         => untrailingslashit( ABSPATH ),
				'table_prefix'    => $wpdb->prefix,
				'db_charset'      => defined( 'DB_CHARSET' ) && DB_CHARSET ? DB_CHARSET : $wpdb->charset,
				'table_charset'   => $this->dumper->table_charset(),
				'wp_version'      => get_bloginfo( 'version' ),
				'plugin_version'  => FERRYMAN_COMPANION_VERSION,
				'allow_pull'      => (bool) $this->settings->get( 'allow_pull' ),
				'allow_push'      => (bool) $this->settings->get( 'allow_push' ),
				'allow_file_pull' => (bool) $this->settings->get( 'allow_file_pull' ),
			),
			200
		);
	}

	/**
	 * POST /tables。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response
	 */
	public function handle_tables( WP_REST_Request $request ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- RESTのコールバックとして他のハンドラと同じ引数を受け取る。
		$this->settings->log( 'tables', 'ok' );
		return new WP_REST_Response(
			array( 'tables' => $this->dumper->list_tables() ),
			200
		);
	}

	/**
	 * POST /export。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_export( WP_REST_Request $request ) {
		$params      = $this->json_params( $request );
		$cursor      = isset( $params['cursor'] ) && is_array( $params['cursor'] ) ? $params['cursor'] : null;
		$limit_bytes = isset( $params['limit_bytes'] ) ? max( 65536, (int) $params['limit_bytes'] ) : 1048576;

		$table = $cursor && isset( $cursor['table'] ) ? $cursor['table'] : ( isset( $params['table'] ) ? $params['table'] : '' );
		if ( '' === $table || ! $this->dumper->is_valid_table( $table ) ) {
			$this->settings->log( 'export', 'error: invalid_table' );
			return new WP_Error( 'ferryman_export_bad_table', '無効なテーブルです: ' . $table, array( 'status' => 400 ) );
		}

		$chunk = $this->dumper->export_chunk( $table, $cursor, $limit_bytes );
		$this->settings->log( 'export', 'ok: ' . $table . ' (' . count( $chunk['rows'] ) . ' rows)' );
		return new WP_REST_Response( $chunk, 200 );
	}

	/**
	 * POST /import。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_import( WP_REST_Request $request ) {
		$params     = $this->json_params( $request );
		$table      = isset( $params['table'] ) ? (string) $params['table'] : '';
		$create     = isset( $params['create_sql'] ) ? (string) $params['create_sql'] : '';
		$columns    = isset( $params['columns'] ) && is_array( $params['columns'] ) ? $params['columns'] : array();
		$rows       = isset( $params['rows'] ) && is_array( $params['rows'] ) ? $params['rows'] : array();
		$session_id = isset( $params['session_id'] ) ? (string) $params['session_id'] : '';
		$chunk_seq  = isset( $params['chunk_seq'] ) ? (int) $params['chunk_seq'] : 0;

		if ( '' === $table ) {
			return new WP_Error( 'ferryman_import_no_table', 'テーブル名がありません。', array( 'status' => 400 ) );
		}

		$result = $this->importer->import( $table, $create, $columns, $rows, $session_id, $chunk_seq );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'import', 'error: ' . $result->get_error_message() );
			return $result;
		}
		if ( ! empty( $result['skipped'] ) ) {
			$this->settings->log( 'import', 'skip(重複連番 #' . $chunk_seq . '): ' . $table );
		} else {
			$this->settings->log( 'import', 'ok: ' . $table . ' (' . $result['written'] . ' rows)' );
		}
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /finalize。一時テーブルを本番テーブルへアトミックに切り替える。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_finalize( WP_REST_Request $request ) {
		$params = $this->json_params( $request );
		$table  = isset( $params['table'] ) ? (string) $params['table'] : '';
		if ( '' === $table ) {
			return new WP_Error( 'ferryman_finalize_no_table', 'テーブル名がありません。', array( 'status' => 400 ) );
		}

		$result = $this->importer->finalize( $table );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'finalize', 'error: ' . $result->get_error_message() );
			return $result;
		}
		$this->settings->log( 'finalize', 'ok: ' . $table );
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /cleanup。push 中断時に残った一時テーブルを削除する。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_cleanup( WP_REST_Request $request ) {
		$params = $this->json_params( $request );
		$table  = isset( $params['table'] ) ? (string) $params['table'] : '';
		if ( '' === $table ) {
			return new WP_Error( 'ferryman_cleanup_no_table', 'テーブル名がありません。', array( 'status' => 400 ) );
		}

		$result = $this->importer->drop_temp_table( $table );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'cleanup', 'error: ' . $result->get_error_message() );
			return $result;
		}
		$this->settings->log( 'cleanup', 'ok: ' . $table );
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /files/list。uploads 配下のファイルを相対パス昇順でページング列挙する。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_files_list( WP_REST_Request $request ) {
		$params = $this->json_params( $request );
		$cursor = isset( $params['cursor'] ) && is_string( $params['cursor'] ) ? $params['cursor'] : null;
		$limit  = isset( $params['limit'] ) ? (int) $params['limit'] : Ferryman_Companion_Files::PAGE_LIMIT;

		$result = $this->files->list_files( $cursor, $limit );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'files_list', 'error: ' . $result->get_error_message() );
			return $result;
		}
		$this->settings->log( 'files_list', 'ok: ' . count( $result['files'] ) . ' files' );
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /files/get。uploads 配下の 1 ファイルをバイト範囲で読み出す。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_files_get( WP_REST_Request $request ) {
		$params = $this->json_params( $request );
		$path   = isset( $params['path'] ) ? (string) $params['path'] : '';
		$offset = isset( $params['offset'] ) ? (int) $params['offset'] : 0;
		$limit  = isset( $params['limit_bytes'] ) ? (int) $params['limit_bytes'] : Ferryman_Companion_Files::MAX_CHUNK_BYTES;

		if ( '' === $path ) {
			return new WP_Error( 'ferryman_files_no_path', 'パスがありません。', array( 'status' => 400 ) );
		}

		$result = $this->files->read_file( $path, $offset, $limit );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'files_get', 'error: ' . $result->get_error_message() );
			return $result;
		}
		$this->settings->log( 'files_get', 'ok: ' . $path . ' (' . $result['bytes'] . ' bytes @ ' . $offset . ')' );
		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * POST /plugins/list。インストール済みプラグインのマニフェストを返す（プラグイン同期）。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response
	 */
	public function handle_plugins_list( WP_REST_Request $request ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- RESTのコールバックとして他のハンドラと同じ引数を受け取る。
		$installer = new Ferryman_Plugins_Installer();
		$manifest  = $installer->local_manifest();
		$this->settings->log( 'plugins_list', 'ok: ' . count( $manifest['plugins'] ) . ' plugins' );
		return new WP_REST_Response( $manifest, 200 );
	}

	/**
	 * POST /backup。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_backup( WP_REST_Request $request ) {
		$params = $this->json_params( $request );
		$tables = isset( $params['tables'] ) && is_array( $params['tables'] ) ? array_map( 'strval', $params['tables'] ) : array();

		$result = $this->backup->create( $tables );
		if ( is_wp_error( $result ) ) {
			$this->settings->log( 'backup', 'error: ' . $result->get_error_message() );
			return $result;
		}
		$this->settings->log( 'backup', 'ok: ' . count( $result['tables'] ) . ' tables (' . size_format( $result['size'] ) . ')' );
		// パスは内部用（本番側の絶対パス露出を防ぐ）。コントローラには backup_id とメタのみ返す。
		return new WP_REST_Response(
			array(
				'backup_id' => $result['backup_id'],
				'tables'    => $result['tables'],
				'size'      => $result['size'],
				'time'      => $result['time'],
			),
			200
		);
	}

	/**
	 * リクエストボディを JSON としてデコードして返す。
	 *
	 * @param WP_REST_Request $request リクエスト。
	 * @return array
	 */
	private function json_params( WP_REST_Request $request ) {
		$body = $request->get_body();
		if ( '' === trim( (string) $body ) ) {
			return array();
		}
		$decoded = json_decode( $body, true );
		return is_array( $decoded ) ? $decoded : array();
	}
}
