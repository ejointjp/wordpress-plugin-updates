<?php
/**
 * ファイル同期で使うパス安全化ヘルパ（両モード共通）。
 *
 * uploads basedir 相対のパスだけを受理し、ディレクトリトラバーサルや
 * シンボリックリンクによる basedir 外への脱出を防ぐ。セキュリティの要なので
 * 実装を 1 箇所に集約し、本番側リーダ・ローカル側ライタの双方から使う。
 * WordPress 関数に依存しない（スタンドアロンで単体テスト可能）。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * パス検証・結合の静的ユーティリティ。
 */
class Ferryman_Paths {

	/**
	 * 列挙・転送から除外するトップディレクトリ（push バックアップ置き場）。
	 */
	const EXCLUDED_TOP = 'ferryman-backups';

	/**
	 * 相対パスが安全か（文字列レベルの検証のみ。FS には触れない）。
	 *
	 * 受理: `2026/06/image.jpg` のような uploads 相対パス（スラッシュ区切り）。
	 * 拒否: 空 / NUL / バックスラッシュ / 先頭スラッシュ（絶対） / ドライブ`:` /
	 *       `.`・`..`・空セグメント（トラバーサルや `//`）。
	 *
	 * @param string $rel 相対パス。
	 * @return bool
	 */
	public static function is_safe_relpath( $rel ) {
		if ( ! is_string( $rel ) || '' === $rel ) {
			return false;
		}
		if ( false !== strpos( $rel, "\0" ) ) {
			return false; // NUL バイト。
		}
		if ( false !== strpos( $rel, '\\' ) ) {
			return false; // バックスラッシュ（Windows 区切り・難読化）。
		}
		if ( false !== strpos( $rel, ':' ) ) {
			return false; // ドライブレター・ストリーム。
		}
		if ( '/' === $rel[0] ) {
			return false; // 絶対パス。
		}
		foreach ( explode( '/', $rel ) as $segment ) {
			if ( '' === $segment || '.' === $segment || '..' === $segment ) {
				return false; // 空（//・末尾/）・カレント・親参照。
			}
		}
		return true;
	}

	/**
	 * 相対パスが除外対象（ferryman-backups 配下）か。
	 *
	 * @param string $rel 相対パス。
	 * @return bool
	 */
	public static function is_excluded( $rel ) {
		if ( ! is_string( $rel ) || '' === $rel ) {
			return true;
		}
		$top = explode( '/', $rel, 2 )[0];
		return self::EXCLUDED_TOP === $top;
	}

	/**
	 * base と相対パスを結合した絶対パス文字列を返す（FS 解決はしない）。
	 *
	 * 安全でない相対パス・除外対象なら false。実際に basedir 配下へ収まるかは
	 * within_base() で別途検証すること（シンボリックリンク脱出の検出）。
	 *
	 * @param string $base 基準ディレクトリ（絶対パス）。
	 * @param string $rel  相対パス。
	 * @return string|false
	 */
	public static function safe_join( $base, $rel ) {
		if ( ! self::is_safe_relpath( $rel ) || self::is_excluded( $rel ) ) {
			return false;
		}
		return rtrim( $base, '/' ) . '/' . $rel;
	}

	/**
	 * 絶対パスが base ディレクトリ配下に収まるか realpath で検証する。
	 *
	 * 対象が存在すれば対象自身を、存在しなければ（書き込み前など）最も近い
	 * 既存の祖先ディレクトリを realpath し、base 配下かを判定する。これにより
	 * シンボリックリンクで base 外へ逃げるケースを弾く。is_safe_relpath で
	 * `..` を排除済みのため、既存祖先が base 配下なら新規パスも base 配下。
	 *
	 * @param string $base base ディレクトリ（絶対パス）。
	 * @param string $abs  検証する絶対パス。
	 * @return bool
	 */
	public static function within_base( $base, $abs ) {
		$real_base = realpath( $base );
		if ( false === $real_base ) {
			return false;
		}
		$real_base_slash = rtrim( $real_base, '/' ) . '/';

		// 対象（または最も近い既存祖先）を探す。
		$check = $abs;
		while ( '' !== $check && ! file_exists( $check ) ) {
			$parent = dirname( $check );
			if ( $parent === $check ) {
				break; // ルート到達。
			}
			$check = $parent;
		}
		$real = realpath( $check );
		if ( false === $real ) {
			return false;
		}
		return $real === $real_base || 0 === strpos( rtrim( $real, '/' ) . '/', $real_base_slash );
	}
}
