<?php
/**
 * 本番側ファイルリーダ（uploads の列挙と読み出し）。
 * 変換は一切行わず、生バイトのみを base64 で返す。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * uploads 配下のファイル列挙とチャンク読み出し。
 */
class Ferryman_Companion_Files {

	/**
	 * list_files の 1 ページ最大件数。
	 */
	const PAGE_LIMIT = 2000;

	/**
	 * read_file の 1 チャンク最大バイト数（base64 化前）。
	 */
	const MAX_CHUNK_BYTES = 4194304; // 4MB。

	/**
	 * uploads ベースディレクトリ（末尾スラッシュ無し）を返す。
	 *
	 * @return string|WP_Error
	 */
	public function uploads_basedir() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			return new WP_Error( 'ferryman_files_uploads', 'uploads ディレクトリを取得できません: ' . $uploads['error'], array( 'status' => 500 ) );
		}
		return untrailingslashit( wp_normalize_path( $uploads['basedir'] ) );
	}

	/**
	 * uploads 配下のファイルを相対パス昇順でページングして返す。
	 *
	 * カーソル（最後に返した相対パス）より後ろを最大 PAGE_LIMIT 件返す。
	 * シンボリックリンクは辿らず、ferryman-backups は除外する。
	 *
	 * @param string|null $cursor 直前ページの最終相対パス（null で先頭から）。
	 * @param int         $limit  1 ページ件数。
	 * @return array|WP_Error { files:[{path,size,mtime}], next_cursor, done }。
	 */
	public function list_files( $cursor = null, $limit = self::PAGE_LIMIT ) {
		$base = $this->uploads_basedir();
		if ( is_wp_error( $base ) ) {
			return $base;
		}
		$limit  = max( 1, min( self::PAGE_LIMIT, (int) $limit ) );
		$cursor = is_string( $cursor ) ? $cursor : '';

		$all = array();
		$this->walk( $base, '', $all );
		sort( $all, SORT_STRING );

		$files = array();
		$last  = '';
		foreach ( $all as $rel ) {
			if ( '' !== $cursor && strcmp( $rel, $cursor ) <= 0 ) {
				continue; // カーソル以前はスキップ。
			}
			$full = $base . '/' . $rel;
			$size = @filesize( $full ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
			if ( false === $size ) {
				continue; // 列挙後に消えた等。
			}
			$files[] = array(
				'path'  => $rel,
				'size'  => (int) $size,
				'mtime' => (int) @filemtime( $full ), // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
			);
			$last    = $rel;
			if ( count( $files ) >= $limit ) {
				break;
			}
		}

		// last より後ろがまだ残っているか。
		$done = true;
		if ( '' !== $last ) {
			foreach ( $all as $rel ) {
				if ( strcmp( $rel, $last ) > 0 ) {
					$done = false;
					break;
				}
			}
		}

		return array(
			'files'       => $files,
			'next_cursor' => $done ? null : $last,
			'done'        => $done,
		);
	}

	/**
	 * 1 ファイルのバイト範囲を base64 で読み出す。
	 *
	 * @param string $rel    uploads 相対パス。
	 * @param int    $offset 開始バイト。
	 * @param int    $limit  最大読み出しバイト数（base64 化前）。
	 * @return array|WP_Error { path, offset, bytes, size, eof, mtime, data }。
	 */
	public function read_file( $rel, $offset = 0, $limit = self::MAX_CHUNK_BYTES ) {
		$base = $this->uploads_basedir();
		if ( is_wp_error( $base ) ) {
			return $base;
		}
		$abs = Ferryman_Paths::safe_join( $base, $rel );
		if ( false === $abs || ! Ferryman_Paths::within_base( $base, $abs ) ) {
			return new WP_Error( 'ferryman_files_bad_path', '不正なファイルパスです。', array( 'status' => 400 ) );
		}
		if ( is_link( $abs ) || ! is_file( $abs ) ) {
			return new WP_Error( 'ferryman_files_not_found', 'ファイルが見つかりません。', array( 'status' => 404 ) );
		}

		$size   = (int) filesize( $abs );
		$offset = max( 0, (int) $offset );
		$limit  = max( 1, min( self::MAX_CHUNK_BYTES, (int) $limit ) );

		$data = '';
		if ( $offset < $size ) {
			$handle = fopen( $abs, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( ! $handle ) {
				return new WP_Error( 'ferryman_files_open', 'ファイルを開けません。', array( 'status' => 500 ) );
			}
			if ( $offset > 0 && -1 === fseek( $handle, $offset ) ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				return new WP_Error( 'ferryman_files_seek', 'シークに失敗しました。', array( 'status' => 500 ) );
			}
			$data = (string) fread( $handle, $limit ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- 指定オフセットから1チャンクだけ読む。WP_Filesystemには範囲を指定した読み込みがない。
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		$bytes = strlen( $data );
		return array(
			'path'   => $rel,
			'offset' => $offset,
			'bytes'  => $bytes,
			'size'   => $size,
			'eof'    => ( $offset + $bytes >= $size ),
			'mtime'  => (int) @filemtime( $abs ), // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
			'data'   => base64_encode( $data ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		);
	}

	/**
	 * ディレクトリを再帰的に走査して相対ファイルパスを集める。
	 * シンボリックリンク（ファイル・ディレクトリ問わず）は辿らない。
	 *
	 * @param string $base    ベースディレクトリ。
	 * @param string $rel_dir 現在の相対ディレクトリ。
	 * @param array  $out     収集先（参照）。
	 * @return void
	 */
	private function walk( $base, $rel_dir, &$out ) {
		$dir     = '' === $rel_dir ? $base : $base . '/' . $rel_dir;
		$entries = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		if ( false === $entries ) {
			return;
		}
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			// トップ階層の除外ディレクトリ（push バックアップ）は丸ごとスキップ。
			if ( '' === $rel_dir && Ferryman_Paths::EXCLUDED_TOP === $entry ) {
				continue;
			}
			$rel  = '' === $rel_dir ? $entry : $rel_dir . '/' . $entry;
			$full = $base . '/' . $rel;
			if ( is_link( $full ) ) {
				continue; // シンボリックリンクは辿らない（脱出防止）。
			}
			if ( is_dir( $full ) ) {
				$this->walk( $base, $rel, $out );
			} elseif ( is_file( $full ) ) {
				$out[] = $rel;
			}
		}
	}
}
