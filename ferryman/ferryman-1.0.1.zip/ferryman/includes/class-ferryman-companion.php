<?php
/**
 * Ferryman Companion メインクラス（ブートストラップ）。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * コンパニオンの各コンポーネントを束ねるシングルトン。
 */
final class Ferryman_Companion {

	/**
	 * シングルトンインスタンス。
	 *
	 * @var Ferryman_Companion|null
	 */
	private static $instance = null;

	/**
	 * 設定。
	 *
	 * @var Ferryman_Companion_Settings
	 */
	public $settings;

	/**
	 * 認証。
	 *
	 * @var Ferryman_Companion_Auth
	 */
	public $auth;

	/**
	 * REST コントローラ。
	 *
	 * @var Ferryman_Companion_REST
	 */
	public $rest;

	/**
	 * 管理画面。
	 *
	 * @var Ferryman_Companion_Admin
	 */
	public $admin;

	/**
	 * インスタンス取得。
	 *
	 * @return Ferryman_Companion
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * コンストラクタ。
	 */
	private function __construct() {
		$this->settings = new Ferryman_Companion_Settings();
		$this->auth     = new Ferryman_Companion_Auth( $this->settings );
		$this->rest     = new Ferryman_Companion_REST( $this->settings, $this->auth );
		$this->admin    = new Ferryman_Companion_Admin( $this->settings );

		add_action( 'rest_api_init', array( $this->rest, 'register_routes' ) );

		// REST API を未ログインに閉じるプラグインがあっても Ferryman のルートだけは
		// permission_callback まで届かせる。他のフィルタより後に評価されるよう最遅で登録する。
		add_filter( 'rest_authentication_errors', array( $this->auth, 'allow_rest_authentication' ), PHP_INT_MAX );

		if ( is_admin() ) {
			$this->admin->hooks();
		}
	}
}
