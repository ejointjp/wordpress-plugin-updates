<?php
/**
 * コントローラ設定（本番 URL・秘密キー）の保持。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * 設定ストア。
 */
class Ferryman_Ctrl_Settings {

	const OPTION_SETTINGS = 'ferryman_ctrl_settings';

	/**
	 * 既定値。
	 *
	 * @return array
	 */
	private function defaults() {
		return array(
			'remote_url' => '', // 本番サイト URL（例 https://example.com）。
			'secret'     => '', // コンパニオンからコピーした秘密キー。
		);
	}

	/**
	 * 全設定を取得。
	 *
	 * @return array
	 */
	public function all() {
		$stored = get_option( self::OPTION_SETTINGS, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, $this->defaults() );
	}

	/**
	 * 単一設定値を取得。
	 *
	 * @param string $key           キー。
	 * @param mixed  $default_value 既定値。
	 * @return mixed
	 */
	public function get( $key, $default_value = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default_value;
	}

	/**
	 * 設定を部分更新。
	 *
	 * @param array $values 値。
	 * @return void
	 */
	public function update( array $values ) {
		$merged = array_merge( $this->all(), $values );
		update_option( self::OPTION_SETTINGS, $merged, false );
	}

	/**
	 * 本番 URL（末尾スラッシュ無し）。
	 *
	 * @return string
	 */
	public function get_remote_url() {
		return untrailingslashit( (string) $this->get( 'remote_url', '' ) );
	}

	/**
	 * 秘密キー。
	 *
	 * wp-config.php で FERRYMAN_CTRL_SECRET を定義していればそれを最優先で返す。
	 * 定数運用時は秘密キーが DB（wp_options）に載らない。
	 *
	 * @return string
	 */
	public function get_secret() {
		if ( $this->secret_is_constant() ) {
			return (string) FERRYMAN_CTRL_SECRET;
		}
		return (string) $this->get( 'secret', '' );
	}

	/**
	 * 秘密キーが wp-config 定数で固定されているか。
	 *
	 * @return bool
	 */
	public function secret_is_constant() {
		return defined( 'FERRYMAN_CTRL_SECRET' ) && '' !== (string) FERRYMAN_CTRL_SECRET;
	}

	/**
	 * 接続設定が揃っているか。
	 *
	 * @return bool
	 */
	public function is_configured() {
		return '' !== $this->get_remote_url() && '' !== $this->get_secret();
	}

	/**
	 * 秘密キーをマスキング表示する。
	 *
	 * @return string
	 */
	public function masked_secret() {
		$secret = $this->get_secret();
		$len    = strlen( $secret );
		if ( 0 === $len ) {
			return '';
		}
		if ( $len <= 8 ) {
			return str_repeat( '•', $len );
		}
		return substr( $secret, 0, 4 ) . str_repeat( '•', $len - 8 ) . substr( $secret, -4 );
	}
}
