<?php
/**
 * handshake メタから検索置換マップを構築する。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * 置換マップ生成。
 *
 * - フル URL（scheme 付き、http/https 両方）
 * - protocol-relative（//host）
 * - JSON エスケープ版（\/\/）
 * - 絶対パス（abspath）
 *
 * フル URL を protocol-relative より先に並べ、str_replace の部分一致衝突を防ぐ。
 */
class Ferryman_Ctrl_Replace_Map {

	/**
	 * 置換マップを構築する。
	 *
	 * @param array  $remote_meta handshake レスポンス（siteurl/home/abspath）。
	 * @param string $direction   'pull'（本番→ローカル） | 'push'（ローカル→本番）。
	 * @return array from => to の順序付き連想配列。
	 */
	public function build( array $remote_meta, $direction ) {
		$local  = array(
			'siteurl' => untrailingslashit( site_url() ),
			'home'    => untrailingslashit( home_url() ),
			'abspath' => untrailingslashit( wp_normalize_path( ABSPATH ) ),
		);
		$remote = array(
			'siteurl' => untrailingslashit( isset( $remote_meta['siteurl'] ) ? $remote_meta['siteurl'] : '' ),
			'home'    => untrailingslashit( isset( $remote_meta['home'] ) ? $remote_meta['home'] : '' ),
			'abspath' => untrailingslashit( isset( $remote_meta['abspath'] ) ? $remote_meta['abspath'] : '' ),
		);

		if ( 'pull' === $direction ) {
			$src = $remote;
			$dst = $local;
		} else {
			$src = $local;
			$dst = $remote;
		}

		$full  = array(); // フル URL（scheme 付き）。
		$rel   = array(); // protocol-relative。
		$paths = array(); // 絶対パス。

		foreach ( array( 'siteurl', 'home' ) as $k ) {
			$this->add_url_variants( $src[ $k ], $dst[ $k ], $full, $rel );
		}
		$this->add_path_variants( $src['abspath'], $dst['abspath'], $paths );

		// グループ順に統合（フル → protocol-relative → パス）。重複キーは先勝ち。
		$map = array();
		foreach ( array( $full, $rel, $paths ) as $group ) {
			foreach ( $group as $from => $to ) {
				if ( '' !== $from && $from !== $to && ! isset( $map[ $from ] ) ) {
					$map[ $from ] = $to;
				}
			}
		}
		return $map;
	}

	/**
	 * 人間可読の主要ペア（UI 表示用）。
	 *
	 * @param array  $remote_meta handshake メタ。
	 * @param string $direction   方向。
	 * @return array<int,array{from:string,to:string}>
	 */
	public function summary( array $remote_meta, $direction ) {
		$local  = array(
			'url'     => untrailingslashit( home_url() ),
			'abspath' => untrailingslashit( wp_normalize_path( ABSPATH ) ),
		);
		$remote = array(
			'url'     => untrailingslashit( isset( $remote_meta['home'] ) ? $remote_meta['home'] : '' ),
			'abspath' => untrailingslashit( isset( $remote_meta['abspath'] ) ? $remote_meta['abspath'] : '' ),
		);
		if ( 'pull' === $direction ) {
			return array(
				array(
					'from' => $remote['url'],
					'to'   => $local['url'],
				),
				array(
					'from' => $remote['abspath'],
					'to'   => $local['abspath'],
				),
			);
		}
		return array(
			array(
				'from' => $local['url'],
				'to'   => $remote['url'],
			),
			array(
				'from' => $local['abspath'],
				'to'   => $remote['abspath'],
			),
		);
	}

	/**
	 * URL ペアから変換エントリを生成する。
	 *
	 * @param string $from_url 変換元 URL。
	 * @param string $to_url   変換先 URL。
	 * @param array  $full     フル URL エントリ（参照）。
	 * @param array  $rel      protocol-relative エントリ（参照）。
	 * @return void
	 */
	private function add_url_variants( $from_url, $to_url, array &$full, array &$rel ) {
		if ( '' === $from_url || '' === $to_url ) {
			return;
		}

		// フル URL（そのまま）。
		$full[ $from_url ]               = $to_url;
		$full[ $this->esc( $from_url ) ] = $this->esc( $to_url );

		// scheme を入れ替えた変換元（http⇄https で保存されている場合に対応）。
		$swapped = $this->swap_scheme( $from_url );
		if ( $swapped !== $from_url ) {
			$full[ $swapped ]               = $to_url;
			$full[ $this->esc( $swapped ) ] = $this->esc( $to_url );
		}

		// protocol-relative。
		$from_rel = $this->strip_scheme( $from_url );
		$to_rel   = $this->strip_scheme( $to_url );
		if ( $from_rel !== $from_url || $to_rel !== $to_url ) {
			$rel[ $from_rel ]               = $to_rel;
			$rel[ $this->esc( $from_rel ) ] = $this->esc( $to_rel );
		}
	}

	/**
	 * パスペアから変換エントリを生成する。
	 *
	 * @param string $from_path 変換元パス。
	 * @param string $to_path   変換先パス。
	 * @param array  $paths     パスエントリ（参照）。
	 * @return void
	 */
	private function add_path_variants( $from_path, $to_path, array &$paths ) {
		if ( '' === $from_path || '' === $to_path || $from_path === $to_path ) {
			return;
		}
		$paths[ $from_path ]               = $to_path;
		$paths[ $this->esc( $from_path ) ] = $this->esc( $to_path );
	}

	/**
	 * スラッシュを JSON エスケープ（/ → \/）する。
	 *
	 * @param string $s 文字列。
	 * @return string
	 */
	private function esc( $s ) {
		return str_replace( '/', '\\/', $s );
	}

	/**
	 * scheme を除去して protocol-relative にする。
	 *
	 * @param string $url URL。
	 * @return string
	 */
	private function strip_scheme( $url ) {
		return preg_replace( '#^https?://#i', '//', $url );
	}

	/**
	 * http ⇄ https を入れ替える。
	 *
	 * @param string $url URL。
	 * @return string
	 */
	private function swap_scheme( $url ) {
		if ( 0 === stripos( $url, 'https://' ) ) {
			return 'http://' . substr( $url, 8 );
		}
		if ( 0 === stripos( $url, 'http://' ) ) {
			return 'https://' . substr( $url, 7 );
		}
		return $url;
	}
}
