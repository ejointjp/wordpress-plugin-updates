<?php
/**
 * 変換エンジン。interconnect/it の Search-Replace アルゴリズムを移植。
 * シリアライズを再帰的に解いて置換し、再シリアライズする。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * recursive_unserialize_replace。
 */
class Ferryman_Ctrl_Replacer {

	/**
	 * 1 セル分の値を置換する。
	 *
	 * @param mixed $value セル値（通常は文字列 / NULL）。
	 * @param array $map   置換マップ（from => to）。
	 * @param int   $count 置換回数（参照で加算）。
	 * @return mixed 置換後の値。
	 */
	public function replace_value( $value, array $map, &$count ) {
		$incomplete = false;
		return $this->recurse( $value, $map, $count, $incomplete );
	}

	/**
	 * 再帰置換本体。
	 *
	 * @param mixed $data       対象。
	 * @param array $map        置換マップ。
	 * @param int   $count      置換回数（参照）。
	 * @param bool  $incomplete 不完全クラス検出フラグ（参照）。
	 * @return mixed
	 */
	private function recurse( $data, $map, &$count, &$incomplete ) {
		// シリアライズ文字列。
		if ( is_string( $data ) && is_serialized( $data ) ) {
			// pullでは第三者が書き込める列（コメント本文など）の値も通るため、任意のクラスを
			// 復元しないようstdClassだけ許可する。ほかのクラスは不完全クラスになり、原文のまま残る。
			$unser = @unserialize( $data, array( 'allowed_classes' => array( 'stdClass' ) ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- シリアライズ値の中のURLを置換するために展開する。壊れた値は警告を抑えて原文のまま残す。
			// unserialize 失敗（かつ serialize(false) でもない）→ 壊さず温存。
			if ( false === $unser && ! $this->is_serialized_false( $data ) ) {
				return $data;
			}
			$nested_incomplete = false;
			$replaced          = $this->recurse( $unser, $map, $count, $nested_incomplete );
			// 不完全クラスを含む → 再シリアライズで壊れる恐れ。原文を温存。
			if ( $nested_incomplete ) {
				return $data;
			}
			$reser = @serialize( $replaced ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- 置換後の値を元の形式に戻す。失敗したら原文のまま残す。
			return ( false === $reser ) ? $data : $reser;
		}

		// 配列 → 各要素を再帰。
		if ( is_array( $data ) ) {
			$out = array();
			foreach ( $data as $key => $value ) {
				$out[ $key ] = $this->recurse( $value, $map, $count, $incomplete );
			}
			return $out;
		}

		// オブジェクト。
		if ( is_object( $data ) ) {
			// 不完全クラスは触らず温存（フラグを立てて親に伝播）。
			if ( $data instanceof __PHP_Incomplete_Class ) {
				$incomplete = true;
				return $data;
			}
			$clone = clone $data;
			foreach ( get_object_vars( $clone ) as $key => $value ) {
				$clone->$key = $this->recurse( $value, $map, $count, $incomplete );
			}
			return $clone;
		}

		// 通常文字列 → str_replace。
		if ( is_string( $data ) ) {
			return $this->replace_string( $data, $map, $count );
		}

		// int / float / bool / null はそのまま。
		return $data;
	}

	/**
	 * 文字列に置換マップを全ペア適用し、置換回数を加算する。
	 *
	 * @param string $str   文字列。
	 * @param array  $map   置換マップ。
	 * @param int    $count 置換回数（参照）。
	 * @return string
	 */
	private function replace_string( $str, $map, &$count ) {
		$result = $str;
		foreach ( $map as $from => $to ) {
			if ( '' === (string) $from ) {
				continue;
			}
			$n      = 0;
			$result = str_replace( $from, $to, $result, $n );
			$count += $n;
		}
		return $result;
	}

	/**
	 * serialize(false)（'b:0;'）かどうか。
	 *
	 * @param string $data 文字列。
	 * @return bool
	 */
	private function is_serialized_false( $data ) {
		return 'b:0;' === trim( $data );
	}
}
