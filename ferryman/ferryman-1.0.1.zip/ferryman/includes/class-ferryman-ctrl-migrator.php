<?php
/**
 * pull / push のオーケストレーション。admin-ajax でチャンクを反復ドライブする。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * 移行エンジン。
 */
class Ferryman_Ctrl_Migrator {

	const NONCE_ACTION = 'ferryman_ctrl_ajax';
	const CAPABILITY   = 'manage_options';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Ctrl_Settings
	 */
	private $settings;

	/**
	 * セッション。
	 *
	 * @var Ferryman_Ctrl_Session
	 */
	private $session;

	/**
	 * 置換マップビルダー。
	 *
	 * @var Ferryman_Ctrl_Replace_Map
	 */
	private $map_builder;

	/**
	 * 変換エンジン。
	 *
	 * @var Ferryman_Ctrl_Replacer
	 */
	private $replacer;

	/**
	 * ローカル DB。
	 *
	 * @var Ferryman_Ctrl_DB
	 */
	private $db;

	/**
	 * ローカルのテーブル実体の文字コード（遅延取得のキャッシュ）。
	 *
	 * @var string|null
	 */
	private $local_table_charset = null;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Ctrl_Settings $settings 設定。
	 */
	public function __construct( Ferryman_Ctrl_Settings $settings ) {
		$this->settings    = $settings;
		$this->session     = new Ferryman_Ctrl_Session();
		$this->map_builder = new Ferryman_Ctrl_Replace_Map();
		$this->replacer    = new Ferryman_Ctrl_Replacer();
		$this->db          = new Ferryman_Ctrl_DB();
	}

	/**
	 * ajax フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'wp_ajax_ferryman_test', array( $this, 'ajax_test' ) );
		add_action( 'wp_ajax_ferryman_tables', array( $this, 'ajax_tables' ) );
		add_action( 'wp_ajax_ferryman_start', array( $this, 'ajax_start' ) );
		add_action( 'wp_ajax_ferryman_step', array( $this, 'ajax_step' ) );
		add_action( 'wp_ajax_ferryman_status', array( $this, 'ajax_status' ) );
		add_action( 'wp_ajax_ferryman_cancel', array( $this, 'ajax_cancel' ) );
	}

	/**
	 * セッションアクセサ（admin から参照）。
	 *
	 * @return Ferryman_Ctrl_Session
	 */
	public function session() {
		return $this->session;
	}

	/*
	 * =====================================================================
	 * ajax ハンドラ
	 * =====================================================================
	 */

	/**
	 * 接続テスト（handshake）。
	 *
	 * @return void
	 */
	public function ajax_test() {
		$this->guard();
		$client    = $this->client();
		$handshake = $client->handshake();
		if ( is_wp_error( $handshake ) ) {
			wp_send_json_error( array( 'message' => $handshake->get_error_message() ) );
		}
		global $wpdb;
		$prefix_ok  = ( isset( $handshake['table_prefix'] ) && $handshake['table_prefix'] === $wpdb->prefix );
		$charset_ok = $this->charset_matches( $handshake );
		wp_send_json_success(
			array(
				'remote'     => $handshake,
				'local'      => array(
					'siteurl'       => site_url(),
					'home'          => home_url(),
					'abspath'       => untrailingslashit( wp_normalize_path( ABSPATH ) ),
					'table_prefix'  => $wpdb->prefix,
					'db_charset'    => $this->local_charset(),
					'table_charset' => $this->local_table_charset(),
				),
				'prefix_ok'  => $prefix_ok,
				'charset_ok' => $charset_ok,
			)
		);
	}

	/**
	 * テーブル一覧取得（方向に応じて本番 or ローカル）。
	 *
	 * @return void
	 */
	public function ajax_tables() {
		$this->guard();
		$direction = isset( $_POST['direction'] ) ? sanitize_key( wp_unslash( $_POST['direction'] ) ) : 'pull'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard()で検証済み。

		if ( 'push' === $direction ) {
			wp_send_json_success(
				array(
					'tables' => $this->db->list_tables(),
					'source' => 'local',
				)
			);
		}

		$client = $this->client();
		$res    = $client->tables();
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => 'テーブル一覧取得に失敗: ' . $res->get_error_message() ) );
		}
		wp_send_json_success(
			array(
				'tables' => $res['tables'],
				'source' => 'remote',
			)
		);
	}

	/**
	 * 移行開始。
	 *
	 * @return void
	 */
	public function ajax_start() {
		$this->guard();
		global $wpdb;

		// 二重起動防止: 進行中セッションがあれば拒否（同時実行による相互破壊を防ぐ）。
		$existing = $this->session->get();
		if ( $existing && isset( $existing['status'] ) && 'running' === $existing['status'] ) {
			wp_send_json_error( array( 'message' => '別の移行が進行中です。完了するか、移行画面で「破棄」してから開始してください。' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- guard()で検証済み。
		$direction = isset( $_POST['direction'] ) ? sanitize_key( wp_unslash( $_POST['direction'] ) ) : '';
		$mode      = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'run';
		if ( ! in_array( $direction, array( 'pull', 'push' ), true ) ) {
			wp_send_json_error( array( 'message' => '方向の指定が不正です。' ) );
		}
		if ( ! in_array( $mode, array( 'run', 'dryrun' ), true ) ) {
			$mode = 'run';
		}
		$tables = isset( $_POST['tables'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['tables'] ) ) : array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$tables = array_values( array_filter( array_unique( $tables ) ) );
		if ( empty( $tables ) ) {
			wp_send_json_error( array( 'message' => '対象テーブルが選択されていません。' ) );
		}

		$client    = $this->client();
		$handshake = $client->handshake();
		if ( is_wp_error( $handshake ) ) {
			wp_send_json_error( array( 'message' => '接続に失敗しました: ' . $handshake->get_error_message() ) );
		}

		// table_prefix 一致検証（MVP 非対応の不一致は中止）。
		if ( ! isset( $handshake['table_prefix'] ) || $handshake['table_prefix'] !== $wpdb->prefix ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						'table_prefix が一致しません（本番: %s / ローカル: %s）。MVP では非対応です。',
						isset( $handshake['table_prefix'] ) ? $handshake['table_prefix'] : '?',
						$wpdb->prefix
					),
				)
			);
		}

		// 方向許可。
		if ( 'pull' === $direction && empty( $handshake['allow_pull'] ) ) {
			wp_send_json_error( array( 'message' => '本番側で pull(export) が許可されていません。' ) );
		}
		if ( 'push' === $direction && empty( $handshake['allow_push'] ) ) {
			wp_send_json_error( array( 'message' => '本番側で push(import) が許可されていません。' ) );
		}

		// 置換マップ。
		$map = $this->map_builder->build( $handshake, $direction );

		// テーブルメタ・総行数。
		$tables_meta = array();
		$rows_total  = 0;
		if ( 'pull' === $direction ) {
			$remote_tables = $client->tables();
			if ( is_wp_error( $remote_tables ) ) {
				wp_send_json_error( array( 'message' => 'テーブル一覧取得に失敗: ' . $remote_tables->get_error_message() ) );
			}
			$index = array();
			foreach ( $remote_tables['tables'] as $t ) {
				$index[ $t['name'] ] = (int) $t['rows'];
			}
			foreach ( $tables as $t ) {
				$rows              = isset( $index[ $t ] ) ? $index[ $t ] : 0;
				$tables_meta[ $t ] = $rows;
				$rows_total       += $rows;
			}
		} else {
			foreach ( $tables as $t ) {
				if ( ! $this->db->is_valid_table( $t ) ) {
					wp_send_json_error( array( 'message' => 'ローカルに存在しないテーブルです: ' . $t ) );
				}
				$rows              = $this->db->count_rows( $t );
				$tables_meta[ $t ] = $rows;
				$rows_total       += $rows;
			}
		}

		// push 本番（run）はまずバックアップ。
		$backup_id = '';
		if ( 'push' === $direction && 'run' === $mode ) {
			$backup = $client->backup( $tables );
			if ( is_wp_error( $backup ) ) {
				wp_send_json_error( array( 'message' => 'バックアップに失敗したため中止しました: ' . $backup->get_error_message() ) );
			}
			$backup_id = isset( $backup['backup_id'] ) ? $backup['backup_id'] : '';
		}

		$warning = $this->charset_matches( $handshake ) ? '' : '警告: テーブルの文字コードが本番とローカルで異なります。';

		$state = $this->session->start(
			array(
				'direction'   => $direction,
				'mode'        => $mode,
				'tables'      => $tables,
				'tables_meta' => $tables_meta,
				'rows_total'  => $rows_total,
				'remote_meta' => $handshake,
				'map'         => $map,
				'backup_id'   => $backup_id,
				'message'     => $warning,
			)
		);

		wp_send_json_success(
			array(
				'progress' => $this->session->progress( $state ),
				'summary'  => $this->map_builder->summary( $handshake, $direction ),
				'warning'  => $warning,
			)
		);
	}

	/**
	 * 1 チャンク処理。
	 *
	 * @return void
	 */
	public function ajax_step() {
		$this->guard();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		}

		$state = $this->session->get();
		if ( null === $state || 'running' !== $state['status'] ) {
			wp_send_json_success( array( 'progress' => $state ? $this->session->progress( $state ) : null ) );
		}

		$table = $this->session->current_table( $state );
		if ( null === $table ) {
			$state = $this->session->update( array( 'status' => 'done' ) );
			wp_send_json_success( array( 'progress' => $this->session->progress( $state ) ) );
		}

		$result = ( 'pull' === $state['direction'] )
			? $this->step_pull( $state, $table )
			: $this->step_push( $state, $table );

		if ( is_wp_error( $result ) ) {
			$state = $this->session->update(
				array(
					'status'  => 'error',
					'message' => $result->get_error_message(),
				)
			);
			wp_send_json_error(
				array(
					'message'  => $result->get_error_message(),
					'progress' => $this->session->progress( $state ),
				)
			);
		}

		wp_send_json_success( array( 'progress' => $this->session->progress( $result ) ) );
	}

	/**
	 * 現在の進捗を返す（再開用）。
	 *
	 * @return void
	 */
	public function ajax_status() {
		$this->guard();
		$state = $this->session->get();
		wp_send_json_success( array( 'progress' => $state ? $this->session->progress( $state ) : null ) );
	}

	/**
	 * セッション破棄。
	 *
	 * @return void
	 */
	public function ajax_cancel() {
		$this->guard();
		$this->cleanup_temp_tables();
		$this->cleanup_remote_temp_tables();
		$this->session->clear();
		wp_send_json_success( array( 'message' => 'セッションを破棄しました。' ) );
	}

	/**
	 * 中断・破棄した pull セッションで残った一時テーブルを掃除する。
	 *
	 * @return void
	 */
	private function cleanup_temp_tables() {
		global $wpdb;
		$state = $this->session->get();
		if ( ! $state || ! isset( $state['direction'] ) || 'pull' !== $state['direction'] ) {
			return;
		}
		$tables = isset( $state['tables'] ) ? (array) $state['tables'] : array();
		foreach ( $tables as $t ) {
			if ( $t !== $wpdb->options ) {
				$this->db->drop_temp_table( $t );
			}
		}
	}

	/**
	 * 中断・破棄した push セッションで本番側に残った一時テーブルを掃除する。
	 *
	 * push はテーブル完了ごとに即 finalize するため、残存する `_fmtmp` は処理中の
	 * 1 テーブルのみ。best-effort（単発呼び出し・失敗無視）で掃除する。失敗しても
	 * 次回 push 先頭の prepare_temp_table で DROP されるため、cancel は成功扱いとする。
	 *
	 * @return void
	 */
	private function cleanup_remote_temp_tables() {
		$state = $this->session->get();
		if ( ! $state || ! isset( $state['direction'] ) || 'push' !== $state['direction'] ) {
			return;
		}
		$tables = isset( $state['tables'] ) ? array_values( (array) $state['tables'] ) : array();
		$idx    = isset( $state['table_index'] ) ? (int) $state['table_index'] : 0;
		if ( $idx < 0 || $idx >= count( $tables ) ) {
			return; // 全テーブル finalize 済み = 残存なし。
		}
		$table = $tables[ $idx ];
		if ( empty( $state['prepared_tables'][ $table ] ) ) {
			return; // 一時テーブル未作成。
		}
		$client = $this->client();
		$this->remote_call(
			function () use ( $client, $table ) {
				return $client->cleanup( $table );
			},
			1
		);
	}

	/*
	 * =====================================================================
	 * ステップ実装
	 * =====================================================================
	 */

	/**
	 * pull の 1 チャンク。
	 *
	 * @param array  $state ステート。
	 * @param string $table テーブル名。
	 * @return array|WP_Error 更新後ステート。
	 */
	private function step_pull( array $state, $table ) {
		global $wpdb;
		$client           = $this->client();
		$cursor           = $state['cursor'];
		$is_first         = empty( $cursor );
		$is_options_table = ( $table === $wpdb->options );

		$res = $this->remote_call(
			function () use ( $client, $table, $cursor ) {
				return $client->export( $table, $cursor, FERRYMAN_CHUNK_BYTES );
			}
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$columns = isset( $res['columns'] ) ? $res['columns'] : array();
		$rows    = isset( $res['rows'] ) ? $res['rows'] : array();
		$count   = 0;

		// 本番→ローカル変換（base64 デコード → 置換）。
		$converted = array();
		foreach ( $rows as $row ) {
			$new = array();
			foreach ( $row as $i => $cell ) {
				if ( null === $cell ) {
					$new[] = null;
					continue;
				}
				$raw = base64_decode( $cell, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
				if ( false === $raw ) {
					$raw = '';
				}
				$new[] = $this->convert_cell( $raw, $table, isset( $columns[ $i ] ) ? $columns[ $i ] : '', $state['map'], $count );
			}
			$converted[] = $new;
		}

		// wp_options の場合: 本番から来た ferryman_ 行を除外する。
		// ローカルのモード・接続設定・セッションを本番のコンパニオン設定で上書きしないため。
		if ( $is_options_table ) {
			$name_col = array_search( 'option_name', $columns, true );
			if ( false !== $name_col ) {
				$converted = array_values(
					array_filter(
						$converted,
						function ( $row ) use ( $name_col ) {
							$val = isset( $row[ $name_col ] ) ? (string) $row[ $name_col ] : '';
							return 0 !== strpos( $val, 'ferryman_' );
						}
					)
				);
			}
		}

		$done = ! empty( $res['done'] );

		// run モードのみローカルへ書き込み。
		if ( 'run' === $state['mode'] ) {
			$already_prepared = ! empty( $state['prepared_tables'][ $table ] );

			if ( $is_options_table ) {
				// wp_options は RENAME 不可（ferryman_ 行を温存するため直接 upsert）。
				if ( $is_first && ! $already_prepared ) {
					$cleared = $this->db->clear_options_table();
					if ( is_wp_error( $cleared ) ) {
						return $cleared;
					}
					$state = $this->mark_prepared( $state, $table );
				}
				// option_id を送らない upsert（主キー衝突で自分の行を消さないため）。
				$written = $this->db->write_options_rows( $columns, $converted );
				if ( is_wp_error( $written ) ) {
					return $written;
				}
			} else {
				// 一時テーブルに書き、完了時に RENAME でアトミック切替（中断時の半壊を防ぐ）。
				if ( $is_first && ! $already_prepared ) {
					$prepared = $this->db->prepare_temp_table( $table, isset( $res['create_sql'] ) ? $res['create_sql'] : '' );
					if ( is_wp_error( $prepared ) ) {
						return $prepared;
					}
					$state = $this->mark_prepared( $state, $table );
				}
				$written = $this->db->write_rows( $this->db->temp_name( $table ), $columns, $converted );
				if ( is_wp_error( $written ) ) {
					return $written;
				}
				if ( $done ) {
					$fin = $this->db->finalize_table( $table );
					if ( is_wp_error( $fin ) ) {
						return $fin;
					}
				}
			}
		}

		return $this->advance( $state, $table, count( $rows ), $count, $done, isset( $res['next_cursor'] ) ? $res['next_cursor'] : null );
	}

	/**
	 * push の 1 チャンク。
	 *
	 * @param array  $state ステート。
	 * @param string $table テーブル名。
	 * @return array|WP_Error 更新後ステート。
	 */
	private function step_push( array $state, $table ) {
		$client = $this->client();
		$cursor = $state['cursor'];
		$chunk  = $this->db->read_chunk( $table, $cursor, FERRYMAN_CHUNK_BYTES );

		$columns = $chunk['columns'];
		$rows    = $chunk['rows'];
		$count   = 0;

		// ローカル→本番変換（置換 → base64 エンコード）。
		$encoded = array();
		foreach ( $rows as $row ) {
			$new = array();
			foreach ( $row as $i => $cell ) {
				if ( null === $cell ) {
					$new[] = null;
					continue;
				}
				$val   = $this->convert_cell( $cell, $table, isset( $columns[ $i ] ) ? $columns[ $i ] : '', $state['map'], $count );
				$new[] = base64_encode( $val ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
			}
			$encoded[] = $new;
		}

		// run モードのみ本番へ送信。
		if ( 'run' === $state['mode'] ) {
			$already_prepared = ! empty( $state['prepared_tables'][ $table ] );
			// create_sql の送信 = 本番側での TRUNCATE トリガ。先頭チャンクかつ未準備のときだけ送る。
			// これにより先頭チャンク送信後に中断→再開しても本番を再 TRUNCATE しない。
			$send_create = ( $chunk['is_first'] && ! $already_prepared );

			// テーブル単位の単調増加チャンク連番。カーソルは送信成功（advance）まで
			// 進まないため、応答消失や再開で同一チャンクを再送しても同じ連番になり、
			// 本番側が重複として弾く（PK 無しテーブルの INSERT 重複を防ぐ）。
			$seq = isset( $state['chunk_seq'][ $table ] ) ? (int) $state['chunk_seq'][ $table ] : 1;

			$payload = array(
				'session_id'                => $state['session_id'],
				'table'                     => $table,
				'chunk_seq'                 => $seq,
				'create_sql'                => $send_create ? $this->db->get_create_sql( $table ) : '',
				'columns'                   => $columns,
				'rows'                      => $encoded,
				'is_first_chunk_of_session' => ( 0 === (int) $state['rows_done'] ),
			);
			$res     = $this->remote_call(
				function () use ( $client, $payload ) {
					return $client->import( $payload );
				}
			);
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			if ( $send_create ) {
				$state = $this->mark_prepared( $state, $table );
			}
			// 送信成功 → 次チャンクの連番へ進める（直後の advance で永続化）。
			if ( ! isset( $state['chunk_seq'] ) || ! is_array( $state['chunk_seq'] ) ) {
				$state['chunk_seq'] = array();
			}
			$state['chunk_seq'][ $table ] = $seq + 1;

			// テーブル完了時に本番側で一時テーブルを RENAME 切替（アトミック）。
			if ( $chunk['done'] ) {
				$fin = $this->remote_call(
					function () use ( $client, $table ) {
						return $client->finalize( $table );
					}
				);
				if ( is_wp_error( $fin ) ) {
					return $fin;
				}
			}
		}

		return $this->advance( $state, $table, count( $rows ), $count, $chunk['done'], $chunk['next_cursor'] );
	}

	/**
	 * 1 セルを変換する。guid カラム（{prefix}posts）は温存。
	 *
	 * @param string $raw    生値。
	 * @param string $table  テーブル名。
	 * @param string $column カラム名。
	 * @param array  $map    置換マップ。
	 * @param int    $count  置換回数（参照）。
	 * @return string
	 */
	private function convert_cell( $raw, $table, $column, $map, &$count ) {
		global $wpdb;
		if ( $table === $wpdb->prefix . 'posts' && 'guid' === $column ) {
			return $raw; // 恒久 ID。URL に見えても置換しない。
		}
		return $this->replacer->replace_value( $raw, $map, $count );
	}

	/**
	 * テーブルを準備済みとして記録し、即セッションを永続化する。
	 *
	 * 先頭チャンクの破壊的準備（TRUNCATE/DELETE/本番TRUNCATE）の直後に保存することで、
	 * カーソル更新前に中断・再開しても同じテーブルを再破壊しない。
	 *
	 * @param array  $state ステート。
	 * @param string $table テーブル名。
	 * @return array 更新後ステート。
	 */
	private function mark_prepared( array $state, $table ) {
		if ( ! isset( $state['prepared_tables'] ) || ! is_array( $state['prepared_tables'] ) ) {
			$state['prepared_tables'] = array();
		}
		$state['prepared_tables'][ $table ] = true;
		return $this->session->update( $state );
	}

	/**
	 * カウンタとカーソルを進めてセッションを更新する。
	 *
	 * @param array      $state       ステート。
	 * @param string     $table       現在テーブル。
	 * @param int        $rows_done   今回処理した行数。
	 * @param int        $replaced    今回の置換回数。
	 * @param bool       $done        このテーブルが完了したか。
	 * @param array|null $next_cursor 次カーソル。
	 * @return array 更新後ステート。
	 */
	private function advance( array $state, $table, $rows_done, $replaced, $done, $next_cursor ) {
		$state['rows_done']     = (int) $state['rows_done'] + (int) $rows_done;
		$state['replace_count'] = (int) $state['replace_count'] + (int) $replaced;

		// テーブルごとの置換件数を累積（dry-run サマリ表示用）。
		if ( ! isset( $state['tables_replace_count'] ) || ! is_array( $state['tables_replace_count'] ) ) {
			$state['tables_replace_count'] = array();
		}
		$state['tables_replace_count'][ $table ] =
			( isset( $state['tables_replace_count'][ $table ] ) ? (int) $state['tables_replace_count'][ $table ] : 0 )
			+ (int) $replaced;

		if ( $done ) {
			$state['table_index'] = (int) $state['table_index'] + 1;
			$state['cursor']      = null;
			if ( $state['table_index'] >= count( $state['tables'] ) ) {
				$state['status'] = 'done';
			}
		} else {
			$state['cursor'] = $next_cursor;
		}

		return $this->session->update( $state );
	}

	/*
	 * =====================================================================
	 * ヘルパ
	 * =====================================================================
	 */

	/**
	 * クライアント生成。
	 *
	 * @return Ferryman_Ctrl_Client
	 */
	private function client() {
		return new Ferryman_Ctrl_Client( $this->settings->get_remote_url(), $this->settings->get_secret() );
	}

	/**
	 * リトライ付きでリモート呼び出し（指数バックオフ）。403 は即時失敗。
	 *
	 * @param callable $callback 呼び出し。
	 * @param int      $attempts 最大試行回数。
	 * @return array|WP_Error
	 */
	private function remote_call( $callback, $attempts = 3 ) {
		$delay = 1;
		$res   = null;
		for ( $i = 0; $i < $attempts; $i++ ) {
			$res = call_user_func( $callback );
			if ( ! is_wp_error( $res ) ) {
				return $res;
			}
			$data   = $res->get_error_data();
			$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 0;
			if ( 403 === $status || 400 === $status ) {
				return $res; // 認証・リクエスト不正はリトライしない。
			}
			if ( $i < $attempts - 1 ) {
				sleep( $delay );
				$delay *= 2;
			}
		}
		return $res;
	}

	/**
	 * DB 文字コードが本番と一致するか。
	 *
	 * @param array $handshake handshake メタ。
	 * @return bool
	 */
	private function charset_matches( array $handshake ) {
		// テーブル実体の文字コードが両側で取れるならそれで判定する。
		// wp-config.php の DB_CHARSET は接続時の宣言でしかなく、Ferryman は転送前に
		// 接続を utf8mb4 へ明示設定するため、定数の差だけでは移行の危険を意味しない。
		$remote_table = isset( $handshake['table_charset'] ) ? (string) $handshake['table_charset'] : '';
		$local_table  = $this->local_table_charset();
		if ( '' !== $remote_table && '' !== $local_table ) {
			return strtolower( $remote_table ) === strtolower( $local_table );
		}

		// 実体が取れない場合（旧版コンパニオン等）は従来どおり定数で判定する。
		$local  = $this->local_charset();
		$remote = isset( $handshake['db_charset'] ) ? $handshake['db_charset'] : '';
		if ( '' === $remote || '' === $local ) {
			return true; // 不明なら警告しない。
		}
		return strtolower( $local ) === strtolower( $remote );
	}

	/**
	 * ローカルの DB 文字コード（wp-config.php の宣言）。
	 *
	 * @return string
	 */
	private function local_charset() {
		global $wpdb;
		return defined( 'DB_CHARSET' ) && DB_CHARSET ? DB_CHARSET : (string) $wpdb->charset;
	}

	/**
	 * ローカルのテーブル実体の文字コード。1 リクエスト内で使い回す。
	 *
	 * @return string
	 */
	private function local_table_charset() {
		if ( null === $this->local_table_charset ) {
			$this->local_table_charset = $this->db->table_charset();
		}
		return $this->local_table_charset;
	}

	/**
	 * 権限・nonce 検証。
	 *
	 * @return void
	 */
	private function guard() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => '権限がありません。' ), 403 );
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}
}
