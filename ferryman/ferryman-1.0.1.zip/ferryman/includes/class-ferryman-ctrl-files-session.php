<?php
/**
 * ファイル同期セッション（進捗ステート）の保持。チャンク再開に使う。
 * DB 移行（ferryman_session）とは別キーで独立管理する。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * wp_options にファイル同期の進捗ステートを保存する。
 */
class Ferryman_Ctrl_Files_Session {

	const OPTION_KEY = 'ferryman_files_session';

	/**
	 * セッションを新規作成して保存する。
	 *
	 * @param array $data 初期ステート。
	 * @return array
	 */
	public function start( array $data ) {
		$state = wp_parse_args(
			$data,
			array(
				'session_id'    => wp_generate_uuid4(),
				'mode'          => 'run', // run | dryrun。
				'worklist'      => array(), // 転送対象 [{path,size,mtime}]。
				'file_index'    => 0,
				'file_offset'   => 0,
				'files_total'   => 0,
				'bytes_total'   => 0,
				'files_done'    => 0,
				'bytes_done'    => 0,
				'scanned_total' => 0, // 本番側の総ファイル数。
				'scanned_bytes' => 0,
				'skipped'       => 0, // 同一でスキップした数。
				'groups'        => array(), // 選択フォルダ（空 = 全件）。
				'status'        => 'running', // running | done | error。
				'message'       => '',
				'started_at'    => current_time( 'mysql' ),
			)
		);
		update_option( self::OPTION_KEY, $state, false );
		return $state;
	}

	/**
	 * 現在のセッションを取得（無ければ null）。
	 *
	 * @return array|null
	 */
	public function get() {
		$state = get_option( self::OPTION_KEY, null );
		return is_array( $state ) ? $state : null;
	}

	/**
	 * セッションを部分更新する。
	 *
	 * @param array $data 更新値。
	 * @return array 更新後ステート。
	 */
	public function update( array $data ) {
		$state = $this->get();
		if ( null === $state ) {
			$state = array();
		}
		$state = array_merge( $state, $data );
		update_option( self::OPTION_KEY, $state, false );
		return $state;
	}

	/**
	 * セッションを破棄する。
	 *
	 * @return void
	 */
	public function clear() {
		delete_option( self::OPTION_KEY );
	}

	/**
	 * 現在処理中のファイルエントリ（{path,size,mtime}）を返す。
	 *
	 * @param array $state ステート。
	 * @return array|null
	 */
	public function current_file( array $state ) {
		$list = isset( $state['worklist'] ) ? $state['worklist'] : array();
		$idx  = isset( $state['file_index'] ) ? (int) $state['file_index'] : 0;
		return isset( $list[ $idx ] ) ? $list[ $idx ] : null;
	}

	/**
	 * UI 向けの進捗サマリを返す。
	 *
	 * @param array $state ステート。
	 * @return array
	 */
	public function progress( array $state ) {
		$bytes_total = max( 1, (int) $state['bytes_total'] );
		$raw_pct     = (int) round( ( (int) $state['bytes_done'] / $bytes_total ) * 100 );
		$percent     = ( 'done' === $state['status'] ) ? 100 : min( 99, $raw_pct );
		$current     = $this->current_file( $state );
		return array(
			'session_id'    => $state['session_id'],
			'mode'          => $state['mode'],
			'status'        => $state['status'],
			'message'       => $state['message'],
			'current_file'  => $current ? $current['path'] : null,
			'file_index'    => (int) $state['file_index'],
			'files_total'   => (int) $state['files_total'],
			'bytes_total'   => (int) $state['bytes_total'],
			'files_done'    => (int) $state['files_done'],
			'bytes_done'    => (int) $state['bytes_done'],
			'scanned_total' => (int) $state['scanned_total'],
			'scanned_bytes' => (int) $state['scanned_bytes'],
			'skipped'       => (int) $state['skipped'],
			'groups_count'  => isset( $state['groups'] ) ? count( (array) $state['groups'] ) : 0,
			'percent'       => $percent,
		);
	}
}
