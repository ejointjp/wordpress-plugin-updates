<?php
/**
 * Ferryman Controller メインクラス（ブートストラップ）。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * コントローラの各コンポーネントを束ねるシングルトン。
 */
final class Ferryman_Ctrl {

	/**
	 * シングルトンインスタンス。
	 *
	 * @var Ferryman_Ctrl|null
	 */
	private static $instance = null;

	/**
	 * 設定。
	 *
	 * @var Ferryman_Ctrl_Settings
	 */
	public $settings;

	/**
	 * 移行オーケストレータ。
	 *
	 * @var Ferryman_Ctrl_Migrator
	 */
	public $migrator;

	/**
	 * ファイル同期オーケストレータ。
	 *
	 * @var Ferryman_Ctrl_Files
	 */
	public $files;

	/**
	 * 管理画面。
	 *
	 * @var Ferryman_Ctrl_Admin
	 */
	public $admin;

	/**
	 * インスタンス取得。
	 *
	 * @return Ferryman_Ctrl
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * コンストラクタ。
	 */
	private function __construct() {
		$this->settings = new Ferryman_Ctrl_Settings();
		$this->migrator = new Ferryman_Ctrl_Migrator( $this->settings );
		$this->files    = new Ferryman_Ctrl_Files( $this->settings );
		$this->admin    = new Ferryman_Ctrl_Admin( $this->settings, $this->migrator, $this->files );

		if ( is_admin() ) {
			$this->admin->hooks();
			$this->migrator->hooks();
			$this->files->hooks();
		}
	}
}
