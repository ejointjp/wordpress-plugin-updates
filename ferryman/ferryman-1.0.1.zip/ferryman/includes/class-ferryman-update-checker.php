<?php
/**
 * 自己ホストの更新チェック。
 *
 * wordpress.orgには載せていないので、更新の情報は配布用のリポジトリ（ejointjp/wordpress-plugin-updates）に
 * 置いたinfo.jsonから取る。メインファイルのヘッダーにUpdate URI（https://yuiami.jp/wp-plugins/ferryman）があると、
 * WordPressはこのプラグインの更新をwordpress.orgに問い合わせず、そのホスト名の付いたフィルタ
 * update_plugins_yuiami.jpを呼ぶ。Update URIは識別子で、実在しなくてよい。
 *
 * - 更新の判定（update_plugins_yuiami.jp）は、キャッシュを読まずに毎回取得する。本体が12時間おきにしか
 *   確認しないうえ、「再確認」ですぐ反映させたいため
 * - 詳細の表示（plugins_api）は、1時間キャッシュした情報を使う。キャッシュはサイトのトランジェントで、
 *   期限が切れれば消える（このプラグインはuninstall.phpを持たない）
 * - 取得できなければ、理由をPHPのエラーログに残して「更新なし」として扱う
 * - 問い合わせで送るのは、info.jsonのURLと固定のUser-Agentだけ。サイトのURLやデータは送らない
 *
 * 定期の更新チェックはwp-cronで動くので、動作モードやis_admin()に関係なく読み込んで登録する（ferryman_boot()）。
 * プラグインが停止中のサイトでは動かない。
 * 中身は/wp-plugin-publishのひな形（assets/selfhost/update-checker.php）と同じで、クラスにまとめる形だけを
 * このプラグインの書き方に合わせてある。導入の手順は同スキルのreferences/selfhost.md。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * 配布用のリポジトリにある最新版の情報を、WordPressの更新の仕組みへ渡す。
 */
class Ferryman_Update_Checker {

	const SLUG           = 'ferryman';
	const BASE_URL       = 'https://raw.githubusercontent.com/ejointjp/wordpress-plugin-updates/main/ferryman/'; // 配布用のリポジトリの、このプラグインの置き場。
	const INFO_TRANSIENT = 'ferryman_update_info'; // 更新の情報のキャッシュ（サイトのトランジェント）。

	/**
	 * フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter( 'update_plugins_yuiami.jp', array( $this, 'filter_update' ), 10, 3 );
		add_filter( 'plugins_api', array( $this, 'filter_plugin_information' ), 10, 3 );
	}

	/**
	 * 更新の判定に、配布用のリポジトリにある最新版の情報を返す。
	 *
	 * 新しいかどうかは本体が比べる。
	 *
	 * @param array|false $update      ここまでのフィルタの結果。
	 * @param array       $plugin_data プラグインのヘッダー。
	 * @param string      $plugin_file プラグインのファイル（plugin_basename()の形）。
	 * @return array|false
	 */
	public function filter_update( $update, $plugin_data, $plugin_file ) {
		if ( plugin_basename( FERRYMAN_FILE ) !== $plugin_file ) {
			return $update;
		}

		$info = $this->get_info( true );
		if ( null === $info ) {
			return $update;
		}

		return array(
			'slug'         => self::SLUG,
			'version'      => $info['version'],
			'package'      => $info['package'],
			'url'          => isset( $plugin_data['AuthorURI'] ) ? $plugin_data['AuthorURI'] : '',
			'requires'     => $this->field( $info, 'requires' ),
			'requires_php' => $this->field( $info, 'requires_php' ),
			'tested'       => $this->tested( $this->field( $info, 'tested' ) ),
		);
	}

	/**
	 * 「詳細を表示」のポップアップに、配布用のリポジトリにある情報を返す。
	 *
	 * @param false|object|array $result ここまでのフィルタの結果。
	 * @param string             $action plugins_api()の種類。
	 * @param object             $args   plugins_api()の引数。
	 * @return false|object|array|WP_Error
	 */
	public function filter_plugin_information( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}

		$info = $this->get_info( false );
		if ( null === $info ) {
			// falseのまま返すと、本体がwordpress.orgの同じslugを見に行く。エラーにして止める。
			return new WP_Error( 'ferryman_update_info', '更新情報を取得できませんでした。後ほどもう一度お試しください。' );
		}

		$sections = isset( $info['sections'] ) && is_array( $info['sections'] ) ? array_filter( $info['sections'], 'is_string' ) : array();

		return (object) array(
			'name'          => esc_html( $this->field( $info, 'name' ) ),
			'slug'          => self::SLUG,
			'version'       => $info['version'],
			'author'        => esc_html( $this->field( $info, 'author' ) ),
			'requires'      => $this->field( $info, 'requires' ),
			'requires_php'  => $this->field( $info, 'requires_php' ),
			'tested'        => $this->tested( $this->field( $info, 'tested' ) ),
			'last_updated'  => $this->field( $info, 'last_updated' ),
			'sections'      => $sections,
			'download_link' => $info['package'],
			'external'      => true, // wordpress.orgのプラグインページへのリンクを出さない。
		);
	}

	/**
	 * 更新の情報（info.json）を返す。
	 *
	 * @param bool $fresh trueならキャッシュを読まずに取得する。
	 * @return array|null 取得できなければnull。
	 */
	private function get_info( $fresh ) {
		if ( ! $fresh ) {
			$cached = get_site_transient( self::INFO_TRANSIENT );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		// WordPressの既定のUser-AgentはサイトのURLを含む。配布元へ送らないよう、固定の文字列にする。
		$response = wp_remote_get(
			self::BASE_URL . 'info.json',
			array(
				'timeout'    => 10,
				'user-agent' => 'ferryman update check',
			)
		);
		if ( is_wp_error( $response ) ) {
			$this->log( $response->get_error_message() );
			return null;
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			$this->log( 'HTTP ' . $status );
			return null;
		}

		$info = json_decode( wp_remote_retrieve_body( $response ), true );
		// zipのURLは、このプラグインの置き場にあるものだけを受け付ける。
		if (
			! is_array( $info )
			|| '' === $this->field( $info, 'version' )
			|| 0 !== strpos( $this->field( $info, 'package' ), self::BASE_URL )
		) {
			$this->log( 'info.json is not valid' );
			return null;
		}

		set_site_transient( self::INFO_TRANSIENT, $info, HOUR_IN_SECONDS );
		return $info;
	}

	/**
	 * 更新の情報を取得できなかった理由を、PHPのエラーログに残す。
	 *
	 * @param string $reason 理由。
	 * @return void
	 */
	private function log( $reason ) {
		error_log( 'Ferryman update check: ' . $reason ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 更新の情報を取得できなかった理由を残すため
	}

	/**
	 * 更新の情報から文字列の項目を取り出す。
	 *
	 * @param array  $info 更新の情報。
	 * @param string $key  項目名。
	 * @return string なければ空文字。
	 */
	private function field( array $info, $key ) {
		return isset( $info[ $key ] ) && is_string( $info[ $key ] ) ? $info[ $key ] : '';
	}

	/**
	 * 「Tested up to」を、サイトのWordPressと同じ系列なら、サイトの版に読み替える。
	 *
	 * readme.txtにはメジャー番号だけ（7.1）を書く。本体はversion_compare()で比べるので、そのまま返すと、
	 * 7.1.2のサイトで「テストされていない」と表示される。wordpress.orgのAPIも、同じ系列の最新のパッチ版に読み替えて返す。
	 *
	 * @param string $tested info.jsonのtested。
	 * @return string
	 */
	private function tested( $tested ) {
		$current = get_bloginfo( 'version' );
		if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $current, $tested . '.' ) ) {
			return $current;
		}
		return $tested;
	}
}
