<?php
/**
 * コンパニオン設定・秘密キー・アクティビティログ・バックアップ一覧の保持。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * 設定ストア。すべて wp_options に保存する。
 */
class Ferryman_Companion_Settings {

	const OPTION_SETTINGS = 'ferryman_companion_settings';
	const OPTION_LOG      = 'ferryman_companion_log';
	const OPTION_BACKUPS  = 'ferryman_companion_backups';

	const LOG_LIMIT = 50;

	/**
	 * 設定の初期値。3 トグルはすべて OFF。
	 *
	 * @return array
	 */
	private function defaults() {
		return array(
			'enabled'         => false, // 接続マスタトグル。
			'allow_pull'      => false, // pull(export) 許可。
			'allow_push'      => false, // push(import) 許可。
			'allow_file_pull' => false, // ファイル pull（uploads 取得）許可。
			'secret'          => '',     // 秘密キー（コントローラへ手動コピー）。
			'allow_insecure'  => false, // 非 HTTPS を明示許可（既定 OFF）。
		);
	}

	/**
	 * 全設定を取得。
	 *
	 * @return array
	 */
	public function all() {
		$stored = get_option( self::OPTION_SETTINGS, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, $this->defaults() );
	}

	/**
	 * 単一設定値を取得。
	 *
	 * @param string $key           キー。
	 * @param mixed  $default_value 既定値。
	 * @return mixed
	 */
	public function get( $key, $default_value = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default_value;
	}

	/**
	 * 設定を部分更新。
	 *
	 * @param array $values 更新する値。
	 * @return void
	 */
	public function update( array $values ) {
		$current = $this->all();
		$merged  = array_merge( $current, $values );
		update_option( self::OPTION_SETTINGS, $merged, false );
	}

	/**
	 * 秘密キーを取得（無ければ空文字）。
	 *
	 * wp-config.php で FERRYMAN_COMPANION_SECRET を定義していればそれを最優先で返す。
	 * 定数運用時は秘密キーが DB（wp_options）に載らないため、DB ダンプや
	 * バックアップが流出しても署名偽造に使われない。
	 *
	 * @return string
	 */
	public function get_secret() {
		if ( $this->secret_is_constant() ) {
			return (string) FERRYMAN_COMPANION_SECRET;
		}
		return (string) $this->get( 'secret', '' );
	}

	/**
	 * 秘密キーが wp-config 定数で固定されているか。
	 *
	 * @return bool
	 */
	public function secret_is_constant() {
		return defined( 'FERRYMAN_COMPANION_SECRET' ) && '' !== (string) FERRYMAN_COMPANION_SECRET;
	}

	/**
	 * 秘密キーを生成して保存し、新しいキーを返す。
	 * 定数で固定されている場合は再生成せず、その定数値を返す。
	 *
	 * @return string
	 */
	public function regenerate_secret() {
		if ( $this->secret_is_constant() ) {
			return $this->get_secret();
		}
		$secret = wp_generate_password( 64, false, false );
		$this->update( array( 'secret' => $secret ) );
		return $secret;
	}

	/*
	 * ---------------------------------------------------------------------
	 * アクティビティログ
	 * ---------------------------------------------------------------------
	 */

	/**
	 * 接続結果を記録する（直近 LOG_LIMIT 件のみ保持）。
	 *
	 * @param string $direction 方向（handshake/tables/export/import/backup）。
	 * @param string $result    結果（ok / 理由）。
	 * @param string $ip        接続元 IP。
	 * @return void
	 */
	public function log( $direction, $result, $ip = '' ) {
		$log = get_option( self::OPTION_LOG, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		array_unshift(
			$log,
			array(
				'time'      => current_time( 'mysql' ),
				'ip'        => $ip ? $ip : $this->client_ip(),
				'direction' => $direction,
				'result'    => $result,
			)
		);
		$log = array_slice( $log, 0, self::LOG_LIMIT );
		update_option( self::OPTION_LOG, $log, false );
	}

	/**
	 * ログ一覧を取得。
	 *
	 * @return array
	 */
	public function get_log() {
		$log = get_option( self::OPTION_LOG, array() );
		return is_array( $log ) ? $log : array();
	}

	/**
	 * 接続元 IP を取得。
	 *
	 * @return string
	 */
	public function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';
	}

	/*
	 * ---------------------------------------------------------------------
	 * バックアップ一覧
	 * ---------------------------------------------------------------------
	 */

	/**
	 * バックアップ記録を追加。
	 *
	 * @param array $entry { backup_id, path, url, tables, time, size }。
	 * @return void
	 */
	public function add_backup( array $entry ) {
		$list = $this->get_backups();
		array_unshift( $list, $entry );
		update_option( self::OPTION_BACKUPS, $list, false );
	}

	/**
	 * バックアップ記録一覧を取得。
	 *
	 * @return array
	 */
	public function get_backups() {
		$list = get_option( self::OPTION_BACKUPS, array() );
		return is_array( $list ) ? $list : array();
	}

	/**
	 * バックアップ記録一覧を保存し直す（世代削除用）。
	 *
	 * @param array $backups 一覧。
	 * @return void
	 */
	public function set_backups( array $backups ) {
		update_option( self::OPTION_BACKUPS, array_values( $backups ), false );
	}
}
