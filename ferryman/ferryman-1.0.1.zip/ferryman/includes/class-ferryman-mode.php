<?php
/**
 * 動作モード（コントローラ / コンパニオン）の保持。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * モードストア。
 */
class Ferryman_Mode {

	const OPTION     = 'ferryman_mode';
	const CONTROLLER = 'controller'; // ローカル側。
	const COMPANION  = 'companion';  // 本番側。

	/**
	 * 現在モードを返す（未設定は空文字）。
	 *
	 * @return string
	 */
	public static function get() {
		$mode = get_option( self::OPTION, '' );
		return in_array( $mode, array( self::CONTROLLER, self::COMPANION ), true ) ? $mode : '';
	}

	/**
	 * モードを設定する。
	 *
	 * @param string $mode モード。
	 * @return bool 成否。
	 */
	public static function set( $mode ) {
		if ( ! in_array( $mode, array( self::CONTROLLER, self::COMPANION ), true ) ) {
			return false;
		}
		update_option( self::OPTION, $mode, false );
		return true;
	}

	/**
	 * モードのラベル。
	 *
	 * @param string|null $mode モード（null で現在値）。
	 * @return string
	 */
	public static function label( $mode = null ) {
		if ( null === $mode ) {
			$mode = self::get();
		}
		if ( self::CONTROLLER === $mode ) {
			return 'コントローラ（ローカル側）';
		}
		if ( self::COMPANION === $mode ) {
			return 'コンパニオン（本番側）';
		}
		return '未設定';
	}

	/**
	 * 設定済みか。
	 *
	 * @return bool
	 */
	public static function is_set() {
		return '' !== self::get();
	}
}
