<?php
/**
 * 動作モード選択・切替の管理画面（常時提供）。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * モード設定 UI。
 */
class Ferryman_Setup_Admin {

	const MENU_SLUG    = 'ferryman';
	const MODE_SLUG    = 'ferryman-mode';
	const NONCE_ACTION = 'ferryman_set_mode';
	const CAPABILITY   = 'manage_options';

	/**
	 * フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		// コントローラ/コンパニオンのトップメニュー登録後に動かすため遅い優先度。
		add_action( 'admin_menu', array( $this, 'add_menu' ), 100 );
		add_action( 'admin_post_ferryman_set_mode', array( $this, 'handle_set_mode' ) );
		add_action( 'admin_notices', array( $this, 'maybe_notice' ) );
	}

	/**
	 * メニュー登録。
	 *
	 * モード未設定: トップメニューとしてモード選択を出す。
	 * モード設定済: 各モードのトップ配下に「動作モード」サブメニューを足す。
	 *
	 * @return void
	 */
	public function add_menu() {
		if ( ! Ferryman_Mode::is_set() ) {
			add_menu_page(
				'Ferryman',
				'Ferryman',
				self::CAPABILITY,
				self::MENU_SLUG,
				array( $this, 'render' ),
				'dashicons-migrate',
				80
			);
			return;
		}
		add_submenu_page(
			self::MENU_SLUG,
			'動作モード',
			'動作モード',
			self::CAPABILITY,
			self::MODE_SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * 未設定時に全画面で案内を出す。
	 *
	 * @return void
	 */
	public function maybe_notice() {
		if ( Ferryman_Mode::is_set() || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$url = admin_url( 'admin.php?page=' . self::MENU_SLUG );
		echo '<div class="notice notice-warning"><p>';
		echo 'Ferryman: 動作モードが未設定です。';
		echo ' <a href="' . esc_url( $url ) . '">このサイトをコントローラ / コンパニオンのどちらで使うか選択</a>してください。';
		echo '</p></div>';
	}

	/**
	 * モード保存。
	 *
	 * @return void
	 */
	public function handle_set_mode() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE_ACTION );

		$mode = isset( $_POST['ferryman_mode'] ) ? sanitize_key( wp_unslash( $_POST['ferryman_mode'] ) ) : '';

		if ( ! Ferryman_Mode::set( $mode ) ) {
			// モード設定済みならこの画面はサブメニュー側（MODE_SLUG）にある。
			ferryman_redirect_with_notice(
				Ferryman_Mode::is_set() ? self::MODE_SLUG : self::MENU_SLUG,
				'mode_invalid',
				'動作モードを保存できませんでした。コントローラかコンパニオンのどちらかを選んでから、もう一度保存してください。',
				'error'
			);
		}

		// 設定後はそのモードのトップへ。通知もそちらの画面に出る。
		ferryman_redirect_with_notice(
			self::MENU_SLUG,
			'mode_set',
			'動作モードを「' . Ferryman_Mode::label( $mode ) . '」に設定しました。'
		);
	}

	/**
	 * 画面描画。
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$current    = Ferryman_Mode::get();
		$action_url = admin_url( 'admin-post.php' );
		?>
		<div class="wrap">
			<h1>Ferryman — 動作モード</h1>
			<hr class="wp-header-end" />
			<?php settings_errors(); ?>
			<p>同じプラグインを本番・ローカル両方に入れ、各サイトでこの画面から役割を選びます。</p>

			<p><strong>現在のモード:</strong> <?php echo esc_html( Ferryman_Mode::label( $current ) ); ?></p>

			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<input type="hidden" name="action" value="ferryman_set_mode" />
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">このサイトの役割</th>
						<td>
							<label style="display:block; margin-bottom:8px;">
								<input type="radio" name="ferryman_mode" value="<?php echo esc_attr( Ferryman_Mode::CONTROLLER ); ?>" <?php checked( Ferryman_Mode::CONTROLLER, $current ); ?> />
								<strong>コントローラ（ローカル側）</strong> — UI・変換・本番への接続を行う司令塔。<em>ローカル環境</em>に設定。
							</label>
							<label style="display:block;">
								<input type="radio" name="ferryman_mode" value="<?php echo esc_attr( Ferryman_Mode::COMPANION ); ?>" <?php checked( Ferryman_Mode::COMPANION, $current ); ?> />
								<strong>コンパニオン（本番側）</strong> — dump/import の口を提供するだけ。<em>本番環境</em>に設定。
							</label>
						</td>
					</tr>
				</table>
				<?php submit_button( 'このモードで動かす' ); ?>
			</form>

			<?php if ( Ferryman_Mode::is_set() ) : ?>
				<p class="description">モードを切り替えても各モードの設定（接続情報・秘密キー・トグル等）は保持されます。切替後、左メニューの表示が入れ替わります。</p>
			<?php endif; ?>
		</div>
		<?php
	}
}
