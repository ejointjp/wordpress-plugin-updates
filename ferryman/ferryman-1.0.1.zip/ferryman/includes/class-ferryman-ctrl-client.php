<?php
/**
 * コンパニオンへの署名付き HTTP クライアント。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST 呼び出しと HMAC 署名付与。
 */
class Ferryman_Ctrl_Client {

	const HEADER_TIMESTAMP = 'X-Ferryman-Timestamp';
	const HEADER_SIGNATURE = 'X-Ferryman-Signature';

	/**
	 * 本番 URL（末尾スラッシュ無し）。
	 *
	 * @var string
	 */
	private $remote_url;

	/**
	 * 秘密キー。
	 *
	 * @var string
	 */
	private $secret;

	/**
	 * コンストラクタ。
	 *
	 * @param string $remote_url 本番 URL。
	 * @param string $secret     秘密キー。
	 */
	public function __construct( $remote_url, $secret ) {
		$this->remote_url = untrailingslashit( $remote_url );
		$this->secret     = $secret;
	}

	/**
	 * GET /handshake。
	 *
	 * @return array|WP_Error
	 */
	public function handshake() {
		return $this->request( 'GET', '/handshake', null );
	}

	/**
	 * POST /tables。
	 *
	 * @return array|WP_Error
	 */
	public function tables() {
		return $this->request( 'POST', '/tables', array() );
	}

	/**
	 * POST /export。
	 *
	 * @param string     $table       テーブル名。
	 * @param array|null $cursor      カーソル。
	 * @param int        $limit_bytes チャンク目安バイト。
	 * @return array|WP_Error
	 */
	public function export( $table, $cursor, $limit_bytes ) {
		$body = array(
			'table'       => $table,
			'cursor'      => $cursor,
			'limit_bytes' => $limit_bytes,
		);
		return $this->request( 'POST', '/export', $body );
	}

	/**
	 * POST /import。
	 *
	 * @param array $payload import ペイロード。
	 * @return array|WP_Error
	 */
	public function import( array $payload ) {
		return $this->request( 'POST', '/import', $payload );
	}

	/**
	 * POST /finalize。一時テーブルを本番テーブルへ切り替える。
	 *
	 * @param string $table テーブル名。
	 * @return array|WP_Error
	 */
	public function finalize( $table ) {
		return $this->request( 'POST', '/finalize', array( 'table' => $table ) );
	}

	/**
	 * POST /backup。
	 *
	 * @param string[] $tables 対象テーブル。
	 * @return array|WP_Error
	 */
	public function backup( array $tables ) {
		return $this->request( 'POST', '/backup', array( 'tables' => array_values( $tables ) ) );
	}

	/**
	 * POST /cleanup。push 中断時に本番側の一時テーブルを削除する。
	 *
	 * @param string $table テーブル名。
	 * @return array|WP_Error
	 */
	public function cleanup( $table ) {
		return $this->request( 'POST', '/cleanup', array( 'table' => $table ) );
	}

	/**
	 * POST /files/list。uploads 配下のファイルをページング列挙する。
	 *
	 * @param string|null $cursor 直前ページの最終相対パス（null で先頭）。
	 * @param int|null    $limit  1 ページ件数（null でサーバ既定）。
	 * @return array|WP_Error
	 */
	public function files_list( $cursor = null, $limit = null ) {
		$body = array( 'cursor' => $cursor );
		if ( null !== $limit ) {
			$body['limit'] = (int) $limit;
		}
		return $this->request( 'POST', '/files/list', $body );
	}

	/**
	 * POST /files/get。uploads 配下の 1 ファイルをバイト範囲で取得する。
	 *
	 * @param string $path        uploads 相対パス。
	 * @param int    $offset      開始バイト。
	 * @param int    $limit_bytes 最大読み出しバイト数。
	 * @return array|WP_Error
	 */
	public function files_get( $path, $offset, $limit_bytes ) {
		return $this->request(
			'POST',
			'/files/get',
			array(
				'path'        => $path,
				'offset'      => (int) $offset,
				'limit_bytes' => (int) $limit_bytes,
			)
		);
	}

	/**
	 * POST /plugins/list。本番のインストール済みプラグインのマニフェストを取得する。
	 *
	 * @return array|WP_Error
	 */
	public function plugins_list() {
		return $this->request( 'POST', '/plugins/list', array() );
	}

	/**
	 * 署名付きリクエストを送信する。
	 *
	 * @param string     $method   HTTP メソッド。
	 * @param string     $endpoint 名前空間後のパス（例 /export）。
	 * @param array|null $body     ボディ配列（null は body 無し）。
	 * @return array|WP_Error デコード済みレスポンス、または失敗時 WP_Error。
	 */
	public function request( $method, $endpoint, $body ) {
		if ( '' === $this->remote_url ) {
			return new WP_Error( 'ferryman_no_remote', '本番 URL が未設定です。' );
		}
		if ( '' === $this->secret ) {
			return new WP_Error( 'ferryman_no_secret', '秘密キーが未設定です。' );
		}

		$route    = '/' . FERRYMAN_NAMESPACE . $endpoint; // 例 /ferryman/v1/export。
		$url      = $this->remote_url . '/wp-json' . $route;
		$body_str = ( null === $body ) ? '' : wp_json_encode( $body );
		$ts       = time();
		$sig      = $this->sign( $ts, $method, $route, $body_str );

		$args = array(
			'method'    => $method,
			'timeout'   => 120,
			'headers'   => array(
				'Content-Type'         => 'application/json',
				'Accept'               => 'application/json',
				self::HEADER_TIMESTAMP => (string) $ts,
				self::HEADER_SIGNATURE => $sig,
			),
			'sslverify' => true,
		);
		if ( 'GET' !== $method ) {
			$args['body'] = $body_str;
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			$message = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : ( 'HTTP ' . $code );
			$code_id = is_array( $data ) && isset( $data['code'] ) ? $data['code'] : 'ferryman_http_error';
			return new WP_Error(
				$code_id,
				$message,
				array(
					'status' => $code,
					'body'   => $raw,
				)
			);
		}

		if ( ! is_array( $data ) ) {
			return new WP_Error( 'ferryman_bad_json', 'レスポンスの JSON 解析に失敗しました。', array( 'body' => $raw ) );
		}

		return $data;
	}

	/**
	 * 署名文字列を計算する（コンパニオンと同一フォーマット）。
	 *
	 * @param int    $timestamp UNIX 秒。
	 * @param string $method    HTTP メソッド。
	 * @param string $route     REST ルート。
	 * @param string $body      生ボディ。
	 * @return string
	 */
	public function sign( $timestamp, $method, $route, $body ) {
		$payload = $timestamp . "\n" . strtoupper( $method ) . "\n" . $route . "\n" . $body;
		return hash_hmac( 'sha256', $payload, $this->secret );
	}
}
