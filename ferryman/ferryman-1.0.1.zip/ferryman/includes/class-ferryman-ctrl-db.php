<?php
/**
 * ローカル DB の読み出し（push 用）と書き込み（pull 用）。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * ローカル DB アクセス。
 */
class Ferryman_Ctrl_DB {

	const BATCH_ROWS = 500;

	/**
	 * 接続文字コードを utf8mb4 に明示設定。
	 *
	 * @return void
	 */
	public function ensure_charset() {
		global $wpdb;
		$wpdb->query( 'SET NAMES utf8mb4' ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 接続の文字コード設定。コアAPIはない。
	}

	/**
	 * prefix 配下のテーブルが実際に使っている文字コードを返す。
	 *
	 * wp-config.php の DB_CHARSET は接続時の宣言でしかなく、テーブル実体の
	 * 文字コードとは一致しないことがある。移行の安全性を左右するのは実体側。
	 *
	 * @return string 例 'utf8mb4'。複数混在時はカンマ区切り。取得不能時は空文字。
	 */
	public function table_charset() {
		global $wpdb;
		$like = $wpdb->esc_like( $wpdb->prefix ) . '%';
		$sql  = $wpdb->prepare(
			'SELECT DISTINCT CCSA.CHARACTER_SET_NAME AS charset
			 FROM information_schema.TABLES T
			 JOIN information_schema.COLLATION_CHARACTER_SET_APPLICABILITY CCSA
			   ON CCSA.COLLATION_NAME = T.TABLE_COLLATION
			 WHERE T.TABLE_SCHEMA = %s AND T.TABLE_NAME LIKE %s AND T.TABLE_TYPE = %s
			 ORDER BY charset',
			DB_NAME,
			$like,
			'BASE TABLE'
		);
		$rows = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。information_schemaの参照にコアAPIはなく、判定には最新の値が要る。
		if ( ! $rows ) {
			return '';
		}
		return implode( ',', array_map( 'strtolower', $rows ) );
	}

	/**
	 * prefix 配下のテーブル一覧と概算行数。
	 *
	 * @return array<int,array{name:string,rows:int}>
	 */
	public function list_tables() {
		global $wpdb;
		$like = $wpdb->esc_like( $wpdb->prefix ) . '%';
		$sql  = $wpdb->prepare(
			'SELECT TABLE_NAME AS name, TABLE_ROWS AS rows_count
			 FROM information_schema.TABLES
			 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s AND TABLE_TYPE = %s
			 ORDER BY TABLE_NAME',
			DB_NAME,
			$like,
			'BASE TABLE'
		);
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。information_schemaの参照にコアAPIはなく、判定には最新の値が要る。
		$out  = array();
		if ( $rows ) {
			foreach ( $rows as $r ) {
				$out[] = array(
					'name' => $r['name'],
					'rows' => (int) $r['rows_count'],
				);
			}
		}
		return $out;
	}

	/**
	 * テーブルが prefix 配下に存在するか。
	 *
	 * @param string $table テーブル名。
	 * @return bool
	 */
	public function is_valid_table( $table ) {
		global $wpdb;
		if ( 0 !== strpos( $table, $wpdb->prefix ) ) {
			return false;
		}
		foreach ( $this->list_tables() as $t ) {
			if ( $t['name'] === $table ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * SHOW CREATE TABLE。
	 *
	 * @param string $table テーブル名。
	 * @return string
	 */
	public function get_create_sql( $table ) {
		global $wpdb;
		$row = $wpdb->get_row( 'SHOW CREATE TABLE `' . $this->ident( $table ) . '`', ARRAY_N ); // phpcs:ignore WordPress.DB
		return ( $row && isset( $row[1] ) ) ? (string) $row[1] : '';
	}

	/**
	 * カラム名一覧。
	 *
	 * @param string $table テーブル名。
	 * @return string[]
	 */
	public function get_columns( $table ) {
		global $wpdb;
		$cols = $wpdb->get_results( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '`', ARRAY_A ); // phpcs:ignore WordPress.DB
		$out  = array();
		if ( $cols ) {
			foreach ( $cols as $c ) {
				$out[] = $c['Field'];
			}
		}
		return $out;
	}

	/**
	 * 生成カラム（GENERATED / VIRTUAL / STORED）の名前一覧を返す。
	 *
	 * @param string $table テーブル名。
	 * @return string[]
	 */
	public function get_generated_columns( $table ) {
		global $wpdb;
		$cols = $wpdb->get_results( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '`', ARRAY_A ); // phpcs:ignore WordPress.DB
		$out  = array();
		if ( $cols ) {
			foreach ( $cols as $c ) {
				$extra = isset( $c['Extra'] ) ? strtoupper( $c['Extra'] ) : '';
				if ( false !== strpos( $extra, 'GENERATED' ) ) {
					$out[] = $c['Field'];
				}
			}
		}
		return $out;
	}

	/**
	 * 単一カラム主キー（複合 / 無しは null）。
	 *
	 * @param string $table テーブル名。
	 * @return string|null
	 */
	public function get_primary_key( $table ) {
		global $wpdb;
		$keys = $wpdb->get_results( 'SHOW KEYS FROM `' . $this->ident( $table ) . '` WHERE Key_name = "PRIMARY"', ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $keys || count( $keys ) !== 1 ) {
			return null;
		}
		return $keys[0]['Column_name'];
	}

	/**
	 * カーソル比較・整列に使う PK 式。数値 PK はそのまま、文字列 PK は BINARY。
	 *
	 * @param string $table テーブル名。
	 * @param string $pk    主キーカラム名。
	 * @return string
	 */
	public function pk_expr( $table, $pk ) {
		$col = '`' . $this->ident( $pk ) . '`';
		return $this->is_numeric_pk( $table, $pk ) ? $col : 'BINARY ' . $col;
	}

	/**
	 * PK が数値型か。
	 *
	 * @param string $table テーブル名。
	 * @param string $pk    主キーカラム名。
	 * @return bool
	 */
	public function is_numeric_pk( $table, $pk ) {
		global $wpdb;
		$row  = $wpdb->get_row( $wpdb->prepare( 'SHOW COLUMNS FROM `' . $this->ident( $table ) . '` LIKE %s', $wpdb->esc_like( $this->ident( $pk ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$type = ( $row && isset( $row['Type'] ) ) ? strtolower( $row['Type'] ) : '';
		return (bool) preg_match( '/^(tinyint|smallint|mediumint|int|integer|bigint|decimal|dec|numeric|fixed|float|double|real|bit|year)\b/', $type );
	}

	/**
	 * 行数。
	 *
	 * @param string $table テーブル名。
	 * @return int
	 */
	public function count_rows( $table ) {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . $this->ident( $table ) . '`' ); // phpcs:ignore WordPress.DB
	}

	/**
	 * push 用にローカルからチャンクを読み出す（生値・base64 化はしない）。
	 *
	 * @param string     $table       テーブル名。
	 * @param array|null $cursor      { last_pk } または { offset }。
	 * @param int        $limit_bytes チャンク目安バイト。
	 * @return array { columns, rows(生値配列), next_cursor, done, is_first }。
	 */
	public function read_chunk( $table, $cursor, $limit_bytes ) {
		global $wpdb;
		$this->ensure_charset();

		$ident       = $this->ident( $table );
		$columns     = $this->get_columns( $table );
		$pk          = $this->get_primary_key( $table );
		$is_first    = empty( $cursor );
		$rows_out    = array();
		$bytes       = 0;
		$next_cursor = null;
		$done        = false;

		if ( $pk ) {
			$pk_expr = $this->pk_expr( $table, $pk );
			$last_pk = ( $cursor && isset( $cursor['last_pk'] ) ) ? $cursor['last_pk'] : null;
			while ( true ) {
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- テーブル名とPK列はident()でバッククォートを除いてから囲んだ識別子。値は%s/%dで渡す。
				if ( null === $last_pk ) {
					$sql = $wpdb->prepare( "SELECT * FROM `$ident` ORDER BY {$pk_expr} ASC LIMIT %d", self::BATCH_ROWS );
				} else {
					$sql = $wpdb->prepare( "SELECT * FROM `$ident` WHERE {$pk_expr} > %s ORDER BY {$pk_expr} ASC LIMIT %d", $last_pk, self::BATCH_ROWS );
				}
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$batch = $wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。テーブルの全行を移行用に読み出すため、コアAPIもキャッシュも使えない。
				if ( empty( $batch ) ) {
					$done = true;
					break;
				}
				$pk_index = array_search( $pk, $columns, true );
				foreach ( $batch as $row ) {
					$rows_out[] = $row;
					$last_pk    = $row[ $pk_index ];
					$bytes     += $this->row_bytes( $row );
				}
				if ( count( $batch ) < self::BATCH_ROWS ) {
					$done = true;
					break;
				}
				if ( $bytes >= $limit_bytes ) {
					break;
				}
			}
			if ( ! $done ) {
				$next_cursor = array(
					'table'   => $table,
					'last_pk' => $last_pk,
				);
			}
		} else {
			$offset = ( $cursor && isset( $cursor['offset'] ) ) ? (int) $cursor['offset'] : 0;
			while ( true ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- テーブル名はident()でバッククォートを除いてから囲んだ識別子。
				$sql   = $wpdb->prepare( "SELECT * FROM `$ident` LIMIT %d OFFSET %d", self::BATCH_ROWS, $offset );
				$batch = $wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- $sqlは直前でprepare済み。テーブルの全行を移行用に読み出すため、コアAPIもキャッシュも使えない。
				if ( empty( $batch ) ) {
					$done = true;
					break;
				}
				foreach ( $batch as $row ) {
					$rows_out[] = $row;
					++$offset;
					$bytes += $this->row_bytes( $row );
				}
				if ( count( $batch ) < self::BATCH_ROWS ) {
					$done = true;
					break;
				}
				if ( $bytes >= $limit_bytes ) {
					break;
				}
			}
			if ( ! $done ) {
				$next_cursor = array(
					'table'  => $table,
					'offset' => $offset,
				);
			}
		}

		return array(
			'columns'     => $columns,
			'rows'        => $rows_out,
			'next_cursor' => $next_cursor,
			'done'        => $done,
			'is_first'    => $is_first,
		);
	}

	/**
	 * pull 用にローカルテーブルを準備する（先頭チャンク）。
	 * 存在すれば TRUNCATE、無ければ create_sql で作成。
	 *
	 * @param string $table      テーブル名。
	 * @param string $create_sql CREATE TABLE 文。
	 * @return true|WP_Error
	 */
	public function prepare_table( $table, $create_sql ) {
		global $wpdb;
		$ident = $this->ident( $table );

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $ident ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( $exists ) {
			$wpdb->query( "TRUNCATE TABLE `{$ident}`" ); // phpcs:ignore WordPress.DB
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'ferryman_local_truncate', 'ローカル TRUNCATE 失敗: ' . $wpdb->last_error );
			}
			return true;
		}
		if ( '' === (string) $create_sql ) {
			return new WP_Error( 'ferryman_local_no_create', 'テーブルが無く CREATE 文もありません: ' . $table );
		}
		$wpdb->query( $create_sql ); // phpcs:ignore WordPress.DB
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_local_create', 'ローカル CREATE 失敗: ' . $wpdb->last_error );
		}
		return true;
	}

	/**
	 * テーブルに対応する一時テーブル名を返す。
	 *
	 * @param string $table テーブル名。
	 * @return string
	 */
	public function temp_name( $table ) {
		return $this->ident( $table ) . '_fmtmp';
	}

	/**
	 * 一時テーブルを用意する（先頭チャンク）。既存構造を LIKE で複製、無ければ create_sql。
	 *
	 * 本物のテーブルには触れず、ここに全チャンクを書き込んでから finalize_table で
	 * RENAME 切替する（中断時の半壊を防ぐアトミック方式）。
	 *
	 * @param string $table      テーブル名。
	 * @param string $create_sql CREATE TABLE 文（元テーブルが無い場合に使用）。
	 * @return true|WP_Error
	 */
	public function prepare_temp_table( $table, $create_sql ) {
		global $wpdb;
		$ident = $this->ident( $table );
		$temp  = $this->temp_name( $table );

		$wpdb->query( "DROP TABLE IF EXISTS `{$temp}`" ); // phpcs:ignore WordPress.DB
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_temp_drop', '一時テーブル削除失敗: ' . $wpdb->last_error );
		}

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $ident ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( $exists ) {
			$wpdb->query( "CREATE TABLE `{$temp}` LIKE `{$ident}`" ); // phpcs:ignore WordPress.DB
		} elseif ( '' !== (string) $create_sql ) {
			$wpdb->query( $this->rewrite_create_name( $create_sql, $ident, $temp ) ); // phpcs:ignore WordPress.DB
		} else {
			return new WP_Error( 'ferryman_temp_nocreate', '一時テーブルを作成できません（元テーブルも CREATE 文もなし）: ' . $table );
		}
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_temp_create', '一時テーブル作成失敗: ' . $wpdb->last_error );
		}
		return true;
	}

	/**
	 * 一時テーブルを本物のテーブルへアトミックに切り替える（完了時）。
	 *
	 * @param string $table テーブル名。
	 * @return true|WP_Error
	 */
	public function finalize_table( $table ) {
		global $wpdb;
		$ident = $this->ident( $table );
		$temp  = $this->temp_name( $table );
		$old   = $ident . '_fmold';

		$wpdb->query( "DROP TABLE IF EXISTS `{$old}`" ); // phpcs:ignore WordPress.DB

		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $ident ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- テーブルの有無を確かめる。コアAPIはなく、直前の操作を反映した状態が要る。
		if ( $exists ) {
			// 既存→退避、一時→本番 を 1 文でアトミックに。
			$wpdb->query( "RENAME TABLE `{$ident}` TO `{$old}`, `{$temp}` TO `{$ident}`" ); // phpcs:ignore WordPress.DB
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'ferryman_finalize_rename', 'テーブル切替失敗: ' . $wpdb->last_error );
			}
			$wpdb->query( "DROP TABLE IF EXISTS `{$old}`" ); // phpcs:ignore WordPress.DB
		} else {
			$wpdb->query( "RENAME TABLE `{$temp}` TO `{$ident}`" ); // phpcs:ignore WordPress.DB
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'ferryman_finalize_rename', 'テーブル切替失敗: ' . $wpdb->last_error );
			}
		}
		return true;
	}

	/**
	 * 中断した移行で残った一時テーブルを掃除する。
	 *
	 * @param string $table テーブル名。
	 * @return void
	 */
	public function drop_temp_table( $table ) {
		global $wpdb;
		$temp = $this->temp_name( $table );
		$wpdb->query( "DROP TABLE IF EXISTS `{$temp}`" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * CREATE TABLE 文の先頭テーブル名を一時テーブル名へ書き換える。
	 *
	 * @param string $create_sql CREATE 文。
	 * @param string $ident      元テーブル名。
	 * @param string $temp       一時テーブル名。
	 * @return string
	 */
	private function rewrite_create_name( $create_sql, $ident, $temp ) {
		return preg_replace(
			'/^(\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?)`' . preg_quote( $ident, '/' ) . '`/i',
			'${1}`' . $temp . '`',
			$create_sql,
			1
		);
	}

	/**
	 * pull 用にローカルへ行を書き込む（変換済みの生値）。
	 *
	 * @param string $table   テーブル名。
	 * @param array  $columns カラム名一覧。
	 * @param array  $rows    行（各セルは生値 / NULL）。
	 * @return int|WP_Error 書き込み行数。
	 */
	public function write_rows( $table, array $columns, array $rows ) {
		global $wpdb;
		if ( empty( $rows ) ) {
			return 0;
		}
		$ident     = $this->ident( $table );
		$generated = $this->get_generated_columns( $table );
		// 生成列は INSERT できないため除外する。
		$skip       = array();
		$col_idents = array();
		foreach ( $columns as $i => $c ) {
			if ( in_array( $c, $generated, true ) ) {
				$skip[ $i ] = true;
				continue;
			}
			$col_idents[] = '`' . $this->ident( $c ) . '`';
		}
		$col_sql = implode( ', ', $col_idents );

		$tuples = array();
		foreach ( $rows as $row ) {
			$cells = array();
			foreach ( $row as $i => $cell ) {
				if ( isset( $skip[ $i ] ) ) {
					continue; // 生成列セルは書かない。
				}
				if ( null === $cell ) {
					$cells[] = 'NULL';
				} else {
					$cells[] = $wpdb->prepare( '%s', $cell );
				}
			}
			$tuples[] = '(' . implode( ', ', $cells ) . ')';
		}
		$sql    = "REPLACE INTO `{$ident}` ({$col_sql}) VALUES " . implode( ', ', $tuples );
		$result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 値は1セルずつprepare('%s')済み、識別子はident()済み。移行先テーブルへの一括書き込みにコアAPIはない。
		if ( false === $result ) {
			return new WP_Error( 'ferryman_local_write', 'ローカル書き込み失敗: ' . $wpdb->last_error );
		}
		return count( $rows );
	}

	/**
	 * wp_options テーブルから ferryman_ 以外のすべての行を削除する。
	 *
	 * TRUNCATE の代わりに使う。これにより Ferryman のモード・設定・セッションが
	 * pull 中も wp_options に残り続け、チャンク途中でも self がリセットされない。
	 *
	 * @return true|WP_Error
	 */
	public function clear_options_table() {
		global $wpdb;
		$wpdb->query( "DELETE FROM `{$wpdb->options}` WHERE `option_name` NOT LIKE 'ferryman\_%'" ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 可変部分のない固定のクエリ。ferryman_以外のオプションを一括で消すコアAPIはない。
		if ( '' !== $wpdb->last_error ) {
			return new WP_Error( 'ferryman_options_clear', 'wp_options クリア失敗: ' . $wpdb->last_error );
		}
		return true;
	}

	/**
	 * wp_options 専用の書き込み。
	 *
	 * option_id（主キー）を送らず option_name 基準で upsert する。
	 * これにより本番の option_id がローカルの ferryman_ 行の option_id と衝突して
	 * REPLACE INTO がその行を削除してしまう事故を防ぐ。
	 *
	 * @param array $columns カラム名一覧。
	 * @param array $rows    行（各セルは生値 / NULL）。
	 * @return int|WP_Error 書き込み行数。
	 */
	public function write_options_rows( array $columns, array $rows ) {
		global $wpdb;
		if ( empty( $rows ) ) {
			return 0;
		}

		// option_id カラムは AUTO_INCREMENT に任せるため除外する。
		$skip = array_search( 'option_id', $columns, true );

		$use_cols   = array();
		$col_idents = array();
		foreach ( $columns as $i => $c ) {
			if ( $i === $skip ) {
				continue;
			}
			$use_cols[]   = $c;
			$col_idents[] = '`' . $this->ident( $c ) . '`';
		}
		if ( empty( $use_cols ) ) {
			return new WP_Error( 'ferryman_options_no_cols', 'wp_options のカラムが特定できません。' );
		}
		$col_sql = implode( ', ', $col_idents );

		$tuples = array();
		foreach ( $rows as $row ) {
			$cells = array();
			foreach ( $row as $i => $cell ) {
				if ( $i === $skip ) {
					continue;
				}
				if ( null === $cell ) {
					$cells[] = 'NULL';
				} else {
					$cells[] = $wpdb->prepare( '%s', $cell );
				}
			}
			$tuples[] = '(' . implode( ', ', $cells ) . ')';
		}

		// option_name UNIQUE を基準に value/autoload を更新。
		$updates = array();
		foreach ( $use_cols as $c ) {
			if ( 'option_name' === $c ) {
				continue;
			}
			$ci        = '`' . $this->ident( $c ) . '`';
			$updates[] = "{$ci} = VALUES({$ci})";
		}
		$update_sql = empty( $updates ) ? '`option_name` = VALUES(`option_name`)' : implode( ', ', $updates );

		$sql    = "INSERT INTO `{$wpdb->options}` ({$col_sql}) VALUES " . implode( ', ', $tuples )
			. " ON DUPLICATE KEY UPDATE {$update_sql}";
		$result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery -- 値は1セルずつprepare('%s')済み、列名はident()済み。オプションの一括書き込みにコアAPIはない。

		if ( false === $result ) {
			return new WP_Error( 'ferryman_options_write', 'wp_options 書き込み失敗: ' . $wpdb->last_error );
		}
		return count( $rows );
	}

	/**
	 * 行の概算バイト数。
	 *
	 * @param array $row ARRAY_N の行。
	 * @return int
	 */
	private function row_bytes( $row ) {
		$bytes = 0;
		foreach ( $row as $cell ) {
			if ( null !== $cell ) {
				$bytes += strlen( $cell );
			}
		}
		return $bytes;
	}

	/**
	 * 識別子サニタイズ（バッククォート除去）。
	 *
	 * @param string $name 識別子。
	 * @return string
	 */
	private function ident( $name ) {
		return str_replace( '`', '', (string) $name );
	}
}
