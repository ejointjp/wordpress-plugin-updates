<?php
/**
 * プラグイン同期の管理画面（全モード共通）。
 *
 * 書き出し（JSONダウンロード）、読み込み（本番から取得 / JSONファイル）、
 * 差分表からの1行ずつのインストール・有効化を提供する。
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/**
 * プラグイン同期UI。
 */
class Ferryman_Plugins_Admin {

	const PARENT_SLUG  = 'ferryman';
	const MENU_SLUG    = 'ferryman-plugins';
	const NONCE_ACTION = 'ferryman_plugins_ajax';
	const NONCE_EXPORT = 'ferryman_plugins_export';
	const CAPABILITY   = 'manage_options';

	const MAX_JSON_BYTES = 1048576; // 読み込むJSONの上限（1MB）。

	/**
	 * インストーラ。
	 *
	 * @var Ferryman_Plugins_Installer
	 */
	private $installer;

	/**
	 * 自ページのフックサフィックス（add_submenu_pageの戻り値）。
	 *
	 * @var string|false
	 */
	private $hook_suffix = false;

	/**
	 * コンストラクタ。
	 */
	public function __construct() {
		$this->installer = new Ferryman_Plugins_Installer();
	}

	/**
	 * フック登録。
	 *
	 * メニューの優先度: モード設定済みなら各モードのメニュー（既定10）の後・
	 * 「動作モード」（100）の前に出す。未設定ならセットアップ画面のトップメニュー（100）の
	 * 後に登録する（先に登録するとトップメニューのリンク先を奪ってしまうため）。
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu' ), Ferryman_Mode::is_set() ? 90 : 110 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_ferryman_plugins_export', array( $this, 'handle_export' ) );
		add_action( 'wp_ajax_ferryman_plugins_import_json', array( $this, 'ajax_import_json' ) );
		add_action( 'wp_ajax_ferryman_plugins_fetch_remote', array( $this, 'ajax_fetch_remote' ) );
		add_action( 'wp_ajax_ferryman_plugins_install', array( $this, 'ajax_install' ) );
		add_action( 'wp_ajax_ferryman_plugins_activate', array( $this, 'ajax_activate' ) );
	}

	/**
	 * メニュー追加。
	 *
	 * @return void
	 */
	public function add_menu() {
		$this->hook_suffix = add_submenu_page(
			self::PARENT_SLUG,
			'プラグイン同期',
			'プラグイン同期',
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * スクリプト・スタイル読み込み（自ページのみ）。
	 *
	 * @param string $hook 現在のフックサフィックス。
	 * @return void
	 */
	public function enqueue( $hook ) {
		if ( ! $this->hook_suffix || $hook !== $this->hook_suffix ) {
			return;
		}
		// コントローラ側が同じハンドルで登録済みならそのまま使われる。
		wp_enqueue_style(
			'ferryman-ctrl-admin',
			FERRYMAN_URL . 'assets/css/admin.css',
			array(),
			$this->asset_version( 'assets/css/admin.css' )
		);
		wp_enqueue_script(
			'ferryman-plugins',
			FERRYMAN_URL . 'assets/js/plugins.js',
			array( 'jquery', 'wp-a11y' ),
			$this->asset_version( 'assets/js/plugins.js' ),
			true
		);
		wp_localize_script(
			'ferryman-plugins',
			'FerrymanPlugins',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
			)
		);
	}

	/**
	 * アセットのキャッシュバスター（ファイルの更新時刻を優先）。
	 *
	 * @param string $relative_path プラグインルートからの相対パス。
	 * @return string
	 */
	private function asset_version( $relative_path ) {
		$file = FERRYMAN_DIR . $relative_path;
		if ( file_exists( $file ) ) {
			return FERRYMAN_VERSION . '.' . filemtime( $file );
		}
		return FERRYMAN_VERSION;
	}

	/**
	 * 画面描画。
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$can_fetch_remote = ( null !== $this->remote_client() );
		$export_url       = wp_nonce_url( admin_url( 'admin-post.php?action=ferryman_plugins_export' ), self::NONCE_EXPORT );
		require FERRYMAN_DIR . 'admin/view-plugins.php';
	}

	/**
	 * JSON書き出し（ダウンロード）。
	 *
	 * @return void
	 */
	public function handle_export() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE_EXPORT );

		$manifest = $this->installer->local_manifest();
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );
		$host     = $host ? preg_replace( '/[^A-Za-z0-9.-]+/', '-', $host ) : 'site';
		$filename = 'ferryman-plugins-' . $host . '-' . wp_date( 'Ymd' ) . '.json';

		$json = wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $json ) {
			wp_die( 'プラグイン一覧をJSONに変換できませんでした。' );
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSONをそのまま送る。
		exit;
	}

	/**
	 * JSONファイルを読み込んで差分を返す。
	 *
	 * @return void
	 */
	public function ajax_import_json() {
		$this->guard();

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification.Missing -- 中身はFerryman_Plugins_Manifest::validate()で検証する。nonceはguard()で検証済み。
		if ( empty( $_FILES['manifest'] ) || ! is_array( $_FILES['manifest'] ) ) {
			wp_send_json_error( array( 'message' => 'JSONファイルが選択されていません。' ) );
		}
		$upload = $_FILES['manifest'];
		// phpcs:enable
		if ( ! empty( $upload['error'] ) || empty( $upload['tmp_name'] ) || ! is_uploaded_file( $upload['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => 'アップロードに失敗しました。' ) );
		}
		if ( (int) $upload['size'] > self::MAX_JSON_BYTES ) {
			wp_send_json_error( array( 'message' => 'ファイルが大きすぎます（上限1MB）。' ) );
		}

		$json = file_get_contents( $upload['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- アップロードの一時ファイル。
		if ( false === $json ) {
			wp_send_json_error( array( 'message' => 'アップロードされたファイルを読み込めませんでした。' ) );
		}
		$this->respond_with_diff( json_decode( $json, true ) );
	}

	/**
	 * 本番（コンパニオン）からマニフェストを取得して差分を返す。
	 *
	 * RESTの応答も外部入力としてvalidate()を通す（respond_with_diff内）。
	 *
	 * @return void
	 */
	public function ajax_fetch_remote() {
		$this->guard();
		$client = $this->remote_client();
		if ( null === $client ) {
			wp_send_json_error( array( 'message' => 'コントローラの接続設定がありません。' ) );
		}

		$res = $client->plugins_list();
		if ( is_wp_error( $res ) ) {
			// 古い本番（ルートが未登録）にはWordPressがrest_no_routeを返す。
			// 本番URLのパス誤りなどによる他の404は、原因を取り違えないよう汎用のエラーで返す。
			if ( 'rest_no_route' === $res->get_error_code() ) {
				wp_send_json_error( array( 'message' => '本番側のFerrymanがプラグイン同期に未対応です。本番のFerrymanを更新してください。' ) );
			}
			wp_send_json_error( array( 'message' => '本番からの取得に失敗: ' . $res->get_error_message() ) );
		}
		$this->respond_with_diff( $res );
	}

	/**
	 * マニフェストを検証し、このサイトとの差分をJSONで返す。
	 *
	 * @param mixed $decoded 取込元のマニフェスト（デコード済み）。
	 * @return void
	 */
	private function respond_with_diff( $decoded ) {
		$manifest = Ferryman_Plugins_Manifest::validate( $decoded );
		if ( is_wp_error( $manifest ) ) {
			wp_send_json_error( array( 'message' => $manifest->get_error_message() ) );
		}
		$local = $this->installer->local_manifest( false );
		$rows  = Ferryman_Plugins_Manifest::diff( $manifest['plugins'], $local['plugins'] );

		wp_send_json_success(
			array(
				'manifest' => array(
					'site'         => $manifest['site'],
					'wp_version'   => $manifest['wp_version'],
					'generated_at' => $manifest['generated_at'],
					'count'        => count( $manifest['plugins'] ),
				),
				'rows'     => $rows,
			)
		);
	}

	/**
	 * 1プラグインをwordpress.orgからインストールする。
	 *
	 * @return void
	 */
	public function ajax_install() {
		$this->guard();
		$entry  = $this->entry_from_request();
		$policy = isset( $_POST['version_policy'] ) ? sanitize_key( wp_unslash( $_POST['version_policy'] ) ) : 'same'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard()で検証済み。

		$result = $this->installer->install( $entry['slug'], $entry['version'], 'latest' !== $policy );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$message = 'インストールしました';
		if ( '' !== $result['version'] ) {
			$message .= '（' . $result['version'] . '）';
		}
		if ( $result['fallback'] ) {
			$message .= ' ※同じ版がないため最新版';
		}
		wp_send_json_success(
			array(
				'file'     => $result['file'],
				'version'  => $result['version'],
				'fallback' => $result['fallback'],
				'message'  => $message,
			)
		);
	}

	/**
	 * 1プラグインを有効化する。
	 *
	 * @return void
	 */
	public function ajax_activate() {
		$this->guard();
		$entry = $this->entry_from_request();
		if ( ! $entry['active'] ) {
			// JSも送らないが、取込元で無効のプラグインはサーバ側でも有効化しない。
			wp_send_json_error( array( 'message' => '取込元で無効のため有効化しません。' ) );
		}

		$result = $this->installer->activate( $entry['file'] );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => '有効化に失敗: ' . $result->get_error_message(),
				)
			);
		}
		wp_send_json_success(
			array( 'message' => $result['already'] ? '有効（既に有効でした）' : '有効化しました' )
		);
	}

	/**
	 * AJAXの入力から1エントリを検証して取り出す。不正ならJSONエラーで終了する。
	 *
	 * マニフェストをサーバに保持しないため、JSからの入力を毎回検証する。
	 *
	 * @return array
	 */
	private function entry_from_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- guard()で検証済み。値はFerryman_Plugins_Manifest::validate_entry()で検証する。
		$raw = array(
			'file'    => isset( $_POST['file'] ) ? (string) wp_unslash( $_POST['file'] ) : '',
			'slug'    => isset( $_POST['slug'] ) ? (string) wp_unslash( $_POST['slug'] ) : '',
			'version' => isset( $_POST['version'] ) ? (string) wp_unslash( $_POST['version'] ) : '',
			'active'  => ! empty( $_POST['active'] ) && '0' !== $_POST['active'],
		);
		// phpcs:enable
		$entry = Ferryman_Plugins_Manifest::validate_entry( $raw );
		if ( is_wp_error( $entry ) ) {
			wp_send_json_error( array( 'message' => '入力が不正です: ' . $entry->get_error_message() ) );
		}
		return $entry;
	}

	/**
	 * コントローラの接続設定からクライアントを組み立てる。
	 *
	 * コントローラモードでなければ、または接続設定がなければnull。
	 *
	 * @return Ferryman_Ctrl_Client|null
	 */
	private function remote_client() {
		if ( Ferryman_Mode::CONTROLLER !== Ferryman_Mode::get() || ! class_exists( 'Ferryman_Ctrl' ) ) {
			return null;
		}
		$settings = Ferryman_Ctrl::instance()->settings;
		if ( ! $settings->is_configured() ) {
			return null;
		}
		return new Ferryman_Ctrl_Client( $settings->get_remote_url(), $settings->get_secret() );
	}

	/**
	 * 権限・nonce検証（AJAX用）。
	 *
	 * @return void
	 */
	private function guard() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => '権限がありません。' ), 403 );
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}
}
