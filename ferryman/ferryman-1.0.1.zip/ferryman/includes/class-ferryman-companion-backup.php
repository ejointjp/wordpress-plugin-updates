<?php
/**
 * push 直前の対象テーブルを保護ディレクトリへ .sql ダンプする。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * バックアップ生成と世代管理。
 */
class Ferryman_Companion_Backup {

	/**
	 * 保護ディレクトリのベース名（uploads 配下）。
	 */
	const BASE_DIRNAME = 'ferryman-backups';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Companion_Settings
	 */
	private $settings;

	/**
	 * ダンパー。
	 *
	 * @var Ferryman_Companion_Dumper
	 */
	private $dumper;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Companion_Settings $settings 設定。
	 * @param Ferryman_Companion_Dumper   $dumper   ダンパー。
	 */
	public function __construct( Ferryman_Companion_Settings $settings, Ferryman_Companion_Dumper $dumper ) {
		$this->settings = $settings;
		$this->dumper   = $dumper;
	}

	/**
	 * 指定テーブル群をバックアップする。
	 *
	 * @param string[] $tables テーブル名一覧。
	 * @return array|WP_Error { backup_id, path, url, tables, time, size }。
	 */
	public function create( array $tables ) {
		if ( empty( $tables ) ) {
			return new WP_Error( 'ferryman_backup_no_tables', 'バックアップ対象テーブルがありません。', array( 'status' => 400 ) );
		}

		// 無制限実行（shared host 対策）。
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		}

		$base = $this->ensure_base_dir();
		if ( is_wp_error( $base ) ) {
			return $base;
		}

		$backup_id = wp_generate_password( 16, false, false );
		$dir       = trailingslashit( $base['dir'] ) . $backup_id;
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'ferryman_backup_mkdir', 'バックアップディレクトリを作成できません。', array( 'status' => 500 ) );
		}
		$this->protect_dir( $dir );

		$timestamp = time();
		$filename  = 'backup-' . gmdate( 'Ymd-His', $timestamp ) . '.sql';
		$filepath  = trailingslashit( $dir ) . $filename;

		$handle = fopen( $filepath, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $handle ) {
			return new WP_Error( 'ferryman_backup_open', 'バックアップファイルを開けません。', array( 'status' => 500 ) );
		}

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- ダンプは大きくなるため、全体をメモリに載せるWP_Filesystem::put_contents()ではなくストリームへ逐次書き込む。
		$this->write_header( $handle, $tables, $timestamp );
		fwrite( $handle, "SET NAMES utf8mb4;\n" );
		// リストア時の strict 系エラー（ゼロ日付・厳格モード等）を避けて取り込み成功率を上げる。
		fwrite( $handle, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n" );
		fwrite( $handle, "SET FOREIGN_KEY_CHECKS=0;\n" );
		foreach ( $tables as $table ) {
			if ( $this->dumper->is_valid_table( $table ) ) {
				$this->dumper->write_table_sql( $table, $handle );
			}
		}
		fwrite( $handle, "SET FOREIGN_KEY_CHECKS=1;\n" );
		// phpcs:enable
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$entry = array(
			'backup_id' => $backup_id,
			'path'      => $filepath,
			'url'       => '', // web 非公開のため URL は提供しない。
			'tables'    => array_values( $tables ),
			'time'      => current_time( 'mysql' ),
			'size'      => (int) @filesize( $filepath ), // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors
		);
		$this->settings->add_backup( $entry );
		$this->rotate( $base['dir'] );

		return $entry;
	}

	/**
	 * uploads 配下のベースディレクトリを用意し保護する。
	 *
	 * @return array|WP_Error { dir }。
	 */
	private function ensure_base_dir() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			return new WP_Error( 'ferryman_backup_uploads', 'uploads ディレクトリを取得できません: ' . $uploads['error'], array( 'status' => 500 ) );
		}
		$dir = trailingslashit( $uploads['basedir'] ) . self::BASE_DIRNAME;
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'ferryman_backup_basedir', 'バックアップベースディレクトリを作成できません。', array( 'status' => 500 ) );
		}
		$this->protect_dir( $dir );
		return array( 'dir' => $dir );
	}

	/**
	 * ディレクトリを web 非公開化する（.htaccess deny + 空 index.php）。
	 *
	 * @param string $dir ディレクトリ。
	 * @return void
	 */
	private function protect_dir( $dir ) {
		$htaccess = trailingslashit( $dir ) . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Order allow,deny\nDeny from all\nRequire all denied\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$index = trailingslashit( $dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}

	/**
	 * SQL ヘッダコメントを書く。
	 *
	 * @param resource $handle    ハンドル。
	 * @param string[] $tables    対象テーブル。
	 * @param int      $timestamp タイムスタンプ。
	 * @return void
	 */
	private function write_header( $handle, $tables, $timestamp ) {
		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- create()が開いたストリームへ逐次書き込む。
		fwrite( $handle, "-- Ferryman push backup\n" );
		fwrite( $handle, '-- Generated: ' . gmdate( 'Y-m-d H:i:s', $timestamp ) . " UTC\n" );
		fwrite( $handle, '-- Site: ' . home_url() . "\n" );
		fwrite( $handle, '-- Tables: ' . implode( ', ', $tables ) . "\n\n" );
		// phpcs:enable
	}

	/**
	 * 古い世代を削除する（FERRYMAN_BACKUP_KEEP 世代を保持）。
	 *
	 * @param string $base_dir ベースディレクトリ。
	 * @return void
	 */
	private function rotate( $base_dir ) {
		$list = $this->settings->get_backups();
		if ( count( $list ) <= FERRYMAN_BACKUP_KEEP ) {
			return;
		}
		$keep   = array_slice( $list, 0, FERRYMAN_BACKUP_KEEP );
		$remove = array_slice( $list, FERRYMAN_BACKUP_KEEP );
		foreach ( $remove as $old ) {
			if ( ! empty( $old['path'] ) && 0 === strpos( $old['path'], $base_dir ) ) {
				$this->delete_backup_dir( dirname( $old['path'] ), $base_dir );
			}
		}
		$this->settings->set_backups( $keep );
	}

	/**
	 * バックアップディレクトリを安全に削除する。
	 *
	 * @param string $dir      削除対象ディレクトリ。
	 * @param string $base_dir ベース（配下であることを保証）。
	 * @return void
	 */
	private function delete_backup_dir( $dir, $base_dir ) {
		// ベース配下のみ削除を許可（誤削除防止）。
		if ( 0 !== strpos( $dir, trailingslashit( $base_dir ) ) ) {
			return;
		}
		foreach ( (array) glob( trailingslashit( $dir ) . '*' ) as $file ) {
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}
		// .htaccess / index.php も削除。
		foreach ( array( '.htaccess', 'index.php' ) as $hidden ) {
			$p = trailingslashit( $dir ) . $hidden;
			if ( is_file( $p ) ) {
				wp_delete_file( $p );
			}
		}
		@rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, Generic.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
	}
}
