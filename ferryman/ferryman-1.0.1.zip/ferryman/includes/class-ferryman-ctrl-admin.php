<?php
/**
 * コントローラ管理画面（接続設定・移行）。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * ローカル側 UI。
 */
class Ferryman_Ctrl_Admin {

	const MENU_SLUG     = 'ferryman';
	const MIGRATE_SLUG  = 'ferryman-migrate';
	const FILES_SLUG    = 'ferryman-files';
	const NONCE_SETTING = 'ferryman_ctrl_settings_save';
	const CAPABILITY    = 'manage_options';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Ctrl_Settings
	 */
	private $settings;

	/**
	 * 移行エンジン。
	 *
	 * @var Ferryman_Ctrl_Migrator
	 */
	private $migrator;

	/**
	 * ファイル同期エンジン。
	 *
	 * @var Ferryman_Ctrl_Files
	 */
	private $files;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Ctrl_Settings $settings 設定。
	 * @param Ferryman_Ctrl_Migrator $migrator 移行エンジン。
	 * @param Ferryman_Ctrl_Files    $files    ファイル同期エンジン。
	 */
	public function __construct( Ferryman_Ctrl_Settings $settings, Ferryman_Ctrl_Migrator $migrator, Ferryman_Ctrl_Files $files ) {
		$this->settings = $settings;
		$this->migrator = $migrator;
		$this->files    = $files;
	}

	/**
	 * フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_ferryman_ctrl_save', array( $this, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * メニュー追加（設定 + 移行）。
	 *
	 * @return void
	 */
	public function add_menu() {
		add_menu_page(
			'Ferryman',
			'Ferryman',
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_settings' ),
			'dashicons-migrate',
			80
		);
		add_submenu_page(
			self::MENU_SLUG,
			'接続設定',
			'接続設定',
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_settings' )
		);
		add_submenu_page(
			self::MENU_SLUG,
			'DB 移行',
			'DB 移行',
			self::CAPABILITY,
			self::MIGRATE_SLUG,
			array( $this, 'render_migrate' )
		);
		add_submenu_page(
			self::MENU_SLUG,
			'ファイル同期',
			'ファイル同期',
			self::CAPABILITY,
			self::FILES_SLUG,
			array( $this, 'render_files' )
		);
	}

	/**
	 * スクリプト・スタイル読み込み（自ページのみ）。
	 *
	 * @param string $hook 現在のフックサフィックス。
	 * @return void
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( $hook, self::MENU_SLUG ) && false === strpos( $hook, self::MIGRATE_SLUG ) ) {
			return;
		}
		wp_enqueue_style(
			'ferryman-ctrl-admin',
			FERRYMAN_CTRL_URL . 'assets/css/admin.css',
			array(),
			$this->asset_version( 'assets/css/admin.css' )
		);
		wp_enqueue_script(
			'ferryman-ctrl-admin',
			FERRYMAN_CTRL_URL . 'assets/js/admin.js',
			array( 'jquery', 'wp-a11y' ),
			$this->asset_version( 'assets/js/admin.js' ),
			true
		);
		wp_localize_script(
			'ferryman-ctrl-admin',
			'FerrymanCtrl',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( Ferryman_Ctrl_Migrator::NONCE_ACTION ),
			)
		);

		// ファイル同期ページではドライバを追加で読み込む（FerrymanCtrl を共用）。
		if ( false !== strpos( $hook, self::FILES_SLUG ) ) {
			wp_enqueue_script(
				'ferryman-ctrl-files',
				FERRYMAN_CTRL_URL . 'assets/js/files.js',
				array( 'jquery', 'ferryman-ctrl-admin' ),
				$this->asset_version( 'assets/js/files.js' ),
				true
			);
		}
	}

	/**
	 * アセットのキャッシュバスター。
	 *
	 * プラグイン版数だけを使うと、版数を上げない修正がブラウザキャッシュに阻まれて
	 * 反映されないため、ファイルの更新時刻を優先して用いる。
	 *
	 * @param string $relative_path プラグインルートからの相対パス。
	 * @return string
	 */
	private function asset_version( $relative_path ) {
		$file = FERRYMAN_CTRL_DIR . $relative_path;
		if ( file_exists( $file ) ) {
			return FERRYMAN_CTRL_VERSION . '.' . filemtime( $file );
		}
		return FERRYMAN_CTRL_VERSION;
	}

	/**
	 * 設定保存。
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE_SETTING );

		$remote_url = isset( $_POST['remote_url'] ) ? esc_url_raw( wp_unslash( $_POST['remote_url'] ) ) : '';
		$values     = array( 'remote_url' => $remote_url );

		// 秘密キーは入力があったときだけ更新（マスキング表示のまま保存しない）。
		// 定数で固定されている場合は DB に保存しない（定数運用を尊重）。
		$secret_in = isset( $_POST['secret'] ) ? sanitize_text_field( wp_unslash( $_POST['secret'] ) ) : '';
		if ( ! $this->settings->secret_is_constant() && '' !== $secret_in && 0 === substr_count( $secret_in, '•' ) ) {
			$values['secret'] = $secret_in;
		}

		$this->settings->update( $values );
		ferryman_redirect_with_notice( self::MENU_SLUG, 'settings_updated', '設定を保存しました。' );
	}

	/**
	 * 接続設定ページ描画。
	 *
	 * @return void
	 */
	public function render_settings() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		require FERRYMAN_CTRL_DIR . 'admin/view-settings.php';
	}

	/**
	 * 移行ページ描画。
	 *
	 * @return void
	 */
	public function render_migrate() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$configured = $this->settings->is_configured();
		$session    = $this->migrator->session()->get();
		require FERRYMAN_CTRL_DIR . 'admin/view-migrate.php';
	}

	/**
	 * ファイル同期ページ描画。
	 *
	 * @return void
	 */
	public function render_files() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$configured = $this->settings->is_configured();
		$session    = $this->files->session()->get();
		require FERRYMAN_CTRL_DIR . 'admin/view-files.php';
	}
}
