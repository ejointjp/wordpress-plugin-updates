<?php
/**
 * 受信リクエストの認証（トグル・HTTPS・HMAC署名・タイムスタンプ・方向許可）。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * permission_callback 段で使う検証ロジック。
 */
class Ferryman_Companion_Auth {

	const HEADER_TIMESTAMP = 'X-Ferryman-Timestamp';
	const HEADER_SIGNATURE = 'X-Ferryman-Signature';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Companion_Settings
	 */
	private $settings;

	/**
	 * 検証済みの結果（リクエストごと・方向許可ごと）。
	 *
	 * WordPress本体は応答を作ったあとAllowヘッダを計算するため、同じリクエストで
	 * permission_callbackをもう一度呼ぶ（rest_send_allow_header()）。検証をやり直すと
	 * 署名が使用済みとしてreplay_detectedで拒否され、拒否のログも重なるため、
	 * 1回目の結果を覚えておいて返す。
	 *
	 * SplObjectStorageはリクエストへの参照を持つため、spl_object_id()と違い、
	 * 破棄されたリクエストのIDが別のリクエストに再利用されて結果を取り違えることがない。
	 *
	 * @var SplObjectStorage
	 */
	private $verified;

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Companion_Settings $settings 設定。
	 */
	public function __construct( Ferryman_Companion_Settings $settings ) {
		$this->settings = $settings;
		$this->verified = new SplObjectStorage();
	}

	/**
	 * リクエストを検証する。成功時 true、失敗時 WP_Error(403)。
	 *
	 * 同じリクエスト・同じ方向許可での2回目以降の呼び出しは、検証もログの記録もやり直さず
	 * 1回目の結果を返す。別のリクエストが同じ署名を使えば、従来どおりリプレイとして拒否する。
	 *
	 * @param WP_REST_Request $request          リクエスト。
	 * @param string          $required_capability 必要な方向許可（'pull' | 'push' | ''）。
	 * @return true|WP_Error
	 */
	public function verify( WP_REST_Request $request, $required_capability = '' ) {
		$results = isset( $this->verified[ $request ] ) ? $this->verified[ $request ] : array();
		if ( ! array_key_exists( $required_capability, $results ) ) {
			$results[ $required_capability ] = $this->check( $request, $required_capability );
			$this->verified[ $request ]      = $results;
		}
		return $results[ $required_capability ];
	}

	/**
	 * 検証の本体。拒否したときはログに記録する。
	 *
	 * @param WP_REST_Request $request             リクエスト。
	 * @param string          $required_capability 必要な方向許可。
	 * @return true|WP_Error
	 */
	private function check( WP_REST_Request $request, $required_capability ) {
		$route = $request->get_route();

		// 1. マスタトグル。
		if ( ! $this->settings->get( 'enabled' ) ) {
			return $this->deny( $route, 'connection_disabled', '接続が無効です（マスタトグル OFF）。' );
		}

		// 2. HTTPS 必須（明示許可時を除く）。
		if ( ! is_ssl() && ! $this->settings->get( 'allow_insecure' ) ) {
			return $this->deny( $route, 'https_required', 'HTTPS が必須です。' );
		}

		// 3. 秘密キー設定済みか。
		$secret = $this->settings->get_secret();
		if ( '' === $secret ) {
			return $this->deny( $route, 'no_secret', '秘密キーが未設定です。' );
		}

		// 4. タイムスタンプ（リプレイ防止）。
		$timestamp = (int) $request->get_header( self::HEADER_TIMESTAMP );
		if ( $timestamp <= 0 ) {
			return $this->deny( $route, 'missing_timestamp', 'タイムスタンプヘッダがありません。' );
		}
		if ( abs( time() - $timestamp ) > FERRYMAN_TIMESTAMP_TOLERANCE ) {
			return $this->deny( $route, 'timestamp_expired', 'タイムスタンプが許容範囲外です（リプレイ防止）。' );
		}

		// 5. HMAC 署名。
		$provided = (string) $request->get_header( self::HEADER_SIGNATURE );
		if ( '' === $provided ) {
			return $this->deny( $route, 'missing_signature', '署名ヘッダがありません。' );
		}
		$expected = $this->sign( $timestamp, $request->get_method(), $route, $request->get_body(), $secret );
		if ( ! hash_equals( $expected, $provided ) ) {
			return $this->deny( $route, 'bad_signature', '署名が不正です。' );
		}

		// 5.5. 同一署名の再利用を拒否（リプレイ防止）。
		// タイムスタンプは許容ウィンドウ内なら通るため、捕捉した正当な署名を
		// ウィンドウ内に再送される攻撃を、署名の使用済み記録で1回限りに制限する。
		if ( ! $this->register_nonce( $provided ) ) {
			return $this->deny( $route, 'replay_detected', '署名が再利用されました（リプレイ防止）。' );
		}

		// 6. 方向許可。
		if ( 'pull' === $required_capability && ! $this->settings->get( 'allow_pull' ) ) {
			return $this->deny( $route, 'pull_not_allowed', 'pull(export) が許可されていません。' );
		}
		if ( 'push' === $required_capability && ! $this->settings->get( 'allow_push' ) ) {
			return $this->deny( $route, 'push_not_allowed', 'push(import) が許可されていません。' );
		}
		if ( 'file_pull' === $required_capability && ! $this->settings->get( 'allow_file_pull' ) ) {
			return $this->deny( $route, 'file_pull_not_allowed', 'ファイル pull（uploads 取得）が許可されていません。' );
		}

		return true;
	}

	/**
	 * REST API を未ログインに対して閉じるプラグイン・設定を、Ferryman のルートに限って回避する。
	 *
	 * `rest_authentication_errors` はルーティング前の共通フックのため、セキュリティ系プラグインが
	 * ここで WP_Error を返すと、Ferryman の permission_callback（HMAC 検証）まで到達せず 401 で落ちる。
	 * そこで「Ferryman の名前空間宛て」かつ「Ferryman の署名ヘッダが付いている」場合に限りエラーを
	 * 打ち消し、判定を permission_callback（Ferryman_Companion_Auth::verify）へ委ねる。
	 *
	 * ここで認証を通すわけではない点に注意。ヘッダの有無しか見ておらず、署名・タイムスタンプ・
	 * リプレイ・方向許可の検証はすべて従来どおり verify() が行う。
	 *
	 * @param WP_Error|true|null $errors 直前までの認証結果。
	 * @return WP_Error|true|null 打ち消す場合 null、それ以外は $errors のまま。
	 */
	public function allow_rest_authentication( $errors ) {
		if ( ! is_wp_error( $errors ) ) {
			return $errors;
		}

		// マスタトグル OFF のときは何もしない（どのみち verify() が拒否する）。
		if ( ! $this->settings->get( 'enabled' ) ) {
			return $errors;
		}

		if ( ! $this->is_ferryman_route() ) {
			return $errors;
		}

		// 署名ヘッダが無いリクエストは Ferryman のクライアントではないため素通ししない。
		$timestamp = isset( $_SERVER['HTTP_X_FERRYMAN_TIMESTAMP'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FERRYMAN_TIMESTAMP'] ) ) : '';
		$signature = isset( $_SERVER['HTTP_X_FERRYMAN_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FERRYMAN_SIGNATURE'] ) ) : '';
		if ( '' === $timestamp || '' === $signature ) {
			return $errors;
		}

		return null;
	}

	/**
	 * 現在のリクエストが Ferryman の名前空間宛てか判定する。
	 *
	 * @return bool
	 */
	private function is_ferryman_route() {
		$prefix = '/' . FERRYMAN_NAMESPACE . '/';

		if ( isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			$route = (string) $GLOBALS['wp']->query_vars['rest_route'];
			return 0 === strpos( $route, $prefix );
		}

		// パーマリンク無効時などで query_vars が未設定のケースへのフォールバック。
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
			return false !== strpos( $uri, rest_get_url_prefix() . $prefix );
		}

		return false;
	}

	/**
	 * 署名文字列を計算する。
	 *
	 * フォーマット: "{timestamp}\n{method}\n{route}\n{raw_body}"
	 *
	 * @param int    $timestamp UNIX 秒。
	 * @param string $method    HTTP メソッド（大文字）。
	 * @param string $route     REST ルート（例 /ferryman/v1/export）。
	 * @param string $body      生のリクエストボディ。
	 * @param string $secret    秘密キー。
	 * @return string
	 */
	public function sign( $timestamp, $method, $route, $body, $secret ) {
		$payload = $timestamp . "\n" . strtoupper( $method ) . "\n" . $route . "\n" . $body;
		return hash_hmac( 'sha256', $payload, $secret );
	}

	/**
	 * 署名を使用済みとして記録する。既に記録済みならリプレイとみなし false。
	 *
	 * 署名は sha256 hex（64文字）なのでそのまま transient キーに使える。
	 * 保持期間は許容ウィンドウの2倍。最悪のクロックずれ（timestamp が
	 * time() より tolerance 先行）でも、署名がリプレイ可能な
	 * 上限（timestamp + tolerance）まで記録が残ることを保証する。
	 *
	 * 注: get/set は厳密にはアトミックでないが、正規クライアントは毎回
	 * 異なる timestamp で署名するため同一署名を再送せず、防ぎたいのは
	 * 逐次的なリプレイ。実用上この粒度で十分。
	 *
	 * @param string $signature HMAC 署名（hex）。
	 * @return bool 新規登録できたら true、既出なら false。
	 */
	private function register_nonce( $signature ) {
		$key = 'ferryman_nonce_' . $signature;
		if ( false !== get_transient( $key ) ) {
			return false;
		}
		set_transient( $key, 1, 2 * FERRYMAN_TIMESTAMP_TOLERANCE );
		return true;
	}

	/**
	 * 拒否（403）。ログに記録して WP_Error を返す。
	 *
	 * @param string $route   ルート。
	 * @param string $code    エラーコード。
	 * @param string $message 理由。
	 * @return WP_Error
	 */
	private function deny( $route, $code, $message ) {
		$this->settings->log( $this->route_label( $route ), 'denied: ' . $code );
		return new WP_Error( 'ferryman_' . $code, $message, array( 'status' => 403 ) );
	}

	/**
	 * ルートからログ用ラベルを得る。
	 *
	 * @param string $route ルート。
	 * @return string
	 */
	private function route_label( $route ) {
		$parts = explode( '/', trim( $route, '/' ) );
		return end( $parts );
	}
}
