<?php
/**
 * コンパニオン管理画面（トグル・秘密キー・ログ・バックアップ一覧）。
 *
 * @package Ferryman_Companion
 */

defined( 'ABSPATH' ) || exit;

/**
 * 本番側 UI。
 */
class Ferryman_Companion_Admin {

	const MENU_SLUG    = 'ferryman';
	const NONCE_ACTION = 'ferryman_companion_save';
	const CAPABILITY   = 'manage_options';

	/**
	 * 設定。
	 *
	 * @var Ferryman_Companion_Settings
	 */
	private $settings;

	/**
	 * 直近で生成したキーを 1 度だけ表示するための一時保持。
	 *
	 * @var string
	 */
	private $flash_secret = '';

	/**
	 * コンストラクタ。
	 *
	 * @param Ferryman_Companion_Settings $settings 設定。
	 */
	public function __construct( Ferryman_Companion_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * フック登録。
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_ferryman_companion_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_ferryman_companion_regen', array( $this, 'handle_regen' ) );
	}

	/**
	 * メニュー追加。
	 *
	 * @return void
	 */
	public function add_menu() {
		add_menu_page(
			'Ferryman Companion',
			'Ferryman',
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render' ),
			'dashicons-migrate',
			80
		);
	}

	/**
	 * 設定保存。
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE_ACTION );

		$this->settings->update(
			array(
				'enabled'         => ! empty( $_POST['enabled'] ),
				'allow_pull'      => ! empty( $_POST['allow_pull'] ),
				'allow_push'      => ! empty( $_POST['allow_push'] ),
				'allow_file_pull' => ! empty( $_POST['allow_file_pull'] ),
				'allow_insecure'  => ! empty( $_POST['allow_insecure'] ),
			)
		);

		ferryman_redirect_with_notice( self::MENU_SLUG, 'settings_updated', '設定を保存しました。' );
	}

	/**
	 * 秘密キー再生成。
	 *
	 * @return void
	 */
	public function handle_regen() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE_ACTION );

		// 定数で固定されている場合は再生成しない。
		if ( $this->settings->secret_is_constant() ) {
			ferryman_redirect_with_notice(
				self::MENU_SLUG,
				'secret_is_constant',
				'秘密キーはwp-config.phpのFERRYMAN_COMPANION_SECRET定数で固定されているため、再生成できません。変える場合はwp-config.phpの定数を書き換えてください。',
				'error'
			);
		}

		$this->settings->regenerate_secret();
		// 生成直後だけフル表示するため transient に退避。
		set_transient( 'ferryman_companion_flash_secret', $this->settings->get_secret(), 60 );

		ferryman_redirect_with_notice(
			self::MENU_SLUG,
			'secret_regenerated',
			'秘密キーを再生成しました。下に表示されたキーをコントローラへコピーしてください。'
		);
	}

	/**
	 * ページ描画。
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$s           = $this->settings->all();
		$secret      = $this->settings->get_secret();
		$by_constant = $this->settings->secret_is_constant();
		$flash       = get_transient( 'ferryman_companion_flash_secret' );
		$has_secret  = '' !== $secret;
		if ( $flash ) {
			delete_transient( 'ferryman_companion_flash_secret' );
		}
		$action_url = admin_url( 'admin-post.php' );
		?>
		<div class="wrap">
			<h1>Ferryman Companion（本番側）</h1>
			<hr class="wp-header-end" />
			<?php settings_errors(); ?>
			<p>ローカル側コントローラからの署名付きリクエストを受け付けます。<strong>移行時のみ ON にし、終わったら OFF</strong> にしてください。</p>

			<?php $this->render_status_banner( $s ); ?>

			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<input type="hidden" name="action" value="ferryman_companion_save" />
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>

				<h2>接続トグル</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">接続を受け付ける</th>
						<td>
							<label><input type="checkbox" name="enabled" value="1" <?php checked( $s['enabled'] ); ?> /> 有効（マスタトグル）</label>
							<p class="description">OFF の間はすべてのリクエストを 403 で拒否します。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">方向許可</th>
						<td>
							<label><input type="checkbox" name="allow_pull" value="1" <?php checked( $s['allow_pull'] ); ?> /> pull(export) を許可</label><br />
							<label><input type="checkbox" name="allow_push" value="1" <?php checked( $s['allow_push'] ); ?> /> push(import) を許可</label><br />
							<label><input type="checkbox" name="allow_file_pull" value="1" <?php checked( $s['allow_file_pull'] ); ?> /> ファイル pull（uploads 取得）を許可</label>
							<p class="description">push は本番 DB を上書きする破壊的操作です。必要なときのみ ON にしてください。<br />ファイル pull は uploads 配下のファイルをローカルへ取得させます（読み取りのみ）。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">HTTPS</th>
						<td>
							<label><input type="checkbox" name="allow_insecure" value="1" <?php checked( $s['allow_insecure'] ); ?> /> 非 HTTPS 接続を許可（非推奨）</label>
							<p class="description">既定では非 HTTPS を拒否します。ローカル検証時以外は OFF のままにしてください。</p>
						</td>
					</tr>
				</table>
				<?php submit_button( '設定を保存' ); ?>
			</form>

			<hr />
			<h2>秘密キー</h2>
			<?php if ( $by_constant ) : ?>
				<p>✔ <code>FERRYMAN_COMPANION_SECRET</code> 定数で設定済み（現在のキー: <code><?php echo esc_html( $this->mask( $secret ) ); ?></code>）</p>
				<p class="description">秘密キーは <code>wp-config.php</code> の定数で固定されています。DB（wp_options）には保存されないため、DB ダンプやバックアップが流出しても署名偽造に使われません。この値をコントローラ側へコピーしてください（再生成はできません）。</p>
			<?php else : ?>
				<?php if ( $flash ) : ?>
					<p>新しい秘密キー（この画面でのみ全体表示します）:</p>
					<p><code style="font-size:14px; word-break:break-all;"><?php echo esc_html( $flash ); ?></code></p>
				<?php elseif ( $has_secret ) : ?>
					<p>現在のキー（マスキング表示）: <code><?php echo esc_html( $this->mask( $secret ) ); ?></code></p>
				<?php else : ?>
					<p><em>未生成です。下のボタンで生成してください。</em></p>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( $action_url ); ?>">
					<input type="hidden" name="action" value="ferryman_companion_regen" />
					<?php wp_nonce_field( self::NONCE_ACTION ); ?>
					<?php submit_button( $has_secret ? '秘密キーを再生成' : '秘密キーを生成', 'secondary' ); ?>
					<p class="description">再生成すると既存のコントローラ設定は無効になります。<br />
					より安全な運用として、<code>wp-config.php</code> に <code>define( 'FERRYMAN_COMPANION_SECRET', '…' );</code> を記述すると DB に保存せず定数で固定できます。</p>
				</form>
			<?php endif; ?>

			<hr />
			<h2>アクティビティログ（直近 <?php echo (int) Ferryman_Companion_Settings::LOG_LIMIT; ?> 件）</h2>
			<?php $this->render_log(); ?>

			<hr />
			<h2>push バックアップ一覧</h2>
			<?php $this->render_backups(); ?>
		</div>
		<?php
	}

	/**
	 * 現在の接続状態バナー。
	 *
	 * @param array $s 設定。
	 * @return void
	 */
	private function render_status_banner( $s ) {
		$on  = $s['enabled'];
		$cls = $on ? 'notice-warning' : 'notice-info';
		echo '<div class="notice ' . esc_attr( $cls ) . '" style="padding:10px 12px;">';
		echo '<p style="margin:0;"><strong>現在の状態:</strong> ';
		echo $on ? '🟢 接続受付中' : '⚪ 接続停止中';
		echo ' / pull: ' . ( $s['allow_pull'] ? '許可' : '不許可' );
		echo ' / push: ' . ( $s['allow_push'] ? '許可' : '不許可' );
		echo ' / file pull: ' . ( ! empty( $s['allow_file_pull'] ) ? '許可' : '不許可' );
		echo '</p></div>';
	}

	/**
	 * ログテーブル描画。
	 *
	 * @return void
	 */
	private function render_log() {
		$log = $this->settings->get_log();
		if ( empty( $log ) ) {
			echo '<p><em>ログはまだありません。</em></p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>日時</th><th>IP</th><th>方向</th><th>結果</th></tr></thead><tbody>';
		foreach ( $log as $row ) {
			echo '<tr>';
			echo '<td>' . esc_html( $row['time'] ) . '</td>';
			echo '<td>' . esc_html( $row['ip'] ) . '</td>';
			echo '<td>' . esc_html( $row['direction'] ) . '</td>';
			echo '<td>' . esc_html( $row['result'] ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * バックアップ一覧描画。
	 *
	 * @return void
	 */
	private function render_backups() {
		$list = $this->settings->get_backups();
		if ( empty( $list ) ) {
			echo '<p><em>バックアップはまだありません。</em></p>';
			return;
		}
		echo '<p>リストアは手動です。サーバ上の下記パスの .sql を MySQL に取り込んでください。</p>';
		echo '<table class="widefat striped"><thead><tr><th>日時</th><th>サイズ</th><th>テーブル</th><th>パス</th></tr></thead><tbody>';
		foreach ( $list as $b ) {
			echo '<tr>';
			echo '<td>' . esc_html( $b['time'] ) . '</td>';
			echo '<td>' . esc_html( size_format( (int) $b['size'] ) ) . '</td>';
			echo '<td>' . esc_html( implode( ', ', (array) $b['tables'] ) ) . '</td>';
			echo '<td><code style="word-break:break-all;">' . esc_html( $b['path'] ) . '</code></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * 秘密キーをマスキングする。
	 *
	 * @param string $secret キー。
	 * @return string
	 */
	private function mask( $secret ) {
		$len = strlen( $secret );
		if ( $len <= 8 ) {
			return str_repeat( '•', $len );
		}
		return substr( $secret, 0, 4 ) . str_repeat( '•', $len - 8 ) . substr( $secret, -4 );
	}
}
