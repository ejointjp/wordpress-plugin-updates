<?php
/**
 * 移行セッション（進捗ステート）の保持。チャンク再開に使う。
 *
 * @package Ferryman_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * wp_options に進捗ステートを保存する。
 */
class Ferryman_Ctrl_Session {

	const OPTION_KEY = 'ferryman_session';

	/**
	 * セッションを新規作成して保存する。
	 *
	 * @param array $data 初期ステート。
	 * @return array
	 */
	public function start( array $data ) {
		$state = wp_parse_args(
			$data,
			array(
				'session_id'           => wp_generate_uuid4(),
				'direction'            => 'pull',
				'mode'                 => 'run',  // run | dryrun。
				'tables'               => array(), // 対象テーブル名。
				'tables_meta'          => array(), // name => rows。
				'table_index'          => 0,
				'cursor'               => null,
				'rows_total'           => 0,
				'rows_done'            => 0,
				'replace_count'        => 0,
				'tables_replace_count' => array(), // table_name => 累積置換件数。
				'prepared_tables'      => array(), // table_name => true（TRUNCATE/準備済み。再開時の再破壊を防ぐ）。
				'status'               => 'running', // running | done | error。
				'message'              => '',
				'remote_meta'          => array(),
				'map'                  => array(),
				'backup_id'            => '',
				'started_at'           => current_time( 'mysql' ),
			)
		);
		update_option( self::OPTION_KEY, $state, false );
		return $state;
	}

	/**
	 * 現在のセッションを取得（無ければ null）。
	 *
	 * @return array|null
	 */
	public function get() {
		$state = get_option( self::OPTION_KEY, null );
		return is_array( $state ) ? $state : null;
	}

	/**
	 * セッションを部分更新する。
	 *
	 * @param array $data 更新値。
	 * @return array 更新後ステート。
	 */
	public function update( array $data ) {
		$state = $this->get();
		if ( null === $state ) {
			$state = array();
		}
		$state = array_merge( $state, $data );
		update_option( self::OPTION_KEY, $state, false );
		return $state;
	}

	/**
	 * セッションを破棄する。
	 *
	 * @return void
	 */
	public function clear() {
		delete_option( self::OPTION_KEY );
	}

	/**
	 * 現在テーブル名を返す。
	 *
	 * @param array $state ステート。
	 * @return string|null
	 */
	public function current_table( array $state ) {
		$tables = isset( $state['tables'] ) ? $state['tables'] : array();
		$idx    = isset( $state['table_index'] ) ? (int) $state['table_index'] : 0;
		return isset( $tables[ $idx ] ) ? $tables[ $idx ] : null;
	}

	/**
	 * UI 向けの進捗サマリを返す。
	 *
	 * @param array $state ステート。
	 * @return array
	 */
	public function progress( array $state ) {
		$rows_total = max( 1, (int) $state['rows_total'] );
		// 完了まで 99% 止め（rows_total は information_schema の概算値のため実行数と乖離しやすい）。
		$raw_pct = (int) round( ( (int) $state['rows_done'] / $rows_total ) * 100 );
		$percent = ( 'done' === $state['status'] ) ? 100 : min( 99, $raw_pct );
		return array(
			'session_id'           => $state['session_id'],
			'direction'            => $state['direction'],
			'mode'                 => $state['mode'],
			'status'               => $state['status'],
			'message'              => $state['message'],
			'current_table'        => $this->current_table( $state ),
			'table_index'          => (int) $state['table_index'],
			'tables_count'         => count( $state['tables'] ),
			'rows_total'           => (int) $state['rows_total'],
			'rows_done'            => (int) $state['rows_done'],
			'replace_count'        => (int) $state['replace_count'],
			'tables_replace_count' => isset( $state['tables_replace_count'] ) ? $state['tables_replace_count'] : array(),
			'tables_meta'          => isset( $state['tables_meta'] ) ? $state['tables_meta'] : array(),
			'tables'               => isset( $state['tables'] ) ? $state['tables'] : array(),
			'backup_id'            => $state['backup_id'],
			'percent'              => $percent,
		);
	}
}
