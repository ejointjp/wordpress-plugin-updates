<?php
/**
 * ファイル同期ビュー（uploads pull・追加更新のみ）。
 *
 * @package Ferryman_Controller
 *
 * @var bool       $configured 接続設定済みか。
 * @var array|null $session    進行中セッション。
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap ferryman-wrap">
	<h1>Ferryman — ファイル同期（uploads）</h1>

	<?php if ( ! $configured ) : ?>
		<div class="notice notice-warning"><p>
			先に <a href="<?php echo esc_url( admin_url( 'admin.php?page=ferryman' ) ); ?>">接続設定</a> で本番 URL と秘密キーを設定してください。
		</p></div>
	<?php else : ?>

		<div class="notice notice-info inline"><p>
			本番の <code>wp-content/uploads</code> をローカルへ取得します（<strong>pull のみ</strong>）。
			<strong>追加・更新のみの非破壊同期</strong>で、ローカルにしか無いファイルは削除しません。
			本番側で <strong>「ファイル pull を許可」</strong> を ON にしてください。
		</p></div>

		<?php if ( $session && 'running' === $session['status'] ) : ?>
			<div class="notice notice-info ferryman-files-resume">
				<p>
					中断されたファイル同期があります（<?php echo (int) $session['files_done']; ?> /
					<?php echo (int) $session['files_total']; ?> ファイル処理済み）。
					<button type="button" class="button" id="ferryman-files-resume-btn">再開する</button>
					<button type="button" class="button" id="ferryman-files-discard-btn">破棄する</button>
				</p>
			</div>
		<?php endif; ?>

		<div id="ferryman-files-groups-box" style="display:none;">
			<h2>対象フォルダ</h2>
			<p class="description">
				スキャンすると本番 uploads のフォルダ一覧が出ます。チェックしたフォルダだけを取得します。
				選択は保存され、次回スキャン時に復元されます。
			</p>
			<div id="ferryman-files-groups"></div>
			<p>
				<label><input type="checkbox" id="ferryman-files-select-all" checked /> 全選択 / 全解除</label>
			</p>
		</div>

		<p class="ferryman-actions">
			<button type="button" class="button button-secondary" id="ferryman-files-scan-btn">スキャン（差分確認）</button>
			<button type="button" class="button button-primary" id="ferryman-files-run-btn">実行（取得）</button>
		</p>

		<div id="ferryman-files-summary" class="ferryman-result" style="display:none;"></div>

		<div id="ferryman-files-progress" class="ferryman-progress" style="display:none;">
			<h2 id="ferryman-files-progress-title">進捗</h2>
			<div class="ferryman-bar"><div class="ferryman-bar-fill" id="ferryman-files-bar-fill"></div></div>
			<p id="ferryman-files-progress-text"></p>
			<pre id="ferryman-files-log" class="ferryman-log"></pre>
		</div>

	<?php endif; ?>
</div>
