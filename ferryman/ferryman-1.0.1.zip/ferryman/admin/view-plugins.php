<?php
/**
 * プラグイン同期ビュー（全モード共通）。
 *
 * @package Ferryman
 *
 * @var bool   $can_fetch_remote コントローラで接続設定済みか（「本番から取得」を出すか）。
 * @var string $export_url       JSON書き出しのURL（nonce付き）。
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap ferryman-wrap">
	<h1>Ferryman — プラグイン同期</h1>
	<p>インストール済みプラグインの一覧をJSONで書き出し、別のサイトで読み込んで足りないプラグインをwordpress.orgからまとめて入れます。</p>

	<h2>書き出し</h2>
	<p>このサイトのプラグイン一覧（名前・版・有効/無効）をJSONファイルとして保存します。</p>
	<p><a class="button button-secondary" href="<?php echo esc_url( $export_url ); ?>">JSONを書き出す</a></p>

	<hr />
	<h2>読み込み</h2>
	<div class="notice notice-info inline"><p>
		足りないプラグインを<strong>wordpress.orgから</strong>インストールし、取込元で有効なものを有効化します。
		<strong>このサイトにしかないプラグインは触らず、無効化・削除もしません。</strong>
		wordpress.orgにないプラグイン（有料・自作）は手動で入れてください。
	</p></div>

	<p class="ferryman-actions">
		<?php if ( $can_fetch_remote ) : ?>
			<button type="button" class="button button-secondary" id="ferryman-plugins-fetch-btn">本番から取得</button>
		<?php endif; ?>
		<input type="file" id="ferryman-plugins-file" accept=".json,application/json" />
		<button type="button" class="button button-secondary" id="ferryman-plugins-import-btn">JSONを読み込む</button>
	</p>
	<div id="ferryman-plugins-message"></div>

	<div id="ferryman-plugins-box" style="display:none;">
		<p id="ferryman-plugins-source" class="description"></p>
		<div id="ferryman-plugins-table"></div>
		<p>
			<label><input type="checkbox" id="ferryman-plugins-select-all" /> 対象をすべて選択 / 解除</label>
		</p>
		<p>
			版の方針:
			<label><input type="radio" name="ferryman-plugins-version" value="same" checked /> 取込元と同じ版（なければ最新）</label>
			&nbsp;
			<label><input type="radio" name="ferryman-plugins-version" value="latest" /> 最新</label>
		</p>
		<p class="ferryman-actions">
			<button type="button" class="button button-primary" id="ferryman-plugins-run-btn">実行</button>
		</p>
		<pre id="ferryman-plugins-log" class="ferryman-log" style="display:none;"></pre>
	</div>
</div>
