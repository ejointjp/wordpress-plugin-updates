<?php
/**
 * 接続設定ビュー。
 *
 * @package Ferryman_Controller
 *
 * @var Ferryman_Ctrl_Settings $this->settings (利用不可。$settings 経由)
 */

defined( 'ABSPATH' ) || exit;

/**
 * このビューを読み込むFerryman_Ctrl_Adminの接続設定。
 *
 * @var Ferryman_Ctrl_Settings $settings
 */
$settings    = $this->settings;
$remote_url  = $settings->get_remote_url();
$masked      = $settings->masked_secret();
$by_constant = $settings->secret_is_constant();
$action_url  = admin_url( 'admin-post.php' );
?>
<div class="wrap ferryman-wrap">
	<h1>Ferryman（ローカル側コントローラ）</h1>
	<hr class="wp-header-end" />
	<?php settings_errors(); ?>
	<p>本番（コンパニオン）と署名付き HTTP で接続し、DB を双方向同期します。変換（URL 置換）はこのプラグインがすべて行います。</p>

	<form method="post" action="<?php echo esc_url( $action_url ); ?>">
		<input type="hidden" name="action" value="ferryman_ctrl_save" />
		<?php wp_nonce_field( self::NONCE_SETTING ); ?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="ferryman-remote-url">本番 URL</label></th>
				<td>
					<input type="url" id="ferryman-remote-url" name="remote_url" class="regular-text"
						value="<?php echo esc_attr( $remote_url ); ?>" placeholder="https://example.com" />
					<p class="description">本番サイトの URL（HTTPS）。末尾スラッシュは不要です。</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ferryman-secret">秘密キー</label></th>
				<td>
					<?php if ( $by_constant ) : ?>
						<p><span class="ferryman-ok">✔ <code>FERRYMAN_CTRL_SECRET</code> 定数で設定済み</span>（現在のキー: <code><?php echo esc_html( $masked ); ?></code>）</p>
						<p class="description">秘密キーは wp-config.php の定数で固定されています。この欄からは変更できません（DB には保存されません）。</p>
					<?php else : ?>
						<input type="text" id="ferryman-secret" name="secret" class="regular-text" autocomplete="off"
							value="<?php echo esc_attr( $masked ); ?>" placeholder="コンパニオンで生成したキーを貼り付け" />
						<p class="description">本番側 Ferryman Companion で生成したキーを貼り付けてください。マスキング表示のまま保存しても既存キーは変わりません。<br />
						より安全な運用として、<code>wp-config.php</code> に <code>define( 'FERRYMAN_CTRL_SECRET', '…' );</code> を記述すると DB に保存せず定数で固定できます。</p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php submit_button( '接続設定を保存' ); ?>
	</form>

	<hr />
	<h2>接続テスト</h2>
	<p>本番に handshake を送り、メタ情報と <code>table_prefix</code> 一致を確認します。</p>
	<p>
		<button type="button" class="button button-secondary" id="ferryman-test-btn">接続テスト</button>
	</p>
	<div id="ferryman-test-result" class="ferryman-result" style="display:none;"></div>
</div>
