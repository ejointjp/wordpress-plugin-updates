<?php
/**
 * DB 移行ビュー。
 *
 * @package Ferryman_Controller
 *
 * @var bool       $configured 接続設定済みか。
 * @var array|null $session    進行中セッション。
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap ferryman-wrap">
	<h1>Ferryman — DB 移行</h1>

	<?php if ( ! $configured ) : ?>
		<div class="notice notice-warning"><p>
			先に <a href="<?php echo esc_url( admin_url( 'admin.php?page=ferryman' ) ); ?>">接続設定</a> で本番 URL と秘密キーを設定してください。
		</p></div>
	<?php else : ?>

		<?php if ( $session && 'running' === $session['status'] ) : ?>
			<div class="notice notice-info ferryman-resume">
				<p>
					中断された移行セッションがあります（<?php echo esc_html( $session['direction'] ); ?> /
					<?php echo esc_html( $session['mode'] ); ?> / <?php echo (int) $session['rows_done']; ?> 行処理済み）。
					<button type="button" class="button" id="ferryman-resume-btn">再開する</button>
					<button type="button" class="button" id="ferryman-discard-btn">破棄する</button>
				</p>
			</div>
		<?php endif; ?>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">方向</th>
				<td>
					<label><input type="radio" name="ferryman_direction" value="pull" checked /> <strong>Pull</strong>（本番 → ローカル：ローカルを上書き）</label><br />
					<label><input type="radio" name="ferryman_direction" value="push" /> <strong>Push</strong>（ローカル → 本番：<span class="ferryman-danger">本番を上書き・破壊的</span>）</label>
				</td>
			</tr>
			<tr>
				<th scope="row">対象テーブル</th>
				<td>
					<p>
						<button type="button" class="button" id="ferryman-load-tables">テーブル一覧を取得</button>
						<span id="ferryman-tables-source" class="description"></span>
					</p>
					<div id="ferryman-tables" class="ferryman-tables"></div>
					<p>
						<label><input type="checkbox" id="ferryman-select-all" checked /> 全選択 / 全解除</label>
					</p>
				</td>
			</tr>
		</table>

		<p class="ferryman-actions">
			<button type="button" class="button button-secondary" id="ferryman-dryrun-btn">Dry run（プレビュー）</button>
			<button type="button" class="button button-primary" id="ferryman-run-btn">実行</button>
		</p>

		<div id="ferryman-summary" class="ferryman-result" style="display:none;"></div>

		<div id="ferryman-progress" class="ferryman-progress" style="display:none;">
			<h2 id="ferryman-progress-title">進捗</h2>
			<div class="ferryman-bar"><div class="ferryman-bar-fill" id="ferryman-bar-fill"></div></div>
			<p id="ferryman-progress-text"></p>
			<pre id="ferryman-log" class="ferryman-log"></pre>
		</div>

		<!-- push 確認モーダル -->
		<div id="ferryman-modal" class="ferryman-modal" style="display:none;">
			<div class="ferryman-modal-box">
				<h2>⚠ 本番 DB を上書きします</h2>
				<p>選択したテーブルの内容を<strong>ローカルのデータで上書き</strong>します。これは破壊的操作です。</p>
				<p>実行前に本番側で対象テーブルの <strong>バックアップ（.sql）</strong> を自動生成します（web 非公開ディレクトリ）。</p>
				<p><label><input type="checkbox" id="ferryman-consent" /> 内容を理解し、本番 DB の上書きに同意します。</label></p>
				<p class="ferryman-modal-actions">
					<button type="button" class="button" id="ferryman-modal-cancel">キャンセル</button>
					<button type="button" class="button button-primary" id="ferryman-modal-confirm" disabled>上書きを実行</button>
				</p>
			</div>
		</div>

	<?php endif; ?>
</div>
