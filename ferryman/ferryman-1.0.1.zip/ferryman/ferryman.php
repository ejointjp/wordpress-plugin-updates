<?php
/**
 * Plugin Name:       Ferryman
 * Description:       WordPress DB 双方向同期。1 つのプラグインを本番・ローカル両方に入れ、管理画面の「動作モード」でコントローラ（ローカル側）/ コンパニオン（本番側）を切り替える。
 * Version:           1.0.1
 * Requires at least: 7.0
 * Requires PHP:      8.0
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://yuiami.jp/wp-plugins/ferryman
 *
 * @package Ferryman
 */

defined( 'ABSPATH' ) || exit;

/*
 * -------------------------------------------------------------------------
 * プラグイン定数
 * -------------------------------------------------------------------------
 */
define( 'FERRYMAN_VERSION', '1.0.1' );
define( 'FERRYMAN_FILE', __FILE__ );
define( 'FERRYMAN_DIR', plugin_dir_path( __FILE__ ) );
define( 'FERRYMAN_URL', plugin_dir_url( __FILE__ ) );

// 共有契約（コントローラ・コンパニオン双方で一致させること）。
define( 'FERRYMAN_NAMESPACE', 'ferryman/v1' );
define( 'FERRYMAN_TIMESTAMP_TOLERANCE', 300 ); // 秒。リプレイ防止の許容ずれ。
defined( 'FERRYMAN_BACKUP_KEEP' ) || define( 'FERRYMAN_BACKUP_KEEP', 5 ); // バックアップ保持世代数（wp-config で上書き可）。
define( 'FERRYMAN_CHUNK_BYTES', 1048576 );     // 1 チャンクの目安バイト数（~1MB）。

// 後方互換エイリアス（各クラスが参照する定数を統合ルートへ向ける）。
define( 'FERRYMAN_COMPANION_VERSION', FERRYMAN_VERSION );
define( 'FERRYMAN_COMPANION_FILE', FERRYMAN_FILE );
define( 'FERRYMAN_COMPANION_DIR', FERRYMAN_DIR );
define( 'FERRYMAN_COMPANION_URL', FERRYMAN_URL );
define( 'FERRYMAN_CTRL_VERSION', FERRYMAN_VERSION );
define( 'FERRYMAN_CTRL_FILE', FERRYMAN_FILE );
define( 'FERRYMAN_CTRL_DIR', FERRYMAN_DIR );
define( 'FERRYMAN_CTRL_URL', FERRYMAN_URL );

require_once FERRYMAN_DIR . 'includes/class-ferryman-mode.php';
require_once FERRYMAN_DIR . 'includes/class-ferryman-setup-admin.php';
// パス安全化ヘルパはファイル同期で両モードが使うため常時読み込む。
require_once FERRYMAN_DIR . 'includes/class-ferryman-paths.php';
// プラグイン同期は全モード共通（未設定時も書出・取込できる）ため常時読み込む。
require_once FERRYMAN_DIR . 'includes/class-ferryman-plugins-manifest.php';
require_once FERRYMAN_DIR . 'includes/class-ferryman-plugins-installer.php';
require_once FERRYMAN_DIR . 'includes/class-ferryman-plugins-admin.php';
// 自己ホストの更新チェックも全モード共通。定期の更新チェックはwp-cronで動くため常時読み込む。
require_once FERRYMAN_DIR . 'includes/class-ferryman-update-checker.php';

/**
 * 動作モードに応じてコンポーネントを起動する。
 *
 * @return void
 */
function ferryman_boot() {
	// 動作モード切替 UI は常時提供。
	( new Ferryman_Setup_Admin() )->hooks();

	// 更新チェックは、動作モードや管理画面かどうかに関係なく登録する。
	( new Ferryman_Update_Checker() )->hooks();

	$mode = Ferryman_Mode::get();

	if ( Ferryman_Mode::CONTROLLER === $mode ) {
		ferryman_require(
			array(
				'class-ferryman-ctrl-settings.php',
				'class-ferryman-ctrl-client.php',
				'class-ferryman-ctrl-replace-map.php',
				'class-ferryman-ctrl-replacer.php',
				'class-ferryman-ctrl-db.php',
				'class-ferryman-ctrl-session.php',
				'class-ferryman-ctrl-migrator.php',
				'class-ferryman-ctrl-files-session.php',
				'class-ferryman-ctrl-files.php',
				'class-ferryman-ctrl-admin.php',
				'class-ferryman-ctrl.php',
			)
		);
		Ferryman_Ctrl::instance();
	} elseif ( Ferryman_Mode::COMPANION === $mode ) {
		ferryman_require(
			array(
				'class-ferryman-companion-settings.php',
				'class-ferryman-companion-auth.php',
				'class-ferryman-companion-dumper.php',
				'class-ferryman-companion-files.php',
				'class-ferryman-companion-backup.php',
				'class-ferryman-companion-importer.php',
				'class-ferryman-companion-rest.php',
				'class-ferryman-companion-admin.php',
				'class-ferryman-companion.php',
			)
		);
		Ferryman_Companion::instance();
	}
	// 未設定時は Setup_Admin のモード選択画面のみ表示。

	// プラグイン同期は全モード共通（未設定時も書出・取込できる）。
	if ( is_admin() ) {
		( new Ferryman_Plugins_Admin() )->hooks();
	}
}
add_action( 'plugins_loaded', 'ferryman_boot' );

/**
 * includes 配下のファイルをまとめて読み込む。
 *
 * @param string[] $files ファイル名。
 * @return void
 */
function ferryman_require( array $files ) {
	foreach ( $files as $file ) {
		require_once FERRYMAN_DIR . 'includes/' . $file;
	}
}

/**
 * 管理画面の通知を登録し、Ferryman の管理画面へ戻して処理を終える。
 *
 * admin-post の保存処理から使う。options.php と同じく transient で通知を渡し、
 * 戻った先の settings_errors() に出させる。通知を URL に載せないので、
 * 再読み込みしても同じ通知は出ない。
 *
 * @param string $page    戻り先のページ slug。
 * @param string $code    通知のコード。
 * @param string $message 通知の文言（エスケープ前）。
 * @param string $type    通知の種類（success / error）。
 * @return void
 */
function ferryman_redirect_with_notice( $page, $code, $message, $type = 'success' ) {
	add_settings_error( 'ferryman', $code, esc_html( $message ), $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );

	wp_safe_redirect(
		add_query_arg(
			array(
				'page'             => $page,
				'settings-updated' => 'true',
			),
			admin_url( 'admin.php' )
		)
	);
	exit;
}
