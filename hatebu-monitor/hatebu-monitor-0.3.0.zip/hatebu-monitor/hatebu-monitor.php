<?php
/**
 * Plugin Name:       Hatebu Monitor
 * Description:       投稿一覧に各投稿のはてなブックマーク数を表示し、ブックマークが増えたらメールでお知らせします。
 * Version:           0.3.0
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://yuiami.jp/wp-plugins/hatebu-monitor
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HATEBU_MONITOR_VERSION', '0.3.0' );
define( 'HATEBU_MONITOR_FILE', __FILE__ );
define( 'HATEBU_MONITOR_DIR', plugin_dir_path( __FILE__ ) );

/*
 * 国際化はしない。表示文字列は日本語で直書きする（CLAUDE.mdの「開発ルール」）。
 *
 * 実装はincludes/に分けてrequireする。
 */

require_once HATEBU_MONITOR_DIR . 'includes/settings.php';
require_once HATEBU_MONITOR_DIR . 'includes/api.php';
require_once HATEBU_MONITOR_DIR . 'includes/fetcher.php';
require_once HATEBU_MONITOR_DIR . 'includes/self-check.php';
require_once HATEBU_MONITOR_DIR . 'includes/notifier.php';
require_once HATEBU_MONITOR_DIR . 'includes/cron.php';
require_once HATEBU_MONITOR_DIR . 'includes/admin-columns.php';
require_once HATEBU_MONITOR_DIR . 'includes/settings-page.php';
require_once HATEBU_MONITOR_DIR . 'includes/update-checker.php';

register_activation_hook( __FILE__, __NAMESPACE__ . '\activate' );
register_deactivation_hook( __FILE__, __NAMESPACE__ . '\deactivate' );
