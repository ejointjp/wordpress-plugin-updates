<?php
/**
 * 設定の既定値・読み出し・検証
 *
 * 設定画面はsettings-page.php。
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 設定のオプション名。値は配列で、notify・recipient・hatena_id・post_typesを持つ */
const OPTION_SETTINGS = 'hatebu_monitor_settings';

/** 設定のグループ名（register_setting()とsettings_fields()で使う） */
const SETTINGS_GROUP = 'hatebu_monitor';

/**
 * はてなIDとして受け付ける形
 *
 * はてなIDの正式な決まりは公式の文書で確かめられなかったので、実在のIDをはじかないよう、ゆるめにしてある。
 * この値はjsonliteのuserと比べるだけで、URLには組み込まない。
 */
const HATENA_ID_PATTERN = '/^[A-Za-z][A-Za-z0-9_-]{1,31}$/';

/**
 * 設定の既定値を返す
 *
 * @return array{notify: bool, recipient: string, hatena_id: string, post_types: string[]}
 */
function default_settings(): array {
	return array(
		'notify'     => true,
		'recipient'  => '',
		'hatena_id'  => '',
		'post_types' => array( 'post', 'page' ),
	);
}

/**
 * 設定で選べる投稿タイプを返す
 *
 * 公開の投稿タイプすべて。attachmentは除く。
 *
 * @return \WP_Post_Type[] 投稿タイプ名をキーにした配列（登録順）。
 */
function get_selectable_post_types(): array {
	$types = get_post_types( array( 'public' => true ), 'objects' );
	unset( $types['attachment'] );

	return $types;
}

/**
 * 設定を返す（欠けたキーは既定値で埋める）
 *
 * @return array{notify: bool, recipient: string, hatena_id: string, post_types: string[]}
 */
function get_settings(): array {
	$saved    = get_option( OPTION_SETTINGS, array() );
	$settings = array_merge( default_settings(), is_array( $saved ) ? $saved : array() );

	return array(
		'notify'     => (bool) $settings['notify'],
		'recipient'  => is_string( $settings['recipient'] ) ? $settings['recipient'] : '',
		'hatena_id'  => is_string( $settings['hatena_id'] ) ? $settings['hatena_id'] : '',
		'post_types' => array_values( array_filter( (array) $settings['post_types'], 'is_string' ) ),
	);
}

/**
 * 対象の投稿タイプを返す
 *
 * 設定にあっても、今は登録されていない（選べない）投稿タイプは除く。
 *
 * @return string[]
 */
function get_target_post_types(): array {
	$settings = \HatebuMonitor\get_settings();

	return array_values( array_intersect( $settings['post_types'], array_keys( get_selectable_post_types() ) ) );
}

/**
 * 通知の宛先を返す
 *
 * 設定が空なら、管理者のメールアドレスを使う。
 */
function get_recipient(): string {
	$settings = \HatebuMonitor\get_settings();

	return '' !== $settings['recipient'] ? $settings['recipient'] : (string) get_option( 'admin_email' );
}

/**
 * 自分のはてなIDを返す
 *
 * 空なら、セルフブクマの機能（判定・印・絞り込み・通知から外す処理）はすべて止まる。
 */
function get_hatena_id(): string {
	return \HatebuMonitor\get_settings()['hatena_id'];
}

/**
 * オプションを登録する
 *
 * 管理画面の外（WP-Cronなど）でupdate_option()したときも検証が走るよう、initで登録する。
 */
function register_settings(): void {
	register_setting(
		SETTINGS_GROUP,
		OPTION_SETTINGS,
		array(
			'type'              => 'array',
			'sanitize_callback' => __NAMESPACE__ . '\sanitize_settings',
			'show_in_rest'      => false,
		)
	);
}
add_action( 'init', __NAMESPACE__ . '\register_settings' );

/**
 * 設定の入力を検証する
 *
 * 不正な宛先とはてなIDは保存せず、前の値を残してエラーを出す。
 *
 * @param mixed $input フォームから来た値。
 * @return array{notify: bool, recipient: string, hatena_id: string, post_types: string[]}
 */
function sanitize_settings( $input ): array {
	$old   = \HatebuMonitor\get_settings();
	$input = is_array( $input ) ? $input : array();

	$recipient = isset( $input['recipient'] ) && is_string( $input['recipient'] ) ? trim( $input['recipient'] ) : '';

	if ( '' !== $recipient && ! is_email( $recipient ) ) {
		add_settings_error_once(
			'invalid_recipient',
			'宛先が有効なメールアドレスではありません。前の値を残しました。'
		);
		$recipient = $old['recipient'];
	}

	$hatena_id = isset( $input['hatena_id'] ) && is_string( $input['hatena_id'] ) ? trim( $input['hatena_id'] ) : '';
	// はてな上の表記（id:hatena）をそのまま貼っても通るよう、先頭のid:を外す。
	$hatena_id = (string) preg_replace( '/^id:/i', '', $hatena_id );

	if ( '' !== $hatena_id && ! preg_match( HATENA_ID_PATTERN, $hatena_id ) ) {
		add_settings_error_once(
			'invalid_hatena_id',
			'はてなIDが正しくありません。英字で始め、英数字・ハイフン・アンダースコアで入力してください。前の値を残しました。'
		);
		$hatena_id = $old['hatena_id'];
	}

	$post_types = isset( $input['post_types'] ) && is_array( $input['post_types'] ) ? $input['post_types'] : array();
	$post_types = array_filter( $post_types, 'is_string' );

	return array(
		'notify'     => ! empty( $input['notify'] ),
		'recipient'  => sanitize_email( $recipient ),
		'hatena_id'  => $hatena_id,
		'post_types' => array_values( array_intersect( array_keys( get_selectable_post_types() ), $post_types ) ),
	);
}

/**
 * 設定のエラーを登録する。sanitize_callbackの中では、add_settings_error()を直接呼ばずにこれを使う
 *
 * - オプションがまだDBにない初回の保存では、sanitize_callbackが2回走る。同じコードは1回だけ登録する
 * - REST API・cronからのupdate_option()でもsanitize_callbackは走るが、そこではadd_settings_error()が
 *   読み込まれていない
 *
 * @param string $code    エラーコード。
 * @param string $message エスケープ済みの文言。
 * @param string $type    error・warning・info・successのどれか。
 */
function add_settings_error_once( string $code, string $message, string $type = 'error' ): void {
	if ( ! function_exists( 'add_settings_error' ) ) {
		return;
	}

	if ( in_array( $code, wp_list_pluck( get_settings_errors( OPTION_SETTINGS ), 'code' ), true ) ) {
		return;
	}

	add_settings_error( OPTION_SETTINGS, $code, $message, $type );
}
