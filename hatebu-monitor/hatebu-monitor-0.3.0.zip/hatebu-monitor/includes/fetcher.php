<?php
/**
 * 取得の処理（対象の選定、保存、増加の検出、結果の記録）
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** はてブ数の投稿メタ */
const META_COUNT = '_hatebu_monitor_count';

/** 最後に数を取れた時刻（UNIX時刻）の投稿メタ */
const META_CHECKED = '_hatebu_monitor_checked';

/** 1回の処理で取る記事の上限（50URL×5リクエスト） */
const MAX_PER_RUN = 250;

/**
 * 1回の処理で件数取得APIへ送るリクエストの上限
 *
 * URLが長くて1回分が50件に届かないときは、5回で送り切れなかった記事を今回は何もしない
 * （取得時刻が更新されないので、次の回に優先して選ばれる）。
 */
const MAX_REQUESTS = 5;

/** この日数以内に公開した記事は、1時間ごとに取る */
const RECENT_DAYS = 7;

/**
 * 「1時間ごと」「1日ごと」の境目を手前へずらす幅（秒）
 *
 * 毎時の予約は「定刻＋遅れ」で走り、取得時刻にはその回が始まった時刻を残す。今回の遅れが前回より短いと、
 * 前回の取得からの間隔が1時間（1日）に数秒足りず、その回は対象から外れて、次に取るのが2時間後（25時間後）になる。
 * 境目をこの幅だけ手前にして、遅れのゆらぎで1回飛ばさないようにする。
 */
const DUE_MARGIN = 5 * MINUTE_IN_SECONDS;

/** 最後に取得した結果のオプション名 */
const OPTION_LAST_RUN = 'hatebu_monitor_last_run';

/**
 * 送信待ちの箱のオプション名（autoloadしない）
 *
 * 値は「投稿ID => 増えた記事（post_id・previous・count・previous_checked）」。通知がオンのとき、増えた記事を
 * 投稿メタを書き換える前に積み、メールを試したら空にする。実行が途中で止まっても、次の回の通知に含められる。
 */
const OPTION_PENDING = 'hatebu_monitor_pending';

/**
 * jsonlite（通知のコメント取得と、セルフブクマの判定）に使える時間（秒）。run_fetch()が始まってから数える
 *
 * 共有サーバーの実行時間の上限に掛からないよう、1回の処理を短く保つ。フィルタhatebu_monitor_comment_budgetで変えられる。
 */
const COMMENT_BUDGET = 30;

/** 実行中の印のtransient。毎時の処理と「今すぐ取得」が重ならないようにする */
const LOCK = 'hatebu_monitor_running';

/**
 * 取りに行く記事を、優先の順に選ぶ
 *
 * 1. 公開から7日以内で、未取得か、前回の取得から1時間以上たったもの（新しい順）
 * 2. 7日を過ぎていて、未取得のもの（新しい順）
 * 3. 7日を過ぎていて、前回の取得から24時間以上たったもの（前回の取得が古い順）
 *
 * 1の「1時間」と3の「24時間」は、DUE_MARGINだけ短く見る（予約の遅れのゆらぎで1回飛ばさないため）。
 *
 * @param int $now   今の時刻（UNIX時刻）。
 * @param int $limit 選ぶ件数の上限。
 * @return int[] 投稿ID。
 */
function select_posts( int $now, int $limit = MAX_PER_RUN ): array {
	$types = get_target_post_types();

	if ( ! $types ) {
		return array();
	}

	// post_dateはサイトのタイムゾーンなので、境目もサイトのタイムゾーンで作る。
	$week_ago = wp_date( 'Y-m-d H:i:s', $now - RECENT_DAYS * DAY_IN_SECONDS );
	$queries  = array(
		array(
			'date_query' => array(
				array(
					'after'     => $week_ago,
					'inclusive' => true,
				),
			),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 250 rows.
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key'     => META_CHECKED,
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => META_CHECKED,
					'value'   => $now - HOUR_IN_SECONDS + DUE_MARGIN,
					'compare' => '<=',
					'type'    => 'NUMERIC',
				),
			),
			'orderby'    => 'date',
			'order'      => 'DESC',
		),
		array(
			'date_query' => array(
				array(
					'before' => $week_ago,
				),
			),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 250 rows.
			'meta_query' => array(
				array(
					'key'     => META_CHECKED,
					'compare' => 'NOT EXISTS',
				),
			),
			'orderby'    => 'date',
			'order'      => 'DESC',
		),
		array(
			'date_query'   => array(
				array(
					'before' => $week_ago,
				),
			),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Runs at most once an hour and is limited to 250 rows.
			'meta_key'     => META_CHECKED,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Runs at most once an hour and is limited to 250 rows.
			'meta_value'   => $now - DAY_IN_SECONDS + DUE_MARGIN,
			'meta_compare' => '<=',
			'meta_type'    => 'NUMERIC',
			'orderby'      => 'meta_value_num',
			'order'        => 'ASC',
		),
	);

	$ids = array();

	foreach ( $queries as $query ) {
		$remaining = $limit - count( $ids );

		if ( $remaining <= 0 ) {
			break;
		}

		// IDだけでなく投稿ごと取る。あとで使うパーマリンクと投稿メタのキャッシュが、ここでまとめて温まる。
		$found = get_posts(
			array_merge(
				$query,
				array(
					'post_type'      => $types,
					'post_status'    => 'publish',
					'posts_per_page' => $remaining,
				)
			)
		);
		$ids   = array_merge( $ids, wp_list_pluck( $found, 'ID' ) );
	}

	return array_map( 'intval', $ids );
}

/**
 * はてブ数を取って投稿メタに保存し、増えた記事を返す
 *
 * 前回の値がない記事（初回）と、数が減った記事は、保存するだけで「増えた記事」に入れない。
 * 数を取れなかった記事は何も更新しない（次の回にやり直す）。
 *
 * @param int[] $post_ids 取りに行く投稿ID。
 * @param int   $now      今の時刻（UNIX時刻）。取得時刻として保存する。
 * @param bool  $queue    trueなら、増えた記事を送信待ちの箱へ積む（通知がオンのとき）。
 * @return array{checked: int, increased: array<int, array{post_id: int, previous: int, count: int, previous_checked: int}>, errors: string[]}
 *         increasedは今回の呼び出しで増えた記事だけ（箱に前からあった記事は含まない）。
 */
function fetch_and_store( array $post_ids, int $now, bool $queue = false ): array {
	$result = array(
		'checked'   => 0,
		'increased' => array(),
		'errors'    => array(),
	);
	$posts  = array();

	foreach ( $post_ids as $post_id ) {
		$url = get_permalink( $post_id );

		if ( $url ) {
			$posts[ $url ] = (int) $post_id;
		}
	}

	$batches = array_slice( count_batches( array_keys( $posts ) ), 0, MAX_REQUESTS );

	foreach ( $batches as $index => $batch ) {
		if ( $index > 0 ) {
			wait_between_requests();
		}

		$counts = fetch_counts( $batch );

		// はてなに届かないなら、残りのリクエストも届かない。待ちとタイムアウトを重ねないよう、ここで打ち切る。
		if ( is_wp_error( $counts ) && is_connection_error( $counts ) ) {
			$result['errors'][] = connection_error_message( $counts, array_sum( array_map( 'count', array_slice( $batches, $index ) ) ) );
			break;
		}

		// 200以外と読めない応答は、このリクエストだけの失敗にして、残りは続ける。
		if ( is_wp_error( $counts ) ) {
			$result['errors'][] = sprintf(
				'はてなからブックマーク数を取得できませんでした（%s）。次回の取得でもう一度確認します。',
				$counts->get_error_message()
			);
			continue;
		}

		$stored              = store_batch( $batch, $counts, $posts, $now, $queue );
		$result['checked']  += $stored['checked'];
		$result['increased'] = array_merge( $result['increased'], $stored['increased'] );

		if ( $stored['missing'] > 0 ) {
			$result['errors'][] = sprintf(
				'はてなが%s件のURLのブックマーク数を返しませんでした。次回の取得でもう一度確認します。',
				number_format_i18n( $stored['missing'] )
			);
		}
	}

	return $result;
}

/**
 * 1回のリクエストで取れた数を保存し、増えた記事を返す
 *
 * $queueがtrueなら、増えた記事を、投稿メタを書き換える前に送信待ちの箱へ積む（保存は1回）。
 * 箱へ積む前に止まれば投稿メタも古いままなので、次の回にもう一度「増えた」と分かる。
 * はてなIDがあれば、数を書き換える前に、セルフブクマの判定のメタも更新する（update_self_for_count()）。
 *
 * @param string[]           $batch  送ったURL。
 * @param array<string, int> $counts fetch_counts()の戻り値。
 * @param array<string, int> $posts  URL => 投稿ID。
 * @param int                $now    取得時刻として保存する時刻。
 * @param bool               $queue  送信待ちの箱へ積むか。
 * @return array{checked: int, missing: int, increased: array<int, array{post_id: int, previous: int, count: int, previous_checked: int}>}
 */
function store_batch( array $batch, array $counts, array $posts, int $now, bool $queue ): array {
	$found     = array();
	$increased = array();

	foreach ( $batch as $url ) {
		if ( ! isset( $counts[ $url ] ) ) {
			continue;
		}

		$post_id           = $posts[ $url ];
		$found[ $post_id ] = $counts[ $url ];
		$previous          = get_post_meta( $post_id, META_COUNT, true );

		if ( '' !== $previous && $counts[ $url ] > (int) $previous ) {
			$increased[] = array(
				'post_id'          => $post_id,
				'previous'         => (int) $previous,
				'count'            => $counts[ $url ],
				'previous_checked' => (int) get_post_meta( $post_id, META_CHECKED, true ),
			);
		}
	}

	if ( $queue && $increased ) {
		add_to_pending( $increased );
	}

	$track_self = '' !== get_hatena_id();

	foreach ( $found as $post_id => $count ) {
		// 前回の数と比べるので、はてブ数のメタを書き換える前に呼ぶ。
		if ( $track_self ) {
			update_self_for_count( $post_id, $count, $now );
		}

		update_post_meta( $post_id, META_COUNT, $count );
		update_post_meta( $post_id, META_CHECKED, $now );
	}

	return array(
		'checked'   => count( $found ),
		'missing'   => count( $batch ) - count( $found ),
		'increased' => $increased,
	);
}

/**
 * 送信待ちの箱の中身を返す
 *
 * @return array<int, array{post_id: int, previous: int, count: int, previous_checked: int}> 投稿ID => 増えた記事。
 */
function get_pending(): array {
	$pending = get_option( OPTION_PENDING, array() );

	return is_array( $pending ) ? $pending : array();
}

/**
 * 増えた記事を送信待ちの箱へ足して保存する
 *
 * 同じ記事がすでに箱にあれば1件にまとめる。前回の数と前回の取得時刻は箱にあるほう（古いほう）、
 * 今回の数は新しいほうを残す。メールには「前回の通知のあとから増えた分」が載る。
 *
 * @param array<int, array{post_id: int, previous: int, count: int, previous_checked: int}> $rows 増えた記事。
 */
function add_to_pending( array $rows ): void {
	$pending = get_pending();

	foreach ( $rows as $row ) {
		$post_id = $row['post_id'];

		if ( isset( $pending[ $post_id ] ) ) {
			$row['previous']         = $pending[ $post_id ]['previous'];
			$row['previous_checked'] = $pending[ $post_id ]['previous_checked'];
		}

		$pending[ $post_id ] = $row;
	}

	update_option( OPTION_PENDING, $pending, false );
}

/**
 * はてなに届かず、件数の取得を打ち切ったときのエラー文を作る
 *
 * @param \WP_Error $error   通信の失敗。
 * @param int       $skipped 今回数を取れなかった記事の件数（失敗したリクエストと、送らなかったリクエストの分）。
 */
function connection_error_message( \WP_Error $error, int $skipped ): string {
	return sprintf(
		'はてなに接続できませんでした（%1$s）。取得を中止したため、%2$s件の投稿を確認できませんでした。次回の取得でもう一度確認します。',
		$error->get_error_message(),
		number_format_i18n( $skipped )
	);
}

/**
 * 取得を1回走らせる。毎時の予約と「今すぐ取得」の共通の入口
 *
 * 対象を選び、数を取って保存し、増えた記事があればメールで知らせ、結果を記録する。
 * PHPのエラー（例外）で止まっても、エラーを記録して実行中の印を外す。例外は投げ直さない
 * （毎時の予約で同じ例外が続いても、設定画面の状況に出し続けるため）。
 *
 * @param string $trigger きっかけ。cronかmanual。
 * @return array 実行中ならarray( 'locked' => true )だけ。それ以外は、locked（false）・time・trigger・
 *               checked・increased（件数）・mail（sent / failed / none）・errorsを持つ配列。
 */
function run_fetch( string $trigger ): array {
	if ( get_transient( LOCK ) ) {
		return array( 'locked' => true );
	}

	// 途中で止まっても、10分で印が切れる。
	set_transient( LOCK, 1, 10 * MINUTE_IN_SECONDS );

	$now      = time();
	$last_run = array(
		'time'      => $now,
		'trigger'   => 'manual' === $trigger ? 'manual' : 'cron',
		'checked'   => 0,
		'increased' => 0,
		'mail'      => 'none',
		'errors'    => array(),
	);

	try {
		fetch_and_notify( $now, $last_run );
	} catch ( \Throwable $e ) {
		$last_run['errors'][] = sprintf(
			'PHPのエラーにより取得を中止しました（%s）。',
			$e->getMessage()
		);
	} finally {
		// リクエストごとの同じ失敗（例: 2回とも500）が並ばないよう、同じ文言は1件にまとめる。
		$last_run['errors'] = array_values( array_unique( $last_run['errors'] ) );
		update_option( OPTION_LAST_RUN, $last_run, false );
		delete_transient( LOCK );
	}

	$last_run['locked'] = false;

	return $last_run;
}

/**
 * 取得の本体。数を取って保存し、送信待ちの箱にある記事をメールで知らせ、最後にセルフブクマを判定する
 *
 * 途中で例外が出ても、そこまでの結果が記録に残るよう、$last_runを書き換えながら進む。
 *
 * @param int   $now      run_fetch()が始まった時刻（UNIX時刻）。
 * @param array $last_run 記録する結果。checked・increased・mail・errorsを書き換える。
 */
function fetch_and_notify( int $now, array &$last_run ): void {
	$notify = \HatebuMonitor\get_settings()['notify'];

	/**
	 * jsonliteに使える秒数。run_fetch()が始まってから数える。
	 *
	 * 通知のコメント取得と、セルフブクマの判定で共有する。過ぎたら、残りの記事はコメントなしで通知に載せ、
	 * 判定は次の回にまわす。
	 *
	 * @param int $seconds 秒数。既定は30。
	 */
	$deadline = $now + (int) apply_filters( 'hatebu_monitor_comment_budget', COMMENT_BUDGET );

	// 箱が空でなければ、前回の実行が通知を送る前に止まった（実行時間の上限など）。
	$leftover = (bool) get_pending();

	if ( $leftover && $notify ) {
		$last_run['errors'][] = '前回の取得は、通知メールを送る前に止まりました。その分の投稿は、今回の通知に含めています。';
	} elseif ( $leftover ) {
		$last_run['errors'][] = '前回の取得は、通知メールを送る前に止まりました。メール通知がオフのため、その分の投稿は送信していません。';
		delete_option( OPTION_PENDING );
	}

	$post_ids              = select_posts( $now );
	$result                = fetch_and_store( $post_ids, $now, $notify );
	$last_run['checked']   = $result['checked'];
	$last_run['increased'] = count( $result['increased'] );
	$last_run['errors']    = array_merge( $last_run['errors'], $result['errors'] );
	$pending               = $notify ? get_pending() : array();

	if ( $pending ) {
		// 送る前に止まったときに、送れなかったと分かるよう、先に失敗としておく（箱は残り、次の回に送る）。
		$last_run['mail'] = 'failed';
		// この回に件数取得のリクエストを送っていれば、最初のコメント取得の前にも間隔をあける。
		$notification = send_notification( array_values( $pending ), $deadline, (bool) $post_ids );

		// wp_mail()を試したら（または、知らせる記事がなかったら）、成否にかかわらず箱を空にする。送信の失敗はmailとerrorsに残る。
		delete_option( OPTION_PENDING );
		$last_run['mail']   = $notification['mail'];
		$last_run['errors'] = array_merge( $last_run['errors'], $notification['errors'] );
	}

	// この回にもうリクエストを送っていれば（件数取得か、通知のコメント取得）、最初の判定の前にも間隔をあける。
	$requested          = (bool) $post_ids || (bool) $pending;
	$last_run['errors'] = array_merge( $last_run['errors'], run_self_checks( $now, $deadline, $requested ) );
}
