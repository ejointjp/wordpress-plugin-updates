<?php
/**
 * 投稿一覧の列と並べ替え、自分のブックマークの印と絞り込み
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 列の名前。並べ替えのorderbyにも使う */
const COLUMN = 'hatebu_monitor_count';

/** 列を見られる権限の既定。取得した数は管理者にだけ見せる（はてなのAPI規約の第4条3項6号） */
const VIEW_CAPABILITY = 'manage_options';

/** 「自分のブクマなし」の絞り込みのクエリ引数。受け付ける値は0だけ */
const SELF_VIEW_ARG = 'hatebu_monitor_self';

/**
 * 今のユーザーが、はてブ数の列を見られるか
 */
function can_view_counts(): bool {
	/**
	 * 投稿一覧のはてブ数の列を見られる権限。
	 *
	 * @param string $capability 権限。既定はmanage_options（管理者）。
	 */
	$capability = (string) apply_filters( 'hatebu_monitor_view_capability', VIEW_CAPABILITY );

	return current_user_can( $capability );
}

/**
 * 対象の投稿タイプの一覧に、列を登録する。列を見られる人のときだけ
 *
 * はてなIDがあれば、「自分のブクマなし」のリンクも足す。
 */
function register_columns(): void {
	if ( ! can_view_counts() ) {
		return;
	}

	$show_self = '' !== get_hatena_id();

	foreach ( get_target_post_types() as $type ) {
		add_filter( "manage_{$type}_posts_columns", __NAMESPACE__ . '\add_column' );
		add_action( "manage_{$type}_posts_custom_column", __NAMESPACE__ . '\render_column', 10, 2 );
		add_filter( "manage_edit-{$type}_sortable_columns", __NAMESPACE__ . '\add_sortable_column' );

		if ( $show_self ) {
			add_filter( "views_edit-{$type}", __NAMESPACE__ . '\add_self_view' );
		}
	}
}
add_action( 'admin_init', __NAMESPACE__ . '\register_columns' );

/**
 * 列を足す。日付の列があれば、その前に入れる
 *
 * @param string[] $columns 列の名前 => 見出し。
 * @return string[]
 */
function add_column( array $columns ): array {
	$label = 'はてブ';

	if ( ! isset( $columns['date'] ) ) {
		$columns[ COLUMN ] = $label;

		return $columns;
	}

	$with_column = array();

	foreach ( $columns as $name => $heading ) {
		if ( 'date' === $name ) {
			$with_column[ COLUMN ] = $label;
		}

		$with_column[ $name ] = $heading;
	}

	return $with_column;
}

/**
 * 列を並べ替えできるようにする。最初のクリックで多い順になる
 *
 * @param array $columns 並べ替えできる列。
 * @return array
 */
function add_sortable_column( array $columns ): array {
	$columns[ COLUMN ] = array( COLUMN, true );

	return $columns;
}

/**
 * 列の中身を出す
 *
 * 1以上ははてブのエントリーページへのリンク、0はリンクなしの0、未取得はダッシュ。自分のブックマークがある記事には、数の後ろに印を付ける。
 *
 * @param string $column  列の名前。
 * @param int    $post_id 投稿ID。
 */
function render_column( string $column, int $post_id ): void {
	if ( COLUMN !== $column ) {
		return;
	}

	$count = get_post_meta( $post_id, META_COUNT, true );

	if ( '' === $count ) {
		echo '<span aria-hidden="true">—</span><span class="screen-reader-text">未取得</span>';

		return;
	}

	$count = (int) $count;

	if ( $count < 1 ) {
		echo '0';

		return;
	}

	$label = sprintf(
		'はてなブックマーク: %s users（新しいタブで開く）',
		number_format_i18n( $count )
	);

	printf(
		'<a href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s">%3$s</a>',
		esc_url( entry_page_url( (string) get_permalink( $post_id ) ) ),
		esc_attr( $label ),
		esc_html( number_format_i18n( $count ) )
	);

	if ( '' !== get_hatena_id() && '1' === get_post_meta( $post_id, META_SELF, true ) ) {
		echo ' <span aria-hidden="true">✓</span><span class="screen-reader-text">自分のブクマあり</span>';
	}
}

/**
 * 「自分のブクマなし」の絞り込みが選ばれているか
 */
function is_self_view(): bool {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list filter; it changes no data.
	return isset( $_GET[ SELF_VIEW_ARG ] ) && '0' === sanitize_key( wp_unslash( $_GET[ SELF_VIEW_ARG ] ) );
}

/**
 * 「自分のブクマなし」の絞り込みを、この投稿タイプの一覧に効かせるか
 *
 * 絞り込みが選ばれていて、はてなIDがあり、列を見られる人で、対象の投稿タイプのときだけ。
 *
 * @param string $post_type 投稿タイプ。
 */
function applies_self_view( string $post_type ): bool {
	return is_self_view() && '' !== get_hatena_id() && can_view_counts() && in_array( $post_type, get_target_post_types(), true );
}

/**
 * 公開済みで、自分のブックマークがないと判定した記事を数える
 *
 * 未判定の記事は数えない。
 *
 * @param string $post_type 投稿タイプ。
 */
function count_self_none( string $post_type ): int {
	$query = new \WP_Query(
		array(
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs once per posts list screen, for administrators only.
			'meta_query'             => array(
				array(
					'key'   => META_SELF,
					'value' => '0',
				),
			),
		)
	);

	return (int) $query->found_posts;
}

/**
 * 「自分のブクマなし」のリンクを作る。コアの「すべて｜公開済み」のリンクと同じ形
 *
 * @param string $post_type 投稿タイプ。
 */
function self_view_link( string $post_type ): string {
	$url = add_query_arg(
		array(
			'post_type'   => $post_type,
			SELF_VIEW_ARG => '0',
		),
		'edit.php'
	);

	return sprintf(
		'<a href="%1$s"%2$s>自分のブクマなし <span class="count">(%3$s)</span></a>',
		esc_url( $url ),
		is_self_view() ? ' class="current" aria-current="page"' : '',
		esc_html( number_format_i18n( count_self_none( $post_type ) ) )
	);
}

/**
 * 投稿一覧の上のリンクの並びに、「自分のブクマなし」を足す
 *
 * @param string[] $views リンクの名前 => HTML。
 * @return string[]
 */
function add_self_view( array $views ): array {
	// フックの名前（views_edit-{投稿タイプ}）から、投稿タイプを取り出す。
	$post_type = (string) substr( (string) current_filter(), strlen( 'views_edit-' ) );

	if ( '' !== $post_type ) {
		$views[ SELF_VIEW_ARG ] = self_view_link( $post_type );
	}

	return $views;
}

/**
 * 「自分のブクマなし」が選ばれていたら、投稿一覧を、公開済みで「なし」の記事に絞る
 *
 * 管理画面の投稿一覧（edit.php）のメインクエリで、対象の投稿タイプのときだけ。列を見られる人にだけ効く。
 *
 * @param \WP_Query $query クエリ。
 */
function filter_self_view( \WP_Query $query ): void {
	global $pagenow;

	if ( ! is_admin() || 'edit.php' !== $pagenow || ! $query->is_main_query() ) {
		return;
	}

	$post_type = $query->get( 'post_type' );

	if ( ! is_string( $post_type ) || ! applies_self_view( $post_type ) ) {
		return;
	}

	$meta_query   = $query->get( 'meta_query' );
	$meta_query   = is_array( $meta_query ) ? $meta_query : array();
	$meta_query[] = array(
		'key'   => META_SELF,
		'value' => '0',
	);

	$query->set( 'post_status', 'publish' );
	$query->set( 'meta_query', $meta_query );
}
add_action( 'pre_get_posts', __NAMESPACE__ . '\filter_self_view' );

/**
 * 絞り込み中は、一覧のフォームに絞り込みの値を引き継ぐ
 *
 * 一覧のフォーム（GET）は、コアがpost_statusとpost_typeしか引き継がない。ページ番号の入力・検索・
 * 「絞り込み」のボタンで、絞り込みが黙って外れないようにする。
 *
 * @param string $post_type 投稿タイプ。
 */
function render_self_view_field( string $post_type ): void {
	if ( ! applies_self_view( $post_type ) ) {
		return;
	}

	printf( '<input type="hidden" name="%s" value="0" />', esc_attr( SELF_VIEW_ARG ) );
}
add_action( 'restrict_manage_posts', __NAMESPACE__ . '\render_self_view_field' );

/**
 * 一覧をはてブ数で並べ替える。列を見られる人のときだけ
 *
 * @param string[]  $clauses クエリの各句。
 * @param \WP_Query $query   クエリ。
 * @return string[]
 */
function sort_clauses( array $clauses, \WP_Query $query ): array {
	if ( ! is_admin() || ! $query->is_main_query() || COLUMN !== $query->get( 'orderby' ) || ! can_view_counts() ) {
		return $clauses;
	}

	$order = strtoupper( (string) $query->get( 'order' ) );

	return count_sort_clauses( $clauses, 'ASC' === $order ? 'ASC' : 'DESC' );
}
add_filter( 'posts_clauses', __NAMESPACE__ . '\sort_clauses', 10, 2 );

/**
 * はてブ数で並べ替える句を足す
 *
 * meta_queryは使わない。未取得の記事（メタがない）を落とさずに後ろへ並べるため、
 * はてブ数のメタだけをLEFT JOINする。
 *
 * @param string[] $clauses クエリの各句。
 * @param string   $order   ASCかDESC。
 * @return string[]
 */
function count_sort_clauses( array $clauses, string $order ): array {
	global $wpdb;

	$order = 'ASC' === $order ? 'ASC' : 'DESC';

	$clauses['join']   .= $wpdb->prepare(
		" LEFT JOIN {$wpdb->postmeta} AS hatebu_monitor_count ON ( {$wpdb->posts}.ID = hatebu_monitor_count.post_id AND hatebu_monitor_count.meta_key = %s )",
		META_COUNT
	);
	$clauses['orderby'] = "( hatebu_monitor_count.meta_value IS NULL ) ASC, CAST( hatebu_monitor_count.meta_value AS SIGNED ) {$order}, {$wpdb->posts}.post_date DESC";

	return $clauses;
}
