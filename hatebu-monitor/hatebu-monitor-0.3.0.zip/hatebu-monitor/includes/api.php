<?php
/**
 * はてなのAPIの呼び出しと応答の解釈
 *
 * WordPressのデータ（投稿・オプション）には触れない。どちらのAPIも認証は要らない。
 * - 件数取得API: https://developer.hatena.ne.jp/ja/documents/bookmark/apis/getcount
 * - エントリー情報取得API: https://developer.hatena.ne.jp/ja/documents/bookmark/apis/getinfo
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 件数取得API（複数URL） */
const COUNT_ENDPOINT = 'https://bookmark.hatenaapis.com/count/entries';

/** エントリー情報取得API（jsonlite） */
const ENTRY_ENDPOINT = 'https://b.hatena.ne.jp/entry/jsonlite/';

/** 件数取得APIに1回で渡せるURLの上限 */
const BATCH_SIZE = 50;

/**
 * 件数取得APIのリクエストのURL全体の長さの上限（文字数）
 *
 * 2026-11-15の実測では、8,015文字なら200、15,995文字と26,635文字は414 Request-URI Too Largeだった。
 * 日本語のスラッグのような長いURLは、50件に届く前にこの長さで区切る。
 */
const MAX_REQUEST_LENGTH = 8000;

/** 件数取得APIのタイムアウト（秒） */
const COUNT_TIMEOUT = 15;

/**
 * エントリー情報取得API（jsonlite）のタイムアウト（秒）
 *
 * 通知のコメントを取るのと、セルフブクマの判定に使う。どちらも取れなくても先へ進めるので、件数取得より短くする。
 * 取れなくても、通知はコメントなしで送り、判定はあとでもう一度試す。
 */
const ENTRY_TIMEOUT = 10;

/**
 * はてなのAPIへGETし、本文を返す
 *
 * @param string $url     リクエストするURL。
 * @param int    $timeout タイムアウト（秒）。
 * @return string|\WP_Error 本文。通信の失敗と200以外はWP_Error。
 */
function request( string $url, int $timeout ) {
	$response = wp_remote_get( $url, array( 'timeout' => $timeout ) );

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );

	if ( 200 !== $code ) {
		return new \WP_Error(
			'hatebu_monitor_http_status',
			sprintf(
				'はてながHTTPステータス%dを返しました',
				$code
			)
		);
	}

	return (string) wp_remote_retrieve_body( $response );
}

/**
 * はてなに届かなかった（通信そのものの失敗）エラーか
 *
 * 200以外のステータス（hatebu_monitor_http_status）と読めない応答（hatebu_monitor_invalid_response）は、はてなから
 * 応答が来ている。それ以外のWP_Error（wp_remote_get()のタイムアウトや名前解決の失敗など）は、届いていない。
 *
 * @param \WP_Error $error request()・fetch_counts()・fetch_entry()が返したエラー。
 */
function is_connection_error( \WP_Error $error ): bool {
	return ! in_array( $error->get_error_code(), array( 'hatebu_monitor_http_status', 'hatebu_monitor_invalid_response' ), true );
}

/**
 * 件数取得APIのクエリの1件分（url=…）を作る
 *
 * @param string $url 聞くURL。
 */
function count_query_param( string $url ): string {
	return 'url=' . rawurlencode( $url );
}

/**
 * 件数取得APIのリクエストのURLを組み立てる
 *
 * @param string[] $urls 聞くURL。
 */
function count_request_url( array $urls ): string {
	return COUNT_ENDPOINT . '?' . implode( '&', array_map( __NAMESPACE__ . '\count_query_param', $urls ) );
}

/**
 * 聞くURLを、件数取得APIの1回分ずつに区切る
 *
 * 1回分は、BATCH_SIZE件まで、かつリクエストのURL全体がMAX_REQUEST_LENGTH文字まで。
 * 1件だけでMAX_REQUEST_LENGTH文字を超えるURLは、その1件だけで1回分にする
 * （はてなが414を返せば、その1回分の失敗として扱われる）。
 *
 * @param string[] $urls 聞くURL。
 * @return array<int, string[]> 1回分ごとのURL。順番は元のまま。
 */
function count_batches( array $urls ): array {
	$batches = array();
	$batch   = array();
	$length  = 0;

	foreach ( $urls as $url ) {
		$param = strlen( count_query_param( $url ) );

		// 2件目からは「&」の1文字が足される。
		if ( $batch && ( count( $batch ) >= BATCH_SIZE || $length + 1 + $param > MAX_REQUEST_LENGTH ) ) {
			$batches[] = $batch;
			$batch     = array();
		}

		$length  = $batch ? $length + 1 + $param : strlen( COUNT_ENDPOINT . '?' ) + $param;
		$batch[] = $url;
	}

	if ( $batch ) {
		$batches[] = $batch;
	}

	return $batches;
}

/**
 * 複数のURLのはてブ数をまとめて取る
 *
 * @param string[] $urls 聞くURL。count_batches()で区切った1回分。
 * @return array<string, int>|\WP_Error 聞いたURL => 数。応答になかったURLは含まない。
 */
function fetch_counts( array $urls ) {
	if ( ! $urls ) {
		return array();
	}

	$body = request( count_request_url( $urls ), COUNT_TIMEOUT );

	if ( is_wp_error( $body ) ) {
		return $body;
	}

	$data = json_decode( $body, true );

	if ( ! is_array( $data ) ) {
		return new \WP_Error(
			'hatebu_monitor_invalid_response',
			'はてなが読み取れない応答を返しました'
		);
	}

	// 応答のキーは送った表記のまま返るが、表記が違っても拾えるよう、デコードした形でも引けるようにする。
	$decoded = array();

	foreach ( $data as $key => $value ) {
		$decoded[ rawurldecode( (string) $key ) ] = $value;
	}

	$counts = array();

	foreach ( $urls as $url ) {
		$count = null;

		if ( isset( $data[ $url ] ) ) {
			$count = to_count( $data[ $url ] );
		} elseif ( isset( $decoded[ rawurldecode( $url ) ] ) ) {
			$count = to_count( $decoded[ rawurldecode( $url ) ] );
		}

		// 数として読めない値は、応答になかったのと同じ扱いにする（数を更新せず、次の回にやり直す）。
		if ( null !== $count ) {
			$counts[ $url ] = $count;
		}
	}

	return $counts;
}

/**
 * 件数取得APIの値を、はてブ数として読む
 *
 * 0以上の整数と、数字だけの文字列だけを受け付ける。配列・数字でない文字列・負の数・小数・
 * null・真偽値は読めないものとする。
 *
 * @param mixed $value 応答の値。
 * @return int|null はてブ数。読めなければnull。
 */
function to_count( $value ): ?int {
	if ( is_int( $value ) ) {
		return $value >= 0 ? $value : null;
	}

	if ( is_string( $value ) && ctype_digit( $value ) ) {
		return (int) $value;
	}

	return null;
}

/**
 * 1つのURLのエントリー情報（ブックマークの一覧）を取る
 *
 * 応答はキャッシュで、件数取得APIの値とずれることがある。数には使わず、通知のコメントを取るのと、
 * セルフブクマの判定（一覧に自分のはてなIDがあるか）にだけ使う。
 *
 * @param string $url 聞くURL。
 * @return array{entry_url: string, bookmarks: array<int, array{user: string, comment: string, timestamp: int}>}|null|\WP_Error
 *         エントリーがなければnull。bookmarksは新しい順。
 */
function fetch_entry( string $url ) {
	$body = request( ENTRY_ENDPOINT . '?url=' . rawurlencode( $url ), ENTRY_TIMEOUT );

	if ( is_wp_error( $body ) ) {
		return $body;
	}

	// エントリーがないURLには、本文がnullで返る。
	if ( 'null' === trim( $body ) ) {
		return null;
	}

	$data = json_decode( $body, true );

	if ( ! is_array( $data ) ) {
		return new \WP_Error(
			'hatebu_monitor_invalid_response',
			'はてなが読み取れない応答を返しました'
		);
	}

	$bookmarks = array();
	$raw       = isset( $data['bookmarks'] ) && is_array( $data['bookmarks'] ) ? $data['bookmarks'] : array();

	foreach ( $raw as $bookmark ) {
		if ( ! is_array( $bookmark ) ) {
			continue;
		}

		$bookmarks[] = array(
			'user'      => isset( $bookmark['user'] ) && is_string( $bookmark['user'] ) ? $bookmark['user'] : '',
			'comment'   => isset( $bookmark['comment'] ) && is_string( $bookmark['comment'] ) ? $bookmark['comment'] : '',
			'timestamp' => isset( $bookmark['timestamp'] ) && is_string( $bookmark['timestamp'] ) ? parse_timestamp( $bookmark['timestamp'] ) : 0,
		);
	}

	return array(
		'entry_url' => isset( $data['entry_url'] ) && is_string( $data['entry_url'] ) ? $data['entry_url'] : '',
		'bookmarks' => $bookmarks,
	);
}

/**
 * はてなの時刻（2025/06/03 07:35の形、日本時間、分まで）をUNIX時刻にする
 *
 * @param string $timestamp はてなの時刻。
 * @return int UNIX時刻。読めなければ0。
 */
function parse_timestamp( string $timestamp ): int {
	// 先頭の!で、書式にない欄（秒）を0にする。付けないと、秒に今の時刻が入る。
	$date = \DateTimeImmutable::createFromFormat( '!Y/m/d H:i', $timestamp, new \DateTimeZone( 'Asia/Tokyo' ) );

	return $date ? $date->getTimestamp() : 0;
}

/**
 * 2つのはてなIDが同じユーザーを指すか
 *
 * 大文字と小文字は区別しない。空文字はどのIDとも一致させない。
 *
 * @param string $a はてなID。
 * @param string $b はてなID。
 */
function is_same_user( string $a, string $b ): bool {
	return '' !== $a && 0 === strcasecmp( $a, $b );
}

/**
 * ブックマークの一覧に、そのユーザーのブックマークがあるか
 *
 * jsonliteの一覧は全件ではない（非表示のユーザーなどが抜ける）。一覧に出ないブックマークは、ないものとして扱う。
 *
 * @param array  $bookmarks fetch_entry()が返すbookmarks。
 * @param string $user      はてなID。
 */
function has_bookmark_by( array $bookmarks, string $user ): bool {
	foreach ( $bookmarks as $bookmark ) {
		if ( is_same_user( $bookmark['user'], $user ) ) {
			return true;
		}
	}

	return false;
}

/**
 * はてブのエントリーページのURLを組み立てる
 *
 * @param string $url 記事のURL。
 */
function entry_page_url( string $url ): string {
	if ( 0 === strpos( $url, 'https://' ) ) {
		return 'https://b.hatena.ne.jp/entry/s/' . substr( $url, 8 );
	}

	return 'https://b.hatena.ne.jp/entry/' . preg_replace( '#^http://#', '', $url );
}

/**
 * はてなのAPIへのリクエストのあいだで待つ
 *
 * APIのドキュメントが「リクエスト毎に数秒の間隔」を求めている。フィルタは検証のためのもの。
 */
function wait_between_requests(): void {
	/**
	 * はてなのAPIへのリクエストのあいだで待つ秒数。
	 *
	 * @param int $seconds 秒数。
	 */
	$seconds = (int) apply_filters( 'hatebu_monitor_request_interval', 3 );

	if ( $seconds > 0 ) {
		sleep( $seconds );
	}
}
