<?php
/**
 * セルフブクマ（自分のはてなIDで付けたブックマーク）の判定
 *
 * 判定の記録、はてブ数の変化に合わせた見直しの印、はてなIDを変えたときのやり直し、
 * 判定する記事の選定、毎時の判定。
 * はてなIDが空のときは、呼び出す側（fetcher.php・notifier.php・admin-columns.php）がここを呼ばないか、
 * ここの関数が何もせずに返る。
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 判定の結果の投稿メタ。'1'ならあり、'0'ならなし。メタがなければ未判定 */
const META_SELF = '_hatebu_monitor_self';

/** 判定した時刻（UNIX時刻）の投稿メタ。0は「はてブ数の変化で見直しが要る」の印 */
const META_SELF_CHECKED = '_hatebu_monitor_self_checked';

/**
 * 1回の処理で、判定のためにjsonliteを呼ぶ記事の上限
 *
 * 通知メールのために取ったjsonliteは数えない（その応答は、そのまま判定に使う）。
 */
const SELF_MAX_PER_RUN = 5;

/**
 * 判定に失敗した記事の控えのオプション。投稿ID => 失敗した時刻（UNIX時刻）。autoloadしない
 *
 * 失敗した記事は、選定の順（公開日の新しい順）で次の回にも先頭に来るので、控えに入れてしばらく選ばない。
 */
const OPTION_SELF_FAILED = 'hatebu_monitor_self_failed';

/** 判定に失敗した記事を、もう一度選ぶまでの時間（秒） */
const SELF_RETRY_AFTER = DAY_IN_SECONDS;

/**
 * 判定の結果を記録する
 *
 * @param int  $post_id    投稿ID。
 * @param bool $bookmarked 自分のブックマークがあるか。
 * @param int  $time       判定した時刻（UNIX時刻）。
 */
function record_self( int $post_id, bool $bookmarked, int $time ): void {
	// 判定した時刻を先に書く。途中で止まっても、判定のない記事は未判定として選び直される。
	update_post_meta( $post_id, META_SELF_CHECKED, $time );
	update_post_meta( $post_id, META_SELF, $bookmarked ? '1' : '0' );
}

/**
 * 判定に失敗した記事の控えを読む。失敗からSELF_RETRY_AFTERを過ぎた項目は落とす
 *
 * @param int $now 今の時刻（UNIX時刻）。
 * @return int[] 投稿ID => 失敗した時刻（UNIX時刻）。
 */
function get_self_failed( int $now ): array {
	$stored = get_option( OPTION_SELF_FAILED, array() );
	$failed = array();

	if ( ! is_array( $stored ) ) {
		return $failed;
	}

	foreach ( $stored as $post_id => $time ) {
		if ( (int) $post_id > 0 && $now - (int) $time < SELF_RETRY_AFTER ) {
			$failed[ (int) $post_id ] = (int) $time;
		}
	}

	return $failed;
}

/**
 * 判定に失敗した記事の控えを書く。空ならオプションごと消す
 *
 * 変わっていなければ、update_option()が書かずに返る。
 *
 * @param int[] $failed 投稿ID => 失敗した時刻（UNIX時刻）。
 */
function save_self_failed( array $failed ): void {
	if ( $failed ) {
		update_option( OPTION_SELF_FAILED, $failed, false );
	} elseif ( null !== get_option( OPTION_SELF_FAILED, null ) ) {
		delete_option( OPTION_SELF_FAILED );
	}
}

/**
 * 新しいはてブ数から、判定できることと、見直しが要ることを記録する
 *
 * 前回の数と比べるので、はてブ数の投稿メタを書き換える前に呼ぶ。
 * - 数が0なら、公開のブックマークが1件もないので、通信せずに「なし」と決める
 * - 「なし」の記事の数が増えたら、自分が付けたかもしれないので、見直しの印（判定時刻を0）を付ける
 * - 「あり」の記事の数が減ったら、自分が消したかもしれないので、見直しの印を付ける
 *
 * 「あり」の記事の数が増えても、「なし」の記事の数が減っても、判定は変わらないので見直さない。
 *
 * @param int $post_id 投稿ID。
 * @param int $count   今回のはてブ数。
 * @param int $now     今の時刻（UNIX時刻）。
 */
function update_self_for_count( int $post_id, int $count, int $now ): void {
	$self = get_post_meta( $post_id, META_SELF, true );

	if ( 0 === $count ) {
		// すでに「なし」なら書かない（数が0のあいだ、取得のたびに書き込みを増やさない）。
		if ( '0' !== $self ) {
			record_self( $post_id, false, $now );
		}

		return;
	}

	$previous = get_post_meta( $post_id, META_COUNT, true );

	// 未判定の記事は、毎時の判定がもともと最優先で選ぶ。
	if ( '' === $self || '' === $previous ) {
		return;
	}

	$previous = (int) $previous;

	if ( ( '0' === $self && $count > $previous ) || ( '1' === $self && $count < $previous ) ) {
		update_post_meta( $post_id, META_SELF_CHECKED, 0 );
	}
}

/**
 * はてなIDを変えたら、全記事の判定を消してやり直す
 *
 * 大文字と小文字だけの違いは、同じIDとみなす。空にしたときも消す。判定に失敗した記事の控えも消す。
 * sanitize_settings()は1回の保存で2回呼ばれうるので、そこではなく、保存されたあとのフックで行う。
 * 取得の実行中にIDを変えると、その回が古いIDで判定した数件（と失敗した記事の控え）は、消したあとに書かれて残りうる。
 *
 * @param mixed $old_value 前の設定。
 * @param mixed $value     新しい設定。
 */
function reset_self_on_id_change( $old_value, $value ): void {
	$old = is_array( $old_value ) && isset( $old_value['hatena_id'] ) && is_string( $old_value['hatena_id'] ) ? $old_value['hatena_id'] : '';
	$new = is_array( $value ) && isset( $value['hatena_id'] ) && is_string( $value['hatena_id'] ) ? $value['hatena_id'] : '';

	if ( 0 === strcasecmp( $old, $new ) ) {
		return;
	}

	delete_post_meta_by_key( META_SELF );
	delete_post_meta_by_key( META_SELF_CHECKED );
	delete_option( OPTION_SELF_FAILED );
}
add_action( 'update_option_' . OPTION_SETTINGS, __NAMESPACE__ . '\reset_self_on_id_change', 10, 2 );

/**
 * セルフブクマを判定しに行く記事を、優先の順に選ぶ
 *
 * はてブ数が1以上の記事だけを見る（0の記事は、数を保存するときに「なし」と決まる）。
 * 1. 未判定（新しい順）
 * 2. はてブ数の変化で見直しが要るもの（判定時刻が0。新しい順）
 * 3. 公開から7日以内の「なし」で、前回の判定から24時間以上たったもの（前回の判定が古い順）
 * 4. 公開から7日を過ぎた「なし」で、前回の判定から7日以上たったもの（前回の判定が古い順）
 *
 * 3と4は、jsonliteのキャッシュで、ブックマークの直後に一覧に載っていなかった分の見直し。
 * どのクエリでも、判定に失敗してからSELF_RETRY_AFTERがたっていない記事と、前のクエリで選んだ記事は選ばない。
 *
 * @param int $now   今の時刻（UNIX時刻）。
 * @param int $limit 選ぶ件数の上限。
 * @return int[] 投稿ID。
 */
function select_self_posts( int $now, int $limit = SELF_MAX_PER_RUN ): array {
	$types = get_target_post_types();

	if ( ! $types ) {
		return array();
	}

	// post_dateはサイトのタイムゾーンなので、境目もサイトのタイムゾーンで作る。
	$week_ago       = wp_date( 'Y-m-d H:i:s', $now - RECENT_DAYS * DAY_IN_SECONDS );
	$has_bookmarks  = array(
		'key'     => META_COUNT,
		'value'   => 0,
		'compare' => '>',
		'type'    => 'NUMERIC',
	);
	$not_bookmarked = array(
		'key'   => META_SELF,
		'value' => '0',
	);
	// meta_queryの各句には名前を付ける（名前のある句とない句を1つの配列に混ぜない。並べ替えは句の名前で指定する）。
	$queries = array(
		array(
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 5 rows.
			'meta_query' => array(
				'count' => $has_bookmarks,
				'self'  => array(
					'key'     => META_SELF,
					'compare' => 'NOT EXISTS',
				),
			),
			'orderby'    => 'date',
			'order'      => 'DESC',
		),
		array(
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 5 rows.
			'meta_query' => array(
				'count'        => $has_bookmarks,
				'self_checked' => array(
					'key'     => META_SELF_CHECKED,
					'value'   => 0,
					'compare' => '=',
					'type'    => 'NUMERIC',
				),
			),
			'orderby'    => 'date',
			'order'      => 'DESC',
		),
		array(
			'date_query' => array(
				array(
					'after'     => $week_ago,
					'inclusive' => true,
				),
			),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 5 rows.
			'meta_query' => array(
				'count'        => $has_bookmarks,
				'self'         => $not_bookmarked,
				// 判定時刻が0のもの（2で選ぶ）と重ならないよう、1以上にする。
				'self_checked' => array(
					'key'     => META_SELF_CHECKED,
					'value'   => array( 1, $now - DAY_IN_SECONDS ),
					'compare' => 'BETWEEN',
					'type'    => 'NUMERIC',
				),
			),
			'orderby'    => array( 'self_checked' => 'ASC' ),
		),
		array(
			'date_query' => array(
				array(
					'before' => $week_ago,
				),
			),
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs at most once an hour and is limited to 5 rows.
			'meta_query' => array(
				'count'        => $has_bookmarks,
				'self'         => $not_bookmarked,
				'self_checked' => array(
					'key'     => META_SELF_CHECKED,
					'value'   => array( 1, $now - WEEK_IN_SECONDS ),
					'compare' => 'BETWEEN',
					'type'    => 'NUMERIC',
				),
			),
			'orderby'    => array( 'self_checked' => 'ASC' ),
		),
	);

	$ids    = array();
	$failed = array_keys( get_self_failed( $now ) );

	foreach ( $queries as $query ) {
		$remaining = $limit - count( $ids );

		if ( $remaining <= 0 ) {
			break;
		}

		// IDだけでなく投稿ごと取る。あとで使うパーマリンクのキャッシュが、ここでまとめて温まる。
		$found = get_posts(
			array_merge(
				$query,
				array(
					'post_type'      => $types,
					'post_status'    => 'publish',
					'posts_per_page' => $remaining,
					// 判定のメタが半端な記事（判定がなく、判定時刻が0）は1と2の両方に当たるので、選んだ記事も外す。
					'post__not_in'   => array_merge( $failed, $ids ),
				)
			)
		);
		$ids   = array_merge( $ids, wp_list_pluck( $found, 'ID' ) );
	}

	return array_map( 'intval', $ids );
}

/**
 * セルフブクマを判定する。毎時の取得（run_fetch()）の最後に呼ばれる
 *
 * はてなIDが空なら何もしない。1回の処理でjsonliteを呼ぶのはSELF_MAX_PER_RUN件までで、
 * リクエストのあいだは間隔をあける。締め切りはコメント取得と共有し、過ぎたら残りは次の回にまわす。
 * 取得に失敗した記事は、判定を記録せずに控え（OPTION_SELF_FAILED）へ入れ、SELF_RETRY_AFTERのあいだは選ばない。
 * はてなに届かなければ、残りの判定はしない。200以外や読めない応答なら、次の記事へ進む。
 *
 * @param int  $now       run_fetch()が始まった時刻（UNIX時刻）。判定した時刻として保存する。
 * @param int  $deadline  jsonliteを呼べる締め切り（UNIX時刻）。0を渡すと、もう過ぎたものとして何も判定しない
 *                        （send_notification()の「0は締め切りなし」とは違う）。
 * @param bool $requested この回に、もうはてなへリクエストを送ったか。送っていれば、最初の判定の前にも間隔をあける。
 * @return string[] エラーの文言。
 */
function run_self_checks( int $now, int $deadline, bool $requested ): array {
	$hatena_id = get_hatena_id();
	$errors    = array();

	if ( '' === $hatena_id ) {
		return $errors;
	}

	$failed = get_self_failed( $now );

	foreach ( select_self_posts( $now ) as $post_id ) {
		if ( time() >= $deadline ) {
			break;
		}

		$url = get_permalink( $post_id );

		if ( ! $url ) {
			continue;
		}

		if ( $requested ) {
			wait_between_requests();
		}

		$requested = true;
		$entry     = fetch_entry( $url );

		if ( is_wp_error( $entry ) ) {
			$failed[ $post_id ] = $now;
			$errors[]           = sprintf(
				'はてなで自分のブックマークを確認できませんでした（%s）。あとでもう一度確認します。',
				$entry->get_error_message()
			);

			// はてなに届かないなら、残りのリクエストも届かない。
			if ( is_connection_error( $entry ) ) {
				break;
			}

			continue;
		}

		// エントリーがない（null）ときは、ブックマークが1件もないので「なし」。
		record_self( $post_id, is_array( $entry ) && has_bookmark_by( $entry['bookmarks'], $hatena_id ), $now );
		unset( $failed[ $post_id ] );
	}

	save_self_failed( $failed );

	return $errors;
}
