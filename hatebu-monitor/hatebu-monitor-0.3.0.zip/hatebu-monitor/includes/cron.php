<?php
/**
 * 予約の登録・解除と、毎時の処理の入口
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 毎時の予約のフック名 */
const HOOK = 'hatebu_monitor_fetch';

/**
 * 毎時の予約がなければ入れる
 *
 * 起点を今の時刻にするので、初回はすぐ走る。
 * 何かの拍子に予約が消えたときのために、管理画面を開くたびにも確かめる。
 */
function schedule(): void {
	if ( ! wp_next_scheduled( HOOK ) ) {
		wp_schedule_event( time(), 'hourly', HOOK );
	}
}
add_action( 'admin_init', __NAMESPACE__ . '\schedule' );

/**
 * 有効化したとき
 */
function activate(): void {
	schedule();
}

/**
 * 無効化したとき。予約と実行中の印を外す（データは残す）
 */
function deactivate(): void {
	wp_clear_scheduled_hook( HOOK );
	delete_transient( LOCK );
}

/**
 * 毎時の予約から呼ばれる
 */
function run_scheduled_fetch(): void {
	run_fetch( 'cron' );
}
add_action( HOOK, __NAMESPACE__ . '\run_scheduled_fetch' );
