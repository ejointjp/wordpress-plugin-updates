<?php
/**
 * 設定画面（設定 > Hatebu Monitor）と「今すぐ取得」
 *
 * 「設定」メニューの配下なので、保存結果とエラーの通知はコアが出す（settings_errors()を呼ばない）。
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 設定画面のスラッグ */
const PAGE_SLUG = 'hatebu-monitor';

/** 「今すぐ取得」のadmin-post.phpのアクション名。nonceのアクションにも使う */
const ACTION_FETCH = 'hatebu_monitor_fetch_now';

/** 「今すぐ取得」のnonceのフィールド名 */
const NONCE_FETCH = '_hatebu_monitor_nonce';

/**
 * 「設定」メニューにページを足す
 */
function add_menu(): void {
	add_options_page( 'Hatebu Monitor', 'Hatebu Monitor', 'manage_options', PAGE_SLUG, __NAMESPACE__ . '\render_page' );
}
add_action( 'admin_menu', __NAMESPACE__ . '\add_menu' );

/**
 * 設定のセクションと項目を登録する
 */
function add_settings_ui(): void {
	add_settings_section( 'hatebu_monitor_notifications', '通知', '__return_null', PAGE_SLUG );
	add_settings_field( 'hatebu_monitor_notify', 'メール通知', __NAMESPACE__ . '\render_notify_field', PAGE_SLUG, 'hatebu_monitor_notifications' );
	add_settings_field(
		'hatebu_monitor_recipient',
		'宛先',
		__NAMESPACE__ . '\render_recipient_field',
		PAGE_SLUG,
		'hatebu_monitor_notifications',
		array( 'label_for' => 'hatebu-monitor-recipient' )
	);

	add_settings_section( 'hatebu_monitor_self', '自分のブックマーク', '__return_null', PAGE_SLUG );
	add_settings_field(
		'hatebu_monitor_hatena_id',
		'自分のはてなID',
		__NAMESPACE__ . '\render_hatena_id_field',
		PAGE_SLUG,
		'hatebu_monitor_self',
		array( 'label_for' => 'hatebu-monitor-hatena-id' )
	);

	add_settings_section( 'hatebu_monitor_targets', '監視する投稿', '__return_null', PAGE_SLUG );
	add_settings_field( 'hatebu_monitor_post_types', '投稿タイプ', __NAMESPACE__ . '\render_post_types_field', PAGE_SLUG, 'hatebu_monitor_targets' );
}
add_action( 'admin_init', __NAMESPACE__ . '\add_settings_ui' );

/**
 * 通知のオン・オフ
 */
function render_notify_field(): void {
	$settings = \HatebuMonitor\get_settings();

	printf(
		'<label><input type="checkbox" name="%1$s[notify]" value="1" %2$s> 投稿のブックマークが増えたらメールで知らせる</label>',
		esc_attr( OPTION_SETTINGS ),
		checked( $settings['notify'], true, false )
	);
}

/**
 * 宛先
 */
function render_recipient_field(): void {
	$settings = \HatebuMonitor\get_settings();

	printf(
		'<input type="email" id="hatebu-monitor-recipient" name="%1$s[recipient]" value="%2$s" class="regular-text">',
		esc_attr( OPTION_SETTINGS ),
		esc_attr( $settings['recipient'] )
	);
	printf(
		'<p class="description">%s</p>',
		esc_html(
			sprintf(
				'空欄にすると、管理者メールアドレス（%s）に送信します。',
				(string) get_option( 'admin_email' )
			)
		)
	);
}

/**
 * 自分のはてなID
 */
function render_hatena_id_field(): void {
	$settings = \HatebuMonitor\get_settings();

	printf(
		'<input type="text" id="hatebu-monitor-hatena-id" name="%1$s[hatena_id]" value="%2$s" class="regular-text" autocomplete="off" spellcheck="false">',
		esc_attr( OPTION_SETTINGS ),
		esc_attr( $settings['hatena_id'] )
	);
	echo '<p class="description">自分でブックマークした投稿を見分け、自分のブックマークを通知から外すために使います。空欄にすると、この機能はオフになります。</p>';
}

/**
 * 対象の投稿タイプ
 */
function render_post_types_field(): void {
	$settings = \HatebuMonitor\get_settings();

	echo '<fieldset><legend class="screen-reader-text"><span>投稿タイプ</span></legend>';

	foreach ( get_selectable_post_types() as $name => $type ) {
		printf(
			'<label><input type="checkbox" name="%1$s[post_types][]" value="%2$s" %3$s> %4$s</label><br>',
			esc_attr( OPTION_SETTINGS ),
			esc_attr( $name ),
			checked( in_array( $name, $settings['post_types'], true ), true, false ),
			esc_html( $type->labels->name )
		);
	}

	echo '</fieldset>';
}

/**
 * 設定画面を出す
 */
function render_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( SETTINGS_GROUP );
			do_settings_sections( PAGE_SLUG );
			submit_button();
			?>
		</form>

		<h2>ステータス</h2>
		<?php render_status(); ?>

		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="<?php echo esc_attr( ACTION_FETCH ); ?>">
			<?php
			wp_nonce_field( ACTION_FETCH, NONCE_FETCH );
			submit_button( '今すぐ取得', 'secondary', 'hatebu_monitor_fetch', false );
			?>
			<p class="description">
				確認の時期が来ている投稿をすぐに確認します。公開から7日以内の投稿は1時間ごと、それ以外の投稿は1日1回確認します。
			</p>
		</form>
	</div>
	<?php
}

/**
 * 最後に取得した結果と、次の予約を出す
 *
 * 予約がない、または2時間以上遅れているときは、WP-Cronが動いていないと警告する。
 */
function render_status(): void {
	$next   = wp_next_scheduled( HOOK );
	$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

	if ( ! $next || $next < time() - 2 * HOUR_IN_SECONDS ) {
		wp_admin_notice(
			'定期取得が動いていません。このサイトではWP-Cronが無効になっている可能性があります。wp-cron.phpを定期的に実行する方法をホスティング会社に確認するか、下の「今すぐ取得」を使ってください。',
			array(
				'type'               => 'warning',
				'additional_classes' => array( 'inline' ),
			)
		);
	}

	$saved = get_option( OPTION_LAST_RUN );
	$rows  = array();

	if ( is_array( $saved ) ) {
		$last_run = array_merge(
			array(
				'time'      => 0,
				'trigger'   => 'cron',
				'checked'   => 0,
				'increased' => 0,
				'mail'      => 'none',
				'errors'    => array(),
			),
			$saved
		);
		$date     = wp_date( $format, (int) $last_run['time'] );

		if ( 'manual' === $last_run['trigger'] ) {
			$rows['最後の取得'] = sprintf(
				'%s（手動）',
				$date
			);
		} else {
			$rows['最後の取得'] = sprintf(
				'%s（定期）',
				$date
			);
		}

		$rows['確認した投稿']       = number_format_i18n( (int) $last_run['checked'] );
		$rows['ブックマークが増えた投稿'] = number_format_i18n( (int) $last_run['increased'] );

		if ( 'sent' === $last_run['mail'] ) {
			$rows['通知メール'] = '送信済み';
		} elseif ( 'failed' === $last_run['mail'] ) {
			$rows['通知メール'] = '失敗';
		} else {
			$rows['通知メール'] = '不要';
		}

		$errors      = array_filter( (array) $last_run['errors'], 'is_string' );
		$rows['エラー'] = $errors ? implode( '', $errors ) : 'なし';
	} else {
		$rows['最後の取得'] = '未実行';
	}

	$rows['次回の定期取得'] = $next ? wp_date( $format, $next ) : '予約なし';

	echo '<table class="form-table" role="presentation"><tbody>';

	foreach ( $rows as $label => $value ) {
		printf( '<tr><th scope="row">%1$s</th><td>%2$s</td></tr>', esc_html( $label ), esc_html( $value ) );
	}

	echo '</tbody></table>';
}

/**
 * 「今すぐ取得」の結果から、通知を作る
 *
 * 成功と失敗を同時に出さない。一部が失敗したときは警告、何も取れなかったときはエラーにする。
 *
 * @param array $run run_fetch()の戻り値。
 * @return array<int, array{code: string, message: string, type: string}>
 */
function fetch_now_notices( array $run ): array {
	if ( ! empty( $run['locked'] ) ) {
		return array(
			array(
				'code'    => 'fetch_locked',
				'message' => '取得がすでに実行中です。1分ほど待ってから、もう一度お試しください。',
				'type'    => 'warning',
			),
		);
	}

	if ( 0 === $run['checked'] && ! $run['errors'] ) {
		return array(
			array(
				'code'    => 'fetch_nothing_due',
				'message' => '今、確認の時期が来ている投稿はありません。',
				'type'    => 'info',
			),
		);
	}

	$sentences = array();

	if ( $run['checked'] > 0 ) {
		$sentences[] = sprintf(
			'%s件の投稿を確認しました。',
			number_format_i18n( $run['checked'] )
		);
	}

	if ( $run['increased'] > 0 ) {
		$sentences[] = sprintf(
			'%s件の投稿でブックマークが増えました。',
			number_format_i18n( $run['increased'] )
		);
	}

	if ( 'sent' === $run['mail'] ) {
		$sentences[] = '通知メールを送信しました。';
	}

	if ( $run['errors'] ) {
		return array(
			array(
				'code'    => 'fetch_failed',
				'message' => implode( '', array_merge( $sentences, $run['errors'] ) ),
				'type'    => $run['checked'] > 0 ? 'warning' : 'error',
			),
		);
	}

	return array(
		array(
			'code'    => 'fetched',
			'message' => implode( '', $sentences ),
			'type'    => 'success',
		),
	);
}

/**
 * 「今すぐ取得」を処理する（admin-post.php）
 *
 * その場で1回取得し、結果を通知に載せて設定画面へ戻す。
 */
function handle_fetch_now(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'この操作を行う権限がありません。', 403 );
	}

	check_admin_referer( ACTION_FETCH, NONCE_FETCH );

	foreach ( fetch_now_notices( run_fetch( 'manual' ) ) as $notice ) {
		add_settings_error( OPTION_SETTINGS, $notice['code'], esc_html( $notice['message'] ), $notice['type'] );
	}

	// options.phpと同じ受け渡し。戻った先で、コアが通知を出す。
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	wp_safe_redirect( add_query_arg( 'settings-updated', 'true', admin_url( 'options-general.php?page=' . PAGE_SLUG ) ) );
	exit;
}
add_action( 'admin_post_' . ACTION_FETCH, __NAMESPACE__ . '\handle_fetch_now' );
