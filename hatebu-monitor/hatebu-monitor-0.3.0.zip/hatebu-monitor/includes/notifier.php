<?php
/**
 * 通知メールの組み立てと送信
 *
 * @package HatebuMonitor
 */

namespace HatebuMonitor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** 1通のメールで、コメントを取りに行く記事の上限 */
const MAX_POSTS_WITH_COMMENTS = 10;

/** 1記事に載せるコメントの上限 */
const MAX_COMMENTS_PER_POST = 5;

/**
 * 増えた記事をまとめて、1通のメールで知らせる
 *
 * 締め切りを過ぎたら、残りの記事はコメントを取りに行かない。記事は載せ、はてブのページのURLは組み立てたものにする。
 *
 * はてなIDがあれば、jsonliteを取った記事について、自分のブックマークを外す。前回の取得以降に付いた
 * 自分のブックマークは増えた数から1引き、自分のコメントは載せない。引いて0になった記事は載せず、
 * 載せる記事がなければメールを送らない。取った応答で、セルフブクマの判定も記録する。
 * jsonliteを取らなかった記事（11件目から・締め切りを過ぎた分・取得に失敗した分）は、これまでどおり載せる。
 *
 * @param array $increased 増えた記事（fetch_and_store()の戻り値や送信待ちの箱の中身）。各要素はpost_id・previous・count・previous_checkedを持つ。
 * @param int   $deadline  コメントを取りに行ける締め切り（UNIX時刻）。0なら締め切りなし。
 * @param bool  $requested この回に、もうはてなへリクエストを送ったか（件数取得）。送っていれば、最初のコメント取得の前にも間隔をあける。
 * @return array{sent: bool, mail: string, errors: string[]} mailはsent・failed・none（知らせる記事がなく、送らなかった）。
 */
function send_notification( array $increased, int $deadline = 0, bool $requested = false ): array {
	$errors    = array();
	$skipped   = 0;
	$hatena_id = get_hatena_id();

	// 増えた数の多い順に並べる。コメントを取りに行くのは上位だけ。
	usort(
		$increased,
		static function ( array $a, array $b ): int {
			return ( $b['count'] - $b['previous'] ) - ( $a['count'] - $a['previous'] );
		}
	);

	$items = array();

	foreach ( $increased as $index => $row ) {
		$post = get_post( $row['post_id'] );
		$url  = (string) get_permalink( $row['post_id'] );
		$item = array(
			'title'     => $post ? html_entity_decode( wp_strip_all_tags( $post->post_title ), ENT_QUOTES, 'UTF-8' ) : '',
			'url'       => $url,
			'diff'      => $row['count'] - $row['previous'],
			'count'     => $row['count'],
			'entry_url' => entry_page_url( $url ),
			'comments'  => array(),
		);

		if ( $index < MAX_POSTS_WITH_COMMENTS && $deadline > 0 && time() >= $deadline ) {
			++$skipped;
		} elseif ( $index < MAX_POSTS_WITH_COMMENTS ) {
			if ( $requested ) {
				wait_between_requests();
			}

			$requested = true;
			$entry     = fetch_entry( $url );

			if ( is_wp_error( $entry ) ) {
				$errors[] = sprintf(
					'はてなから新しいコメントを取得できませんでした（%s）。通知にはコメントが含まれていません。',
					$entry->get_error_message()
				);
			} else {
				// エントリーがない（null）ときは、ブックマークが1件もないものとして扱う。
				$bookmarks = is_array( $entry ) ? $entry['bookmarks'] : array();

				// はてなのページ以外のURLが返ってきても、メールには載せない。
				if ( is_array( $entry ) && 0 === strpos( $entry['entry_url'], 'https://b.hatena.ne.jp/' ) ) {
					$item['entry_url'] = $entry['entry_url'];
				}

				if ( '' !== $hatena_id ) {
					// 取った応答で、セルフブクマの判定も済ませる（削除済みの投稿にはメタを書かない）。
					if ( $post ) {
						record_self( $row['post_id'], has_bookmark_by( $bookmarks, $hatena_id ), time() );
					}

					$own       = exclude_own_bookmarks( $bookmarks, $hatena_id, $row['previous_checked'] );
					$bookmarks = $own['bookmarks'];

					if ( $own['new'] ) {
						--$item['diff'];
					}
				}

				$item['comments'] = collect_new_comments( $bookmarks, $row['previous_checked'] );
			}
		}

		// 増えたのが自分のブックマークだけの記事は載せない。
		if ( $item['diff'] > 0 ) {
			$items[] = $item;
		}
	}

	if ( $skipped > 0 ) {
		$errors[] = sprintf(
			'取得に時間がかかりすぎたため、%s件の投稿の新しいコメントは通知に含めていません。',
			number_format_i18n( $skipped )
		);
	}

	// 増えたのが自分のブックマークだけなら、知らせることがない。
	if ( ! $items ) {
		return array(
			'sent'   => false,
			'mail'   => 'none',
			'errors' => array_values( array_unique( $errors ) ),
		);
	}

	$blogname = wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES );
	$count    = count( $items );
	$subject  = sprintf(
		'[%1$s] %2$s件の投稿に新しいはてなブックマーク',
		$blogname,
		number_format_i18n( $count )
	);
	$sent     = wp_mail( get_recipient(), $subject, build_message( $items, $blogname ) );

	if ( ! $sent ) {
		$errors[] = '通知メールを送信できませんでした。このサイトからメールを送信できるか確認してください。';
	}

	return array(
		'sent'   => (bool) $sent,
		'mail'   => $sent ? 'sent' : 'failed',
		'errors' => array_values( array_unique( $errors ) ),
	);
}

/**
 * ブックマークの一覧から自分のブックマークを外し、前回の取得以降に付いたものがあったかを返す
 *
 * はてなの時刻は分までしかないので、前回の取得時刻を分に切り捨てて比べる（collect_new_comments()と同じ）。
 * 時刻を読めなかったブックマーク（timestampが0）は、前回より前に付いたものとして扱う
 * （増えた数から引かないので、通知が余分に届く側に倒れる）。
 *
 * @param array  $bookmarks fetch_entry()が返すbookmarks。
 * @param string $hatena_id 自分のはてなID。
 * @param int    $since     前回の取得時刻（UNIX時刻）。
 * @return array{bookmarks: array, new: bool} bookmarksは自分のものを除いた一覧（順番は元のまま）。
 */
function exclude_own_bookmarks( array $bookmarks, string $hatena_id, int $since ): array {
	$since  = $since - ( $since % MINUTE_IN_SECONDS );
	$others = array();
	$new    = false;

	foreach ( $bookmarks as $bookmark ) {
		if ( ! is_same_user( $bookmark['user'], $hatena_id ) ) {
			$others[] = $bookmark;
			continue;
		}

		if ( $bookmark['timestamp'] >= $since ) {
			$new = true;
		}
	}

	return array(
		'bookmarks' => $others,
		'new'       => $new,
	);
}

/**
 * 前回の取得以降に付いたコメントを選ぶ
 *
 * はてなの時刻は分までしかないので、前回の取得時刻を分に切り捨てて比べる。
 * ユーザー名とコメントは外から来た文字列なので、タグと改行を落とす。
 *
 * @param array $bookmarks fetch_entry()が返すbookmarks（新しい順）。
 * @param int   $since     前回の取得時刻（UNIX時刻）。
 * @return array<int, array{user: string, comment: string}> 新しい順に、MAX_COMMENTS_PER_POST件まで。
 */
function collect_new_comments( array $bookmarks, int $since ): array {
	$since    = $since - ( $since % MINUTE_IN_SECONDS );
	$comments = array();

	foreach ( $bookmarks as $bookmark ) {
		$comment = sanitize_text_field( $bookmark['comment'] );

		if ( '' === $comment || $bookmark['timestamp'] < $since ) {
			continue;
		}

		$comments[] = array(
			'user'    => sanitize_text_field( $bookmark['user'] ),
			'comment' => $comment,
		);

		if ( count( $comments ) >= MAX_COMMENTS_PER_POST ) {
			break;
		}
	}

	return $comments;
}

/**
 * メールの本文（テキスト）を組み立てる
 *
 * @param array  $items    記事ごとの配列。title・url・diff・count・entry_url・commentsを持つ。
 * @param string $blogname サイト名。
 */
function build_message( array $items, string $blogname ): string {
	$lines = array(
		'次の投稿に新しいはてなブックマークが付きました:',
		'',
	);

	foreach ( $items as $item ) {
		$lines[] = $item['title'];
		$lines[] = sprintf(
			'+%1$s (%2$s users)',
			number_format_i18n( $item['diff'] ),
			number_format_i18n( $item['count'] )
		);
		$lines[] = $item['url'];
		$lines[] = sprintf(
			'はてなブックマーク: %s',
			$item['entry_url']
		);

		if ( $item['comments'] ) {
			$lines[] = '新しいコメント:';

			foreach ( $item['comments'] as $comment ) {
				$lines[] = '- ' . $comment['user'] . ': ' . $comment['comment'];
			}
		}

		$lines[] = '';
	}

	$lines[] = '-- ';
	$lines[] = sprintf(
		'%1$s（%2$s）のHatebu Monitorプラグインが送信しました。',
		$blogname,
		home_url()
	);

	return implode( "\n", $lines );
}
