<?php
/**
 * アンインストール時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * オプション・投稿メタ・transient・予約を増やしたら、同じコミットでここも更新すること。
 *
 * @package HatebuMonitor
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'hatebu_monitor_settings' );
delete_option( 'hatebu_monitor_last_run' );
delete_option( 'hatebu_monitor_pending' );
delete_option( 'hatebu_monitor_self_failed' );
delete_transient( 'hatebu_monitor_running' );
delete_site_transient( 'hatebu_monitor_update_info' );
delete_post_meta_by_key( '_hatebu_monitor_count' );
delete_post_meta_by_key( '_hatebu_monitor_checked' );
delete_post_meta_by_key( '_hatebu_monitor_self' );
delete_post_meta_by_key( '_hatebu_monitor_self_checked' );
wp_clear_scheduled_hook( 'hatebu_monitor_fetch' );
