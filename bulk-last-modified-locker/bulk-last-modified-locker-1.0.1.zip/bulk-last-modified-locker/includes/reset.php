<?php
/**
 * 更新日を公開日に戻す
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1件の投稿の更新日を公開日へ戻す
 *
 * publish 以外はスキップする。下書きや予約投稿の post_date は
 * 「公開予定日」であって、戻し先として意味を成さないため。
 * $wpdb->update の直叩きではなく wp_update_post を通すのは、
 * clean_post_cache と save_post を走らせて他プラグインとの整合を保つため。
 *
 * @param int $post_id 投稿 ID。
 * @return string reset | unchanged | skipped | denied | error のいずれか。
 */
function blml_reset_modified( int $post_id ): string {
	$post = get_post( $post_id );

	if ( ! $post || 'publish' !== $post->post_status ) {
		return 'skipped';
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return 'denied';
	}

	if ( $post->post_modified === $post->post_date && $post->post_modified_gmt === $post->post_date_gmt ) {
		return 'unchanged';
	}

	// wp_update_post は既存本文を保存フィルタに通し直す。unfiltered_html の
	// 無いユーザーの実行で kses が本文を削らないよう、一時的に外して戻す。
	$had_kses = false !== has_filter( 'content_save_pre', 'wp_filter_post_kses' );
	if ( $had_kses ) {
		kses_remove_filters();
	}

	blml_flag( 'reset', $post_id );
	$result = wp_update_post( array( 'ID' => $post_id ), true );
	blml_flag( 'reset', 0 );

	if ( $had_kses ) {
		kses_init_filters();
	}

	return is_wp_error( $result ) ? 'error' : 'reset';
}

/**
 * 一括操作と行アクションを登録する
 *
 * public な投稿タイプの一覧画面に出す。ロックの除外リストは見ない。
 * 除外は「ロックしない」という意味で、日付を戻す操作まで取り上げない。
 *
 * @return void
 */
function blml_register_admin_hooks(): void {
	foreach ( array_keys( blml_get_public_post_types() ) as $type ) {
		add_filter( "bulk_actions-edit-{$type}", 'blml_add_bulk_action' );
		add_filter( "handle_bulk_actions-edit-{$type}", 'blml_handle_bulk_reset', 10, 3 );
	}

	add_filter( 'post_row_actions', 'blml_add_row_action', 10, 2 );
	add_filter( 'page_row_actions', 'blml_add_row_action', 10, 2 );
}
add_action( 'admin_init', 'blml_register_admin_hooks' );

/**
 * 一括操作の項目を足す
 *
 * @param array<string, string> $actions 既存の一括操作。
 * @return array<string, string> 追加後の一括操作。
 */
function blml_add_bulk_action( array $actions ): array {
	$actions['blml_reset'] = __( 'Reset modified date to publish date', 'bulk-last-modified-locker' );
	return $actions;
}

/**
 * 一括操作を処理する
 *
 * nonce は core が bulk-posts で検証済み。権限は blml_reset_modified() が
 * 1件ずつ確認する。
 *
 * @param string $redirect_to リダイレクト先。
 * @param string $doaction    実行する操作名。
 * @param int[]  $post_ids    対象の投稿 ID。
 * @return string 件数付きのリダイレクト先。
 */
function blml_handle_bulk_reset( $redirect_to, $doaction, $post_ids ) {
	if ( 'blml_reset' !== $doaction ) {
		return $redirect_to;
	}

	$reset   = 0;
	$skipped = 0;

	foreach ( array_map( 'intval', (array) $post_ids ) as $post_id ) {
		if ( 'reset' === blml_reset_modified( $post_id ) ) {
			++$reset;
		} else {
			++$skipped;
		}
	}

	return add_query_arg(
		array(
			'blml_reset'   => $reset,
			'blml_skipped' => $skipped,
		),
		$redirect_to
	);
}

/**
 * 行アクションに「更新日を公開日に戻す」を足す
 *
 * 公開済み・public な投稿タイプ・編集権限あり・更新日がずれている行だけに出す。
 * ロックの除外リストは見ない。
 *
 * @param array<string, string> $actions 既存の行アクション。
 * @param WP_Post               $post    行の投稿。
 * @return array<string, string> 追加後の行アクション。
 */
function blml_add_row_action( array $actions, WP_Post $post ): array {
	if ( 'publish' !== $post->post_status ) {
		return $actions;
	}

	if ( ! array_key_exists( $post->post_type, blml_get_public_post_types() ) ) {
		return $actions;
	}

	if ( ! current_user_can( 'edit_post', $post->ID ) ) {
		return $actions;
	}

	if ( $post->post_modified === $post->post_date && $post->post_modified_gmt === $post->post_date_gmt ) {
		return $actions;
	}

	$url = wp_nonce_url(
		admin_url( 'admin-post.php?action=blml_reset&post=' . $post->ID ),
		'blml_reset_' . $post->ID
	);

	$confirm = __( 'Reset the modified date of this post to its publish date? This cannot be undone.', 'bulk-last-modified-locker' );

	$actions['blml_reset'] = sprintf(
		'<a href="%s" onclick="return confirm(%s);">%s</a>',
		esc_url( $url ),
		esc_attr( wp_json_encode( $confirm ) ),
		esc_html__( 'Reset modified date', 'bulk-last-modified-locker' )
	);

	return $actions;
}

/**
 * 行アクションからの実行を処理する
 *
 * @return void
 */
function blml_handle_row_reset(): void {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

	check_admin_referer( 'blml_reset_' . $post_id );

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_die( esc_html__( 'You are not allowed to edit this post.', 'bulk-last-modified-locker' ) );
	}

	$status = blml_reset_modified( $post_id );

	$redirect = wp_get_referer();
	if ( ! $redirect ) {
		$redirect = admin_url( 'edit.php' );
	}

	wp_safe_redirect(
		add_query_arg(
			array(
				'blml_reset'   => 'reset' === $status ? 1 : 0,
				'blml_skipped' => 'reset' === $status ? 0 : 1,
			),
			$redirect
		)
	);
	exit;
}
add_action( 'admin_post_blml_reset', 'blml_handle_row_reset' );

/**
 * 実行結果の通知を出す
 *
 * 一括操作と行アクションの戻り先は投稿一覧だけなので、そこ以外では出さない。
 *
 * @return void
 */
function blml_render_reset_notice(): void {
	$screen = get_current_screen();

	if ( ! $screen || 'edit' !== $screen->base ) {
		return;
	}

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- 表示専用の件数で、状態を変えない。
	if ( ! isset( $_GET['blml_reset'] ) ) {
		return;
	}

	$reset   = absint( $_GET['blml_reset'] );
	$skipped = isset( $_GET['blml_skipped'] ) ? absint( $_GET['blml_skipped'] ) : 0;
	// phpcs:enable

	$messages = array();

	if ( $reset ) {
		/* translators: %d: 戻した件数 */
		$messages[] = sprintf( _n( 'Reset the modified date of %d post to its publish date.', 'Reset the modified date of %d posts to their publish date.', $reset, 'bulk-last-modified-locker' ), $reset );
	}

	if ( $skipped ) {
		/* translators: %d: スキップした件数 */
		$messages[] = sprintf( _n( '%d post was skipped.', '%d posts were skipped.', $skipped, 'bulk-last-modified-locker' ), $skipped );
	}

	if ( ! $messages ) {
		return;
	}

	$class = $reset ? 'notice-success' : 'notice-warning';

	printf(
		'<div class="notice %s is-dismissible"><p>%s</p></div>',
		esc_attr( $class ),
		esc_html( implode( ' ', $messages ) )
	);
}
add_action( 'admin_notices', 'blml_render_reset_notice' );

/**
 * 一括操作の実行前に確認ダイアログを出す
 *
 * メッセージは wp_json_encode で JS のリテラルにして埋める。
 * JSON_HEX_TAG / JSON_HEX_AMP は、翻訳文に記号が混ざっても
 * script タグを閉じられないようにするため。
 *
 * @return void
 */
function blml_print_bulk_confirm_script(): void {
	$screen = get_current_screen();

	if ( ! $screen || ! array_key_exists( $screen->post_type, blml_get_public_post_types() ) ) {
		return;
	}

	/* translators: %d: 選択中の件数 */
	$message = __( 'Reset the modified date of %d selected posts to their publish date? This cannot be undone.', 'bulk-last-modified-locker' );
	?>
	<script>
	( function () {
		var message = <?php echo wp_json_encode( $message, JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
		document.addEventListener( 'submit', function ( event ) {
			var form = event.target;
			if ( 'posts-filter' !== form.id ) {
				return;
			}
			var action = '';
			[ 'action', 'action2' ].forEach( function ( name ) {
				var select = form.querySelector( 'select[name="' + name + '"]' );
				if ( select && '-1' !== select.value && ! action ) {
					action = select.value;
				}
			} );
			if ( 'blml_reset' !== action ) {
				return;
			}
			var count = form.querySelectorAll( 'input[name="post[]"]:checked' ).length;
			if ( ! window.confirm( message.replace( '%d', String( count ) ) ) ) {
				event.preventDefault();
			}
		} );
	} )();
	</script>
	<?php
}
add_action( 'admin_print_footer_scripts-edit.php', 'blml_print_bulk_confirm_script' );

/**
 * エディタの「公開日に戻す」ボタン用の REST ルートを登録する
 *
 * @return void
 */
function blml_register_reset_route(): void {
	register_rest_route(
		'blml/v1',
		'/reset/(?P<id>\d+)',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'permission_callback' => function ( WP_REST_Request $request ): bool {
				return current_user_can( 'edit_post', (int) $request['id'] );
			},
			'callback'            => function ( WP_REST_Request $request ) {
				$post_id = (int) $request['id'];
				$status  = blml_reset_modified( $post_id );
				$post    = get_post( $post_id );

				// modified はエディタ側の post.modified と同じ RFC3339 形式で返す。
				// 生の MySQL 形式を返すと dateI18n が非 ISO のフォールバック解釈になる。
				return rest_ensure_response(
					array(
						'status'   => $status,
						'modified' => $post ? mysql_to_rfc3339( $post->post_modified ) : '',
					)
				);
			},
			'args'                => array(
				'id' => array(
					'type'     => 'integer',
					'required' => true,
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'blml_register_reset_route' );
