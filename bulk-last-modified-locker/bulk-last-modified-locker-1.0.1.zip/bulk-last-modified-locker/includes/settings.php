<?php
/**
 * 設定画面とオプションの読み書き
 *
 * オプションは blml_enabled（ロックのオンオフ）と
 * blml_excluded_post_types（除外する投稿タイプ slug の配列）の2つ。
 * 除外リストは UI 上「ロックする」のチェックリストとして見せ、外されたものを除外として保存する。
 * UI のチェック＝ロック対象、オプションの値＝除外、と真偽が反転している点に注意。
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * オプションを登録する
 *
 * @return void
 */
function blml_register_settings(): void {
	register_setting(
		'blml',
		'blml_enabled',
		array(
			'type'              => 'boolean',
			'sanitize_callback' => 'blml_sanitize_enabled',
			'default'           => true,
		)
	);

	register_setting(
		'blml',
		'blml_excluded_post_types',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'blml_sanitize_excluded',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'blml_register_settings' );

/**
 * ロックのオンオフを正規化する
 *
 * 未チェックのチェックボックスはフォーム送信に含まれないため、
 * options.php からは null が渡る。これを false として保存する。
 *
 * @param mixed $value 保存前の値。
 * @return bool ロックする場合 true。
 */
function blml_sanitize_enabled( $value ): bool {
	return (bool) $value;
}

/**
 * 除外リストを正規化する
 *
 * 設定画面からは array( 'all' => 表示した全タイプ, 'locked' => チェックされたタイプ ) の
 * 形で届き、差分（チェックを外されたもの）が除外リストになる。update_option() へ
 * 直接 slug の配列を渡した場合はそのまま検証だけ行う。いずれも実在する public な
 * 投稿タイプ（attachment 除く）の slug のみ通す。
 *
 * @param mixed $value 保存前の値。
 * @return string[] 除外する投稿タイプ slug の配列。
 */
function blml_sanitize_excluded( $value ): array {
	if ( ! is_array( $value ) ) {
		return array();
	}

	if ( isset( $value['all'] ) ) {
		$all      = is_array( $value['all'] ) ? $value['all'] : array();
		$locked   = isset( $value['locked'] ) && is_array( $value['locked'] ) ? $value['locked'] : array();
		$excluded = array_diff( $all, $locked );
	} else {
		$excluded = $value;
	}

	$valid = blml_get_public_post_types();

	$excluded = array_intersect( array_map( 'sanitize_key', $excluded ), array_keys( $valid ) );

	return array_values( array_unique( $excluded ) );
}

/**
 * 設定ページを追加する
 *
 * @return void
 */
function blml_add_settings_page(): void {
	add_options_page(
		__( 'Bulk Last Modified Locker', 'bulk-last-modified-locker' ),
		__( 'Bulk Last Modified Locker', 'bulk-last-modified-locker' ),
		'manage_options',
		'blml',
		'blml_render_settings_page'
	);
}
add_action( 'admin_menu', 'blml_add_settings_page' );

/**
 * プラグイン一覧に設定リンクを足す
 *
 * @param string[] $links 既存のリンク。
 * @return string[] 設定リンクを先頭に足したリンク。
 */
function blml_add_settings_link( array $links ): array {
	array_unshift(
		$links,
		'<a href="' . esc_url( admin_url( 'options-general.php?page=blml' ) ) . '">'
		. esc_html__( 'Settings', 'bulk-last-modified-locker' ) . '</a>'
	);

	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( BLML_PLUGIN_FILE ), 'blml_add_settings_link' );

/**
 * 設定ページを描画する
 *
 * @return void
 */
function blml_render_settings_page(): void {
	$types = blml_get_public_post_types( 'objects' );

	$excluded = get_option( 'blml_excluded_post_types', array() );
	$excluded = is_array( $excluded ) ? $excluded : array();
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<p><?php esc_html_e( 'This plugin keeps the modified date of your published posts from moving forward when you edit them.', 'bulk-last-modified-locker' ); ?></p>
		<p><?php esc_html_e( 'It never rewrites dates that are already stored. The only thing that changes an existing date is the reset action, which you run yourself on the posts you choose.', 'bulk-last-modified-locker' ); ?></p>
		<form action="options.php" method="post">
			<?php settings_fields( 'blml' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php echo esc_html_x( 'Lock', 'settings row label', 'bulk-last-modified-locker' ); ?></th>
					<td>
						<label>
							<input
								type="checkbox"
								name="blml_enabled"
								value="1"
								<?php checked( blml_is_enabled() ); ?>
							/>
							<?php esc_html_e( 'Lock the modified date', 'bulk-last-modified-locker' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'When this is off, modified dates move as usual. The reset actions in the posts list and in the block editor stay available.', 'bulk-last-modified-locker' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Locked post types', 'bulk-last-modified-locker' ); ?></th>
					<td>
						<fieldset>
							<legend class="screen-reader-text"><?php esc_html_e( 'Locked post types', 'bulk-last-modified-locker' ); ?></legend>
							<p class="description"><?php esc_html_e( 'While the lock is on, the modified date is locked for the checked post types. Uncheck a post type to leave it out of the lock. The reset actions stay available for every post type either way.', 'bulk-last-modified-locker' ); ?></p>
							<?php foreach ( $types as $slug => $type ) : ?>
								<input type="hidden" name="blml_excluded_post_types[all][]" value="<?php echo esc_attr( $slug ); ?>" />
								<label style="display:block;margin-bottom:4px;">
									<input
										type="checkbox"
										name="blml_excluded_post_types[locked][]"
										value="<?php echo esc_attr( $slug ); ?>"
										<?php checked( ! in_array( $slug, $excluded, true ) ); ?>
									/>
									<?php
									printf(
										/* translators: 1: 投稿タイプ名, 2: スラッグ */
										esc_html__( '%1$s (%2$s)', 'bulk-last-modified-locker' ),
										esc_html( $type->labels->name ),
										esc_html( $slug )
									);
									?>
								</label>
							<?php endforeach; ?>
						</fieldset>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
