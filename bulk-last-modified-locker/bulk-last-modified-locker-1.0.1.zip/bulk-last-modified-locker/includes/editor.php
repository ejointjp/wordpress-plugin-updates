<?php
/**
 * ブロックエディタ用スクリプトの登録と受け渡し
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * サイドバー用スクリプトを読み込む
 *
 * public な投稿タイプの編集画面に出す。ロックの除外リストは見ない。
 * 除外したタイプでも「公開日に戻す」は使えるようにするため。
 *
 * @return void
 */
function blml_enqueue_editor_assets(): void {
	$post = get_post();

	if ( ! $post || ! array_key_exists( $post->post_type, blml_get_public_post_types() ) ) {
		return;
	}

	wp_enqueue_script(
		'blml-editor',
		plugins_url( 'assets/editor.js', BLML_PLUGIN_FILE ),
		array(
			'wp-api-fetch',
			'wp-components',
			'wp-data',
			'wp-date',
			'wp-edit-post',
			'wp-editor',
			'wp-element',
			'wp-i18n',
			'wp-notices',
			'wp-plugins',
		),
		BLML_VERSION,
		true
	);

	wp_set_script_translations( 'blml-editor', 'bulk-last-modified-locker', BLML_PLUGIN_DIR . 'languages' );

	wp_localize_script(
		'blml-editor',
		'blmlEditor',
		array(
			'postId'     => $post->ID,
			'restPath'   => rest_get_route_for_post( $post ),
			'dateFormat' => get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),

			/*
			 * ロックがオフ、または除外された投稿タイプなら false。
			 * パネルは出すが「ロック中」と「今回は進める」は見せない。
			 * wp_localize_script は値を文字列にする。true は "1"、false は "" で届く。
			 */
			'locked'     => blml_is_enabled() && in_array( $post->post_type, blml_get_target_post_types(), true ),
		)
	);
}
add_action( 'enqueue_block_editor_assets', 'blml_enqueue_editor_assets' );
