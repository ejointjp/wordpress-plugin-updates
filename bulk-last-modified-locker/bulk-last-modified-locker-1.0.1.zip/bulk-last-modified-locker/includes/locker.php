<?php
/**
 * ロック判定と対象投稿タイプの解決
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 保存1リクエスト内だけ有効な一時フラグ
 *
 * DB には何も書かない。値は対象の投稿 ID（0 は未設定）。
 * - bump:  この保存に限りロックを外し、更新日を進めさせる
 * - reset: この保存で更新日を公開日へ戻す
 *
 * @param string   $name  フラグ名（bump | reset）。
 * @param int|null $value セットする投稿 ID。省略時は読み取り。0 でクリア。
 * @return int 現在の値。
 */
function blml_flag( string $name, ?int $value = null ): int {
	static $flags = array(
		'bump'  => 0,
		'reset' => 0,
	);

	if ( null !== $value ) {
		$flags[ $name ] = $value;
	}

	return $flags[ $name ] ?? 0;
}

/**
 * リクエストの終わりに一時フラグを落とす
 *
 * 常駐ワーカー（Swoole / RoadRunner など）では static がリクエストを
 * またいで生き残る。REST の保存が途中で打ち切られてフラグが消費されな
 * かった場合に、次のリクエストの同じ投稿の保存へ漏らさないための保険。
 *
 * @return void
 */
function blml_clear_flags(): void {
	blml_flag( 'bump', 0 );
	blml_flag( 'reset', 0 );
}
add_action( 'shutdown', 'blml_clear_flags' );

/**
 * ロックが有効かどうかを返す
 *
 * オプションが無いサイト（この設定より前から使っている場合）では true を返し、
 * これまでどおりロックする。
 *
 * @return bool ロックする場合 true。
 */
function blml_is_enabled(): bool {
	return (bool) get_option( 'blml_enabled', true );
}

/**
 * このプラグインが扱う投稿タイプを返す
 *
 * public な投稿タイプから attachment（post_status が inherit のため
 * 元々ロックされない）を引いたもの。除外リストは引かない。
 * 設定画面のチェックリストに並ぶ顔ぶれがこれにあたる。
 *
 * @param string $output 'names' で slug、'objects' で投稿タイプオブジェクト。
 * @return array<string, mixed> 投稿タイプ slug をキーにした配列。
 */
function blml_get_public_post_types( string $output = 'names' ): array {
	$types = get_post_types( array( 'public' => true ), $output );
	unset( $types['attachment'] );

	return $types;
}

/**
 * ロック対象の投稿タイプを返す
 *
 * blml_get_public_post_types() から除外リストを引いた残り。除外リストは
 * 「外したものだけを覚える」方式なので、後から増えた CPT は自動で対象に入る。
 *
 * @return string[] 投稿タイプ slug の配列。
 */
function blml_get_target_post_types(): array {
	$types = blml_get_public_post_types();

	$excluded = get_option( 'blml_excluded_post_types', array() );

	if ( is_array( $excluded ) && $excluded ) {
		$types = array_diff_key( $types, array_flip( $excluded ) );
	}

	/**
	 * ロック対象の投稿タイプを変更する
	 *
	 * @param string[] $types 投稿タイプ slug の配列。
	 */
	return apply_filters( 'blml_post_types', array_values( $types ) );
}

/**
 * 保存直前の投稿データの更新日を、DB に入っている元の値へ戻す
 *
 * 新規投稿（ID なし）は現在日時をセットさせるためスキップする。
 * 公開済み → 公開のときだけロックし、下書きからの公開や
 * 非公開への変更では通常どおり更新日を進める。
 *
 * @param array<string, mixed> $data    サニタイズ済みの投稿データ。
 * @param array<string, mixed> $postarr 加工前の投稿データ。
 * @return array<string, mixed> 更新日を差し替えた投稿データ。
 */
function blml_lock_modified_date( $data, $postarr ) {
	if ( empty( $postarr['ID'] ) ) {
		return $data;
	}

	// 「公開日に戻す」の実行中。明示的な操作なので対象タイプの判定より先に通す。
	if ( blml_flag( 'reset' ) === (int) $postarr['ID'] ) {
		$data['post_modified']     = $data['post_date'];
		$data['post_modified_gmt'] = $data['post_date_gmt'];
		return $data;
	}

	// ロックがオフ。更新日は通常どおり進める。上の「戻す」より後に置くこと。
	// オフのあいだも公開日に戻す操作は使えるようにしている。
	if ( ! blml_is_enabled() ) {
		return $data;
	}

	if ( ! in_array( $data['post_type'], blml_get_target_post_types(), true ) ) {
		return $data;
	}

	// 「今回は更新日を進める」が指定された保存。ロックを外して通常の動きに任せる。
	// フラグは消費した時点でクリアする。persistent worker な SAPI では
	// static がリクエストをまたいで生き残るため、放置すると次の保存にも効いてしまう。
	if ( blml_flag( 'bump' ) === (int) $postarr['ID'] ) {
		blml_flag( 'bump', 0 );
		return $data;
	}

	$original_post = get_post( (int) $postarr['ID'] );

	if ( $original_post && 'publish' === $original_post->post_status && 'publish' === $data['post_status'] ) {
		$data['post_modified']     = $original_post->post_modified;
		$data['post_modified_gmt'] = $original_post->post_modified_gmt;
	}

	return $data;
}
add_filter( 'wp_insert_post_data', 'blml_lock_modified_date', 10, 2 );

/**
 * REST 保存リクエストの blml_bump パラメータを拾う
 *
 * rest_pre_insert_{$post_type} は wp_insert_post より前に走るため、
 * ここで立てたフラグが blml_lock_modified_date() に間に合う。
 *
 * @param stdClass        $prepared_post 挿入直前の投稿データ。
 * @param WP_REST_Request $request       リクエスト。
 * @return stdClass 受け取ったままの投稿データ。
 */
function blml_catch_bump_param( $prepared_post, $request ) {
	if ( ! empty( $prepared_post->ID ) && rest_sanitize_boolean( $request->get_param( 'blml_bump' ) ) ) {
		blml_flag( 'bump', (int) $prepared_post->ID );
	}

	return $prepared_post;
}

/**
 * 対象投稿タイプぶんの rest_pre_insert フィルタを登録する
 *
 * 対象は除外リスト次第で動的に決まるため、rest_api_init まで遅らせる。
 *
 * @return void
 */
function blml_register_rest_hooks(): void {
	// ロックがオフなら blml_bump を拾う必要が無い（外すロックが無い）。
	if ( ! blml_is_enabled() ) {
		return;
	}

	foreach ( blml_get_target_post_types() as $type ) {
		add_filter( "rest_pre_insert_{$type}", 'blml_catch_bump_param', 10, 2 );
	}
}
add_action( 'rest_api_init', 'blml_register_rest_hooks' );
