<?php
/**
 * アンインストール時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 *
 * このプラグインが保存するデータは、オプション blml_enabled と blml_excluded_post_types の2件と、
 * 更新情報のキャッシュ（サイトのトランジェント blml_update_info）。
 * cron・カスタムテーブルは作らないため、削除するのはこの3件だけ。
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$blml_options = array( 'blml_enabled', 'blml_excluded_post_types' );

if ( is_multisite() ) {
	/*
	 * オプションはサイトごとに持つが、このファイルはネットワーク全体で1回しか
	 * 走らない。全サイトを回らないとサブサイトに残骸が残る。
	 * サイト数の多いネットワークでメモリを食わないよう、100件ずつ取る。
	 */
	$blml_batch  = 100;
	$blml_offset = 0;

	do {
		$blml_site_ids = get_sites(
			array(
				'fields'                 => 'ids',
				'number'                 => $blml_batch,
				'offset'                 => $blml_offset,
				'update_site_meta_cache' => false,
			)
		);
		$blml_found    = count( $blml_site_ids );

		foreach ( $blml_site_ids as $blml_site_id ) {
			switch_to_blog( $blml_site_id );

			foreach ( $blml_options as $blml_option ) {
				delete_option( $blml_option );
			}

			restore_current_blog();
		}

		$blml_offset += $blml_batch;
	} while ( $blml_found === $blml_batch );
} else {
	foreach ( $blml_options as $blml_option ) {
		delete_option( $blml_option );
	}
}

// 更新情報のキャッシュは、マルチサイトでもネットワーク全体で1つ。サイトごとのループの外で消す。
delete_site_transient( 'blml_update_info' );

/*
 * 保存するデータを増やしたら、同じコミットでここも更新すること。
 * 足し忘れがユーザーの DB に残骸として残る。
 */
