<?php
/**
 * Plugin Name:       Bulk Last Modified Locker
 * Description:       Locks the last modified date of every published post across all public post types. Bump it on demand or reset it to the publish date.
 * Version:           1.0.1
 * Requires at least: 6.7
 * Requires PHP:      8.0
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bulk-last-modified-locker
 * Domain Path:       /languages
 * Update URI:        https://yuiami.jp/wp-plugins/bulk-last-modified-locker
 *
 * @package BulkLastModifiedLocker
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BLML_VERSION', '1.0.1' );
define( 'BLML_PLUGIN_FILE', __FILE__ );
define( 'BLML_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require BLML_PLUGIN_DIR . 'includes/locker.php';
require BLML_PLUGIN_DIR . 'includes/settings.php';
require BLML_PLUGIN_DIR . 'includes/editor.php';
require BLML_PLUGIN_DIR . 'includes/reset.php';
require BLML_PLUGIN_DIR . 'includes/update-checker.php';
