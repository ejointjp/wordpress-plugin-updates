=== Bulk Last Modified Locker ===
Contributors: ejointjp
Tags: last modified, modified date, posts, pages, seo
Requires at least: 6.7
Tested up to: 7.1
Stable tag: 1.0.1
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Locks the modified date of published posts across all public post types. Bump it only when you choose, or reset it to the publish date.

== Description ==

Fixing a typo should not make a three-year-old article look brand new. Bulk Last Modified Locker keeps the last modified date of your published posts exactly where it was, no matter how many times you edit them.

There is nothing to set up per post. Activate the plugin and the lock applies to every published post of every public post type at once.

- Applies in bulk — no per-post switch to remember, so nothing slips through
- Covers every public post type, including custom post types added later. Exclude specific post types on the settings screen if you need to
- Bump the modified date on purpose: tick "Bump the modified date on this save" in the block editor sidebar when an update deserves a new date. The tick applies to that save only and is never stored
- Made a mistake? Reset the modified date back to the publish date from the posts list (bulk action or row action) or from the block editor sidebar
- New posts still get a correct modified date when they are first published
- Need the dates to move again for a while? Turn the lock off on the settings screen. The reset actions keep working while it is off, so you can still fix dates that already moved
- No database tables and no scheduled events. Two option rows and a short-lived cache of the update information, nothing else
- To check for updates, it requests a small file (`info.json`) from GitHub (`raw.githubusercontent.com`), where the plugin is distributed. The request does not include your site's URL or any site data. It makes no other external requests

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/bulk-last-modified-locker` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.

That is all. The lock is active as soon as the plugin is activated.

== Frequently Asked Questions ==

= Does this change the modified date of posts that already exist? =

No. Activating the plugin never rewrites existing data. It only prevents the modified date from moving forward when you save a published post. The only exception is the explicit "reset to publish date" action, which you run yourself on the posts you choose.

= Will newly published posts get a wrong date? =

No. The lock is skipped when a post is created, and when a draft is published for the first time. Those posts get the normal modified date.

= How do I update the modified date when an edit deserves it? =

Tick "Bump the modified date on this save" in the block editor sidebar before saving. The date moves for that save only, and the checkbox resets itself afterwards.

= A post's modified date moved by accident. Can I undo that? =

Yes. Select the posts in the posts list and run the "Reset modified date to publish date" bulk action, or use the row action, or the button in the block editor sidebar. This sets the modified date back to the publish date. It cannot restore an arbitrary earlier value, and it cannot be undone.

= Can I turn the lock off? =

Yes. Go to Settings → Bulk Last Modified Locker and uncheck "Lock the modified date". Modified dates then move as usual. Deactivating the plugin does the same thing, but turning the lock off keeps the "reset to publish date" actions available, so you can still repair dates that moved by accident.

= Can I exclude a post type from the lock? =

Yes. Go to Settings → Bulk Last Modified Locker and uncheck the post types you want to leave unlocked. Post types added later are locked automatically until you uncheck them. Unchecking only turns off the lock: the reset actions stay available for every public post type, so you can still fix a date that moved before you excluded the post type.

= Can I exclude a specific post from the lock? =

No. The lock deliberately applies to every published post of the covered post types, so that there is no per-post state to keep track of. Use the sidebar checkbox when a specific save deserves a new date.

= Does it work with the classic editor? =

The lock itself works everywhere. The "bump on this save" checkbox and the sidebar reset button are only available in the block editor; the reset actions in the posts list work regardless of the editor.

== Changelog ==

= 1.0.1 =
* Added an update checker. New versions now appear on the Plugins screen and can be installed from there.

= 1.0.0 =
* Initial release.
