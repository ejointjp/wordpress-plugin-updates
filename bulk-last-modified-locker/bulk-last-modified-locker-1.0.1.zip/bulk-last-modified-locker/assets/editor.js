/**
 * ブロックエディタのサイドバーに更新日ロックのパネルを出す
 *
 * ビルド工程を持たないため、JSX を使わず wp.element.createElement を直接呼ぶ。
 * 「今回は更新日を進める」の状態は post meta に持たず、保存リクエストの
 * ボディへ blml_bump を注入するだけ。DB には何も残らない。
 */
( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useRef = wp.element.useRef;
	var useSelect = wp.data.useSelect;
	var settings = window.blmlEditor || {};

	var PluginPostStatusInfo =
		( wp.editor && wp.editor.PluginPostStatusInfo ) ||
		( wp.editPost && wp.editPost.PluginPostStatusInfo );

	// 「今回は更新日を進める」フラグ。次の保存リクエストにだけ効く。
	var bumpNext = false;

	// 保存リクエストのボディに blml_bump を注入するミドルウェア。
	// 対象は現在の投稿への PUT / POST だけ。autosaves エンドポイントは
	// パスが一致しないため対象外になる。
	wp.apiFetch.use( function ( options, next ) {
		if ( bumpNext && isCurrentPostSave( options ) ) {
			options.data = Object.assign( {}, options.data || {}, { blml_bump: true } );
		}
		return next( options );
	} );

	function isCurrentPostSave( options ) {
		if ( ! options || ! options.path || ! options.method ) {
			return false;
		}
		if ( 'PUT' !== options.method && 'POST' !== options.method ) {
			return false;
		}
		return options.path.split( '?' )[ 0 ] === settings.restPath;
	}

	function BlmlPanel() {
		var bumpState = useState( false );
		var bumpChecked = bumpState[ 0 ];
		var setBumpChecked = bumpState[ 1 ];

		var overrideState = useState( '' );
		var overrideModified = overrideState[ 0 ];
		var setOverrideModified = overrideState[ 1 ];

		var post = useSelect( function ( select ) {
			var editor = select( 'core/editor' );
			return {
				// DB 側のステータス。下書きから publish に切り替えただけの未保存状態は
				// まだロックされていないため、保存済みステータスで判定する。
				status: editor.getCurrentPostAttribute( 'status' ),
				modified: editor.getCurrentPostAttribute( 'modified' ),
				isSaving: editor.isSavingPost() && ! editor.isAutosavingPost(),
			};
		}, [] );

		// 保存が終わったらチェックを外し、次の保存を再びロックへ戻す。
		var wasSaving = useRef( false );
		useEffect(
			function () {
				if ( wasSaving.current && ! post.isSaving ) {
					bumpNext = false;
					setBumpChecked( false );
					setOverrideModified( '' );
				}
				wasSaving.current = post.isSaving;
			},
			[ post.isSaving ]
		);

		// ロックが効くのは公開済みの投稿だけ。それ以外ではパネルを出さない。
		if ( 'publish' !== post.status || ! PluginPostStatusInfo ) {
			return null;
		}

		// ロックがオフのときは「ロック中」表示と「今回は更新日を進める」を出さない。
		// 外すロックが無いためで、「公開日に戻す」は引き続き使える。
		var locked = !! settings.locked;

		return el(
			PluginPostStatusInfo,
			{ className: 'blml-panel' },
			el(
				'div',
				null,
				el(
					'div',
					{ style: { marginBottom: '8px' } },
					__( 'Modified date', 'bulk-last-modified-locker' ) + ': ',
					wp.date.dateI18n( settings.dateFormat, overrideModified || post.modified ),
					locked ? ' · ' + __( 'Locked', 'bulk-last-modified-locker' ) : null
				),
				locked
					? el( wp.components.CheckboxControl, {
							label: __( 'Bump the modified date on this save', 'bulk-last-modified-locker' ),
							help: __( 'Applies to this save only.', 'bulk-last-modified-locker' ),
							checked: bumpChecked,
							onChange: function ( value ) {
								bumpNext = value;
								setBumpChecked( value );
							},
					  } )
					: null,
				el(
					wp.components.Button,
					{
						variant: 'secondary',
						isDestructive: true,
						onClick: function () {
							if ( ! window.confirm( __( 'Reset the modified date to the publish date? This cannot be undone.', 'bulk-last-modified-locker' ) ) ) {
								return;
							}
							wp.apiFetch( {
								path: '/blml/v1/reset/' + settings.postId,
								method: 'POST',
							} )
								.then( function ( response ) {
									// unchanged は「既に公開日と一致」なので成功扱い。
									// skipped / denied / error は成功トーストを出さない。
									if ( 'reset' !== response.status && 'unchanged' !== response.status ) {
										wp.data.dispatch( 'core/notices' ).createErrorNotice(
											__( 'Could not reset the modified date.', 'bulk-last-modified-locker' ),
											{ type: 'snackbar' }
										);
										return;
									}
									setOverrideModified( response.modified );
									wp.data.dispatch( 'core/notices' ).createSuccessNotice(
										__( 'The modified date was reset to the publish date.', 'bulk-last-modified-locker' ),
										{ type: 'snackbar' }
									);
								} )
								.catch( function () {
									wp.data.dispatch( 'core/notices' ).createErrorNotice(
										__( 'Could not reset the modified date.', 'bulk-last-modified-locker' ),
										{ type: 'snackbar' }
									);
								} );
						},
					},
					__( 'Reset to publish date', 'bulk-last-modified-locker' )
				)
			)
		);
	}

	wp.plugins.registerPlugin( 'bulk-last-modified-locker', {
		render: BlmlPanel,
	} );
} )( window.wp );
