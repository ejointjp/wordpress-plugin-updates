<?php
/**
 * Plugin Name:       Tiny SEO
 * Description:       A simple, lightweight plugin that delivers the SEO that matters most with a few easy settings: per-page meta tags, Open Graph and structured data.
 * Version:           0.2.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tiny-seo
 * Domain Path:       /languages
 * Update URI:        https://yuiami.jp/wp-plugins/tiny-seo
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TINY_SEO_VERSION', '0.2.0' );
define( 'TINY_SEO_FILE', __FILE__ );
define( 'TINY_SEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'TINY_SEO_URL', plugin_dir_url( __FILE__ ) );

// 翻訳は、同梱したlanguages/の.moを、WordPress（6.8以降）がDomain Pathから自動で読む。
// load_plugin_textdomain()は呼ばない。

require_once TINY_SEO_DIR . 'includes/utils.php';
require_once TINY_SEO_DIR . 'includes/settings.php';
require_once TINY_SEO_DIR . 'includes/compat.php';
require_once TINY_SEO_DIR . 'includes/helpers.php';
require_once TINY_SEO_DIR . 'includes/meta.php';
require_once TINY_SEO_DIR . 'includes/breadcrumbs.php';
require_once TINY_SEO_DIR . 'includes/json-ld.php';
require_once TINY_SEO_DIR . 'includes/sitemap.php';
require_once TINY_SEO_DIR . 'includes/author-archives.php';
require_once TINY_SEO_DIR . 'includes/update-checker.php';

if ( is_admin() ) {
	require_once TINY_SEO_DIR . 'includes/admin/meta-box.php';
	require_once TINY_SEO_DIR . 'includes/admin/settings-page.php';
	require_once TINY_SEO_DIR . 'includes/migrate/migrate.php';
}

/**
 * 有効化したことを記録する。直後のプラグイン一覧で、取り込めるデータがあれば案内する。
 */
function tiny_seo_activate() {
	set_transient( 'tiny_seo_activated', 1, HOUR_IN_SECONDS );
}
register_activation_hook( __FILE__, 'tiny_seo_activate' );
