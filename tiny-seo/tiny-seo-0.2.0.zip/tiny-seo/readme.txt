=== Tiny SEO ===
Contributors: ejointjp
Tags: seo, meta description, open graph, json-ld, sitemap
Requires at least: 6.4
Tested up to: 7.1
Stable tag: 0.2.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple, lightweight plugin that delivers the SEO that matters most with a few easy settings: per-page meta tags, Open Graph and structured data.

== Description ==

Tiny SEO is a simple, lightweight plugin. A few easy settings give each page the SEO that matters most: SEO titles, meta descriptions, Open Graph and X Card tags, structured data and a clean sitemap. There is no scoring, no dashboard, no upsell and no setup wizard. One meta box on the edit screen and one settings page are all there is.

It builds on what WordPress already does. The sitemap is the WordPress core sitemap (`wp-sitemap.xml`). Robots directives are added to the robots meta tag that WordPress itself prints, and the canonical URL is the one WordPress prints, so a page never ends up with two of either. By default the SEO description is saved as the post excerpt, so what you write stays on your site even if you stop using the plugin.

= What you can set for each post =

* SEO title, with an option to remove the site name from the title tag
* SEO description (meta description)
* Canonical URL
* noindex, nofollow (the post is also removed from the sitemap)

The meta box shows a search result preview for desktop and mobile, and character counters for the title and the description.

= What it outputs =

* **Title tag** – the SEO title when you have set one. Archives, search results and the 404 page keep the WordPress default.
* **Meta description** – on posts and pages that have a description, on category and tag archives that have a description, and on the front page (the site tagline when it has no description of its own). It is never generated from the post content.
* **Robots** – noindex for author archives and date archives (each can be turned off), post format archives and the 404 page. Tag archives can be set to noindex as well.
* **Author archives** – can be disabled on single-author sites. Author archives then redirect to the home page, and links to the author point to the home page, so the URL name of the author is not shown.
* **Open Graph and X (Twitter) Card tags** – title, description, URL, site name, image and article dates. The image is the featured image, or the default image you choose on the settings page.
* **JSON-LD structured data** – WebSite and Organization on the front page, Article on posts, and BreadcrumbList (can be turned off).
* **Sitemap tweaks** – removes noindexed posts and post format archives, the users sitemap when author archives are noindexed or disabled, and tags when tag archives are noindexed. Adds the last modified date to posts and terms.

= Works with what you already have =

* While Yoast SEO, Rank Math or All in One SEO is active, Tiny SEO outputs nothing and hides its meta box, so tags are never duplicated. It starts working when you deactivate the other plugin.
* You can import titles, descriptions, noindex flags, canonical URLs and some settings from Yoast SEO and Jetpack SEO with a button on the settings page. The original data is not deleted, and values you have already changed in Tiny SEO are not overwritten.
* After you leave Yoast SEO, requests for its old sitemap URLs (such as `/sitemap_index.xml`) are redirected to the WordPress core sitemap.
* When Jetpack is active, its Open Graph tags and Twitter Cards are turned off to avoid duplicates.

= What it does not do =

Content analysis and readability scores, redirect management, SEO fields for categories and tags, and per-archive images are out of scope.

= Small footprint =

Tiny SEO loads no JavaScript or CSS on the front end; its scripts are used only on the edit screen and the settings page. It creates no database tables and runs no scheduled tasks. Its data is one settings option and a few post meta fields.

= Privacy =

Tiny SEO does not track anything and sets no cookies. To check for updates, it requests a small file (`info.json`) from GitHub (`raw.githubusercontent.com`), where the plugin is distributed. The request does not include your site's URL or any site data. It makes no other external requests.

= For theme developers =

Themes can reuse the data Tiny SEO works with:

* `tiny_seo_get_breadcrumb_items()` – the breadcrumb trail used for BreadcrumbList, for rendering visible breadcrumbs
* `tiny_seo_get_description()`, `tiny_seo_get_summary()`, `tiny_seo_get_image()`
* `tiny_seo_is_active()` – whether Tiny SEO is currently outputting tags

Filters: `tiny_seo_default_image`, `tiny_seo_breadcrumb_items`, `tiny_seo_meta_box_post_types`, `tiny_seo_article_type`, `tiny_seo_json_ld_graph`, `tiny_seo_og_tags`.

== Installation ==

1. Install the plugin through the WordPress plugins screen, or upload the plugin files to the `/wp-content/plugins/tiny-seo` directory.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Open Settings -> Tiny SEO and choose where the SEO description is saved, the default image and the indexing options.
4. If you are moving from another SEO plugin, import its data from the same page, then deactivate that plugin.
5. Edit a post and fill in the "SEO Settings" meta box.

== Frequently Asked Questions ==

= Can I use it together with Yoast SEO, Rank Math or All in One SEO? =

You can keep both installed while you move over. While one of them is active, Tiny SEO outputs nothing on the front end and hides its meta box; only the settings page and the import work. Tiny SEO takes over as soon as you deactivate the other plugin.

= Where is the SEO description saved? =

By default it is saved as the post excerpt, and the description field and the excerpt panel stay in sync. If your theme shows excerpts on cards and you want a different text for search engines, choose "Separate SEO field" on the settings page. Changing this setting does not move existing data.

= What happens to my data when I deactivate or delete the plugin? =

Deactivating deletes nothing. Deleting the plugin also keeps everything unless you turn on "Delete settings and SEO data when the plugin is deleted" on the settings page. Post excerpts are never deleted.

= Does it create its own sitemap? =

No. It adjusts the WordPress core sitemap at `wp-sitemap.xml`. The settings page shows the sitemap URL to submit to search engines.

= Does it edit robots.txt? =

No. Tiny SEO only adds directives such as noindex to the robots meta tag of each page, and never touches `robots.txt`. WordPress adds the sitemap URL to its own virtual robots.txt. If your site has a physical `robots.txt` file, add the sitemap line there yourself.

= Does it output breadcrumbs on the page? =

It outputs BreadcrumbList structured data only. A theme can render visible breadcrumbs from `tiny_seo_get_breadcrumb_items()`. If another plugin already outputs breadcrumb structured data, turn the option off on the settings page.

== Changelog ==

= 0.2.0 =
* Added an option to disable author archives. Author archives redirect to the home page, and links to the author point to the home page, so the URL name of the author is not shown.
* The Yoast SEO importer now imports the "Disable author archives" setting.

= 0.1.5 =
* Added an update checker. New versions now appear on the Plugins screen and can be installed from there.
* The Japanese translation is bundled with the plugin again.

= 0.1.4 =
* Added the meta description to the front page and to category and tag archives, and an option to set tag archives to noindex.
