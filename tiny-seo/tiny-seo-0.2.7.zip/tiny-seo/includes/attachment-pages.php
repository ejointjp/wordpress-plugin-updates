<?php
/**
 * 添付ファイルのページの転送（設定画面の「添付ファイルのページをファイルにリダイレクト」）
 *
 * 設定はコアのoption wp_attachment_pages_enabledに持ち、転送はふだんコアのredirect_canonical()が行う。
 * ただし、テーマがwp_get_attachment_urlのフィルタで添付のURLからホストを外していると（3dpst.comの親テーマsticなど）、
 * コアはスキームのない転送先を組み立て、転送をやめてしまう（添付ファイルのページが200で表示される）。
 * そのため、添付のURLがルートからの相対URLのときだけ、Tiny SEOが絶対URLにして転送する。絶対URLのときはコアに任せる。
 * 転送する・しないの判定は、コアのredirect_canonical()に揃える。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 添付ファイルのページから転送する先（絶対URL）を返す。転送しないときは空文字。
 *
 * - 添付ファイルのページが有効（wp_attachment_pages_enabledが真）なら転送しない
 * - 添付のURLが絶対URLなら、コアのredirect_canonical()に任せる。//で始まるURLはコアも転送しない
 *   （別のホストへはwp_safe_redirect()で送れないので扱わない）
 * - 親の投稿が公開されていないときは転送しない（コアと同じく、公開前の投稿のファイルのURLを知らせない）。
 *   ただし、親が非公開（private）で、その投稿を読める利用者なら転送する。親の投稿を取れない（削除された）ときは、親の確認を飛ばす
 *
 * @param int $attachment_id 添付ID。
 * @return string
 */
function tiny_seo_attachment_redirect_url( $attachment_id ) {
	$attachment_id = (int) $attachment_id;
	if ( get_option( 'wp_attachment_pages_enabled' ) ) {
		return '';
	}
	$url = (string) wp_get_attachment_url( $attachment_id );
	if ( '' === $url || '/' !== $url[0] || 0 === strpos( $url, '//' ) ) {
		return '';
	}
	$parent_id = (int) wp_get_post_parent_id( $attachment_id );
	$parent    = $parent_id ? get_post( $parent_id ) : null; // get_post( 0 )は表示中の投稿を返すので呼ばない
	if ( $parent instanceof WP_Post ) {
		$status = get_post_status_object( get_post_status( $parent ) );
		if (
			! ( $status && $status->private && current_user_can( 'read_post', $parent->ID ) )
			&& ! is_post_publicly_viewable( $parent )
		) {
			return '';
		}
	}
	return tiny_seo_absolute_url( $url, home_url( '/' ) );
}

/**
 * 添付ファイルのページを、ファイルへ301で転送する。コアのredirect_canonical()（優先度10）より先に動かす。
 *
 * コアと同じく、GETとHEAD以外のリクエストと、プレビューでは転送しない。
 */
function tiny_seo_redirect_attachment_page() {
	if ( ! tiny_seo_is_active() || ! is_attachment() || is_preview() ) {
		return;
	}
	if ( isset( $_SERVER['REQUEST_METHOD'] ) && ! in_array( strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ), array( 'GET', 'HEAD' ), true ) ) {
		return;
	}
	$url = tiny_seo_attachment_redirect_url( (int) get_queried_object_id() );
	if ( '' === $url ) {
		return;
	}
	wp_safe_redirect( $url, 301 );
	exit;
}
add_action( 'template_redirect', 'tiny_seo_redirect_attachment_page', 1 );
