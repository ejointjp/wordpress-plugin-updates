<?php
/**
 * 投稿タイプの一覧（アーカイブ）のURLを載せるサイトマップ（wp-sitemap-archives-1.xml）
 *
 * WordPress標準のサイトマップは、投稿タイプの一覧のURL（has_archiveの/products/など）を載せない。
 * Yoast SEOは載せていたので、Yoastから替えたときに消えないよう、サイトマップの種類をひとつ足す。
 * 足すのはincludes/sitemap.phpのtiny_seo_sitemap_register_archives()。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 投稿タイプの一覧のサイトマップ。
 *
 * 載せるのは、標準のサイトマップに投稿が載る投稿タイプ（postsプロバイダの投稿タイプ。公開で、wp_sitemaps_post_typesを通したもの）
 * のうち、has_archiveが真で公開済みの投稿がある投稿タイプの一覧。postは除く（記事一覧は「投稿ページ」の固定ページとして、
 * 固定ページのサイトマップに載るため）。lastmodは、その投稿タイプの公開済み投稿のpost_modified_gmtの最大値。
 * 一覧の数は投稿タイプの数までなので、1ページに収める。
 */
class Tiny_SEO_Sitemaps_Archives extends WP_Sitemaps_Provider {

	/**
	 * プロバイダ名（URLのwp-sitemap-archives-1.xmlになる。コアの書き換えの規則に合わせ、英小文字だけ）。
	 */
	public function __construct() {
		$this->name        = 'archives';
		$this->object_type = 'archive';
	}

	/**
	 * 一覧のURLとlastmodを返す。
	 *
	 * @param int    $page_num       ページ番号。
	 * @param string $object_subtype 使わない（下位の種類を持たない）。
	 * @return array[]
	 */
	public function get_url_list( $page_num, $object_subtype = '' ) {
		if ( 1 !== (int) $page_num ) {
			return array();
		}
		$post_types = $this->get_post_types();
		$lastmods   = $this->get_lastmods( $post_types );
		$url_list   = array();
		foreach ( $post_types as $post_type ) {
			if ( ! isset( $lastmods[ $post_type ] ) ) {
				continue;
			}
			$loc = get_post_type_archive_link( $post_type );
			if ( ! $loc ) {
				continue;
			}
			$entry  = array( 'loc' => $loc );
			$latest = $lastmods[ $post_type ];
			if ( '0000-00-00 00:00:00' !== $latest ) {
				// GMTの値なのでUTCとして読む。mysql2date()はサイトのタイムゾーンの時刻として読むため使わない
				$entry['lastmod'] = ( new DateTimeImmutable( $latest, new DateTimeZone( 'UTC' ) ) )->format( 'c' );
			}
			$url_list[] = $entry;
		}
		return $url_list;
	}

	/**
	 * ページ数。一覧がなければ0（インデックスに載らない）。
	 *
	 * @param string $object_subtype 使わない（下位の種類を持たない）。
	 * @return int
	 */
	public function get_max_num_pages( $object_subtype = '' ) {
		return $this->get_url_list( 1 ) ? 1 : 0;
	}

	/**
	 * 一覧を載せる候補の投稿タイプ名。フィルタtiny_seo_sitemap_archive_post_typesで変えられる。
	 *
	 * @return string[]
	 */
	protected function get_post_types() {
		$posts      = wp_sitemaps_get_server()->registry->get_provider( 'posts' );
		$post_types = array();
		if ( $posts ) {
			foreach ( $posts->get_object_subtypes() as $name => $post_type ) {
				if ( 'post' !== $name && ! empty( $post_type->has_archive ) ) {
					$post_types[] = (string) $name;
				}
			}
		}
		/**
		 * サイトマップに一覧を載せる投稿タイプ名を変える。公開済みの投稿がない投稿タイプと、一覧のURLがない投稿タイプは、
		 * ここに入れても載らない。
		 *
		 * @param string[] $post_types 投稿タイプ名。
		 */
		$post_types = apply_filters( 'tiny_seo_sitemap_archive_post_types', $post_types );
		return array_values( array_unique( array_filter( (array) $post_types, 'is_string' ) ) );
	}

	/**
	 * 投稿タイプごとの最終更新日時（GMT）を、投稿タイプ名 → MySQLの日時の連想配列で返す。
	 * 値は、その投稿タイプの公開済み投稿のpost_modified_gmtの最大値。公開済み投稿のない投稿タイプは入らない。
	 * 失敗したらログに残し、空の配列を返す（一覧を載せない）。
	 *
	 * @param string[] $post_types 投稿タイプ名。
	 * @return array<string, string>
	 */
	protected function get_lastmods( array $post_types ) {
		global $wpdb;
		if ( ! $post_types ) {
			return array();
		}
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 投稿タイプごとのMAX()を1回で読む。WP_Queryでは集計できない。サイトマップの生成時だけ走る
			$wpdb->prepare(
				"SELECT post_type, MAX(post_modified_gmt) AS latest
				 FROM {$wpdb->posts}
				 WHERE post_type IN ( " . implode( ', ', array_fill( 0, count( $post_types ), '%s' ) ) . " )
				   AND post_status = 'publish'
				 GROUP BY post_type",
				$post_types
			)
		);
		if ( $wpdb->last_error ) {
			error_log( 'Tiny SEO sitemap: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 問い合わせの失敗を残すため
			return array();
		}
		$lastmods = array();
		foreach ( (array) $rows as $row ) {
			$lastmods[ (string) $row->post_type ] = (string) $row->latest;
		}
		return $lastmods;
	}
}
