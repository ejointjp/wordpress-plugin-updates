<?php
/**
 * 削除時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * 設定の「削除時にデータも消す」がONのときだけ、設定と_tiny_seo_*のメタを消す。
 * 抜粋（post_excerpt）はWordPress標準のデータなので、ONでも触らない。
 * optionやメタを増やしたら、同じコミットでここも更新すること。
 *
 * @package tiny-seo
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$tiny_seo_settings = get_option( 'tiny_seo_settings' );
if ( ! is_array( $tiny_seo_settings ) || empty( $tiny_seo_settings['delete_data_on_uninstall'] ) ) {
	return;
}

delete_option( 'tiny_seo_settings' );
delete_transient( 'tiny_seo_activated' );
delete_site_transient( 'tiny_seo_update_info' );
foreach ( array( '_tiny_seo_title', '_tiny_seo_hide_site_name', '_tiny_seo_description', '_tiny_seo_canonical', '_tiny_seo_noindex' ) as $tiny_seo_meta_key ) {
	delete_post_meta_by_key( $tiny_seo_meta_key );
}
