<?php
/**
 * 出力で共通に使う値の取得
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 表示中のページで「SEOの値を持つ投稿」のIDを返す。
 *
 * 単体ページはその投稿。投稿一覧（is_home）は、show_on_front=pageで「投稿ページ」に指定した固定ページのときだけその固定ページ。
 * それ以外は0。show_on_front=postsのトップページは、page_for_postsに値が残っていても0（コアもその値を使わない）。
 *
 * @return int
 */
function tiny_seo_current_post_id() {
	if ( is_singular() ) {
		return (int) get_queried_object_id();
	}
	if ( is_home() && ! is_front_page() ) {
		// 投稿ページのときはget_queried_object_id()がpage_for_postsの固定ページを返す。壊れた設定では0
		return (int) get_queried_object_id();
	}
	return 0;
}

/**
 * 出力用にテキストを整える。タグを除き、文字参照を文字に戻し、改行と空白の連続をひとつの空白にする。
 *
 * 文字参照を戻すのはJSON-LDでもそのまま読めるようにするため。HTMLに出すときはesc_attr()などでエスケープする。
 *
 * @param mixed $text テキスト。
 * @return string
 */
function tiny_seo_normalize_text( $text ) {
	$text = wp_strip_all_tags( (string) $text );
	$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	return trim( (string) preg_replace( '/[\r\n\t ]+/', ' ', $text ) );
}

/**
 * SEOディスクリプションを返す。未設定なら空文字。
 *
 * 保存先の設定がexcerptなら手動の抜粋、metaなら_tiny_seo_description（空なら手動の抜粋）。
 * 本文からの自動抜粋は使わない。パスワードで保護された投稿では空文字。
 *
 * @param int $post_id 投稿ID。
 * @return string
 */
function tiny_seo_get_description( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id || post_password_required( $post_id ) ) {
		return '';
	}
	if ( 'meta' === tiny_seo_get_setting( 'description_source' ) ) {
		$description = tiny_seo_normalize_text( get_post_meta( $post_id, '_tiny_seo_description', true ) );
		if ( '' !== $description ) {
			return $description;
		}
	}
	return tiny_seo_normalize_text( get_post_field( 'post_excerpt', $post_id ) );
}

/**
 * 投稿の要約を返す。SEOディスクリプション、なければ本文からの自動抜粋。OGPとJSON-LDで使う。
 *
 * 自動抜粋はthe_contentフィルタを通って重く、OGPとJSON-LDの両方から呼ばれるので、1リクエストの中では投稿ごとに1回だけ作る。
 * 覚えておくのは自動抜粋だけ（descriptionは設定で変わるので毎回読む）。投稿を更新したら捨てる（tiny_seo_forget_auto_excerpt()）。
 *
 * @param int $post_id 投稿ID。
 * @return string
 */
function tiny_seo_get_summary( $post_id ) {
	$post_id     = (int) $post_id;
	$description = tiny_seo_get_description( $post_id );
	if ( '' !== $description || ! $post_id || post_password_required( $post_id ) ) {
		return $description;
	}
	$summary = wp_cache_get( $post_id, 'tiny_seo_auto_excerpt' );
	if ( false === $summary ) {
		$summary = tiny_seo_normalize_text( get_the_excerpt( $post_id ) );
		wp_cache_set( $post_id, $summary, 'tiny_seo_auto_excerpt' );
	}
	return (string) $summary;
}

// 自動抜粋はリクエストの中だけで覚えておく（永続オブジェクトキャッシュに残すと、フィルタや設定の変更が反映されなくなる）
wp_cache_add_non_persistent_groups( 'tiny_seo_auto_excerpt' );

/**
 * 投稿を更新したら、覚えておいた自動抜粋を捨てる。
 *
 * @param int $post_id 投稿ID。
 */
function tiny_seo_forget_auto_excerpt( $post_id ) {
	wp_cache_delete( (int) $post_id, 'tiny_seo_auto_excerpt' );
}
add_action( 'clean_post_cache', 'tiny_seo_forget_auto_excerpt' );

/**
 * 添付画像の情報を返す。画像でなければnull。
 *
 * @param int $attachment_id 添付ID。
 * @return array{url:string,width:int,height:int,mime:string}|null
 */
function tiny_seo_attachment_image( $attachment_id ) {
	$src = wp_get_attachment_image_src( (int) $attachment_id, 'full' );
	if ( ! $src ) {
		return null;
	}
	return array(
		'url'    => (string) $src[0],
		'width'  => (int) $src[1],
		'height' => (int) $src[2],
		'mime'   => (string) get_post_mime_type( (int) $attachment_id ),
	);
}

/**
 * OGPとJSON-LDに使う画像を返す。
 *
 * アイキャッチ → 設定の既定画像 → フィルタtiny_seo_default_imageの戻り値 → null。
 * アイキャッチが削除済みの添付を指しているなど、画像として使えないときは次の候補へ進む。
 *
 * @param int $post_id 投稿ID。0ならアイキャッチを見ない。
 * @return array{url:string,width:int,height:int,mime:string}|null
 */
function tiny_seo_get_image( $post_id ) {
	$post_id    = (int) $post_id;
	$candidates = array();
	if ( $post_id && has_post_thumbnail( $post_id ) ) {
		$candidates[] = (int) get_post_thumbnail_id( $post_id );
	}
	$candidates[] = (int) tiny_seo_get_setting( 'default_image_id' );

	foreach ( $candidates as $attachment_id ) {
		if ( ! $attachment_id ) {
			continue;
		}
		$image = tiny_seo_attachment_image( $attachment_id );
		if ( $image ) {
			return $image;
		}
	}

	/**
	 * アイキャッチも既定画像もないときの画像。テーマが同梱の画像を渡すのに使う。
	 *
	 * @param array|null $image   {url, width, height, mime}の配列。urlだけでもよい。
	 * @param int        $post_id 投稿ID（0ならアーカイブなど）。
	 */
	$image = apply_filters( 'tiny_seo_default_image', null, $post_id );
	if ( ! is_array( $image ) || empty( $image['url'] ) ) {
		return null;
	}
	return array(
		'url'    => (string) $image['url'],
		'width'  => isset( $image['width'] ) ? (int) $image['width'] : 0,
		'height' => isset( $image['height'] ) ? (int) $image['height'] : 0,
		'mime'   => isset( $image['mime'] ) ? (string) $image['mime'] : '',
	);
}
