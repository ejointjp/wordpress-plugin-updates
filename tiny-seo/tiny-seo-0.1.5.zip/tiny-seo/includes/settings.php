<?php
/**
 * 設定（option tiny_seo_settings）
 *
 * 既定値・読み出し・保存前の検証をここに置く。画面（設定 → Tiny SEO）はincludes/admin/settings-page.php。
 * register_setting()はinitで呼ぶ。設定画面だけでなく、取り込み処理などからのupdate_option()でも同じ検証を通すため。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TINY_SEO_OPTION = 'tiny_seo_settings';

/**
 * 設定の既定値。
 *
 * @return array
 */
function tiny_seo_default_settings() {
	return array(
		'description_source'       => 'excerpt',
		'default_image_id'         => 0,
		'twitter_handle'           => '',
		'twitter_card_type'        => 'summary_large_image',
		'noindex_author'           => true,
		'noindex_date'             => true,
		'noindex_tag'              => false,
		'breadcrumb_json_ld'       => true,
		'delete_data_on_uninstall' => false,
		'migrated'                 => array(),
	);
}

/**
 * 設定をすべて返す。保存していないキーは既定値で埋める。
 *
 * @return array
 */
function tiny_seo_get_settings() {
	$saved = get_option( TINY_SEO_OPTION, array() );
	return array_merge( tiny_seo_default_settings(), is_array( $saved ) ? $saved : array() );
}

/**
 * 設定をひとつ返す。知らないキーはnull。
 *
 * @param string $key キー。
 * @return mixed
 */
function tiny_seo_get_setting( $key ) {
	$settings = tiny_seo_get_settings();
	return array_key_exists( $key, $settings ) ? $settings[ $key ] : null;
}

/**
 * 設定の一部を書き換える（取り込み処理から使う）。保存時にtiny_seo_sanitize_settings()を通る。
 *
 * キーdisable_attachment_pagesを渡すと、コアのoption wp_attachment_pages_enabledを書き換える。
 *
 * @param array $changes 書き換える値。
 * @return bool update_option()の戻り値。
 */
function tiny_seo_update_settings( array $changes ) {
	return update_option( TINY_SEO_OPTION, array_merge( tiny_seo_get_settings(), $changes ) );
}

/**
 * 設定を登録する。
 */
function tiny_seo_register_setting() {
	register_setting(
		'tiny_seo',
		TINY_SEO_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'tiny_seo_sanitize_settings',
			'default'           => tiny_seo_default_settings(),
			'show_in_rest'      => false,
		)
	);
}
add_action( 'init', 'tiny_seo_register_setting' );

/**
 * 保存する前に検証する。
 *
 * - 不正な値はエラーを登録し、その項目は前の値を残す
 * - 入力に_formがあれば設定画面からの保存として扱い、送られてこないチェックボックスをOFFにする。
 *   _formがなければ（取り込み処理などからの部分更新）、入力にないキーは前の値を残す
 * - disable_attachment_pagesはコアのoption wp_attachment_pages_enabledに書き、設定には持たない
 * - migratedは取り込み処理だけが書く。画面からの保存では前の値を残す
 *
 * @param mixed $input 入力。
 * @return array
 */
function tiny_seo_sanitize_settings( $input ) {
	$old       = tiny_seo_get_settings();
	$input     = is_array( $input ) ? $input : array();
	$from_form = ! empty( $input['_form'] );
	$output    = array_intersect_key( $old, tiny_seo_default_settings() );

	if ( isset( $input['description_source'] ) ) {
		if ( in_array( $input['description_source'], array( 'excerpt', 'meta' ), true ) ) {
			$output['description_source'] = $input['description_source'];
		} else {
			tiny_seo_add_settings_error( 'invalid_description_source', esc_html__( 'Choose where to save the description from the list. The previous value was kept.', 'tiny-seo' ) );
		}
	}

	if ( isset( $input['twitter_card_type'] ) ) {
		if ( in_array( $input['twitter_card_type'], array( 'summary_large_image', 'summary' ), true ) ) {
			$output['twitter_card_type'] = $input['twitter_card_type'];
		} else {
			tiny_seo_add_settings_error( 'invalid_twitter_card_type', esc_html__( 'Choose the X card type from the list. The previous value was kept.', 'tiny-seo' ) );
		}
	}

	if ( isset( $input['twitter_handle'] ) ) {
		$handle = tiny_seo_parse_twitter_handle( $input['twitter_handle'] );
		if ( null === $handle ) {
			tiny_seo_add_settings_error( 'invalid_twitter_handle', esc_html__( 'The X username can contain only letters, numbers and underscores, up to 15 characters. The previous value was kept.', 'tiny-seo' ) );
		} else {
			$output['twitter_handle'] = $handle;
		}
	}

	if ( isset( $input['default_image_id'] ) ) {
		$image_id = absint( $input['default_image_id'] );
		if ( 0 === $image_id || wp_attachment_is_image( $image_id ) ) {
			$output['default_image_id'] = $image_id;
		} else {
			tiny_seo_add_settings_error( 'invalid_default_image', esc_html__( 'The default image must be an image in the Media Library. The previous image was kept.', 'tiny-seo' ) );
		}
	}

	foreach ( array( 'noindex_author', 'noindex_date', 'noindex_tag', 'breadcrumb_json_ld', 'delete_data_on_uninstall' ) as $key ) {
		if ( array_key_exists( $key, $input ) ) {
			$output[ $key ] = (bool) $input[ $key ];
		} elseif ( $from_form ) {
			$output[ $key ] = false;
		}
	}

	if ( $from_form || array_key_exists( 'disable_attachment_pages', $input ) ) {
		update_option( 'wp_attachment_pages_enabled', empty( $input['disable_attachment_pages'] ) ? '1' : '0' );
	}

	if ( isset( $input['migrated'] ) && is_array( $input['migrated'] ) ) {
		$migrated = array();
		foreach ( $input['migrated'] as $source => $time ) {
			$migrated[ sanitize_key( $source ) ] = absint( $time );
		}
		$output['migrated'] = $migrated;
	}

	return $output;
}

/**
 * 設定のエラーを登録する。
 *
 * - settings_errors()は文言をエスケープせずに出力する。渡す前にエスケープしておくこと
 * - optionがまだDBにない初回の保存ではsanitize_callbackが2回走る。同じコードは1回だけ登録する
 * - WP-CLIなどadd_settings_error()が読み込まれていない場面では、PHPのエラーログに残す
 *
 * @param string $code    エラーコード。
 * @param string $message エスケープ済みの文言。
 */
function tiny_seo_add_settings_error( $code, $message ) {
	if ( ! function_exists( 'add_settings_error' ) ) {
		error_log( 'Tiny SEO settings: ' . wp_strip_all_tags( html_entity_decode( $message, ENT_QUOTES, 'UTF-8' ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 画面に出せない場面でもエラーを残すため
		return;
	}
	if ( in_array( $code, wp_list_pluck( get_settings_errors( TINY_SEO_OPTION ), 'code' ), true ) ) {
		return;
	}
	add_settings_error( TINY_SEO_OPTION, $code, $message );
}
