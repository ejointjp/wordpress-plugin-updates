<?php
/**
 * Jetpack SEO（SEOツールモジュール）からの取り込み
 *
 * - jetpack_seo_html_title → _tiny_seo_titleと_tiny_seo_hide_site_name='1'
 *   （Jetpackはこの値を<title>全体として使う。modules/seo-tools/class-jetpack-seo-titles.phpのget_custom_title()）
 *   サイト名を外すのは、タイトルを書いた、または同じタイトルがあったときだけ
 * - advanced_seo_description → description
 * - jetpack_seo_noindex（'1'のみ） → _tiny_seo_noindex
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Jetpack SEOのデータを取り込む。
 *
 * @return array|WP_Error
 */
function tiny_seo_import_jetpack() {
	$result = tiny_seo_import_new_result();

	$rows = tiny_seo_import_rows( array( 'jetpack_seo_html_title', 'advanced_seo_description', 'jetpack_seo_noindex' ) );
	foreach ( $rows as $row ) {
		$post_id = (int) $row->post_id;
		$value   = trim( (string) $row->meta_value );
		switch ( $row->meta_key ) {
			case 'jetpack_seo_html_title':
				// タイトルを書いた（または同じ）ときだけサイト名を外す
				if ( in_array( tiny_seo_import_title( $post_id, $value, $result ), array( 'written', 'same' ), true ) ) {
					tiny_seo_import_hide_site_name( $post_id );
				}
				break;
			case 'advanced_seo_description':
				tiny_seo_import_description( $post_id, $value, $result );
				break;
			case 'jetpack_seo_noindex':
				if ( '1' === $value ) {
					tiny_seo_import_noindex( $post_id, $result );
				}
				break;
		}
	}
	if ( is_wp_error( $rows->getReturn() ) ) {
		return $rows->getReturn();
	}
	return $result;
}
