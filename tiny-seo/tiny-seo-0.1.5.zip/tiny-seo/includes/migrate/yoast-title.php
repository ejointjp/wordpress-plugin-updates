<?php
/**
 * Yoast SEOのテンプレートの展開と、タイトルの変換（WordPressに依存しない純粋関数）
 *
 * 単体テスト: tests/php/test-yoast-title.php
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Yoastのテンプレート変数を展開する。
 *
 * %%title%%は投稿タイトル、%%sitename%%はサイト名、%%sitedesc%%はキャッチフレーズ、%%sep%%は「-」。
 * それ以外の%%...%%（%%page%%、%%cf_...%%など）は空にする。半角の空白の連続はひとつにまとめる（全角スペースは触らない）。
 *
 * @param string $template   テンプレート。
 * @param string $post_title 投稿タイトル（post_titleの生値）。
 * @param string $site_name  サイト名。
 * @param string $site_desc  キャッチフレーズ。
 * @return string
 */
function tiny_seo_expand_yoast_template( $template, $post_title, $site_name, $site_desc ) {
	$expanded = strtr(
		(string) $template,
		array(
			'%%title%%'    => $post_title,
			'%%sitename%%' => $site_name,
			'%%sitedesc%%' => $site_desc,
			'%%sep%%'      => '-',
		)
	);
	$expanded = (string) preg_replace( '/%%[^%\s]+%%/u', '', $expanded );
	return trim( (string) preg_replace( '/[ \t]+/', ' ', $expanded ) );
}

/**
 * Yoastのタイトル（_yoast_wpseo_title）を、Tiny SEOの保存形式に変換する。
 *
 * 末尾が「- サイト名」ならそれを取り除いてサイト名付き（hide_site_name=false）、そうでなければ全文をサイト名なし（true）。
 * 結果が投稿タイトルと同じでサイト名付きなら、既定のタイトルと同じなのでnull。空でもnull。
 *
 * @param string $template   _yoast_wpseo_titleの値。
 * @param string $post_title 投稿タイトル（post_titleの生値）。
 * @param string $site_name  サイト名。
 * @param string $site_desc  キャッチフレーズ。
 * @return array{title:string, hide_site_name:bool}|null
 */
function tiny_seo_convert_yoast_title( $template, $post_title, $site_name, $site_desc ) {
	$expanded       = tiny_seo_expand_yoast_template( $template, $post_title, $site_name, $site_desc );
	$hide_site_name = true;
	if ( '' !== $site_name ) {
		$suffix = '/[ \t]*-[ \t]*' . preg_quote( $site_name, '/' ) . '$/u';
		if ( preg_match( $suffix, $expanded ) ) {
			$expanded       = trim( (string) preg_replace( $suffix, '', $expanded ) );
			$hide_site_name = false;
		}
	}
	if ( '' === $expanded || ( ! $hide_site_name && $expanded === $post_title ) ) {
		return null;
	}
	return array(
		'title'          => $expanded,
		'hide_site_name' => $hide_site_name,
	);
}
