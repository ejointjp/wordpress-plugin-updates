<?php
/**
 * cadstation-2026テーマ（接頭辞c3m_）からの取り込み
 *
 * - c3m_seo_title → _tiny_seo_title
 * - c3m_seo_hide_site_name（'1'のみ） → _tiny_seo_hide_site_name
 * - c3m_seo_description → description（csoは抜粋と分けていたので、先にdescriptionの保存先をmetaにしておく）
 * - c3m_seo_noindex（'1'のみ） → _tiny_seo_noindex
 * descriptionの保存先がmetaでなければ、何も書かずにエラーを返す（カードに使っている抜粋をdescriptionで上書きしないため）。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * cadstation-2026テーマのデータを取り込む。
 *
 * @return array|WP_Error
 */
function tiny_seo_import_c3m() {
	if ( 'meta' !== tiny_seo_get_setting( 'description_source' ) ) {
		return new WP_Error(
			'tiny_seo_import_c3m_needs_meta',
			__( 'Set Description source to Separate SEO field before importing from cadstation-2026, so that card excerpts are not overwritten.', 'tiny-seo' )
		);
	}
	$result = tiny_seo_import_new_result();

	$rows = tiny_seo_import_rows( array( 'c3m_seo_title', 'c3m_seo_hide_site_name', 'c3m_seo_description', 'c3m_seo_noindex' ) );
	foreach ( $rows as $row ) {
		$post_id = (int) $row->post_id;
		$value   = trim( (string) $row->meta_value );
		switch ( $row->meta_key ) {
			case 'c3m_seo_title':
				tiny_seo_import_title( $post_id, $value, $result );
				break;
			case 'c3m_seo_hide_site_name':
				if ( '1' === $value ) {
					tiny_seo_import_hide_site_name( $post_id );
				}
				break;
			case 'c3m_seo_description':
				tiny_seo_import_description( $post_id, $value, $result );
				break;
			case 'c3m_seo_noindex':
				if ( '1' === $value ) {
					tiny_seo_import_noindex( $post_id, $result );
				}
				break;
		}
	}
	if ( is_wp_error( $rows->getReturn() ) ) {
		return $rows->getReturn();
	}
	return $result;
}
