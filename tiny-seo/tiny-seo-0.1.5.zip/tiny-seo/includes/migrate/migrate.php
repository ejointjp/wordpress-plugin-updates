<?php
/**
 * 他のSEOツールからのデータの取り込み
 *
 * 設定画面のボタンから実行する（自動では走らせない。descriptionの保存先を先に決めてから取り込むため）。
 * 何度実行してもよい。書き先が空なら書き、同じ内容ならそのまま（件数には数える）、違う内容ならTiny SEOで手直しした値として
 * 上書きせず、スキップとして投稿IDを報告する（タイトル、description、canonical）。noindexと「サイト名を外す」は立てるだけで消さない。
 * 元のデータは消さない。投稿ステータスは問わない（リビジョンは除く）。
 * 抜粋はwp_update_post()を通さずに書く（更新日時とサイトマップのlastmodを変えないため）。
 * このファイルは管理画面でだけ読み込む。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/yoast.php';
require_once __DIR__ . '/c3m.php';
require_once __DIR__ . '/jetpack.php';

/**
 * 取り込めるソース。
 *
 * @return array<string, array{label:string, meta_keys:string[], options:string[], callback:callable}>
 */
function tiny_seo_import_sources() {
	return array(
		'yoast'   => array(
			'label'     => 'Yoast SEO',
			'meta_keys' => array( '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_meta-robots-noindex', '_yoast_wpseo_canonical' ),
			'options'   => array( 'wpseo_titles', 'wpseo_social' ),
			'callback'  => 'tiny_seo_import_yoast',
		),
		'c3m'     => array(
			'label'     => 'cadstation-2026',
			'meta_keys' => array( 'c3m_seo_title', 'c3m_seo_hide_site_name', 'c3m_seo_description', 'c3m_seo_noindex' ),
			'options'   => array(),
			'callback'  => 'tiny_seo_import_c3m',
		),
		'jetpack' => array(
			'label'     => 'Jetpack SEO',
			'meta_keys' => array( 'jetpack_seo_html_title', 'advanced_seo_description', 'jetpack_seo_noindex' ),
			'options'   => array(),
			'callback'  => 'tiny_seo_import_jetpack',
		),
	);
}

/**
 * 指定したメタキーの値を持つ行の数（リビジョンを除く）。失敗したら0を返してログに残す。
 *
 * @param string[] $meta_keys メタキー。
 * @return int
 */
function tiny_seo_import_count( array $meta_keys ) {
	global $wpdb;
	$placeholders = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 取り込めるデータがあるかを数えるだけ。INの数だけ%sを並べている
	$count = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT(*)
			 FROM {$wpdb->postmeta} AS pm
			 INNER JOIN {$wpdb->posts} AS p ON p.ID = pm.post_id
			 WHERE pm.meta_key IN ( {$placeholders} )
			   AND pm.meta_value <> ''
			   AND p.post_type <> 'revision'",
			$meta_keys
		)
	);
	// phpcs:enable
	if ( $wpdb->last_error ) {
		error_log( 'Tiny SEO import: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 問い合わせの失敗を残すため
		return 0;
	}
	return (int) $count;
}

/**
 * 取り込めるデータが見つかったソースのキーを返す。
 *
 * @return string[]
 */
function tiny_seo_detect_import_sources() {
	$found = array();
	foreach ( tiny_seo_import_sources() as $key => $source ) {
		$has_option = false;
		foreach ( $source['options'] as $option ) {
			if ( ! empty( get_option( $option ) ) ) {
				$has_option = true;
				break;
			}
		}
		if ( $has_option || tiny_seo_import_count( $source['meta_keys'] ) > 0 ) {
			$found[] = $key;
		}
	}
	return $found;
}

/**
 * 指定したメタキーの行を、束に分けて読みながら1行ずつ返す（リビジョンを除く。投稿ID、meta_idの順）。
 *
 * 全件を一度に読むと、行の配列と、取り込み中に読んだ投稿とメタのキャッシュが投稿の数だけ増え続け、
 * 大きなサイトではメモリが足りなくなる（本文30KBの投稿2,000件で約70MB）。
 * そのため、次の束を読む前に、前の束の投稿のキャッシュ（postsとpost_meta）を捨てる。
 * 問い合わせに失敗したら、ログに残して止まる。それまでの束は取り込み済みになる（取り込み直してよい）。
 *
 * 使い方: foreachで回し、終わったらgetReturn()がWP_Errorでないかを確かめる。
 *
 * @param string[] $meta_keys  メタキー。
 * @param int      $batch_size 1回に読む行の数。
 * @return Generator post_id・meta_key・meta_valueの行を返す。getReturn()は、読み終えたらtrue、失敗したらWP_Error。
 */
function tiny_seo_import_rows( array $meta_keys, $batch_size = 500 ) {
	global $wpdb;
	$placeholders = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
	$batch_size   = max( 1, (int) $batch_size );
	$last_post_id = 0;
	$last_meta_id = 0;
	do {
		// 前の束の最後の行（投稿ID、meta_id）より後ろを読む。OFFSETと違い、読み進めても問い合わせが重くならない
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- 一度きりの取り込み。投稿タイプとステータスを問わずpostmetaを直接読む。INの数だけ%sを並べ、値はarray_merge()でまとめて渡している
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_id, pm.post_id, pm.meta_key, pm.meta_value
				 FROM {$wpdb->postmeta} AS pm
				 INNER JOIN {$wpdb->posts} AS p ON p.ID = pm.post_id
				 WHERE pm.meta_key IN ( {$placeholders} )
				   AND pm.meta_value <> ''
				   AND p.post_type <> 'revision'
				   AND ( pm.post_id > %d OR ( pm.post_id = %d AND pm.meta_id > %d ) )
				 ORDER BY pm.post_id, pm.meta_id
				 LIMIT %d",
				array_merge( $meta_keys, array( $last_post_id, $last_post_id, $last_meta_id, $batch_size ) )
			)
		);
		// phpcs:enable
		if ( $wpdb->last_error ) {
			error_log( 'Tiny SEO import: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 問い合わせの失敗を残すため
			return new WP_Error( 'tiny_seo_import_query', $wpdb->last_error );
		}
		$rows    = (array) $rows;
		$fetched = count( $rows );
		foreach ( $rows as $row ) {
			yield $row;
		}
		if ( $fetched ) {
			$last         = end( $rows );
			$last_post_id = (int) $last->post_id;
			$last_meta_id = (int) $last->meta_id;
			$post_ids     = array_values( array_unique( array_map( 'intval', wp_list_pluck( $rows, 'post_id' ) ) ) );
			wp_cache_delete_multiple( $post_ids, 'posts' );
			wp_cache_delete_multiple( $post_ids, 'post_meta' );
		}
	} while ( $fetched === $batch_size );
	return true;
}

/**
 * 取り込みの結果の入れ物。
 *
 * @return array{title:int, description:int, noindex:int, canonical:int, settings:int, skipped:int[]}
 */
function tiny_seo_import_new_result() {
	return array(
		'title'       => 0,
		'description' => 0,
		'noindex'     => 0,
		'canonical'   => 0,
		'settings'    => 0,
		'skipped'     => array(),
	);
}

/**
 * 取り込んだ値を投稿メタに書く。
 *
 * 書き先が空なら書いて数える。同じ内容（$normalizeを掛けて比べる）なら書かずに数える。
 * 違う内容なら、Tiny SEOで手直しした値として書かず、投稿IDをスキップとして残す。
 *
 * @param int      $post_id   投稿ID。
 * @param string   $meta_key  書き先のメタキー。
 * @param string   $value     書く値（サニタイズ済みで空でないこと）。
 * @param callable $normalize 比べる前に両方の値に掛ける関数。
 * @param string   $count_key 件数を足す結果のキー。
 * @param array    $result    結果（件数とスキップを足す）。
 * @return string 'written'（書いた）、'same'（同じ値があった）、'skipped'（違う値があった）。
 */
function tiny_seo_import_meta( $post_id, $meta_key, $value, callable $normalize, $count_key, array &$result ) {
	$current = (string) get_post_meta( $post_id, $meta_key, true );
	if ( '' === trim( $current ) ) {
		// update_post_meta()は値をunslashするので、wp_slash()して渡す（バックスラッシュを残すため）
		update_post_meta( $post_id, $meta_key, wp_slash( $value ) );
		++$result[ $count_key ];
		return 'written';
	}
	if ( call_user_func( $normalize, $current ) === call_user_func( $normalize, $value ) ) {
		++$result[ $count_key ];
		return 'same';
	}
	$result['skipped'][] = (int) $post_id;
	return 'skipped';
}

/**
 * SEOタイトルを書く。書き先に違うタイトルがあれば書かない（tiny_seo_import_meta()）。
 *
 * YoastとJetpackは、戻り値が'written'か'same'のときだけ「サイト名を外す」を立てる
 * （タイトルを書かなかった投稿のサイト名の扱いを変えないため）。
 *
 * @param int    $post_id 投稿ID。
 * @param string $title   タイトル。
 * @param array  $result  結果（件数とスキップを足す）。
 * @return string 'written'、'same'、'skipped'、'empty'（サニタイズすると空なので何もしない）。
 */
function tiny_seo_import_title( $post_id, $title, array &$result ) {
	$title = sanitize_text_field( $title );
	if ( '' === $title ) {
		return 'empty';
	}
	return tiny_seo_import_meta( $post_id, '_tiny_seo_title', $title, 'trim', 'title', $result );
}

/**
 * 「タイトルタグからサイト名を外す」を立てる。値がなければ'1'を書く。消すことはしない。
 *
 * Tiny SEOでチェックを外した状態（メタがない）は、取り込んでいない状態と見分けられない。
 * そのため、取り込み直すと、元のデータでサイト名を外していた投稿（YoastとJetpackではタイトルが同じ投稿）には、またチェックが付く。
 *
 * @param int $post_id 投稿ID。
 */
function tiny_seo_import_hide_site_name( $post_id ) {
	if ( '1' !== (string) get_post_meta( $post_id, '_tiny_seo_hide_site_name', true ) ) {
		update_post_meta( $post_id, '_tiny_seo_hide_site_name', '1' );
	}
}

/**
 * SEOディスクリプションを書く。
 *
 * 抜粋モード: 抜粋が空なら書く。同じ内容ならそのまま（件数には数える）。違う内容ならスキップして投稿IDを残す。
 * メタモード: _tiny_seo_descriptionに、抜粋モードと同じ決まりで書く（tiny_seo_import_meta()）。
 *
 * @param int    $post_id     投稿ID。
 * @param string $description 説明文。
 * @param array  $result      結果（件数とスキップを足す）。
 */
function tiny_seo_import_description( $post_id, $description, array &$result ) {
	global $wpdb;
	$description = sanitize_textarea_field( $description );
	if ( '' === $description ) {
		return;
	}
	if ( 'meta' === tiny_seo_get_setting( 'description_source' ) ) {
		tiny_seo_import_meta( $post_id, '_tiny_seo_description', $description, 'tiny_seo_normalize_text', 'description', $result );
		return;
	}

	$current = (string) get_post_field( 'post_excerpt', $post_id );
	if ( '' === trim( $current ) ) {
		$updated = $wpdb->update( $wpdb->posts, array( 'post_excerpt' => $description ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- wp_update_post()を通すと更新日時が変わるため
		if ( false === $updated ) {
			error_log( 'Tiny SEO import: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 書き込みの失敗を残すため
			$result['skipped'][] = (int) $post_id;
			return;
		}
		clean_post_cache( $post_id );
		++$result['description'];
		return;
	}
	if ( tiny_seo_normalize_text( $current ) === tiny_seo_normalize_text( $description ) ) {
		++$result['description'];
		return;
	}
	$result['skipped'][] = (int) $post_id;
}

/**
 * noindex, nofollowを立てる。値がなければ'1'を書く。すでに'1'ならそのまま（件数には数える）。
 *
 * Tiny SEOでnoindexを外した状態（メタがない）は、取り込んでいない状態と見分けられない。
 * そのため、取り込み直すと、元のデータでnoindexの投稿にはまた立つ。
 *
 * @param int   $post_id 投稿ID。
 * @param array $result  結果（件数を足す）。
 */
function tiny_seo_import_noindex( $post_id, array &$result ) {
	if ( '1' !== (string) get_post_meta( $post_id, '_tiny_seo_noindex', true ) ) {
		update_post_meta( $post_id, '_tiny_seo_noindex', '1' );
	}
	++$result['noindex'];
}

/**
 * canonicalを書く。http / https以外は書かない。書き先に違うURLがあれば書かない（tiny_seo_import_meta()）。
 *
 * @param int    $post_id 投稿ID。
 * @param string $url     URL。
 * @param array  $result  結果（件数とスキップを足す）。
 */
function tiny_seo_import_canonical( $post_id, $url, array &$result ) {
	$url = esc_url_raw( $url, array( 'http', 'https' ) );
	if ( '' === $url ) {
		return;
	}
	tiny_seo_import_meta( $post_id, '_tiny_seo_canonical', $url, 'trim', 'canonical', $result );
}

/**
 * 取り込んだ設定を書き、設定に入った項目だけを数える。
 *
 * 書き込みはtiny_seo_update_settings()を通るので、不正な値はtiny_seo_sanitize_settings()が弾き、
 * エラーを登録して前の値を残す。弾かれた項目は数えない。書いたあとの値と比べて決める
 * （Xのアカウント名は先頭の@を外した形、添付ページはコアのoption wp_attachment_pages_enabledで比べる）。
 *
 * @param array $changes 設定のキー → 取り込む値。
 * @param array $result  結果（settingsに件数を足す）。
 */
function tiny_seo_import_settings( array $changes, array &$result ) {
	if ( ! $changes ) {
		return;
	}
	tiny_seo_update_settings( $changes );
	$settings = tiny_seo_get_settings();
	foreach ( $changes as $key => $value ) {
		if ( 'disable_attachment_pages' === $key ) {
			$applied = ( '0' === (string) get_option( 'wp_attachment_pages_enabled' ) ) === (bool) $value;
		} elseif ( 'twitter_handle' === $key ) {
			$applied = tiny_seo_parse_twitter_handle( $value ) === $settings['twitter_handle'];
		} else {
			$applied = array_key_exists( $key, $settings ) && $settings[ $key ] === $value;
		}
		if ( $applied ) {
			++$result['settings'];
		}
	}
}

/**
 * 取り込みを実行し、取り込み済みを記録する。
 *
 * @param string $source ソースのキー。
 * @return array|WP_Error 結果（tiny_seo_import_new_result()の形）。
 */
function tiny_seo_run_import( $source ) {
	$sources = tiny_seo_import_sources();
	if ( ! isset( $sources[ $source ] ) ) {
		return new WP_Error( 'tiny_seo_import_unknown', __( 'Unknown import source.', 'tiny-seo' ) );
	}
	$result = call_user_func( $sources[ $source ]['callback'] );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	$migrated            = (array) tiny_seo_get_setting( 'migrated' );
	$migrated[ $source ] = time();
	tiny_seo_update_settings( array( 'migrated' => $migrated ) );
	return $result;
}

/**
 * 取り込みの結果の文面。
 *
 * @param string $label  ソースの表示名。
 * @param array  $result 結果。
 * @return string エスケープ前の文面。
 */
function tiny_seo_import_summary( $label, array $result ) {
	$message = sprintf(
		/* translators: 1: Name of the plugin or theme, 2: Number of titles, 3: Number of descriptions, 4: Number of noindex flags, 5: Number of canonical URLs, 6: Number of settings. */
		__( 'Imported from %1$s. Titles: %2$s, descriptions: %3$s, noindex: %4$s, canonical URLs: %5$s, settings: %6$s.', 'tiny-seo' ),
		$label,
		number_format_i18n( $result['title'] ),
		number_format_i18n( $result['description'] ),
		number_format_i18n( $result['noindex'] ),
		number_format_i18n( $result['canonical'] ),
		number_format_i18n( $result['settings'] )
	);
	if ( ! empty( $result['skipped'] ) ) {
		$message .= ' ' . sprintf(
			/* translators: %s: Comma-separated post IDs. */
			__( 'These posts were not changed because Tiny SEO already has different values for them: %s. Compare them in the editor and update them by hand.', 'tiny-seo' ),
			implode( ', ', array_map( 'intval', array_unique( $result['skipped'] ) ) )
		);
	}
	return $message;
}

/**
 * 取り込みボタンを受けて実行し、設定画面へ戻して結果を知らせる（/wp-admin-notices）。
 */
function tiny_seo_handle_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'tiny-seo' ), 403 );
	}
	check_admin_referer( 'tiny_seo_import' );

	$source  = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : '';
	$sources = tiny_seo_import_sources();
	$result  = tiny_seo_run_import( $source );

	if ( is_wp_error( $result ) ) {
		add_settings_error(
			TINY_SEO_OPTION,
			'import_failed',
			esc_html(
				sprintf(
					/* translators: %s: Error message. */
					__( 'Import failed: %s Reload the page and try again. If it keeps failing, check the PHP error log.', 'tiny-seo' ),
					$result->get_error_message()
				)
			)
		);
	} else {
		add_settings_error(
			TINY_SEO_OPTION,
			'imported',
			esc_html( tiny_seo_import_summary( $sources[ $source ]['label'], $result ) ),
			empty( $result['skipped'] ) ? 'success' : 'warning'
		);
	}

	set_transient( 'settings_errors', get_settings_errors(), 30 );
	wp_safe_redirect( add_query_arg( 'settings-updated', 'true', admin_url( 'options-general.php?page=tiny-seo' ) ) );
	exit;
}
add_action( 'admin_post_tiny_seo_import', 'tiny_seo_handle_import' );

/**
 * 設定画面の「Import」の節を出す。見つかったソースごとにボタンを出す（設定のフォームの外に置く）。
 */
function tiny_seo_render_import_section() {
	$sources  = tiny_seo_import_sources();
	$detected = tiny_seo_detect_import_sources();
	$migrated = (array) tiny_seo_get_setting( 'migrated' );
	?>
	<h2><?php esc_html_e( 'Import', 'tiny-seo' ); ?></h2>
	<?php if ( ! $detected ) : ?>
		<p><?php esc_html_e( 'No SEO data from other tools was found.', 'tiny-seo' ); ?></p>
		<?php
		return;
	endif;
	?>
	<p><?php esc_html_e( 'Imports titles, descriptions, noindex flags, canonical URLs and settings from other SEO tools. Choose the description source above before importing. The original data is not deleted. You can run an import again: values you have already changed in Tiny SEO are not overwritten, and those posts are listed after the import.', 'tiny-seo' ); ?></p>
	<table class="form-table" role="presentation">
		<tbody>
			<?php foreach ( $detected as $key ) : ?>
				<tr>
					<th scope="row"><?php echo esc_html( $sources[ $key ]['label'] ); ?></th>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="tiny_seo_import">
							<input type="hidden" name="source" value="<?php echo esc_attr( $key ); ?>">
							<?php
							wp_nonce_field( 'tiny_seo_import' );
							/* translators: %s: Name of the plugin or theme. */
							submit_button( sprintf( __( 'Import from %s', 'tiny-seo' ), $sources[ $key ]['label'] ), 'secondary', 'submit', false );
							?>
						</form>
						<p class="description">
							<?php
							if ( ! empty( $migrated[ $key ] ) ) {
								/* translators: %s: Date and time. */
								printf( esc_html__( 'Last imported on %s.', 'tiny-seo' ), esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $migrated[ $key ] ) ) );
							} else {
								esc_html_e( 'Not imported yet.', 'tiny-seo' );
							}
							?>
						</p>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * 有効化した直後、プラグイン一覧で取り込めるデータがあれば案内する。
 */
function tiny_seo_render_activation_notice() {
	// 画面と権限を先に見る。transientの読み取りはoptionのクエリになるので、プラグイン一覧以外の画面では走らせない
	$screen = get_current_screen();
	if ( ! $screen || 'plugins' !== $screen->id || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! get_transient( 'tiny_seo_activated' ) ) {
		return;
	}
	delete_transient( 'tiny_seo_activated' );

	$pending = array_diff( tiny_seo_detect_import_sources(), array_keys( (array) tiny_seo_get_setting( 'migrated' ) ) );
	if ( ! $pending ) {
		return;
	}
	$sources = tiny_seo_import_sources();
	$labels  = array();
	foreach ( $pending as $key ) {
		$labels[] = $sources[ $key ]['label'];
	}
	$link = sprintf(
		'<a href="%1$s">%2$s</a>',
		esc_url( admin_url( 'options-general.php?page=tiny-seo' ) ),
		esc_html__( 'Settings → Tiny SEO', 'tiny-seo' )
	);
	wp_admin_notice(
		sprintf(
			/* translators: 1: Names of plugins or themes, 2: Link to the settings page. */
			esc_html__( 'Tiny SEO found SEO data from %1$s. Choose the description source, then import the data in %2$s.', 'tiny-seo' ),
			esc_html( implode( ', ', $labels ) ),
			$link
		),
		array(
			'type'        => 'info',
			'dismissible' => true,
		)
	);
}
add_action( 'admin_notices', 'tiny_seo_render_activation_notice' );
