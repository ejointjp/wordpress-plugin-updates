<?php
/**
 * SEOメタタグ（表側）
 *
 * <title>・meta description・canonical・robotsを扱う。OGP / Twitter Cardは同じファイルの後半。
 * 他のSEOプラグインが有効なあいだは何もしない（tiny_seo_is_active()）。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * -----------------------------------------------------------------------------
 * <title>
 * -----------------------------------------------------------------------------
 */

/**
 * <title>にwptexturizeを掛けないようにする。
 *
 * WordPress標準の<title>はdocument_titleフィルタでwptexturizeを通り、区切りの「 - 」がen dash（–）に、
 * "が”に変わる。Yoast SEOと同じ見た目（区切り「-」）にそろえるため外す。
 * Yoast SEOが有効なあいだはYoastがpre_get_document_titleで<title>を返すので、この変更は表に出ない。
 */
function tiny_seo_disable_title_texturize() {
	if ( tiny_seo_is_active() ) {
		remove_filter( 'document_title', 'wptexturize' );
	}
}
add_action( 'init', 'tiny_seo_disable_title_texturize' );

/**
 * <title>をメタボックスの値で組み立て直す。
 *
 * - _tiny_seo_titleがあればtitleに使う
 * - なければ（トップページを除き）wptexturizeを通さない投稿タイトルを使う。
 *   WordPress標準はsingle_post_titleフィルタでもwptexturizeを掛けるため
 * - _tiny_seo_hide_site_nameが'1'ならサイト名（site）とキャッチフレーズ（tagline）を外す
 *
 * @param array $parts WordPressが組み立てたtitleの部品。
 * @return array
 */
function tiny_seo_document_title_parts( $parts ) {
	if ( ! tiny_seo_is_active() ) {
		return $parts;
	}
	$post_id = tiny_seo_current_post_id();
	if ( ! $post_id ) {
		return $parts;
	}
	$seo_title = (string) get_post_meta( $post_id, '_tiny_seo_title', true );
	if ( '' !== $seo_title ) {
		$parts['title'] = $seo_title;
	} elseif ( ! is_front_page() ) {
		$parts['title'] = wp_strip_all_tags( (string) get_post_field( 'post_title', $post_id ) );
	}
	if ( '1' === (string) get_post_meta( $post_id, '_tiny_seo_hide_site_name', true ) ) {
		unset( $parts['site'], $parts['tagline'] );
	}
	return $parts;
}
add_filter( 'document_title_parts', 'tiny_seo_document_title_parts' );

/*
 * -----------------------------------------------------------------------------
 * robots
 * -----------------------------------------------------------------------------
 */

/**
 * robotsを足す。<meta>を直接出さずwp_robotsフィルタで制御する（WordPress標準の出力と二重にしない）。
 *
 * - 値を持つ投稿で_tiny_seo_noindexが'1': noindex, nofollow
 * - 著者アーカイブ（設定がON）、日付アーカイブ（設定がON）、タグアーカイブ（設定がON。既定はOFF）、
 *   投稿フォーマットのアーカイブ、404: noindex
 *
 * @param array $robots wp_robots()の連想配列。
 * @return array
 */
function tiny_seo_wp_robots( $robots ) {
	if ( ! tiny_seo_is_active() ) {
		return $robots;
	}
	$post_id = tiny_seo_current_post_id();
	if ( $post_id ) {
		if ( '1' === (string) get_post_meta( $post_id, '_tiny_seo_noindex', true ) ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}
	if (
		( is_author() && tiny_seo_get_setting( 'noindex_author' ) )
		|| ( is_date() && tiny_seo_get_setting( 'noindex_date' ) )
		|| ( is_tag() && tiny_seo_get_setting( 'noindex_tag' ) )
		|| is_tax( 'post_format' )
		|| is_404()
	) {
		$robots['noindex'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'tiny_seo_wp_robots' );

/*
 * -----------------------------------------------------------------------------
 * description
 * -----------------------------------------------------------------------------
 */

/**
 * 表示中のページの<meta name="description">の値を返す。出さないページでは空文字。
 *
 * - 値を持つ投稿: SEOディスクリプション（本文からの自動抜粋は使わない）
 * - タームのアーカイブ: タームの説明文
 * - トップページ: 上が空なら（値を持つ投稿がない投稿一覧のトップも含めて）キャッチフレーズ
 * - それ以外（検索結果、著者・日付アーカイブなど）: 出さない
 *
 * @return string
 */
function tiny_seo_meta_description() {
	$post_id     = tiny_seo_current_post_id();
	$description = '';
	if ( $post_id ) {
		$description = tiny_seo_get_description( $post_id );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$description = tiny_seo_normalize_text( term_description() );
	}
	if ( '' === $description && is_front_page() ) {
		$description = tiny_seo_normalize_text( get_bloginfo( 'description' ) );
	}
	return $description;
}

/**
 * <meta name="description">を出す。値が空のページでは出さない。
 */
function tiny_seo_print_meta_description() {
	if ( ! tiny_seo_is_active() ) {
		return;
	}
	$description = tiny_seo_meta_description();
	if ( '' === $description ) {
		return;
	}
	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
}
add_action( 'wp_head', 'tiny_seo_print_meta_description', 1 );

/*
 * -----------------------------------------------------------------------------
 * canonical
 * -----------------------------------------------------------------------------
 */

/**
 * canonicalを手入力の値に差し替える。コアのrel_canonical()はwp_get_canonical_url()を通してこの値を出す。
 *
 * @param string  $url  WordPressが決めたcanonical。
 * @param WP_Post $post 投稿。
 * @return string
 */
function tiny_seo_filter_canonical_url( $url, $post ) {
	if ( ! tiny_seo_is_active() || ! $post instanceof WP_Post ) {
		return $url;
	}
	$custom = (string) get_post_meta( $post->ID, '_tiny_seo_canonical', true );
	return '' !== $custom ? $custom : $url;
}
add_filter( 'get_canonical_url', 'tiny_seo_filter_canonical_url', 10, 2 );

/*
 * -----------------------------------------------------------------------------
 * OGP / Twitter Card
 * -----------------------------------------------------------------------------
 */

/**
 * 表示中のページのOGPとTwitter Cardを、プロパティ名 → 値の連想配列で返す。空の値は出力で省く。
 *
 * - og:typeはトップページ以外の単体ページ（固定ページを含む）がarticle、それ以外はwebsite
 * - og:titleは<title>と同じ文字列
 * - og:descriptionは値を持つ投稿が要約、タームのアーカイブはタームの説明文。どれも空ならキャッチフレーズ
 * - og:urlは、canonicalを手入力した単体ページではその値、それ以外はページ自身のURL
 * - article:modified_timeは単体ページ、article:published_timeは投稿（post）だけ
 *
 * @return array<string, string|int>
 */
function tiny_seo_og_tags() {
	$post_id = tiny_seo_current_post_id();

	$description = '';
	if ( $post_id ) {
		$description = tiny_seo_get_summary( $post_id );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$description = tiny_seo_normalize_text( term_description() );
	}
	if ( '' === $description ) {
		$description = tiny_seo_normalize_text( get_bloginfo( 'description' ) );
	}

	// canonicalを手入力した単体ページでは、og:urlもその値にする（共有の集計先を<link rel="canonical">と同じURLにそろえる）。
	// 投稿一覧ページではコアがcanonicalを出さないので、手入力の値は使わない
	$canonical = ( $post_id && is_singular() ) ? (string) get_post_meta( $post_id, '_tiny_seo_canonical', true ) : '';

	$url = '';
	if ( '' !== $canonical ) {
		$url = $canonical;
	} elseif ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( $post_id ) {
		$url = (string) get_permalink( $post_id );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$link = get_term_link( get_queried_object() );
		$url  = is_wp_error( $link ) ? '' : (string) $link;
	} elseif ( is_post_type_archive() ) {
		$object = get_queried_object();
		$url    = $object instanceof WP_Post_Type ? (string) get_post_type_archive_link( $object->name ) : '';
	}

	$tags = array(
		'og:locale'      => tiny_seo_og_locale( get_locale() ),
		'og:type'        => ( is_singular() && ! is_front_page() ) ? 'article' : 'website',
		'og:title'       => html_entity_decode( wp_get_document_title(), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
		'og:description' => $description,
		'og:url'         => $url,
		'og:site_name'   => get_bloginfo( 'name' ),
	);

	$image = tiny_seo_get_image( $post_id );
	if ( $image ) {
		$tags['og:image'] = $image['url'];
		if ( $image['width'] && $image['height'] ) {
			$tags['og:image:width']  = $image['width'];
			$tags['og:image:height'] = $image['height'];
		}
		$tags['og:image:type'] = $image['mime'];
	}

	if ( is_singular() ) {
		if ( is_singular( 'post' ) ) {
			$tags['article:published_time'] = get_the_date( 'c', $post_id );
		}
		$tags['article:modified_time'] = get_the_modified_date( 'c', $post_id );
	}

	$tags['twitter:card'] = (string) tiny_seo_get_setting( 'twitter_card_type' );
	$handle               = (string) tiny_seo_get_setting( 'twitter_handle' );
	if ( '' !== $handle ) {
		$tags['twitter:site']    = '@' . $handle;
		$tags['twitter:creator'] = '@' . $handle;
	}

	/**
	 * 出力するOGPとTwitter Card。
	 *
	 * @param array<string, string|int> $tags プロパティ名 → 値。twitter:で始まるものはname属性で、それ以外はproperty属性で出す。
	 */
	return (array) apply_filters( 'tiny_seo_og_tags', array_filter( $tags, 'strlen' ) );
}

/**
 * OGPとTwitter Cardを出す。404では出さない。
 */
function tiny_seo_print_og_tags() {
	if ( ! tiny_seo_is_active() || is_404() ) {
		return;
	}
	foreach ( tiny_seo_og_tags() as $property => $content ) {
		$content = (string) $content;
		if ( '' === $content ) {
			continue;
		}
		$attribute = 0 === strpos( (string) $property, 'twitter:' ) ? 'name' : 'property';
		$value     = in_array( $property, array( 'og:url', 'og:image' ), true ) ? esc_url( $content ) : esc_attr( $content );
		printf( '<meta %1$s="%2$s" content="%3$s">' . "\n", esc_attr( $attribute ), esc_attr( $property ), $value ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $valueは直前でesc_url()かesc_attr()を通している
	}
}
add_action( 'wp_head', 'tiny_seo_print_og_tags', 5 );
