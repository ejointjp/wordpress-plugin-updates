<?php
/**
 * WordPress標準サイトマップ（wp-sitemap.xml）の調整と、Yoast SEOの旧サイトマップURLの転送
 *
 * - 著者アーカイブをnoindexにする設定なら、usersを出さない
 * - post_formatタクソノミーを出さない。タグアーカイブをnoindexにする設定なら、post_tagも出さない
 * - _tiny_seo_noindexが'1'の投稿を出さない（robotsでnoindexにしたURLを送るとSearch Consoleで警告される）
 * - 投稿とタームにlastmodを付ける
 * - /sitemap_index.xmlと/<name>-sitemap[N].xmlをwp-sitemap.xmlへ301する（Yoast停止後に404になるため）
 *
 * Yoast SEOが有効なあいだは、Yoastが標準サイトマップを止めているので何も起きない。転送もしない。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 著者アーカイブをnoindexにする設定なら、usersプロバイダを外す。
 *
 * @param WP_Sitemaps_Provider|false $provider プロバイダ。
 * @param string                     $name     プロバイダ名。
 * @return WP_Sitemaps_Provider|false
 */
function tiny_seo_sitemap_add_provider( $provider, $name ) {
	if ( 'users' === $name && tiny_seo_is_active() && tiny_seo_get_setting( 'noindex_author' ) ) {
		return false;
	}
	return $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'tiny_seo_sitemap_add_provider', 10, 2 );

/**
 * post_formatを外す（アーカイブはnoindex）。タグアーカイブをnoindexにする設定なら、post_tagも外す。
 *
 * @param array $taxonomies タクソノミー。
 * @return array
 */
function tiny_seo_sitemap_taxonomies( $taxonomies ) {
	if ( ! tiny_seo_is_active() ) {
		return $taxonomies;
	}
	unset( $taxonomies['post_format'] );
	if ( tiny_seo_get_setting( 'noindex_tag' ) ) {
		unset( $taxonomies['post_tag'] );
	}
	return $taxonomies;
}
add_filter( 'wp_sitemaps_taxonomies', 'tiny_seo_sitemap_taxonomies' );

/**
 * _tiny_seo_noindexが'1'の投稿をクエリから外す。
 *
 * キーを持たない投稿は残すため、NOT EXISTSと「'1'以外」のORで絞る。ほかのフィルタが付けたmeta_queryはANDで重ねる。
 * コアはURL一覧とページ数のどちらも、このフィルタを通した同じ引数でWP_Queryを組むので、ページ分割とずれない。
 *
 * @param array $args WP_Queryの引数。
 * @return array
 */
function tiny_seo_sitemap_exclude_noindex( $args ) {
	if ( ! tiny_seo_is_active() ) {
		return $args;
	}
	$noindex_query = array(
		'relation' => 'OR',
		array(
			'key'     => '_tiny_seo_noindex',
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => '_tiny_seo_noindex',
			'value'   => '1',
			'compare' => '!=',
		),
	);
	if ( ! empty( $args['meta_query'] ) ) {
		$noindex_query = array(
			'relation' => 'AND',
			$args['meta_query'],
			$noindex_query,
		);
	}
	$args['meta_query'] = $noindex_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- noindexの投稿を除くにはメタで絞るしかない。サイトマップの生成時だけ走る
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'tiny_seo_sitemap_exclude_noindex' );

/**
 * 投稿にlastmod（最終更新日時）を付ける。
 *
 * post_modified_gmtをmysql2date()に渡すと、GMTの値がサイトのタイムゾーンの時刻として扱われ9時間ずれるため、
 * get_post_modified_time()でGMTとして読む。
 *
 * @param array   $entry サイトマップの1件。
 * @param WP_Post $post  投稿。
 * @return array
 */
function tiny_seo_sitemap_post_lastmod( $entry, $post ) {
	if ( ! tiny_seo_is_active() || ! $post instanceof WP_Post ) {
		return $entry;
	}
	$lastmod = get_post_modified_time( 'c', true, $post );
	if ( $lastmod ) {
		$entry['lastmod'] = $lastmod;
	}
	return $entry;
}
add_filter( 'wp_sitemaps_posts_entry', 'tiny_seo_sitemap_post_lastmod', 10, 2 );

/**
 * タクソノミーのタームごとの最終更新日時（GMT）を、タームID → MySQLの日時の連想配列で返す。
 * 値は、そのタームに属する公開済み投稿のpost_modified_gmtの最大値。公開済み投稿のないタームは入らない。
 *
 * サイトマップの1ページには最大2,000タームが載る。タームごとに問い合わせるとその数だけ問い合わせが走るため、
 * タクソノミーごとに1回でまとめて読み、リクエストの中だけ覚えておく。
 * 失敗したらログに残し、空の配列を覚える（タームの数だけ同じ失敗を繰り返さない）。
 *
 * @param string $taxonomy タクソノミー。
 * @return array<int, string>
 */
function tiny_seo_sitemap_term_lastmods( $taxonomy ) {
	global $wpdb;
	$taxonomy = (string) $taxonomy;
	$lastmods = wp_cache_get( $taxonomy, 'tiny_seo_term_lastmod' );
	if ( is_array( $lastmods ) ) {
		return $lastmods;
	}
	$rows     = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- タクソノミーごとに1回のMAX()。WP_Queryでは集計できない
		$wpdb->prepare(
			"SELECT tt.term_id, MAX(p.post_modified_gmt) AS latest
			 FROM {$wpdb->posts} AS p
			 INNER JOIN {$wpdb->term_relationships} AS tr ON p.ID = tr.object_id
			 INNER JOIN {$wpdb->term_taxonomy} AS tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
			 WHERE tt.taxonomy = %s
			   AND p.post_status = 'publish'
			 GROUP BY tt.term_id",
			$taxonomy
		)
	);
	$lastmods = array();
	if ( $wpdb->last_error ) {
		error_log( 'Tiny SEO sitemap: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 問い合わせの失敗を残すため
	} else {
		foreach ( (array) $rows as $row ) {
			$lastmods[ (int) $row->term_id ] = (string) $row->latest;
		}
	}
	wp_cache_set( $taxonomy, $lastmods, 'tiny_seo_term_lastmod' );
	return $lastmods;
}

// リクエストの中だけで覚えておく（永続オブジェクトキャッシュに残すと、投稿を更新してもlastmodが変わらなくなる）
wp_cache_add_non_persistent_groups( 'tiny_seo_term_lastmod' );

/**
 * タームにlastmodを付ける。そのタームに属する公開済み投稿のpost_modified_gmtの最大値。
 *
 * @param array  $entry    サイトマップの1件。
 * @param int    $term_id  タームID。
 * @param string $taxonomy タクソノミー。
 * @return array
 */
function tiny_seo_sitemap_term_lastmod( $entry, $term_id, $taxonomy ) {
	if ( ! tiny_seo_is_active() ) {
		return $entry;
	}
	$lastmods = tiny_seo_sitemap_term_lastmods( $taxonomy );
	$latest   = isset( $lastmods[ (int) $term_id ] ) ? $lastmods[ (int) $term_id ] : '';
	if ( '' !== $latest && '0000-00-00 00:00:00' !== $latest ) {
		// GMTの値なのでUTCとして読む。mysql2date()はサイトのタイムゾーンの時刻として読むため使わない
		$entry['lastmod'] = ( new DateTimeImmutable( $latest, new DateTimeZone( 'UTC' ) ) )->format( 'c' );
	}
	return $entry;
}
add_filter( 'wp_sitemaps_taxonomies_entry', 'tiny_seo_sitemap_term_lastmod', 10, 3 );

/**
 * Yoast SEOの旧サイトマップURLを、WordPress標準のサイトマップ（get_sitemap_url( 'index' )）へ301する。
 * 404になったリクエストだけが対象。
 *
 * 転送先はコアに決めさせる（パーマリンクを使わないサイトでは/?sitemap=index）。サイトマップが無効なら転送しない
 * （転送先も404になるため）。get_sitemap_url()は無効でもURLを返すので、sitemaps_enabled()で確かめる。
 * redirect_canonical()が推測で別の投稿へ飛ばす前に動かすため、優先度1で登録する。
 */
function tiny_seo_redirect_legacy_sitemap() {
	if ( ! tiny_seo_is_active() || ! is_404() ) {
		return;
	}
	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
	$path        = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
	if ( ! tiny_seo_is_legacy_sitemap_path( $path ) ) {
		return;
	}
	$sitemaps = wp_sitemaps_get_server();
	if ( ! $sitemaps || ! $sitemaps->sitemaps_enabled() ) {
		return;
	}
	$url = get_sitemap_url( 'index' );
	if ( ! $url ) {
		return;
	}
	wp_safe_redirect( $url, 301 );
	exit;
}
add_action( 'template_redirect', 'tiny_seo_redirect_legacy_sitemap', 1 );
