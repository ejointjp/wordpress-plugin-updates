<?php
/**
 * 他のプラグインとの関係
 *
 * - 他のSEOプラグインが有効なあいだは、Tiny SEOの出力を止める（tiny_seo_is_active()）
 * - JetpackのOGPとTwitterカードを止める（Tiny SEOが出すので二重になる）
 *
 * Yoast SEO（wordpress-seo）はtiny-seoより後に読み込まれる。判定は必ずフックの中で行うこと。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 有効な他のSEOプラグインの名前を返す。なければ空文字。
 *
 * @return string
 */
function tiny_seo_conflicting_plugin() {
	if ( defined( 'WPSEO_VERSION' ) ) {
		return 'Yoast SEO';
	}
	if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
		return 'Rank Math';
	}
	if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
		return 'All in One SEO';
	}
	return '';
}

/**
 * Tiny SEOが出力してよいか（他のSEOプラグインが有効でないか）。
 *
 * @return bool
 */
function tiny_seo_is_active() {
	return '' === tiny_seo_conflicting_plugin();
}

/**
 * JetpackのOGPを止める。Jetpackはplugins_loadedでこのフィルタを読む。
 *
 * @param bool $enabled Jetpackが出すかどうか。
 * @return bool
 */
function tiny_seo_filter_jetpack_open_graph( $enabled ) {
	return tiny_seo_is_active() ? false : $enabled;
}
add_filter( 'jetpack_enable_open_graph', 'tiny_seo_filter_jetpack_open_graph', 100 );

/**
 * JetpackのTwitterカードを止める。
 *
 * @param bool $disabled 止めるかどうか。
 * @return bool
 */
function tiny_seo_filter_jetpack_twitter_cards( $disabled ) {
	return tiny_seo_is_active() ? true : $disabled;
}
add_filter( 'jetpack_disable_twitter_cards', 'tiny_seo_filter_jetpack_twitter_cards', 100 );

/**
 * Jetpackの「SEOツール」モジュールが有効か。有効ならtitleとdescriptionが二重になるので、設定画面で警告する。
 *
 * @return bool
 */
function tiny_seo_jetpack_seo_tools_active() {
	return class_exists( 'Jetpack' ) && method_exists( 'Jetpack', 'is_module_active' ) && Jetpack::is_module_active( 'seo-tools' );
}
