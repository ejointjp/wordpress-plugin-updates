<?php
/**
 * WordPressに依存しない小さな関数
 *
 * 単体テスト（tests/php/）からWordPressなしで読み込めるよう、ここではWordPressの関数を呼ばず、フックも登録しない。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Xのアカウント名を正規化する。
 *
 * 前後の空白と先頭の@を外す。空なら空文字、使えない文字を含むか16文字以上ならnull。
 *
 * @param string $raw 入力値。
 * @return string|null
 */
function tiny_seo_parse_twitter_handle( $raw ) {
	$handle = ltrim( trim( (string) $raw ), '@' );
	if ( '' === $handle ) {
		return '';
	}
	return preg_match( '/^[A-Za-z0-9_]{1,15}$/', $handle ) ? $handle : null;
}

/**
 * Yoast SEOの旧サイトマップのパスか。
 *
 * /sitemap_index.xmlと/<name>-sitemap[N].xml（post-sitemap.xml、category-sitemap2.xmlなど）。
 * wp-で始まる名前（WordPress標準のwp-sitemap-*.xml）は含めない。
 *
 * @param string $path URLのパス部分。
 * @return bool
 */
function tiny_seo_is_legacy_sitemap_path( $path ) {
	return (bool) preg_match( '#/(sitemap_index|(?!wp-)[a-z0-9_-]+-sitemap[0-9]*)\.xml$#', (string) $path );
}

/**
 * WordPressのロケールをog:localeの形にする。
 *
 * 日本語サイトのロケールは「ja」だが、OGPは「言語_地域」の形なので「ja_JP」にする。それ以外はそのまま返す。
 *
 * @param string $locale get_locale()の値。
 * @return string
 */
function tiny_seo_og_locale( $locale ) {
	return 'ja' === $locale ? 'ja_JP' : (string) $locale;
}
