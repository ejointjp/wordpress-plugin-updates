<?php
/**
 * パンくずの階層
 *
 * BreadcrumbListのJSON-LDと、テーマの画面表示のパンくずで共有する（Haku2のtemplate-parts/breadcrumbs.phpが使う）。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 表示中のページのパンくずの階層を返す。
 *
 * 先頭は常にHome。最後の要素がcurrent=true（現在地）。Homeだけ（要素1つ）なら、呼び出し側で出さないこと。
 *
 * - 投稿: Home > 最初のカテゴリ > 投稿タイトル。「最初」はget_the_category()の並び（カテゴリ名の順）の先頭。
 *   カテゴリを複数付けた投稿で別のカテゴリを出したいときは、フィルタtiny_seo_breadcrumb_itemsで差し替える
 * - 固定ページ: Home > 祖先ページ… > 現在のページ
 * - その他の投稿タイプ: Home > 投稿タイプのアーカイブ（あれば）> タイトル
 * - 投稿一覧、ターム、投稿タイプのアーカイブ、著者、検索、404、その他のアーカイブ: Home > それぞれの名前
 *
 * @return array<int, array{name:string, url:string, current:bool}>
 */
function tiny_seo_get_breadcrumb_items() {
	$items = array(
		array(
			'name'    => __( 'Home', 'tiny-seo' ),
			'url'     => home_url( '/' ),
			'current' => false,
		),
	);

	if ( is_front_page() ) {
		// トップページはHomeだけ
		return (array) apply_filters( 'tiny_seo_breadcrumb_items', $items );
	}

	if ( is_category() || is_tag() || is_tax() ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$link    = get_term_link( $term );
			$items[] = array(
				'name'    => $term->name,
				'url'     => is_wp_error( $link ) ? '' : (string) $link,
				'current' => true,
			);
		}
	} elseif ( is_singular( 'post' ) ) {
		$post_id    = (int) get_queried_object_id();
		$categories = get_the_category( $post_id );
		if ( $categories ) {
			$items[] = array(
				'name'    => $categories[0]->name,
				'url'     => (string) get_category_link( $categories[0]->term_id ),
				'current' => false,
			);
		}
		$items[] = tiny_seo_breadcrumb_current_post( $post_id );
	} elseif ( is_page() ) {
		$post_id = (int) get_queried_object_id();
		foreach ( array_reverse( get_post_ancestors( $post_id ) ) as $ancestor_id ) {
			$items[] = array(
				'name'    => get_the_title( $ancestor_id ),
				'url'     => (string) get_permalink( $ancestor_id ),
				'current' => false,
			);
		}
		$items[] = tiny_seo_breadcrumb_current_post( $post_id );
	} elseif ( is_singular() ) {
		$post_id   = (int) get_queried_object_id();
		$post_type = get_post_type_object( (string) get_post_type( $post_id ) );
		$archive   = $post_type ? get_post_type_archive_link( $post_type->name ) : false;
		if ( $post_type && $archive ) {
			$items[] = array(
				'name'    => $post_type->labels->name,
				'url'     => (string) $archive,
				'current' => false,
			);
		}
		$items[] = tiny_seo_breadcrumb_current_post( $post_id );
	} elseif ( is_home() ) {
		$posts_page_id = (int) get_option( 'page_for_posts' );
		$items[]       = array(
			'name'    => $posts_page_id ? get_the_title( $posts_page_id ) : __( 'Blog', 'tiny-seo' ),
			'url'     => $posts_page_id ? (string) get_permalink( $posts_page_id ) : '',
			'current' => true,
		);
	} elseif ( is_post_type_archive() ) {
		$post_type = get_queried_object();
		if ( $post_type instanceof WP_Post_Type ) {
			$items[] = array(
				'name'    => $post_type->labels->name,
				'url'     => (string) get_post_type_archive_link( $post_type->name ),
				'current' => true,
			);
		}
	} elseif ( is_author() ) {
		$author = get_queried_object();
		if ( $author instanceof WP_User ) {
			$items[] = array(
				'name'    => $author->display_name,
				'url'     => (string) get_author_posts_url( $author->ID ),
				'current' => true,
			);
		}
	} elseif ( is_search() ) {
		$items[] = array(
			/* translators: %s: Search query. */
			'name'    => sprintf( __( 'Search results for “%s”', 'tiny-seo' ), get_search_query( false ) ),
			'url'     => '',
			'current' => true,
		);
	} elseif ( is_404() ) {
		$items[] = array(
			'name'    => __( 'Page not found', 'tiny-seo' ),
			'url'     => '',
			'current' => true,
		);
	} elseif ( is_archive() ) {
		$title = wp_strip_all_tags( get_the_archive_title() );
		if ( '' !== $title ) {
			$items[] = array(
				'name'    => $title,
				'url'     => '',
				'current' => true,
			);
		}
	}

	/**
	 * パンくずの階層。テーマが項目の名前やURLを差し替えるのに使う。
	 *
	 * @param array $items name・url・currentの配列。
	 */
	return (array) apply_filters( 'tiny_seo_breadcrumb_items', $items );
}

/**
 * パンくずの現在地（単体ページ）の項目を返す。
 *
 * @param int $post_id 投稿ID。
 * @return array{name:string, url:string, current:bool}
 */
function tiny_seo_breadcrumb_current_post( $post_id ) {
	return array(
		'name'    => get_the_title( $post_id ),
		'url'     => (string) get_permalink( $post_id ),
		'current' => true,
	);
}
