<?php
/**
 * 「SEO Settings」メタボックス（投稿編集画面）
 *
 * 項目: SEOタイトルと「タイトルタグからサイト名を外す」、SEOディスクリプション、Canonical URL、noindex, nofollow。
 * SEOディスクリプションの保存先は設定description_sourceで変わる。
 *   - excerpt: post_excerptに入れる。描画時から値が変わったときだけ書き換える（抜粋パネルだけを直したときに上書きしないため）
 *   - meta: _tiny_seo_descriptionに入れる
 * 他のSEOプラグインが有効なあいだは出さない（二重入力を避ける）。
 * このファイルは管理画面でだけ読み込む。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * メタボックスを出す投稿タイプ（公開の投稿タイプから添付を除いたもの）。
 *
 * @return string[]
 */
function tiny_seo_meta_box_post_types() {
	$types = get_post_types( array( 'public' => true ) );
	unset( $types['attachment'] );

	/**
	 * メタボックスを出す投稿タイプ。
	 *
	 * @param string[] $types 投稿タイプ名。
	 */
	return array_values( (array) apply_filters( 'tiny_seo_meta_box_post_types', array_values( $types ) ) );
}

/**
 * メタボックス用のCSSとJSを、対象の投稿タイプの編集画面でだけ読み込む。
 *
 * @param string $hook_suffix 管理画面のフック名。
 */
function tiny_seo_enqueue_meta_box_assets( $hook_suffix ) {
	if ( ! tiny_seo_is_active() || ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->post_type, tiny_seo_meta_box_post_types(), true ) ) {
		return;
	}

	$asset_file = TINY_SEO_DIR . 'build/meta-box.asset.php';
	if ( ! file_exists( $asset_file ) ) {
		_doing_it_wrong(
			__FUNCTION__,
			sprintf(
				/* translators: %s: File path. */
				esc_html__( '%s was not found. Run pnpm build.', 'tiny-seo' ),
				'build/meta-box.asset.php'
			),
			'0.1.0'
		);
		return;
	}
	$asset = require $asset_file;

	wp_enqueue_style( 'tiny-seo-meta-box', TINY_SEO_URL . 'build/meta-box.css', array(), $asset['version'] );
	wp_enqueue_script( 'tiny-seo-meta-box', TINY_SEO_URL . 'build/meta-box.js', $asset['dependencies'], $asset['version'], true );
	wp_localize_script(
		'tiny-seo-meta-box',
		'tinySeoMetaBox',
		array(
			'i18n' => array(
				'tooShort'         => __( 'Too short', 'tiny-seo' ),
				'goodLength'       => __( 'Good length', 'tiny-seo' ),
				'tooLong'          => __( 'Too long', 'tiny-seo' ),
				'titlePlaceholder' => __( 'Enter an SEO title', 'tiny-seo' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'tiny_seo_enqueue_meta_box_assets' );

/**
 * メタボックスを登録する。
 */
function tiny_seo_add_meta_box() {
	if ( ! tiny_seo_is_active() ) {
		return;
	}
	add_meta_box(
		'tiny_seo_meta_box',
		__( 'SEO Settings', 'tiny-seo' ),
		'tiny_seo_render_meta_box',
		tiny_seo_meta_box_post_types(),
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'tiny_seo_add_meta_box' );

/**
 * メタボックスの中身。
 *
 * プレビューに使う投稿タイトル・サイト名・自動抜粋と保存先、投稿タイプが抜粋に対応するかは、data属性でJSに渡す。
 *
 * @param WP_Post $post 編集中の投稿。
 */
function tiny_seo_render_meta_box( $post ) {
	$post_id        = (int) $post->ID;
	$source         = (string) tiny_seo_get_setting( 'description_source' );
	$seo_title      = (string) get_post_meta( $post_id, '_tiny_seo_title', true );
	$hide_site_name = '1' === (string) get_post_meta( $post_id, '_tiny_seo_hide_site_name', true );
	$description    = 'meta' === $source ? (string) get_post_meta( $post_id, '_tiny_seo_description', true ) : (string) $post->post_excerpt;
	$canonical      = (string) get_post_meta( $post_id, '_tiny_seo_canonical', true );
	$noindex        = '1' === (string) get_post_meta( $post_id, '_tiny_seo_noindex', true );
	// パスワードで保護された投稿では、get_the_excerpt()がコアの「保護されているため抜粋はありません」の文を返す。
	// 表側でも保護された投稿のdescriptionは空なので、プレビューも空にする（編集者のCookieの有無で変えない）
	$auto_excerpt = '' !== $post->post_password ? '' : tiny_seo_normalize_text( get_the_excerpt( $post ) );

	wp_nonce_field( 'tiny_seo_save_meta_box', 'tiny_seo_meta_box_nonce' );
	?>
	<div class="tiny-seo-meta-box"
		data-description-source="<?php echo esc_attr( $source ); ?>"
		data-post-title="<?php echo esc_attr( $post->post_title ); ?>"
		data-site-name="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
		data-auto-excerpt="<?php echo esc_attr( $auto_excerpt ); ?>"
		data-excerpt-supported="<?php echo esc_attr( post_type_supports( $post->post_type, 'excerpt' ) ? '1' : '0' ); ?>">
		<?php // 欄（textarea）と同じesc_textarea()で出す。esc_attr()は既存の文字参照を二重にエスケープしないので、送信される値が欄と食い違う ?>
		<input type="hidden" name="tiny_seo_description_original" value="<?php echo esc_textarea( $description ); ?>">

		<div class="tiny-seo-field">
			<label for="tiny-seo-title"><?php esc_html_e( 'SEO title', 'tiny-seo' ); ?></label>
			<input type="text" id="tiny-seo-title" name="tiny_seo_title" value="<?php echo esc_attr( $seo_title ); ?>" class="tiny-seo-input">
			<div class="tiny-seo-char-count">
				<span><span data-count-for="tiny-seo-title">0</span> <?php esc_html_e( 'characters', 'tiny-seo' ); ?></span>
				<span class="tiny-seo-char-status" data-status-for="tiny-seo-title"></span>
			</div>
			<p>
				<label>
					<input type="checkbox" id="tiny-seo-hide-site-name" name="tiny_seo_hide_site_name" value="1" <?php checked( $hide_site_name ); ?>>
					<?php esc_html_e( 'Remove site name from title tag', 'tiny-seo' ); ?>
				</label>
			</p>
			<p class="description"><?php esc_html_e( 'Leave empty to use the post title. Aim for 28 to 60 characters.', 'tiny-seo' ); ?></p>
		</div>

		<div class="tiny-seo-field">
			<label for="tiny-seo-description"><?php esc_html_e( 'SEO description', 'tiny-seo' ); ?></label>
			<textarea id="tiny-seo-description" name="tiny_seo_description" rows="3" class="tiny-seo-input"><?php echo esc_textarea( $description ); ?></textarea>
			<div class="tiny-seo-char-count">
				<span><span data-count-for="tiny-seo-description">0</span> <?php esc_html_e( 'characters', 'tiny-seo' ); ?></span>
				<span class="tiny-seo-char-status" data-status-for="tiny-seo-description"></span>
			</div>
			<p class="description">
				<?php
				if ( 'meta' === $source ) {
					esc_html_e( 'Used for search results and social sharing. When empty, the excerpt is used. Aim for 80 to 160 characters.', 'tiny-seo' );
				} else {
					esc_html_e( 'Saved as the excerpt and used for search results and social sharing. Aim for 80 to 160 characters.', 'tiny-seo' );
				}
				?>
			</p>
		</div>

		<div class="tiny-seo-preview">
			<h4><?php esc_html_e( 'Search result preview', 'tiny-seo' ); ?></h4>
			<div class="tiny-seo-preview-version">
				<h5><?php esc_html_e( 'Desktop', 'tiny-seo' ); ?></h5>
				<div class="tiny-seo-preview-container tiny-seo-preview--desktop">
					<div class="tiny-seo-preview-title"></div>
					<div class="tiny-seo-preview-description"></div>
				</div>
			</div>
			<div class="tiny-seo-preview-version">
				<h5><?php esc_html_e( 'Mobile', 'tiny-seo' ); ?></h5>
				<div class="tiny-seo-preview-container tiny-seo-preview--mobile">
					<div class="tiny-seo-preview-title"></div>
					<div class="tiny-seo-preview-description"></div>
				</div>
			</div>
		</div>

		<div class="tiny-seo-field">
			<label for="tiny-seo-canonical"><?php esc_html_e( 'Canonical URL', 'tiny-seo' ); ?></label>
			<input type="url" id="tiny-seo-canonical" name="tiny_seo_canonical" value="<?php echo esc_attr( $canonical ); ?>" class="tiny-seo-input" placeholder="https://">
			<p class="description"><?php esc_html_e( 'Leave empty to use the default canonical URL.', 'tiny-seo' ); ?></p>
		</div>

		<div class="tiny-seo-field">
			<label>
				<input type="checkbox" name="tiny_seo_noindex" value="1" <?php checked( $noindex ); ?>>
				<?php esc_html_e( 'Set this page to noindex, nofollow (also excluded from the sitemap)', 'tiny-seo' ); ?>
			</label>
		</div>
	</div>
	<?php
}

/**
 * メタボックスからの保存か（nonce、autosave、フォームの投稿ID、権限）。
 *
 * @param int $post_id 保存しようとしている投稿のID。
 * @return bool
 */
function tiny_seo_meta_box_request_is_valid( $post_id ) {
	if ( ! isset( $_POST['tiny_seo_meta_box_nonce'], $_POST['post_ID'] ) ) {
		return false;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tiny_seo_meta_box_nonce'] ) ), 'tiny_seo_save_meta_box' ) ) {
		return false;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return false;
	}
	// リビジョンの作成など、同じリクエストで別の投稿を保存するときには何もしない
	if ( absint( wp_unslash( $_POST['post_ID'] ) ) !== (int) $post_id ) {
		return false;
	}
	return current_user_can( 'edit_post', $post_id );
}

/**
 * 抜粋モードで、SEOディスクリプションをpost_excerptに入れる。
 *
 * wp_update_post()を呼び直さず、保存中のデータに差し込む（二重に保存しない）。
 * 描画時の値（tiny_seo_description_original）から変わっていなければ触らない。
 * 抜粋パネルだけを直して保存したときに、SEO欄の古い値で上書きしないため。
 *
 * @param array $data    保存するデータ（スラッシュ付き）。
 * @param array $postarr wp_insert_post()に渡された値。
 * @return array
 */
function tiny_seo_filter_insert_post_data( $data, $postarr ) {
	if ( ! tiny_seo_is_active() || 'excerpt' !== tiny_seo_get_setting( 'description_source' ) ) {
		return $data;
	}
	$post_id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
	if ( ! $post_id || ! tiny_seo_meta_box_request_is_valid( $post_id ) ) {
		return $data;
	}
	if ( ! isset( $_POST['tiny_seo_description'], $_POST['tiny_seo_description_original'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- tiny_seo_meta_box_request_is_valid()で確認済み
		return $data;
	}
	$description = sanitize_textarea_field( wp_unslash( $_POST['tiny_seo_description'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- 同上
	$original    = sanitize_textarea_field( wp_unslash( $_POST['tiny_seo_description_original'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- 同上
	if ( $description === $original ) {
		return $data;
	}
	$data['post_excerpt'] = wp_slash( $description );
	return $data;
}
add_filter( 'wp_insert_post_data', 'tiny_seo_filter_insert_post_data', 10, 2 );

/**
 * メタボックスの値を投稿メタに保存する。空欄やチェックなしは削除する。
 *
 * update_post_meta()は値をunslashするので、unslash済みの値はwp_slash()して渡す（バックスラッシュを残すため）。
 *
 * @param int $post_id 投稿ID。
 */
function tiny_seo_save_meta_box( $post_id ) {
	if ( ! tiny_seo_is_active() || ! tiny_seo_meta_box_request_is_valid( $post_id ) ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- tiny_seo_meta_box_request_is_valid()で確認済み

	if ( isset( $_POST['tiny_seo_title'] ) ) {
		$title = sanitize_text_field( wp_unslash( $_POST['tiny_seo_title'] ) );
		if ( '' !== $title ) {
			update_post_meta( $post_id, '_tiny_seo_title', wp_slash( $title ) );
		} else {
			delete_post_meta( $post_id, '_tiny_seo_title' );
		}
	}

	if ( isset( $_POST['tiny_seo_canonical'] ) ) {
		$canonical = esc_url_raw( wp_unslash( $_POST['tiny_seo_canonical'] ), array( 'http', 'https' ) );
		if ( '' !== $canonical ) {
			update_post_meta( $post_id, '_tiny_seo_canonical', wp_slash( $canonical ) );
		} else {
			delete_post_meta( $post_id, '_tiny_seo_canonical' );
		}
	}

	if ( 'meta' === tiny_seo_get_setting( 'description_source' ) && isset( $_POST['tiny_seo_description'] ) ) {
		$description = sanitize_textarea_field( wp_unslash( $_POST['tiny_seo_description'] ) );
		if ( '' !== $description ) {
			update_post_meta( $post_id, '_tiny_seo_description', wp_slash( $description ) );
		} else {
			delete_post_meta( $post_id, '_tiny_seo_description' );
		}
	}

	foreach (
		array(
			'tiny_seo_hide_site_name' => '_tiny_seo_hide_site_name',
			'tiny_seo_noindex'        => '_tiny_seo_noindex',
		) as $field => $meta_key
	) {
		if ( isset( $_POST[ $field ] ) ) {
			update_post_meta( $post_id, $meta_key, '1' );
		} else {
			delete_post_meta( $post_id, $meta_key );
		}
	}

	// phpcs:enable
}
add_action( 'save_post', 'tiny_seo_save_meta_box' );
