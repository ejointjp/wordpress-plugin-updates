<?php
/**
 * 設定画面（設定 → Tiny SEO）
 *
 * Settings APIで作る。保存前の検証はincludes/settings.phpのtiny_seo_sanitize_settings()。
 * 「設定」メニュー配下なので、保存時の「設定を保存しました。」と検証エラーはコアが表示する。
 * ここでsettings_errors()を呼ぶと二重に出る（/wp-admin-notices）。
 * フォームには_formを入れ、送られてこないチェックボックスをOFFとして扱わせる。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TINY_SEO_PAGE = 'tiny-seo';

/**
 * 設定メニューを追加する。
 */
function tiny_seo_add_settings_page() {
	add_options_page(
		__( 'Tiny SEO', 'tiny-seo' ),
		__( 'Tiny SEO', 'tiny-seo' ),
		'manage_options',
		TINY_SEO_PAGE,
		'tiny_seo_render_settings_page'
	);
}
add_action( 'admin_menu', 'tiny_seo_add_settings_page' );

/**
 * 設定の節と項目を登録する。
 */
function tiny_seo_register_settings_fields() {
	add_settings_section( 'tiny_seo_general', __( 'General', 'tiny-seo' ), '__return_false', TINY_SEO_PAGE );
	add_settings_field(
		'description_source',
		__( 'Description source', 'tiny-seo' ),
		'tiny_seo_render_select_field',
		TINY_SEO_PAGE,
		'tiny_seo_general',
		array(
			'key'         => 'description_source',
			'label_for'   => 'tiny-seo-description_source',
			'options'     => array(
				'excerpt' => __( 'Excerpt (recommended)', 'tiny-seo' ),
				'meta'    => __( 'Separate SEO field', 'tiny-seo' ),
			),
			'description' => __( 'Excerpt: the SEO description is saved as the post excerpt, so it stays even if you stop using Tiny SEO. Separate SEO field: the description is saved separately, and the excerpt is used when it is empty. Changing this does not move existing data.', 'tiny-seo' ),
		)
	);
	add_settings_field( 'default_image_id', __( 'Default image', 'tiny-seo' ), 'tiny_seo_render_image_field', TINY_SEO_PAGE, 'tiny_seo_general' );

	add_settings_section( 'tiny_seo_social', __( 'Social', 'tiny-seo' ), '__return_false', TINY_SEO_PAGE );
	add_settings_field(
		'twitter_handle',
		__( 'X username', 'tiny-seo' ),
		'tiny_seo_render_text_field',
		TINY_SEO_PAGE,
		'tiny_seo_social',
		array(
			'key'         => 'twitter_handle',
			'label_for'   => 'tiny-seo-twitter_handle',
			'prefix'      => '@',
			'description' => __( 'Output as twitter:site and twitter:creator. Leave empty to omit them.', 'tiny-seo' ),
		)
	);
	add_settings_field(
		'twitter_card_type',
		__( 'X card type', 'tiny-seo' ),
		'tiny_seo_render_select_field',
		TINY_SEO_PAGE,
		'tiny_seo_social',
		array(
			'key'       => 'twitter_card_type',
			'label_for' => 'tiny-seo-twitter_card_type',
			'options'   => array(
				'summary_large_image' => __( 'Summary with large image', 'tiny-seo' ),
				'summary'             => __( 'Summary', 'tiny-seo' ),
			),
		)
	);

	add_settings_section( 'tiny_seo_indexing', __( 'Indexing', 'tiny-seo' ), '__return_false', TINY_SEO_PAGE );
	$checkboxes = array(
		'noindex_author'           => array( __( 'Author archives', 'tiny-seo' ), __( 'Add noindex and remove authors from the sitemap', 'tiny-seo' ), '' ),
		'noindex_date'             => array( __( 'Date archives', 'tiny-seo' ), __( 'Add noindex', 'tiny-seo' ), '' ),
		'noindex_tag'              => array( __( 'Tag archives', 'tiny-seo' ), __( 'Add noindex and remove tags from the sitemap', 'tiny-seo' ), '' ),
		'disable_attachment_pages' => array( __( 'Attachment pages', 'tiny-seo' ), __( 'Redirect attachment pages to the file', 'tiny-seo' ), '' ),
		'breadcrumb_json_ld'       => array( __( 'Breadcrumbs', 'tiny-seo' ), __( 'Output BreadcrumbList structured data', 'tiny-seo' ), __( 'Turn this off if another plugin, such as Breadcrumb NavXT, already outputs breadcrumb structured data.', 'tiny-seo' ) ),
	);
	foreach ( $checkboxes as $key => $texts ) {
		add_settings_field(
			$key,
			$texts[0],
			'tiny_seo_render_checkbox_field',
			TINY_SEO_PAGE,
			'tiny_seo_indexing',
			array(
				'key'         => $key,
				'label'       => $texts[1],
				'description' => $texts[2],
			)
		);
	}

	add_settings_section( 'tiny_seo_data', __( 'Data', 'tiny-seo' ), '__return_false', TINY_SEO_PAGE );
	add_settings_field(
		'delete_data_on_uninstall',
		__( 'Uninstall', 'tiny-seo' ),
		'tiny_seo_render_checkbox_field',
		TINY_SEO_PAGE,
		'tiny_seo_data',
		array(
			'key'         => 'delete_data_on_uninstall',
			'label'       => __( 'Delete settings and SEO data when the plugin is deleted', 'tiny-seo' ),
			'description' => __( 'Deletes the SEO titles, descriptions, canonical URLs and noindex flags saved by Tiny SEO. Post excerpts are never deleted.', 'tiny-seo' ),
		)
	);
}
add_action( 'admin_init', 'tiny_seo_register_settings_fields' );

/**
 * 項目の説明文を出す。
 *
 * @param array $args 項目の引数（description）。
 */
function tiny_seo_render_field_description( $args ) {
	if ( ! empty( $args['description'] ) ) {
		printf( '<p class="description">%s</p>', esc_html( $args['description'] ) );
	}
}

/**
 * 選択肢の項目を出す。
 *
 * @param array $args key・label_for・options・description。
 */
function tiny_seo_render_select_field( $args ) {
	$value = (string) tiny_seo_get_setting( $args['key'] );
	printf( '<select id="%1$s" name="%2$s">', esc_attr( $args['label_for'] ), esc_attr( TINY_SEO_OPTION . '[' . $args['key'] . ']' ) );
	foreach ( $args['options'] as $option_value => $label ) {
		printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $option_value ), selected( $value, $option_value, false ), esc_html( $label ) );
	}
	echo '</select>';
	tiny_seo_render_field_description( $args );
}

/**
 * 1行のテキストの項目を出す。
 *
 * @param array $args key・label_for・prefix・description。
 */
function tiny_seo_render_text_field( $args ) {
	if ( ! empty( $args['prefix'] ) ) {
		echo esc_html( $args['prefix'] ) . ' ';
	}
	printf(
		'<input type="text" id="%1$s" name="%2$s" value="%3$s" class="regular-text">',
		esc_attr( $args['label_for'] ),
		esc_attr( TINY_SEO_OPTION . '[' . $args['key'] . ']' ),
		esc_attr( (string) tiny_seo_get_setting( $args['key'] ) )
	);
	tiny_seo_render_field_description( $args );
}

/**
 * チェックボックスの項目を出す。disable_attachment_pagesはコアのoption wp_attachment_pages_enabledを映す。
 *
 * @param array $args key・label・description。
 */
function tiny_seo_render_checkbox_field( $args ) {
	if ( 'disable_attachment_pages' === $args['key'] ) {
		$checked = '0' === (string) get_option( 'wp_attachment_pages_enabled', '1' );
	} else {
		$checked = (bool) tiny_seo_get_setting( $args['key'] );
	}
	printf(
		'<label><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s> %4$s</label>',
		esc_attr( 'tiny-seo-' . $args['key'] ),
		esc_attr( TINY_SEO_OPTION . '[' . $args['key'] . ']' ),
		checked( $checked, true, false ),
		esc_html( $args['label'] )
	);
	tiny_seo_render_field_description( $args );
}

/**
 * 既定の画像の項目を出す。選択はsrc/settings.jsのメディアライブラリ。
 *
 * 「削除」ボタンは、画像がないときstyleで隠す。hidden属性は、管理画面のCSS（.wp-core-ui .button）のdisplayに打ち消されて効かない。
 */
function tiny_seo_render_image_field() {
	$image_id = (int) tiny_seo_get_setting( 'default_image_id' );
	$preview  = $image_id ? wp_get_attachment_image( $image_id, 'medium', false, array( 'alt' => '' ) ) : '';
	?>
	<div class="tiny-seo-image-field">
		<input type="hidden" name="<?php echo esc_attr( TINY_SEO_OPTION ); ?>[default_image_id]" value="<?php echo esc_attr( (string) $image_id ); ?>">
		<div class="tiny-seo-image-preview"><?php echo wp_kses_post( $preview ); ?></div>
		<p>
			<button type="button" class="button tiny-seo-image-select"><?php esc_html_e( 'Select image', 'tiny-seo' ); ?></button>
			<button type="button" class="button tiny-seo-image-remove"<?php echo $image_id ? '' : ' style="display:none"'; ?>><?php esc_html_e( 'Remove image', 'tiny-seo' ); ?></button>
		</p>
		<p class="description"><?php esc_html_e( 'Used for og:image when a post has no featured image, and on archive pages.', 'tiny-seo' ); ?></p>
	</div>
	<?php
}

/**
 * 設定画面を出す。
 *
 * settings_fields()がnonceを出すので、独自のnonceはいらない。
 */
function tiny_seo_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'tiny-seo' ) );
	}
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<hr class="wp-header-end">
		<form action="options.php" method="post">
			<?php settings_fields( 'tiny_seo' ); ?>
			<input type="hidden" name="<?php echo esc_attr( TINY_SEO_OPTION ); ?>[_form]" value="1">
			<?php
			do_settings_sections( TINY_SEO_PAGE );
			submit_button();
			?>
		</form>
		<?php
		tiny_seo_render_status_section();
		tiny_seo_render_import_section();
		?>
	</div>
	<?php
}

/**
 * 状態（出力しているか、Jetpackの警告、サイトマップのURL）を出す。
 */
function tiny_seo_render_status_section() {
	$conflict = tiny_seo_conflicting_plugin();
	// get_sitemap_url()は無効でもURLを返すので、sitemaps_enabled()で確かめる（includes/sitemap.phpの転送と同じ）
	$sitemaps = wp_sitemaps_get_server();
	$sitemap  = ( $sitemaps && $sitemaps->sitemaps_enabled() ) ? get_sitemap_url( 'index' ) : '';
	?>
	<h2><?php esc_html_e( 'Status', 'tiny-seo' ); ?></h2>
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Output', 'tiny-seo' ); ?></th>
				<td>
					<?php
					if ( '' !== $conflict ) {
						/* translators: %s: Name of another SEO plugin. */
						printf( esc_html__( '%s is active. Tiny SEO outputs nothing and hides its meta box until you deactivate it.', 'tiny-seo' ), esc_html( $conflict ) );
					} else {
						esc_html_e( 'Active. Tiny SEO outputs the title, meta description, robots, Open Graph and JSON-LD.', 'tiny-seo' );
					}
					?>
				</td>
			</tr>
			<?php if ( tiny_seo_jetpack_seo_tools_active() ) : ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Jetpack', 'tiny-seo' ); ?></th>
					<td><?php esc_html_e( 'The Jetpack SEO Tools module is active. Deactivate it in the Jetpack settings to avoid duplicate titles and descriptions.', 'tiny-seo' ); ?></td>
				</tr>
			<?php endif; ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Sitemap', 'tiny-seo' ); ?></th>
				<td>
					<?php if ( $sitemap ) : ?>
						<a href="<?php echo esc_url( $sitemap ); ?>"><?php echo esc_html( $sitemap ); ?></a>
					<?php else : ?>
						<?php esc_html_e( 'The WordPress sitemap is disabled.', 'tiny-seo' ); ?>
					<?php endif; ?>
				</td>
			</tr>
		</tbody>
	</table>
	<?php
}

/**
 * 設定画面のスクリプト（既定の画像の選択）を読み込む。
 *
 * @param string $hook_suffix 管理画面のフック名。
 */
function tiny_seo_enqueue_settings_assets( $hook_suffix ) {
	if ( 'settings_page_' . TINY_SEO_PAGE !== $hook_suffix ) {
		return;
	}
	$asset_file = TINY_SEO_DIR . 'build/settings.asset.php';
	if ( ! file_exists( $asset_file ) ) {
		_doing_it_wrong(
			__FUNCTION__,
			sprintf(
				/* translators: %s: File path. */
				esc_html__( '%s was not found. Run pnpm build.', 'tiny-seo' ),
				'build/settings.asset.php'
			),
			'0.1.0'
		);
		return;
	}
	$asset = require $asset_file;

	wp_enqueue_media();
	wp_enqueue_script(
		'tiny-seo-settings',
		TINY_SEO_URL . 'build/settings.js',
		array_merge( $asset['dependencies'], array( 'media-editor' ) ),
		$asset['version'],
		true
	);
	wp_localize_script(
		'tiny-seo-settings',
		'tinySeoSettings',
		array(
			'i18n' => array(
				'frameTitle'  => __( 'Select the default image', 'tiny-seo' ),
				'frameButton' => __( 'Use this image', 'tiny-seo' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'tiny_seo_enqueue_settings_assets' );
