<?php
/**
 * 著者アーカイブの無効化（設定disable_author_archives）
 *
 * 1人で書いているサイトでは、著者アーカイブはトップページと同じ記事の一覧になる。さらにURLには投稿者のURL用の名前
 * （user_nicename。変えていなければログイン名と同じ）が出る。設定をオンにすると、次のようにする。
 *
 * - 著者アーカイブ（?author=N、/author/名前/、そのフィード）を、トップページへ301で転送する。その名前（番号）の投稿者がいなくても転送する
 * - 投稿者へのリンク（get_author_posts_url()）をトップページにする。転送されるだけのURLへリンクを張らず、名前も出さない
 * - サイトマップから著者を外す（includes/sitemap.php）。構造化データの著者のurlは省く（includes/json-ld.php）
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 著者アーカイブを無効にしているか。
 *
 * @return bool
 */
function tiny_seo_author_archives_disabled() {
	return tiny_seo_is_active() && (bool) tiny_seo_get_setting( 'disable_author_archives' );
}

/**
 * 著者アーカイブを開こうとしたリクエストか。名前（番号）の投稿者がいなくてもtrue。
 *
 * 存在しない名前では、WordPressが404にしてis_author()がfalseになる。正しい名前だけを転送すると、
 * 応答の違い（301と404）から、推測した名前の当たり外れを確かめられてしまう。
 *
 * @return bool
 */
function tiny_seo_is_author_request() {
	return is_author() || '' !== (string) get_query_var( 'author_name' ) || '' !== (string) get_query_var( 'author' );
}

/**
 * 著者アーカイブを、トップページへ301で転送する。
 *
 * WordPressの正規化のリダイレクト（優先度10）より先に動かす。
 */
function tiny_seo_redirect_author_archive() {
	if ( tiny_seo_author_archives_disabled() && tiny_seo_is_author_request() ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'tiny_seo_redirect_author_archive', 1 );

/**
 * 投稿者へのリンクを、トップページにする。
 *
 * @param string $link 著者アーカイブのURL。
 * @return string
 */
function tiny_seo_filter_author_link( $link ) {
	return tiny_seo_author_archives_disabled() ? home_url( '/' ) : $link;
}
add_filter( 'author_link', 'tiny_seo_filter_author_link' );
