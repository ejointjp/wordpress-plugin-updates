<?php
/**
 * JSON-LD構造化データ
 *
 * - トップページ: WebSite + Organization
 * - 投稿（post）の単体: Article
 * - トップページと404以外: BreadcrumbList（設定がONのとき）
 * ひとつの<script type="application/ld+json">に@graphとして出す。他のSEOプラグインが有効なあいだは何も出さない。
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Organizationノード（サイト名・URL・サイトロゴ）を返す。ロゴはカスタマイザーのサイトロゴ。未設定ならlogoを省く。
 *
 * @return array
 */
function tiny_seo_organization_node() {
	$node = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => tiny_seo_normalize_text( get_bloginfo( 'name' ) ),
		'url'   => home_url( '/' ),
	);

	$logo_id = (int) get_theme_mod( 'custom_logo' );
	$logo    = $logo_id ? wp_get_attachment_image_src( $logo_id, 'full' ) : false;
	if ( $logo ) {
		$node['logo'] = array(
			'@type' => 'ImageObject',
			'url'   => (string) $logo[0],
		);
		if ( $logo[1] && $logo[2] ) {
			$node['logo']['width']  = (int) $logo[1];
			$node['logo']['height'] = (int) $logo[2];
		}
	}
	return $node;
}

/**
 * WebSiteノードを返す。
 *
 * @return array
 */
function tiny_seo_website_node() {
	return array(
		'@type'       => 'WebSite',
		'@id'         => home_url( '/#website' ),
		'url'         => home_url( '/' ),
		'name'        => tiny_seo_normalize_text( get_bloginfo( 'name' ) ),
		'description' => tiny_seo_normalize_text( get_bloginfo( 'description' ) ),
		'inLanguage'  => get_bloginfo( 'language' ),
		'publisher'   => array( '@id' => home_url( '/#organization' ) ),
	);
}

/**
 * 投稿のArticleノードを返す。imageはアイキャッチがあるときだけ。
 *
 * @param int $post_id 投稿ID。
 * @return array
 */
function tiny_seo_article_node( $post_id ) {
	$author_id = (int) get_post_field( 'post_author', $post_id );

	/**
	 * Articleノードの@type（BlogPosting、NewsArticleなど）。
	 *
	 * @param string $type    既定はArticle。
	 * @param int    $post_id 投稿ID。
	 */
	$type = (string) apply_filters( 'tiny_seo_article_type', 'Article', $post_id );

	$node = array(
		'@type'            => $type,
		'headline'         => tiny_seo_normalize_text( get_the_title( $post_id ) ),
		'description'      => tiny_seo_get_summary( $post_id ),
		'datePublished'    => get_the_date( 'c', $post_id ),
		'dateModified'     => get_the_modified_date( 'c', $post_id ),
		'mainEntityOfPage' => (string) get_permalink( $post_id ),
		'inLanguage'       => get_bloginfo( 'language' ),
		'author'           => array(
			'@type' => 'Person',
			'name'  => tiny_seo_normalize_text( get_the_author_meta( 'display_name', $author_id ) ),
			'url'   => (string) get_author_posts_url( $author_id ),
		),
		'publisher'        => tiny_seo_organization_node(),
	);

	// 著者アーカイブを無効にしているときは、著者のurlを省く（トップページへ転送されるだけのURLになるため）
	if ( tiny_seo_author_archives_disabled() ) {
		unset( $node['author']['url'] );
	}

	// tiny_seo_get_image()は既定の画像に落ちるので使わない。アイキャッチが画像として使えないとき（ない添付を指しているなど）も省く
	$image = has_post_thumbnail( $post_id ) ? tiny_seo_attachment_image( (int) get_post_thumbnail_id( $post_id ) ) : null;
	if ( $image ) {
		$node['image'] = array( $image['url'] );
	}
	return $node;
}

/**
 * BreadcrumbListノードを返す。階層がHomeだけならnull。URLのない項目（検索結果など）はitemを省く。
 *
 * 項目はテーマがフィルタtiny_seo_breadcrumb_itemsで差し替えられるので、形を確かめる。
 * 名前のない項目と配列でない項目は飛ばし（ListItemにはnameが要る）、URLが文字列でなければitemを省く。
 *
 * @return array|null
 */
function tiny_seo_breadcrumb_node() {
	$elements = array();
	foreach ( tiny_seo_get_breadcrumb_items() as $item ) {
		$name = ( is_array( $item ) && isset( $item['name'] ) && is_scalar( $item['name'] ) ) ? tiny_seo_normalize_text( $item['name'] ) : '';
		if ( '' === $name ) {
			continue;
		}
		$element = array(
			'@type'    => 'ListItem',
			'position' => count( $elements ) + 1,
			'name'     => $name,
		);
		if ( isset( $item['url'] ) && is_string( $item['url'] ) && '' !== $item['url'] ) {
			$element['item'] = $item['url'];
		}
		$elements[] = $element;
	}
	if ( count( $elements ) < 2 ) {
		return null;
	}
	return array(
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $elements,
	);
}

/**
 * 表示中のページのJSON-LDのノードを返す。
 *
 * @return array
 */
function tiny_seo_json_ld_graph() {
	$nodes = array();
	if ( is_front_page() ) {
		$nodes[] = tiny_seo_website_node();
		$nodes[] = tiny_seo_organization_node();
	} elseif ( is_singular( 'post' ) ) {
		$nodes[] = tiny_seo_article_node( (int) get_queried_object_id() );
	}
	// 404はOGPと同じく出さない（noindexのページに構造化データは要らない）
	if ( ! is_front_page() && ! is_404() && tiny_seo_get_setting( 'breadcrumb_json_ld' ) ) {
		$breadcrumb = tiny_seo_breadcrumb_node();
		if ( $breadcrumb ) {
			$nodes[] = $breadcrumb;
		}
	}

	/**
	 * 出力するJSON-LDのノード（@graphの中身）。
	 *
	 * @param array $nodes ノードの配列。
	 */
	return array_values( (array) apply_filters( 'tiny_seo_json_ld_graph', $nodes ) );
}

/**
 * JSON-LDを出す。
 */
function tiny_seo_print_json_ld() {
	if ( ! tiny_seo_is_active() ) {
		return;
	}
	$nodes = tiny_seo_json_ld_graph();
	if ( ! $nodes ) {
		return;
	}
	// JSON_HEX_TAGで<と>をUnicodeエスケープの形にし、タイトルなどに</script>が入っても<script>から抜けないようにする
	$json = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $nodes,
		),
		JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG
	);
	if ( false === $json ) {
		error_log( 'Tiny SEO: JSON-LD could not be encoded: ' . json_last_error_msg() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 出力を諦めた理由を残すため
		return;
	}
	echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON_HEX_TAGでエンコード済み
}
add_action( 'wp_head', 'tiny_seo_print_json_ld' );
