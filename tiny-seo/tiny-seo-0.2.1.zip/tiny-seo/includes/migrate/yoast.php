<?php
/**
 * Yoast SEOからの取り込み
 *
 * - _yoast_wpseo_title → テンプレートを展開して_tiny_seo_titleと_tiny_seo_hide_site_name
 *   （サイト名を外すのは、タイトルを書いた、または同じタイトルがあったときだけ。Tiny SEOで付けたチェックは消さない）
 * - _yoast_wpseo_metadesc → description（テンプレート変数も展開する）
 * - _yoast_wpseo_meta-robots-noindex（'1'のみ） → _tiny_seo_noindex
 * - _yoast_wpseo_canonical → _tiny_seo_canonical
 * - option wpseo_titles: noindex-author-wpseo、noindex-archive-wpseo、noindex-tax-post_tag、disable-attachment → 設定
 * - option wpseo_social: twitter_site、twitter_card_type、og_default_image_id → 設定
 *
 * @package tiny-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/yoast-title.php';

/**
 * Yoast SEOのデータを取り込む。
 *
 * @return array|WP_Error
 */
function tiny_seo_import_yoast() {
	$result    = tiny_seo_import_new_result();
	$site_name = (string) get_bloginfo( 'name' );
	$site_desc = (string) get_bloginfo( 'description' );

	$rows = tiny_seo_import_rows( array( '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_meta-robots-noindex', '_yoast_wpseo_canonical' ) );
	foreach ( $rows as $row ) {
		$post_id = (int) $row->post_id;
		$value   = trim( (string) $row->meta_value );
		$title   = (string) get_post_field( 'post_title', $post_id );

		switch ( $row->meta_key ) {
			case '_yoast_wpseo_title':
				$converted = tiny_seo_convert_yoast_title( $value, $title, $site_name, $site_desc );
				if ( $converted ) {
					$status = tiny_seo_import_title( $post_id, $converted['title'], $result );
					// タイトルを書いた（または同じ）ときだけ立てる。サイト名付きの変換結果でも、Tiny SEOで立てたチェックは消さない
					if ( $converted['hide_site_name'] && in_array( $status, array( 'written', 'same' ), true ) ) {
						tiny_seo_import_hide_site_name( $post_id );
					}
				}
				break;
			case '_yoast_wpseo_metadesc':
				tiny_seo_import_description( $post_id, tiny_seo_expand_yoast_template( $value, $title, $site_name, $site_desc ), $result );
				break;
			case '_yoast_wpseo_meta-robots-noindex':
				if ( '1' === $value ) {
					tiny_seo_import_noindex( $post_id, $result );
				}
				break;
			case '_yoast_wpseo_canonical':
				tiny_seo_import_canonical( $post_id, $value, $result );
				break;
		}
	}
	if ( is_wp_error( $rows->getReturn() ) ) {
		return $rows->getReturn();
	}

	$changes = array();
	$titles  = get_option( 'wpseo_titles' );
	if ( is_array( $titles ) ) {
		$map = array(
			'noindex-author-wpseo'  => 'noindex_author',
			'disable-author'        => 'disable_author_archives',
			'noindex-archive-wpseo' => 'noindex_date',
			'noindex-tax-post_tag'  => 'noindex_tag',
			'disable-attachment'    => 'disable_attachment_pages',
		);
		foreach ( $map as $yoast_key => $key ) {
			if ( array_key_exists( $yoast_key, $titles ) ) {
				$changes[ $key ] = (bool) $titles[ $yoast_key ];
			}
		}
	}
	$social = get_option( 'wpseo_social' );
	if ( is_array( $social ) ) {
		if ( ! empty( $social['twitter_site'] ) ) {
			$changes['twitter_handle'] = (string) $social['twitter_site'];
		}
		if ( isset( $social['twitter_card_type'] ) && in_array( $social['twitter_card_type'], array( 'summary_large_image', 'summary' ), true ) ) {
			$changes['twitter_card_type'] = $social['twitter_card_type'];
		}
		if ( ! empty( $social['og_default_image_id'] ) ) {
			$changes['default_image_id'] = (int) $social['og_default_image_id'];
		}
	}
	tiny_seo_import_settings( $changes, $result );
	return $result;
}
