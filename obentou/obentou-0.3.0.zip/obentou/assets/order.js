/**
 * 並び替えモード（投稿一覧・ターム一覧）
 *
 * 通常の一覧では見出し横に「並び替えモード」ボタンだけを出す。
 * 並び替えモード（URLにobentou_sort=1）では#the-listの行をドラッグで並べ替え、「順序を保存」でAJAX保存する。
 * 階層のある一覧では親子の関係を変えない。どこに落としても、同じ親を持つ兄弟のなかの順位として解釈し、
 * 子孫ごと正しい位置に収め直す。
 * 保存の結果は、管理画面の標準の通知（.notice）としてバーの直下に出し、wp.a11y.speak()で読み上げる。
 *
 * グローバル変数obentouOrderはPHP側（includes/order-common.php）がwp_add_inline_scriptで注入する。
 * キー: kind（post / term）、objectType、hierarchical、idPrefix（post- / tag-）、action、ajaxUrl、nonce、
 *       isSortMode、sortUrl、exitUrl
 */

/* global jQuery, obentouOrder, wp */

( function ( $ ) {
	'use strict';

	var data = window.obentouOrder || {};

	// 行のID（post-12 / tag-12 → 12）。IDのない行（クイック編集の行、ドラッグ中のプレースホルダーなど）は0。
	// 0の行は、子孫の判定でも兄弟の判定でも数えない
	function rowId( $row ) {
		var raw = $row.attr( 'id' ) || '';
		return parseInt( raw.replace( data.idPrefix, '' ), 10 ) || 0;
	}

	// 行の親のID。クイック編集の隠しデータから取る（投稿は.post_parent、タームは.parent）。ないときは0
	function rowParent( $row ) {
		var $inline = $( '#inline_' + rowId( $row ) );
		var text = $inline.find( data.kind === 'post' ? '.post_parent' : '.parent' ).first().text();
		return parseInt( text, 10 ) || 0;
	}

	// その行の子孫の行。直後から、親が「その行か、すでに数えた子孫」である行が続くあいだを子孫とする。
	// 見た目の深さ（level-N）は、検索や絞り込みで平らに並んだ一覧では親子を表さないので使わない。
	// IDのない行（ドラッグ中のプレースホルダーなど）と、$skipの行は飛ばして数え続ける。
	// IDのない行を起点にしたときは、子孫なし（IDが0のまま数えると、親が0の最上位の行がすべて子孫になる）
	function descendantRows( $row, $skip ) {
		if ( ! rowId( $row ) ) {
			return $();
		}
		var ids = {};
		var rows = [];
		ids[ rowId( $row ) ] = true;
		$row.nextAll( 'tr' ).each( function () {
			var $next = $( this );
			var id = rowId( $next );
			if ( ! id || ( $skip && $next.is( $skip ) ) ) {
				return;
			}
			if ( ! ids[ rowParent( $next ) ] ) {
				return false;
			}
			ids[ id ] = true;
			rows.push( this );
		} );
		return $( rows );
	}

	// サブツリーの最後の行（子孫がなければその行）
	function subtreeEnd( $row, $skip ) {
		var $desc = descendantRows( $row, $skip );
		return $desc.length ? $desc.last() : $row;
	}

	$( function () {
		var $list = $( '#the-list' );
		if ( ! $list.length ) {
			return;
		}

		if ( ! data.isSortMode ) {
			// 入口は見出し横に置く（一覧の上の絞り込みとまぎれないように）
			var $enter = $( '<a class="page-title-action"></a>' )
				.attr( 'href', data.sortUrl )
				.text( '並び替えモード' );
			var $titleActions = $( '.wrap .page-title-action' );
			if ( $titleActions.length ) {
				$titleActions.last().after( $enter );
			} else {
				$( '.wrap .wp-heading-inline' ).first().after( $enter );
			}
			return;
		}

		// 並び替えモードの説明と操作は、見出しの下のバーにまとめる。
		// 保存の結果の通知もバーの直下に出すので、バーといっしょに1つの入れ物に入れ、
		// 長い一覧をスクロールしても両方が上に残るようにする（固定はCSSで入れ物に付ける）
		var $saveBtn = $( '<button type="button" class="button button-primary" disabled>順序を保存</button>' );
		var $exitLink = $( '<a class="button"></a>' ).attr( 'href', data.exitUrl ).text( '並び替えモードを終了' );
		var $status = $( '<span class="obentou-order-status" role="status"></span>' );
		var note = '：☰をドラッグして並べ替え、「順序を保存」を押してください。';
		if ( data.hierarchical ) {
			note += '親子の関係は変わりません（同じ親のなかで順番が変わります）。';
		}
		var $bar = $( '<div class="notice notice-info inline obentou-sort-bar"></div>' ).append(
			$( '<p class="obentou-sort-bar-text"></p>' ).append(
				$( '<strong></strong>' ).text( '並び替えモード' ),
				document.createTextNode( note )
			),
			$( '<div class="obentou-sort-bar-actions"></div>' ).append( $saveBtn, $exitLink, $status )
		);
		var $sticky = $( '<div class="obentou-sort-sticky"></div>' ).append( $bar );
		var $headerEnd = $( '.wrap .wp-header-end' ).first();
		if ( $headerEnd.length ) {
			$headerEnd.after( $sticky );
		} else {
			$list.closest( 'table' ).before( $sticky );
		}

		// サーバーの文言がない失敗のときの文言
		var RETRY_MESSAGE = '順序を保存できませんでした。ページを読み込み直して、もう一度お試しください。';

		// 絞り込み・検索をしてもモードに留まる（投稿一覧は#posts-filter、ターム一覧は.search-form）
		$( '#posts-filter, .search-form' ).append( '<input type="hidden" name="obentou_sort" value="1">' );

		// いまの一覧の並び（IDの配列）。プレースホルダーとヘルパー、IDのない行は数えない
		function currentIds() {
			return $list.children( 'tr' ).not( '.ui-sortable-placeholder, .ui-sortable-helper' ).map( function () {
				return rowId( $( this ) ) || null;
			} ).get();
		}

		// 最後に保存した（開いたときの）並び。いまの並びと違うあいだは「保存していない並び替えがある」
		var savedIds = currentIds();

		// 保存していない並び替えがあるときは、ページを離れる前に確認する
		var isDirty = false;
		window.addEventListener( 'beforeunload', function ( event ) {
			if ( isDirty ) {
				event.preventDefault();
				event.returnValue = '';
			}
		} );

		// いまの並びを最後に保存した並びと比べ、保存ボタンと状態表示を合わせる
		// （落とした位置は収め直しで変わるので、ドロップの時点ではなく収め直したあとで比べる）
		function refreshDirty() {
			isDirty = currentIds().join( ',' ) !== savedIds.join( ',' );
			$saveBtn.prop( 'disabled', ! isDirty );
			$status.text( isDirty ? '保存していない並び替えがあります。' : '' );
		}

		// 保存の結果を、管理画面の標準の通知としてバーの直下に出す（前の結果の通知は消す）。
		// 閉じるボタンはcommon.jsがwp-notice-addedで付ける。目で見ていない人にもわかるよう、読み上げもする
		function showNotice( message, type ) {
			$sticky.children( '.obentou-order-notice' ).remove();
			$bar.after(
				$( '<div class="notice inline is-dismissible obentou-order-notice"></div>' )
					.addClass( 'notice-' + type )
					.append( $( '<p></p>' ).text( message ) )
			);
			$( document ).trigger( 'wp-notice-added' );
			wp.a11y.speak( message, 'error' === type ? 'assertive' : 'polite' );
		}

		// 保存に失敗したときの表示。状態表示を保存前に戻し（ボタンも押し直せる）、理由を通知で出す
		function showError( message ) {
			refreshDirty();
			showNotice( message, 'error' );
		}

		// 失敗の理由。サーバーが返した文言を優先し、ないときはHTTPステータスと次にすることを書く。
		// admin-ajax.phpは、nonceの期限切れとログアウトをJSONではない本文で返す。
		// ステータスだけで決めないのは、WAFなどが返す別の403まで「期限切れ」と案内してしまうため
		function failMessage( xhr ) {
			var json = xhr && xhr.responseJSON;
			var status = xhr ? xhr.status : 0;
			if ( json && json.data && json.data.message ) {
				return json.data.message;
			}
			if ( 403 === status && '-1' === String( xhr.responseText || '' ).trim() ) {
				// nonceの期限切れ。check_ajax_referer()は、403と本文の-1で答える
				return 'ページの有効期限が切れた可能性があります。読み込み直して、もう一度お試しください。';
			}
			if ( 400 === status && '0' === String( xhr.responseText || '' ).trim() ) {
				// ログアウト。admin-ajax.phpは、ログインしていない人のwp_ajax_*に、400と本文の0で答える
				return 'ログインが切れています。もう一度ログインしてから、やり直してください。';
			}
			if ( status >= 400 ) {
				return '順序を保存できませんでした（HTTP ' + status + '）。もう一度お試しください。';
			}
			if ( ! status ) {
				return '順序を保存できませんでした。サーバーと通信できませんでした。接続を確かめて、もう一度お試しください。';
			}
			return RETRY_MESSAGE;
		}

		// 落とした行を、同じ親を持つ兄弟のなかの順位として収め直す
		// （前の兄弟のサブツリーの直後へ。前の兄弟がなければ親の直後へ。
		// 親が最上位（0）なら先頭へ。親が一覧に出ていない行（絞り込み中）は、落とした位置のまま）。
		// IDのない行（クイック編集の行など）は兄弟に数えない（数えると、親0の最上位の兄弟として扱われる）
		function placeAmongSiblings( $item ) {
			var parent = rowParent( $item );
			var $rows = $list.children( 'tr' );
			var siblingsBefore = [];
			var passedItem = false;
			var $parentRow = null;
			$rows.each( function () {
				var $row = $( this );
				if ( $row.is( $item ) ) {
					passedItem = true;
					return;
				}
				if ( ! rowId( $row ) ) {
					return;
				}
				if ( parent && rowId( $row ) === parent ) {
					$parentRow = $row;
				}
				if ( ! passedItem && rowParent( $row ) === parent ) {
					siblingsBefore.push( $row );
				}
			} );

			var $anchor = null;
			if ( siblingsBefore.length ) {
				$anchor = subtreeEnd( siblingsBefore[ siblingsBefore.length - 1 ], $item );
			} else if ( $parentRow ) {
				$anchor = $parentRow;
			}

			if ( $anchor ) {
				if ( $anchor.next( 'tr' )[ 0 ] !== $item[ 0 ] ) {
					$anchor.after( $item );
				}
			} else if ( ! parent && $rows.first()[ 0 ] !== $item[ 0 ] ) {
				$list.prepend( $item );
			}
		}

		// ドラッグ中に外しておく子孫の行
		var $draggedDescendants = $();

		$list.sortable( {
			items: '> tr',
			handle: '.check-column',
			axis: 'y',
			cursor: 'grabbing',
			opacity: 0.8,
			placeholder: 'obentou-sortable-placeholder',
			// テーブル行の列幅を維持するヘルパー
			helper: function ( e, tr ) {
				var $originals = tr.children();
				var $helper = tr.clone();
				$helper.children().each( function ( i ) {
					$( this ).width( $originals.eq( i ).outerWidth() );
				} );
				return $helper;
			},
			// プレースホルダーにセル構造を追加し、子孫の行を外す（親を動かすと子孫がついてくる）。
			// colspanは見えているセルだけで数える（隠した列のセルまで数えると、ドラッグ中に表の列幅が崩れる）
			start: function ( e, ui ) {
				ui.placeholder.html( '<td colspan="' + ui.item.children( ':not(.hidden)' ).length + '"></td>' );
				$draggedDescendants = descendantRows( ui.item ).detach();
				// 外した行の分だけ表の高さが変わるので、並びの判定に使う位置を測り直す
				// （refreshは使わない。items: '> tr'がドラッグ中のヘルパーとプレースホルダーまで拾うため）
				$list.sortable( 'refreshPositions' );
			},
			// 落とした位置を兄弟のなかの順位として収め直し、子孫を戻してから、保存していない並び替えがあるかを決める
			stop: function ( e, ui ) {
				placeAmongSiblings( ui.item );
				ui.item.after( $draggedDescendants );
				$draggedDescendants = $();
				refreshDirty();
			},
		} );

		// 保存処理
		$saveBtn.on( 'click', function () {
			var ids = currentIds();
			var order = $.map( ids, function ( id, index ) {
				return { id: id, position: index };
			} );
			if ( ! order.length ) {
				return;
			}

			$saveBtn.prop( 'disabled', true );
			// 応答が返るまでは並べ替えさせない（待つあいだの変更を「保存しました」で消さないため）
			$list.sortable( 'disable' );
			$status.text( '保存中...' );

			// 順序はJSON文字列1つで送る（行ごとに変数を分けると、大きな一覧でmax_input_varsを超えた分が黙って欠けるため）。
			// 送った件数も添え、サーバーは届いた件数と食い違えば保存しない。
			var payload = { action: data.action, nonce: data.nonce, order: JSON.stringify( order ), count: order.length };
			payload[ data.kind === 'post' ? 'post_type' : 'taxonomy' ] = data.objectType;

			$.post( data.ajaxUrl, payload )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						showError( ( response && response.data && response.data.message ) || RETRY_MESSAGE );
						return;
					}
					savedIds = ids;
					// 順序列と、クイック編集の隠しデータの順序を、保存した位置に合わせる
					// （読み込み直さずにクイック編集で更新したとき、古い順序で上書きされないように）
					$.each( order, function ( i, item ) {
						$( '#' + data.idPrefix + item.id ).find( '.column-obentou_order' ).text( item.position );
						$( '#inline_' + item.id + ' .menu_order' ).text( item.position );
					} );
					refreshDirty();
					showNotice( ( response.data && response.data.message ) || '順序を保存しました。', 'success' );
				} )
				.fail( function ( xhr ) {
					showError( failMessage( xhr ) );
				} )
				.always( function () {
					$list.sortable( 'enable' );
				} );
		} );
	} );
} )( jQuery );
