<?php
/**
 * タームの並び替え（保存、AJAX、表側の適用）
 *
 * 順序はterm meta _obentou_orderに持つ。表側は2つの経路で効かせる。
 * get_terms()などタクソノミー1つの取得は、terms_clausesでSQLのORDER BYを差し替える。
 * 投稿に付いたタームは、WP_Queryが全タクソノミーをまとめて取ってキャッシュに入れる（terms_clausesを通らない）ので、
 * get_the_termsフィルタで読み出すときに並べ替える。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * タームの順序を保存する
 *
 * そのタクソノミーにないIDは飛ばす。値が変わるものだけ書く。
 *
 * @param string $taxonomy タクソノミー名。
 * @param array  $order    array( array( 'id' => int, 'position' => int ), ... )。
 * @return array|WP_Error array( 'updated' => int, 'skipped' => int, 'failed' => int )。
 */
function obentou_apply_term_order( $taxonomy, $order ) {
	if ( ! obentou_is_order_taxonomy( $taxonomy ) ) {
		return new WP_Error( 'obentou_not_orderable', 'このタクソノミーは並び替えの対象ではありません。設定 > Obentou Admin Packで対象にしてください。' );
	}
	if ( ! is_array( $order ) || empty( $order ) ) {
		return new WP_Error( 'obentou_invalid_order', '並び替えのデータが不正です。ページを読み込み直して、もう一度並び替えてください。' );
	}

	$result = array(
		'updated' => 0,
		'skipped' => 0,
		'failed'  => 0,
	);
	$ids    = array();
	foreach ( $order as $item ) {
		$id       = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
		$position = isset( $item['position'] ) ? absint( $item['position'] ) : 0;
		$term     = $id ? get_term( $id, $taxonomy ) : null;
		if ( ! $term || is_wp_error( $term ) ) {
			++$result['skipped'];
			continue;
		}
		$current = get_term_meta( $id, '_obentou_order', true );
		if ( '' !== $current && (int) $current === $position ) {
			$ids[] = $id;
			continue;
		}
		$updated = update_term_meta( $id, '_obentou_order', $position );
		if ( false === $updated || is_wp_error( $updated ) ) {
			++$result['failed'];
			error_log( sprintf( 'Obentou Admin Pack: ターム%dの順序を保存できませんでした。', $id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 失敗を運用側が気付けるように残す
			continue;
		}
		++$result['updated'];
		$ids[] = $id;
	}

	if ( $ids ) {
		obentou_mark_order_saved( 'taxonomies', $taxonomy );
		do_action( 'obentou_term_order_saved', $taxonomy, $ids );
	}
	return $result;
}

/**
 * AJAX: タームの順序を保存する
 */
function obentou_ajax_save_term_order() {
	check_ajax_referer( 'obentou_order', 'nonce' );

	// タクソノミー名はsanitize_key()で小文字にしない（register_taxonomy()は大文字を含む名前もそのまま登録する）。
	// 文字列であることだけを確かめ、obentou_authorize_term_order()がtaxonomy_exists()と設定の許可リストで判定する
	$taxonomy = isset( $_POST['taxonomy'] ) ? wp_unslash( $_POST['taxonomy'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 登録済みの名前と許可リストに完全一致するものだけを通す（上のコメント）
	if ( ! is_string( $taxonomy ) ) {
		$taxonomy = '';
	}
	$object = obentou_authorize_term_order( $taxonomy );
	if ( is_wp_error( $object ) ) {
		obentou_send_order_result( $object );
	}
	$order = obentou_read_order_payload();
	if ( is_wp_error( $order ) ) {
		obentou_send_order_result( $order );
	}
	obentou_send_order_result( obentou_apply_term_order( $taxonomy, $order ) );
}
add_action( 'wp_ajax_obentou_save_term_order', 'obentou_ajax_save_term_order' );

/**
 * 保存した順序でタームを並べる（ORDER BYの差し替え）
 *
 * 対象のタクソノミーで、一度でも保存していて、orderbyが既定（name）のときだけ。
 * 降順の指定（wp_list_categories( array( 'order' => 'DESC' ) )やREST APIのorder=desc）は、コアの名前の降順に任せる。
 * 降順かどうかは、コアが正規化した$clauses['order']で決める（コアはASC以外をすべてDESCとして扱うので、'DESCENDING'のような値も降順になる）。
 * メタの値は相関サブクエリで取り、JOINで行が増えて件数やリストが重複する事故を防ぐ。
 * ターム一覧（edit-tags.php）で列のソートを指定しているときは触らない。投稿一覧のorderbyは投稿の並びなので、絞り込みのドロップダウンには保存順を効かせる。
 * タクソノミーが2つ以上のクエリは通らない。WP_Queryが投稿の読み込みで投稿タイプの全タクソノミーを1回のクエリで取り、
 * キャッシュに名前順で入れる経路がそれに当たるので、キャッシュから読むget_the_terms()は、obentou_sort_the_terms()が読み出すときに並べ替える。
 *
 * @param array    $clauses    fields / join / where / distinct / orderby / order / limits。
 * @param string[] $taxonomies タクソノミー名の配列。
 * @param array    $args       クエリの引数。
 * @return array
 */
function obentou_apply_term_order_to_clauses( $clauses, $taxonomies, $args ) {
	global $wpdb, $pagenow;

	$taxonomies = array_values( (array) $taxonomies );
	if ( 1 !== count( $taxonomies ) ) {
		return $clauses;
	}
	$taxonomy = $taxonomies[0];
	if ( ! obentou_is_order_taxonomy( $taxonomy ) || ! obentou_has_saved_order( 'taxonomies', $taxonomy ) ) {
		return $clauses;
	}
	$orderby = isset( $args['orderby'] ) ? $args['orderby'] : 'name';
	if ( ! is_string( $orderby ) || 'name' !== $orderby ) {
		return $clauses;
	}
	if ( isset( $clauses['order'] ) && 'ASC' !== strtoupper( (string) $clauses['order'] ) ) {
		return $clauses;
	}
	if ( isset( $args['fields'] ) && 'count' === $args['fields'] ) {
		return $clauses;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 列のソートの有無を読むだけ
	if ( is_admin() && 'edit-tags.php' === $pagenow && ! empty( $_GET['orderby'] ) ) {
		return $clauses;
	}

	$subquery           = $wpdb->prepare(
		"(SELECT CAST(obentou_tm.meta_value AS SIGNED) FROM {$wpdb->termmeta} AS obentou_tm WHERE obentou_tm.term_id = t.term_id AND obentou_tm.meta_key = %s LIMIT 1)",
		'_obentou_order'
	);
	$clauses['orderby'] = "ORDER BY COALESCE({$subquery}, 2147483647) ASC, t.name";
	$clauses['order']   = 'ASC';
	return $clauses;
}
add_filter( 'terms_clauses', 'obentou_apply_term_order_to_clauses', 10, 3 );

/**
 * 投稿に付いたタームを保存順に並べ替える（get_the_terms()の結果）
 *
 * WP_Queryは投稿を読み込むとき、投稿タイプの全タクソノミーを1回のクエリで取り、名前順でキャッシュに入れる。
 * タクソノミーが2つ以上のクエリはterms_clausesで差し替えないので、そのあとのget_the_terms()はキャッシュの名前順をそのまま返す。
 * そこで、読み出すときに並べ替える（永続オブジェクトキャッシュに古い順序が残っていても、読むたびに保存順になる）。
 * 対象のタクソノミーで、一度でも保存しているときだけ。順序のないタームは、順序のあるものの後ろに並べる。
 * 順序が同じ（または、どちらもない）ものは、名前のstrcmp()で決める。
 *
 * @param WP_Term[]|WP_Error $terms    投稿に付いたターム。
 * @param int                $post_id  投稿ID。
 * @param string             $taxonomy タクソノミー名。
 * @return WP_Term[]|WP_Error
 */
function obentou_sort_the_terms( $terms, $post_id, $taxonomy ) {
	if ( ! is_array( $terms ) || ! $terms ) {
		return $terms;
	}
	if ( ! obentou_is_order_taxonomy( $taxonomy ) || ! obentou_has_saved_order( 'taxonomies', $taxonomy ) ) {
		return $terms;
	}

	$positions = array();
	foreach ( $terms as $term ) {
		if ( ! is_object( $term ) || ! isset( $term->term_id ) ) {
			return $terms;
		}
		$saved                       = get_term_meta( $term->term_id, '_obentou_order', true );
		$positions[ $term->term_id ] = '' === $saved ? PHP_INT_MAX : (int) $saved;
	}

	usort(
		$terms,
		static function ( $a, $b ) use ( $positions ) {
			if ( $positions[ $a->term_id ] !== $positions[ $b->term_id ] ) {
				return $positions[ $a->term_id ] < $positions[ $b->term_id ] ? -1 : 1;
			}
			return strcmp( $a->name, $b->name );
		}
	);
	return $terms;
}
add_filter( 'get_the_terms', 'obentou_sort_the_terms', 10, 3 );
