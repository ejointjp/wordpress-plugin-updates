<?php
/**
 * ID列と、IDとスラッグの検索
 *
 * show_uiの投稿タイプ（メディアを含む）・タクソノミー・ユーザーの一覧に、チェック欄の直後へ「ID」列を足す。
 * 投稿とタームの一覧の検索欄では、数字だけを入れたときはそのIDの項目を、スラッグと完全に一致する語を入れたときは
 * そのスラッグの項目を、1件だけ出す（どちらでもなければ通常の検索）。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 列のフックを登録する（投稿タイプとタクソノミーが登録されたあとに走らせる）
 */
function obentou_id_column_init() {
	foreach ( get_post_types( array( 'show_ui' => true ), 'names' ) as $post_type ) {
		if ( 'attachment' === $post_type ) {
			continue;
		}
		add_filter( "manage_{$post_type}_posts_columns", 'obentou_add_id_column' );
		add_filter( "manage_edit-{$post_type}_sortable_columns", 'obentou_add_id_sortable_column' );
	}
	add_filter( 'manage_media_columns', 'obentou_add_id_column' );
	add_filter( 'manage_upload_sortable_columns', 'obentou_add_id_sortable_column' );

	foreach ( obentou_get_taxonomies() as $taxonomy => $object ) {
		add_filter( "manage_edit-{$taxonomy}_columns", 'obentou_add_id_column' );
		add_filter( "manage_{$taxonomy}_custom_column", 'obentou_render_term_id_column', 10, 3 );
		add_filter( "manage_edit-{$taxonomy}_sortable_columns", 'obentou_add_id_sortable_column_terms' );
	}

	add_filter( 'manage_users_columns', 'obentou_add_id_column' );
	add_filter( 'manage_users_custom_column', 'obentou_render_user_id_column', 10, 3 );
	add_filter( 'manage_users_sortable_columns', 'obentou_add_id_sortable_column' );
}
add_action( 'admin_init', 'obentou_id_column_init' );

/**
 * 列の一覧に「ID」を足す（チェック欄の直後。チェック欄がなければ先頭）
 *
 * @param array $columns 列のキー => 見出し。
 * @return array
 */
function obentou_add_id_column( $columns ) {
	$columns = is_array( $columns ) ? $columns : array();
	if ( isset( $columns['obentou_id'] ) ) {
		return $columns;
	}
	$head = array();
	if ( isset( $columns['cb'] ) ) {
		$head['cb'] = $columns['cb'];
		unset( $columns['cb'] );
	}
	$head['obentou_id'] = 'ID';
	return $head + $columns;
}

/**
 * ID列をソート可にする（投稿・メディア・ユーザー。orderbyはID）
 *
 * @param array $columns ソート可の列。
 * @return array
 */
function obentou_add_id_sortable_column( $columns ) {
	$columns['obentou_id'] = 'ID';
	return $columns;
}

/**
 * ID列をソート可にする（ターム。orderbyはid）
 *
 * @param array $columns ソート可の列。
 * @return array
 */
function obentou_add_id_sortable_column_terms( $columns ) {
	$columns['obentou_id'] = 'id';
	return $columns;
}

/**
 * 投稿・固定ページ・メディアのID列の中身
 *
 * @param string $column  列のキー。
 * @param int    $post_id 投稿ID。
 */
function obentou_render_post_id_column( $column, $post_id ) {
	if ( 'obentou_id' === $column ) {
		echo (int) $post_id;
	}
}
add_action( 'manage_posts_custom_column', 'obentou_render_post_id_column', 10, 2 );
add_action( 'manage_pages_custom_column', 'obentou_render_post_id_column', 10, 2 );
add_action( 'manage_media_custom_column', 'obentou_render_post_id_column', 10, 2 );

/**
 * タームのID列の中身
 *
 * @param string $content 既定の中身。
 * @param string $column  列のキー。
 * @param int    $term_id タームID。
 * @return string
 */
function obentou_render_term_id_column( $content, $column, $term_id ) {
	return 'obentou_id' === $column ? (string) (int) $term_id : $content;
}

/**
 * ユーザーのID列の中身
 *
 * @param string $output  既定の中身。
 * @param string $column  列のキー。
 * @param int    $user_id ユーザーID。
 * @return string
 */
function obentou_render_user_id_column( $output, $column, $user_id ) {
	return 'obentou_id' === $column ? (string) (int) $user_id : $output;
}

/**
 * ID列の幅（一覧の画面だけ。コアのlist-tablesに添える）
 */
function obentou_id_column_style() {
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->base, array( 'edit', 'upload', 'edit-tags', 'users' ), true ) ) {
		return;
	}
	wp_add_inline_style( 'list-tables', '.wp-list-table .column-obentou_id { width: 60px; }' );
}
add_action( 'admin_enqueue_scripts', 'obentou_id_column_style' );

/**
 * 検索語を、スラッグの完全一致に使う値にする
 *
 * 空白を含む語は、スラッグではなく複数の語句として検索したいので対象にしない。
 * sanitize_title()は小文字にし、日本語などはパーセントエンコードするので、保存されているスラッグと同じ形になる
 * （日本語のまま入れても、エンコードした形で入れても一致する）。
 *
 * @param string $s 検索語（trim済み）。
 * @return string スラッグ。対象でないとき（空白を含む、スラッグにすると空になる）は空文字。
 */
function obentou_search_to_slug( $s ) {
	if ( preg_match( '/\s/u', $s ) ) {
		return '';
	}
	return sanitize_title( $s );
}

/**
 * 一覧の見出しの「〜の検索結果」に、検索語を残す
 *
 * IDやスラッグの検索では、クエリのsを空にしてpに置き換える。そのままだと見出しから検索語が消えるので、
 * sが空のときだけ、元の検索語をget_search_query()が返すようにする。
 *
 * @param string $s 元の検索語。
 */
function obentou_keep_search_query( $s ) {
	add_filter(
		'get_search_query',
		static function ( $value ) use ( $s ) {
			return '' === $value ? $s : $value;
		}
	);
}

/**
 * 検索語がスラッグと完全に一致する投稿のIDを返す
 *
 * 探すのは一覧の投稿タイプの中だけ。post_statusはanyなので、ゴミ箱と自動下書きの投稿は含まない。
 * nameはpost_nameとの完全一致で、階層ありの投稿タイプでも同じ（親は見ない）。
 * suppress_filtersをfalseにして、ほかのプラグインがposts_whereなどで入れる絞り込みも通す（get_posts()の既定は通さない）。
 *
 * @param string $s         検索語（trim済み）。
 * @param string $post_type 一覧の投稿タイプ。
 * @return int 投稿ID。見つからなければ0。
 */
function obentou_find_post_id_by_slug( $s, $post_type ) {
	$slug = obentou_search_to_slug( $s );
	if ( '' === $slug ) {
		return 0;
	}
	$found = get_posts(
		array(
			'name'             => $slug,
			'post_type'        => $post_type,
			'post_status'      => 'any',
			'numberposts'      => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);
	return $found ? (int) $found[0] : 0;
}

/**
 * 投稿一覧の検索欄にIDかスラッグを入れたら、その投稿を1件出す
 *
 * 数字だけの語はIDとして扱い（スラッグは見ない）、そのIDの投稿が存在し、投稿タイプが一覧と同じときだけ使う。
 * 0（s=0など）はIDとして扱わない（get_post( 0 )はグローバルの$postを返しうるため）。
 * 数字だけでない語は、空白を含まず、sanitize_title()に通した値が、一覧の投稿タイプの投稿のスラッグ（post_name）と
 * 完全に一致するときだけ使う（ゴミ箱と自動下書きは探さない）。
 * どちらでもなければ何もしない（通常の検索になる）。使うときは、pにIDを入れてsを空にし、
 * 見出しに検索語が表示されるようにフィルタで復元する。
 *
 * @param WP_Query $query 一覧のクエリ。
 */
function obentou_id_search_posts( $query ) {
	global $pagenow;
	if ( ! is_admin() || 'edit.php' !== $pagenow || ! $query->is_main_query() ) {
		return;
	}
	// pre_get_postsの時点のsは、スラッシュが付いている（通常の検索では、あとでコアが外す）
	$s         = trim( wp_unslash( (string) $query->get( 's' ) ) );
	$post_type = $query->get( 'post_type' );
	if ( '' === $s || ! is_string( $post_type ) || '' === $post_type ) {
		return;
	}
	if ( ctype_digit( $s ) ) {
		$post    = (int) $s > 0 ? get_post( (int) $s ) : null;
		$post_id = $post && $post->post_type === $post_type ? (int) $post->ID : 0;
	} else {
		$post_id = obentou_find_post_id_by_slug( $s, $post_type );
	}
	if ( ! $post_id ) {
		return;
	}
	$query->set( 'p', $post_id );
	$query->set( 's', '' );
	obentou_keep_search_query( $s );
}
add_action( 'pre_get_posts', 'obentou_id_search_posts' );

/**
 * ターム一覧の検索欄にIDかスラッグを入れたら、そのタームを1件出す
 *
 * 数字だけの語はIDとして扱い（スラッグは見ない）、そのタクソノミーにそのIDのタームが存在するときだけ使う。
 * 投稿と同じく、0はIDとして扱わない。数字だけでない語は、空白を含まず、sanitize_title()に通した値が、
 * そのタクソノミーのタームのスラッグと完全に一致するときだけ使う。どちらでもなければ何もしない（通常の検索になる）。
 * 使うときは、includeにそのタームのIDを入れてsearchを空にする。
 * 件数を数えるwp_count_terms()にも同じ引数が通るので、ページ送りも1件になる。
 *
 * @param array $args       get_terms()の引数。
 * @param array $taxonomies タクソノミー名の配列。
 * @return array
 */
function obentou_id_search_terms( $args, $taxonomies ) {
	global $pagenow;
	if ( ! is_admin() || 'edit-tags.php' !== $pagenow || empty( $args['search'] ) ) {
		return $args;
	}
	$s          = trim( (string) $args['search'] );
	$taxonomies = isset( $args['taxonomy'] ) ? (array) $args['taxonomy'] : (array) $taxonomies;
	if ( '' === $s || 1 !== count( $taxonomies ) ) {
		return $args;
	}
	$taxonomy = reset( $taxonomies );
	if ( ctype_digit( $s ) ) {
		$term = (int) $s > 0 ? get_term( (int) $s, $taxonomy ) : null;
	} else {
		$slug = obentou_search_to_slug( $s );
		$term = '' === $slug ? null : get_term_by( 'slug', $slug, $taxonomy );
	}
	if ( ! $term || is_wp_error( $term ) ) {
		return $args;
	}
	$args['include'] = array( (int) $term->term_id );
	$args['search']  = '';
	return $args;
}
add_filter( 'get_terms_args', 'obentou_id_search_terms', 10, 2 );
