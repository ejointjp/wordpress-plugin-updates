<?php
/**
 * 自己ホストの更新チェック
 *
 * wordpress.orgには載せていないので、更新の情報は配布用のリポジトリ（ejointjp/wordpress-plugin-updates）に置いたinfo.jsonから取る。
 * メインファイルのヘッダーにUpdate URI（https://yuiami.jp/wp-plugins/obentou）があると、WordPressはこのプラグインの更新を
 * wordpress.orgに問い合わせず、そのホスト名の付いたフィルタupdate_plugins_yuiami.jpを呼ぶ。Update URIは識別子で、実在しなくてよい。
 *
 * - 更新の判定（update_plugins_yuiami.jp）は、キャッシュを読まずに毎回取得する。本体が12時間おきにしか確認しないうえ、
 *   「再確認」ですぐ反映させたいため
 * - 詳細の表示（plugins_api）は、1時間キャッシュした情報を使う
 * - 取得できなければ、理由をPHPのエラーログに残して「更新なし」として扱う
 * - 問い合わせで送るのは、info.jsonのURLと固定のUser-Agentだけ。サイトのURLやデータは送らない
 *
 * 定期の更新チェックはwp-cronで動くので、is_admin()の外で読み込むこと。プラグインが停止中のサイトでは動かない。
 * ひな形と導入の手順は/wp-plugin-publishのreferences/selfhost.md。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const OBENTOU_UPDATE_SLUG     = 'obentou';
const OBENTOU_UPDATE_BASE_URL = 'https://raw.githubusercontent.com/ejointjp/wordpress-plugin-updates/main/obentou/';

/**
 * 更新の情報（info.json）を返す。
 *
 * @param bool $fresh trueならキャッシュを読まずに取得する。
 * @return array|null 取得できなければnull。
 */
function obentou_get_update_info( $fresh ) {
	if ( ! $fresh ) {
		$cached = get_site_transient( 'obentou_update_info' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	// WordPressの既定のUser-AgentはサイトのURLを含む。配布元へ送らないよう、固定の文字列にする
	// 待つ時間は、本体の更新チェック（wp_update_plugins()）の基本の値と同じく、cronでは30秒、それ以外は3秒
	$response = wp_remote_get(
		OBENTOU_UPDATE_BASE_URL . 'info.json',
		array(
			'timeout'    => wp_doing_cron() ? 30 : 3,
			'user-agent' => 'obentou update check',
		)
	);
	if ( is_wp_error( $response ) ) {
		obentou_log_update_error( $response->get_error_message() );
		return null;
	}
	$status = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $status ) {
		obentou_log_update_error( 'HTTP ' . $status );
		return null;
	}
	$info = json_decode( wp_remote_retrieve_body( $response ), true );
	// zipのURLは、このプラグインの置き場にあるものだけを受け付ける
	if (
		! is_array( $info )
		|| '' === obentou_update_field( $info, 'version' )
		|| 0 !== strpos( obentou_update_field( $info, 'package' ), OBENTOU_UPDATE_BASE_URL )
	) {
		obentou_log_update_error( 'info.json is not valid' );
		return null;
	}

	set_site_transient( 'obentou_update_info', $info, HOUR_IN_SECONDS );
	return $info;
}

/**
 * 更新の情報を取得できなかった理由を、PHPのエラーログに残す。
 *
 * @param string $reason 理由。
 */
function obentou_log_update_error( $reason ) {
	error_log( 'Obentou Admin Pack update check: ' . $reason ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 更新の情報を取得できなかった理由を残すため
}

/**
 * 更新の情報から文字列の項目を取り出す。なければ空文字。
 *
 * @param array  $info 更新の情報。
 * @param string $key  項目名。
 * @return string
 */
function obentou_update_field( array $info, $key ) {
	return isset( $info[ $key ] ) && is_string( $info[ $key ] ) ? $info[ $key ] : '';
}

/**
 * 「Tested up to」を、サイトのWordPressと同じ系列なら、サイトの版に読み替える。
 *
 * readme.txtにはメジャー番号だけ（7.1）を書く。本体はversion_compare()で比べるので、そのまま返すと、
 * 7.1.2のサイトで「テストされていない」と表示される。wordpress.orgのAPIも、同じ系列の最新のパッチ版に読み替えて返す。
 *
 * @param string $tested info.jsonのtested。
 * @return string
 */
function obentou_update_tested( $tested ) {
	$current = get_bloginfo( 'version' );
	if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $current, $tested . '.' ) ) {
		return $current;
	}
	return $tested;
}

/**
 * 更新の判定に、配布用のリポジトリにある最新版の情報を返す。新しいかどうかは本体が比べる。
 *
 * @param array|false $update      ここまでのフィルタの結果。
 * @param array       $plugin_data プラグインのヘッダー。
 * @param string      $plugin_file プラグインのファイル（plugin_basename()の形）。
 * @return array|false
 */
function obentou_filter_update( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( OBENTOU_FILE ) !== $plugin_file ) {
		return $update;
	}
	$info = obentou_get_update_info( true );
	if ( null === $info ) {
		return $update;
	}
	return array(
		'slug'         => OBENTOU_UPDATE_SLUG,
		'version'      => $info['version'],
		'package'      => $info['package'],
		'url'          => isset( $plugin_data['AuthorURI'] ) ? $plugin_data['AuthorURI'] : '',
		'requires'     => obentou_update_field( $info, 'requires' ),
		'requires_php' => obentou_update_field( $info, 'requires_php' ),
		'tested'       => obentou_update_tested( obentou_update_field( $info, 'tested' ) ),
	);
}
add_filter( 'update_plugins_yuiami.jp', 'obentou_filter_update', 10, 3 );

/**
 * 「詳細を表示」のポップアップに、配布用のリポジトリにある情報を返す。
 *
 * @param false|object|array $result ここまでのフィルタの結果。
 * @param string             $action plugins_api()の種類。
 * @param object             $args   plugins_api()の引数。
 * @return false|object|array|WP_Error
 */
function obentou_filter_plugin_information( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || ! isset( $args->slug ) || OBENTOU_UPDATE_SLUG !== $args->slug ) {
		return $result;
	}
	$info = obentou_get_update_info( false );
	if ( null === $info ) {
		// falseのまま返すと、本体がwordpress.orgの同じslugを見に行く。エラーにして止める
		return new WP_Error( 'obentou_update_info', '更新情報を取得できませんでした。後ほどもう一度お試しください。' );
	}
	$sections = isset( $info['sections'] ) && is_array( $info['sections'] ) ? array_filter( $info['sections'], 'is_string' ) : array();
	return (object) array(
		'name'          => esc_html( obentou_update_field( $info, 'name' ) ),
		'slug'          => OBENTOU_UPDATE_SLUG,
		'version'       => $info['version'],
		'author'        => esc_html( obentou_update_field( $info, 'author' ) ),
		'requires'      => obentou_update_field( $info, 'requires' ),
		'requires_php'  => obentou_update_field( $info, 'requires_php' ),
		'tested'        => obentou_update_tested( obentou_update_field( $info, 'tested' ) ),
		'last_updated'  => obentou_update_field( $info, 'last_updated' ),
		'sections'      => $sections,
		'download_link' => $info['package'],
		'external'      => true, // wordpress.orgのプラグインページへのリンクを出さない
	);
}
add_filter( 'plugins_api', 'obentou_filter_plugin_information', 10, 3 );
