<?php
/**
 * 一覧の絞り込み（タクソノミーのドロップダウンと、親ページのドロップダウン）
 *
 * ドロップダウンの値はobentou_filter[タクソノミー]（スラッグ）とobentou_parent（投稿ID）で受け取り、
 * pre_get_postsで一覧のクエリに入れる。タクソノミーのquery_varには頼らない。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * いま選ばれている絞り込みの値（スラッグ）を返す
 *
 * @param string $taxonomy タクソノミー名。
 * @return string 選ばれていなければ空。
 */
function obentou_get_filter_value( $taxonomy ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 一覧の表示条件を読むだけ
	if ( empty( $_GET['obentou_filter'] ) || ! is_array( $_GET['obentou_filter'] ) || ! isset( $_GET['obentou_filter'][ $taxonomy ] ) ) {
		return '';
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 一覧の表示条件を読むだけ; is_string() 検証後に wp_unslash() と sanitize_title()
	$raw = $_GET['obentou_filter'][ $taxonomy ];
	if ( ! is_string( $raw ) ) {
		return '';
	}
	$value = sanitize_title( wp_unslash( $raw ) );
	return ( '' === $value || '0' === $value ) ? '' : $value;
}

/**
 * いま選ばれている親の投稿IDを返す
 *
 * @return int 選ばれていなければ0。
 */
function obentou_get_parent_filter_value() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 一覧の表示条件を読むだけ
	return isset( $_GET['obentou_parent'] ) ? absint( $_GET['obentou_parent'] ) : 0;
}

/**
 * 投稿一覧の上にドロップダウンを出す
 *
 * コアのカテゴリーの絞り込みと同じく、どのドロップダウンにもスクリーンリーダー用のラベルを付ける。
 * タクソノミーのラベルはいつも「{単数形ラベル}で絞り込み」にする。labels->filter_by_itemは使わない
 * （コアは階層ありのタクソノミーの既定を「カテゴリーで絞り込む」で埋めるので、どのドロップダウンも、コアのカテゴリーのものと同じ名前になる）。
 * 親のラベルは先頭の選択肢と同じ文言。
 *
 * @param string $post_type 投稿タイプ。
 * @param string $which     top / bottom。
 */
function obentou_render_list_filters( $post_type, $which = 'top' ) {
	if ( 'top' !== $which ) {
		return;
	}

	foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy ) {
		if ( 'category' === $taxonomy->name || ! $taxonomy->show_ui || ! obentou_is_filter_taxonomy( $taxonomy->name ) ) {
			continue;
		}
		$id       = 'obentou-filter-' . $taxonomy->name;
		$dropdown = wp_dropdown_categories(
			array(
				'show_option_all' => $taxonomy->labels->all_items,
				'taxonomy'        => $taxonomy->name,
				'name'            => 'obentou_filter[' . $taxonomy->name . ']',
				'id'              => $id,
				'value_field'     => 'slug',
				'selected'        => obentou_get_filter_value( $taxonomy->name ),
				'hide_empty'      => false,
				'hierarchical'    => true,
				'hide_if_empty'   => true,
				'orderby'         => 'name',
				'echo'            => false,
			)
		);
		// タームが1つもなく、ドロップダウンを出さないときは、ラベルも出さない
		if ( '' === $dropdown ) {
			continue;
		}
		$label = sprintf( '%sで絞り込み', $taxonomy->labels->singular_name );
		printf( '<label class="screen-reader-text" for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $label ) );
		echo $dropdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_dropdown_categories()がエスケープして組み立てたHTML
	}

	if ( is_post_type_hierarchical( $post_type ) ) {
		$object = get_post_type_object( $post_type );
		$label  = sprintf( '%sの親で絞り込み', $object->labels->singular_name );
		// 非公開の投稿は、その投稿タイプの非公開の投稿を読める人にだけ選択肢に出す
		$statuses = current_user_can( $object->cap->read_private_posts )
			? array( 'publish', 'private', 'draft', 'pending', 'future' )
			: array( 'publish', 'draft', 'pending', 'future' );
		$dropdown = wp_dropdown_pages(
			array(
				'post_type'         => esc_attr( $post_type ),
				'name'              => 'obentou_parent',
				'id'                => 'obentou-parent',
				'show_option_none'  => esc_html( $label ),
				'option_none_value' => '',
				'selected'          => (int) obentou_get_parent_filter_value(),
				'post_status'       => $statuses, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 出力する値ではない（ステータス名の配列。echoをfalseにして、組み立てたHTMLを下で出す）
				'sort_column'       => 'menu_order, post_title',
				'echo'              => false,
			)
		);
		if ( '' !== $dropdown ) {
			printf( '<label class="screen-reader-text" for="obentou-parent">%s</label>', esc_html( $label ) );
			echo $dropdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_dropdown_pages()がエスケープして組み立てたHTML
		}
	}
}
add_action( 'restrict_manage_posts', 'obentou_render_list_filters', 10, 2 );

/**
 * ドロップダウンの値を一覧のクエリに入れる
 *
 * 複数のドロップダウンを選んだときはAND。ほかの処理が入れたtax_queryが自分のrelation（ORなど）を持つときは、
 * それを上書きせずに入れ子にして、ANDで組み合わせる。
 *
 * @param WP_Query $query 一覧のクエリ。
 */
function obentou_apply_list_filters( $query ) {
	global $pagenow;
	if ( ! is_admin() || 'edit.php' !== $pagenow || ! $query->is_main_query() ) {
		return;
	}
	$post_type = $query->get( 'post_type' );
	if ( ! is_string( $post_type ) || '' === $post_type ) {
		return;
	}

	$existing = $query->get( 'tax_query' );
	$clauses  = array();
	foreach ( get_object_taxonomies( $post_type, 'names' ) as $taxonomy ) {
		if ( 'category' === $taxonomy || ! obentou_is_filter_taxonomy( $taxonomy ) ) {
			continue;
		}
		$slug = obentou_get_filter_value( $taxonomy );
		if ( '' === $slug ) {
			continue;
		}
		$clauses[] = array(
			'taxonomy' => $taxonomy,
			'field'    => 'slug',
			'terms'    => $slug,
		);
	}
	if ( $clauses ) {
		if ( is_array( $existing ) && isset( $existing['relation'] ) ) {
			$tax_query = array_merge(
				array(
					'relation' => 'AND',
					$existing,
				),
				$clauses
			);
		} else {
			$tax_query             = array_merge( array_filter( (array) $existing, 'is_array' ), $clauses );
			$tax_query['relation'] = 'AND';
		}
		$query->set( 'tax_query', $tax_query );
	}

	$parent = obentou_get_parent_filter_value();
	if ( $parent && is_post_type_hierarchical( $post_type ) && get_post_type( $parent ) === $post_type ) {
		$query->set( 'post_parent', $parent );
	}
}
add_action( 'pre_get_posts', 'obentou_apply_list_filters' );
