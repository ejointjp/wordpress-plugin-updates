<?php
/**
 * Plugin Name:       Obentou Admin Pack
 * Description:       管理画面の一覧にID列・絞り込み・ドラッグ＆ドロップの並び替えを足す、小さな便利機能の詰め合わせ。
 * Version:           0.1.0
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Author:            Takashi Fujisaki
 * Author URI:        https://yuiami.jp
 * Update URI:        https://yuiami.jp/wp-plugins/obentou
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       obentou
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OBENTOU_VERSION', '0.1.0' );
define( 'OBENTOU_FILE', __FILE__ );
define( 'OBENTOU_DIR', plugin_dir_path( __FILE__ ) );
define( 'OBENTOU_URL', plugin_dir_url( __FILE__ ) );

// 自己ホストの更新チェック。定期の更新チェックはwp-cronで動くので、is_admin()の中に入れない。
require_once OBENTOU_DIR . 'includes/update-checker.php';
require_once OBENTOU_DIR . 'includes/settings.php';
require_once OBENTOU_DIR . 'includes/id-column.php';
require_once OBENTOU_DIR . 'includes/list-filters.php';
require_once OBENTOU_DIR . 'includes/order-common.php';
require_once OBENTOU_DIR . 'includes/order-posts.php';
require_once OBENTOU_DIR . 'includes/order-terms.php';
