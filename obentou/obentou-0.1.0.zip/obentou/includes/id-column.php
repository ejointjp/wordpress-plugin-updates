<?php
/**
 * ID列とID検索
 *
 * show_uiの投稿タイプ（メディアを含む）・タクソノミー・ユーザーの一覧に、チェック欄の直後へ「ID」列を足す。
 * 検索欄に数字だけを入れたときは、そのIDの項目を1件出す。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 列のフックを登録する（投稿タイプとタクソノミーが登録されたあとに走らせる）
 */
function obentou_id_column_init() {
	foreach ( get_post_types( array( 'show_ui' => true ), 'names' ) as $post_type ) {
		if ( 'attachment' === $post_type ) {
			continue;
		}
		add_filter( "manage_{$post_type}_posts_columns", 'obentou_add_id_column' );
		add_filter( "manage_edit-{$post_type}_sortable_columns", 'obentou_add_id_sortable_column' );
	}
	add_filter( 'manage_media_columns', 'obentou_add_id_column' );
	add_filter( 'manage_upload_sortable_columns', 'obentou_add_id_sortable_column' );

	foreach ( obentou_get_taxonomies() as $taxonomy => $object ) {
		add_filter( "manage_edit-{$taxonomy}_columns", 'obentou_add_id_column' );
		add_filter( "manage_{$taxonomy}_custom_column", 'obentou_render_term_id_column', 10, 3 );
		add_filter( "manage_edit-{$taxonomy}_sortable_columns", 'obentou_add_id_sortable_column_terms' );
	}

	add_filter( 'manage_users_columns', 'obentou_add_id_column' );
	add_filter( 'manage_users_custom_column', 'obentou_render_user_id_column', 10, 3 );
	add_filter( 'manage_users_sortable_columns', 'obentou_add_id_sortable_column' );
}
add_action( 'admin_init', 'obentou_id_column_init' );

/**
 * 列の一覧に「ID」を足す（チェック欄の直後。チェック欄がなければ先頭）
 *
 * @param array $columns 列のキー => 見出し。
 * @return array
 */
function obentou_add_id_column( $columns ) {
	$columns = is_array( $columns ) ? $columns : array();
	if ( isset( $columns['obentou_id'] ) ) {
		return $columns;
	}
	$head = array();
	if ( isset( $columns['cb'] ) ) {
		$head['cb'] = $columns['cb'];
		unset( $columns['cb'] );
	}
	$head['obentou_id'] = 'ID';
	return $head + $columns;
}

/**
 * ID列をソート可にする（投稿・メディア・ユーザー。orderbyはID）
 *
 * @param array $columns ソート可の列。
 * @return array
 */
function obentou_add_id_sortable_column( $columns ) {
	$columns['obentou_id'] = 'ID';
	return $columns;
}

/**
 * ID列をソート可にする（ターム。orderbyはid）
 *
 * @param array $columns ソート可の列。
 * @return array
 */
function obentou_add_id_sortable_column_terms( $columns ) {
	$columns['obentou_id'] = 'id';
	return $columns;
}

/**
 * 投稿・固定ページ・メディアのID列の中身
 *
 * @param string $column  列のキー。
 * @param int    $post_id 投稿ID。
 */
function obentou_render_post_id_column( $column, $post_id ) {
	if ( 'obentou_id' === $column ) {
		echo (int) $post_id;
	}
}
add_action( 'manage_posts_custom_column', 'obentou_render_post_id_column', 10, 2 );
add_action( 'manage_pages_custom_column', 'obentou_render_post_id_column', 10, 2 );
add_action( 'manage_media_custom_column', 'obentou_render_post_id_column', 10, 2 );

/**
 * タームのID列の中身
 *
 * @param string $content 既定の中身。
 * @param string $column  列のキー。
 * @param int    $term_id タームID。
 * @return string
 */
function obentou_render_term_id_column( $content, $column, $term_id ) {
	return 'obentou_id' === $column ? (string) (int) $term_id : $content;
}

/**
 * ユーザーのID列の中身
 *
 * @param string $output  既定の中身。
 * @param string $column  列のキー。
 * @param int    $user_id ユーザーID。
 * @return string
 */
function obentou_render_user_id_column( $output, $column, $user_id ) {
	return 'obentou_id' === $column ? (string) (int) $user_id : $output;
}

/**
 * ID列の幅（一覧の画面だけ。コアのlist-tablesに添える）
 */
function obentou_id_column_style() {
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->base, array( 'edit', 'upload', 'edit-tags', 'users' ), true ) ) {
		return;
	}
	wp_add_inline_style( 'list-tables', '.wp-list-table .column-obentou_id { width: 60px; }' );
}
add_action( 'admin_enqueue_scripts', 'obentou_id_column_style' );

/**
 * 投稿一覧の検索欄に数字だけを入れたら、そのIDの投稿を1件出す
 *
 * そのIDの投稿が存在し、投稿タイプが一覧と同じときだけ。見出しに検索語が表示されるようにフィルタで復元する。
 * 0（s=0など）はIDとして扱わない（get_post( 0 )はグローバルの$postを返しうるため）。
 *
 * @param WP_Query $query 一覧のクエリ。
 */
function obentou_id_search_posts( $query ) {
	global $pagenow;
	if ( ! is_admin() || 'edit.php' !== $pagenow || ! $query->is_main_query() ) {
		return;
	}
	$s = trim( (string) $query->get( 's' ) );
	if ( '' === $s || ! ctype_digit( $s ) || (int) $s <= 0 ) {
		return;
	}
	$post = get_post( (int) $s );
	if ( ! $post || $post->post_type !== $query->get( 'post_type' ) ) {
		return;
	}
	$query->set( 'p', (int) $s );
	$query->set( 's', '' );
	add_filter(
		'get_search_query',
		static function ( $value ) use ( $s ) {
			return '' === $value ? $s : $value;
		}
	);
}
add_action( 'pre_get_posts', 'obentou_id_search_posts' );

/**
 * ターム一覧の検索欄に数字だけを入れたら、そのIDのタームを1件出す
 *
 * 件数を数えるwp_count_terms()にも同じ引数が通るので、ページ送りも1件になる。投稿と同じく、0はIDとして扱わない。
 *
 * @param array $args       get_terms()の引数。
 * @param array $taxonomies タクソノミー名の配列。
 * @return array
 */
function obentou_id_search_terms( $args, $taxonomies ) {
	global $pagenow;
	if ( ! is_admin() || 'edit-tags.php' !== $pagenow || empty( $args['search'] ) ) {
		return $args;
	}
	$s = trim( (string) $args['search'] );
	if ( ! ctype_digit( $s ) || (int) $s <= 0 ) {
		return $args;
	}
	$taxonomies = isset( $args['taxonomy'] ) ? (array) $args['taxonomy'] : (array) $taxonomies;
	if ( 1 !== count( $taxonomies ) ) {
		return $args;
	}
	$term = get_term( (int) $s, reset( $taxonomies ) );
	if ( ! $term || is_wp_error( $term ) ) {
		return $args;
	}
	$args['include'] = array( (int) $s );
	$args['search']  = '';
	return $args;
}
add_filter( 'get_terms_args', 'obentou_id_search_terms', 10, 2 );
