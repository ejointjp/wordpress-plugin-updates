<?php
/**
 * 設定の既定値・読み出し・sanitize・設定画面（設定 > Obentou Admin Pack）
 *
 * optionはobentou_settingsの1つ。保存されていないあいだは実行時に既定値を計算する。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 設定画面に並べる投稿タイプ（show_uiのもの。メディアは除く）
 *
 * @return WP_Post_Type[] 投稿タイプ名 => オブジェクト。
 */
function obentou_get_post_types() {
	$types = get_post_types( array( 'show_ui' => true ), 'objects' );
	unset( $types['attachment'] );
	return $types;
}

/**
 * 設定画面に並べるタクソノミー（show_uiで、show_uiの投稿タイプに付いているもの）
 *
 * link_categoryのように、管理画面に一覧のないものを外す。
 *
 * @return WP_Taxonomy[] タクソノミー名 => オブジェクト。
 */
function obentou_get_taxonomies() {
	$ui_post_types = array_keys( get_post_types( array( 'show_ui' => true ), 'names' ) );
	$taxonomies    = array();
	foreach ( get_taxonomies( array( 'show_ui' => true ), 'objects' ) as $name => $taxonomy ) {
		if ( array_intersect( (array) $taxonomy->object_type, $ui_post_types ) ) {
			$taxonomies[ $name ] = $taxonomy;
		}
	}
	return $taxonomies;
}

/**
 * 設定の既定値（optionが保存されていないあいだに使う）
 *
 * @return array{filter_taxonomies: string[], order_post_types: string[], order_taxonomies: string[]}
 */
function obentou_get_default_settings() {
	$hierarchical_types = array();
	foreach ( obentou_get_post_types() as $name => $type ) {
		if ( $type->hierarchical ) {
			$hierarchical_types[] = $name;
		}
	}
	$taxonomies              = obentou_get_taxonomies();
	$hierarchical_taxonomies = array();
	foreach ( $taxonomies as $name => $taxonomy ) {
		if ( $taxonomy->hierarchical ) {
			$hierarchical_taxonomies[] = $name;
		}
	}
	return array(
		'filter_taxonomies' => $hierarchical_taxonomies,
		'order_post_types'  => $hierarchical_types,
		'order_taxonomies'  => array_keys( $taxonomies ),
	);
}

/**
 * 設定を返す
 *
 * @param string $key filter_taxonomies / order_post_types / order_taxonomies。
 * @return string[]
 */
function obentou_get_setting( $key ) {
	$settings = get_option( 'obentou_settings' );
	if ( ! is_array( $settings ) ) {
		$settings = obentou_get_default_settings();
	}
	return isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
}

/**
 * 絞り込みのドロップダウンを出すタクソノミーか
 *
 * @param string $taxonomy タクソノミー名。
 * @return bool
 */
function obentou_is_filter_taxonomy( $taxonomy ) {
	return taxonomy_exists( $taxonomy ) && in_array( $taxonomy, obentou_get_setting( 'filter_taxonomies' ), true );
}

/**
 * 並び替えの対象の投稿タイプか
 *
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obentou_is_order_post_type( $post_type ) {
	return post_type_exists( $post_type ) && in_array( $post_type, obentou_get_setting( 'order_post_types' ), true );
}

/**
 * 並び替えの対象のタクソノミーか
 *
 * @param string $taxonomy タクソノミー名。
 * @return bool
 */
function obentou_is_order_taxonomy( $taxonomy ) {
	return taxonomy_exists( $taxonomy ) && in_array( $taxonomy, obentou_get_setting( 'order_taxonomies' ), true );
}

/**
 * 名前のリストを、許可された名前だけに絞る
 *
 * 文字列の値だけを残し、許可リストとそのまま突き合わせる。sanitize_key()は通さない
 * （register_taxonomy()は大文字を含む名前もそのまま登録するので、小文字にすると一致しなくなる）。
 * 入れ子の配列などの文字列でない値は、突き合わせる前に捨てる（strval()に渡すと警告が出るため）。
 *
 * @param array    $input   送られてきた設定。
 * @param string   $key     キー。
 * @param string[] $allowed 許可する名前。
 * @return string[] 許可リストの順に並んだ名前。
 */
function obentou_sanitize_name_list( $input, $key, $allowed ) {
	if ( empty( $input[ $key ] ) || ! is_array( $input[ $key ] ) ) {
		return array();
	}
	$values = array_filter( $input[ $key ], 'is_string' );
	return array_values( array_intersect( $allowed, $values ) );
}

/**
 * 設定のsanitize。登録済みでshow_uiのものだけを通す
 *
 * @param mixed $input 送られてきた設定。
 * @return array
 */
function obentou_sanitize_settings( $input ) {
	$input      = is_array( $input ) ? $input : array();
	$taxonomies = array_keys( obentou_get_taxonomies() );
	return array(
		'filter_taxonomies' => obentou_sanitize_name_list( $input, 'filter_taxonomies', $taxonomies ),
		'order_post_types'  => obentou_sanitize_name_list( $input, 'order_post_types', array_keys( obentou_get_post_types() ) ),
		'order_taxonomies'  => obentou_sanitize_name_list( $input, 'order_taxonomies', $taxonomies ),
	);
}

/**
 * 設定画面をメニューに登録する
 */
function obentou_add_settings_page() {
	add_options_page( 'Obentou Admin Pack', 'Obentou Admin Pack', 'manage_options', 'obentou', 'obentou_render_settings_page' );
}
add_action( 'admin_menu', 'obentou_add_settings_page' );

/**
 * 設定とセクション・フィールドを登録する
 */
function obentou_register_settings() {
	register_setting(
		'obentou',
		'obentou_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'obentou_sanitize_settings',
		)
	);

	// 項目名（title）は、チェックボックスの組のlegendにも使うので引数でも渡す
	add_settings_section( 'obentou_filters', '一覧の絞り込み', 'obentou_render_filters_section', 'obentou' );
	$title = 'ドロップダウンを出すタクソノミー';
	add_settings_field(
		'filter_taxonomies',
		$title,
		'obentou_render_taxonomy_checkboxes',
		'obentou',
		'obentou_filters',
		array(
			'key'   => 'filter_taxonomies',
			'title' => $title,
		)
	);

	add_settings_section( 'obentou_order', '並び替え', 'obentou_render_order_section', 'obentou' );
	$title = '対象の投稿タイプ';
	add_settings_field(
		'order_post_types',
		$title,
		'obentou_render_post_type_checkboxes',
		'obentou',
		'obentou_order',
		array(
			'key'   => 'order_post_types',
			'title' => $title,
		)
	);
	$title = '対象のタクソノミー';
	add_settings_field(
		'order_taxonomies',
		$title,
		'obentou_render_taxonomy_checkboxes',
		'obentou',
		'obentou_order',
		array(
			'key'   => 'order_taxonomies',
			'title' => $title,
		)
	);
}
add_action( 'admin_init', 'obentou_register_settings' );

/**
 * 「一覧の絞り込み」セクションの説明
 */
function obentou_render_filters_section() {
	echo '<p>チェックしたタクソノミーのドロップダウンを、投稿一覧の上に出します。カテゴリーはWordPressが出すので、ここには出しません。階層ありの投稿タイプには「親で絞り込み」も出します。</p>';
}

/**
 * 「並び替え」セクションの説明
 */
function obentou_render_order_section() {
	echo '<p>チェックした投稿タイプ・タクソノミーの一覧に「並び替えモード」ボタンを出します。並び替えを一度保存すると、表側の並びにも反映されます。</p>';
}

/**
 * チェックボックスの一覧を出す
 *
 * 組の名前（項目名と同じ文言）を、スクリーンリーダー用のlegendで付ける。
 *
 * @param string   $key   設定のキー。
 * @param string[] $names 名前の配列（キー）とラベル（値）。
 * @param string   $title 項目名。
 */
function obentou_render_checkboxes( $key, $names, $title ) {
	$current = obentou_get_setting( $key );
	echo '<fieldset>';
	printf( '<legend class="screen-reader-text">%s</legend>', esc_html( $title ) );
	foreach ( $names as $name => $label ) {
		printf(
			'<label><input type="checkbox" name="obentou_settings[%1$s][]" value="%2$s"%3$s> %4$s <code>%2$s</code></label><br>',
			esc_attr( $key ),
			esc_attr( $name ),
			checked( in_array( $name, $current, true ), true, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
}

/**
 * 投稿タイプのチェックボックス
 *
 * @param array $args add_settings_fieldの引数（key、title）。
 */
function obentou_render_post_type_checkboxes( $args ) {
	$names = array();
	foreach ( obentou_get_post_types() as $name => $type ) {
		$names[ $name ] = $type->labels->name;
	}
	obentou_render_checkboxes( $args['key'], $names, $args['title'] );
}

/**
 * タクソノミーのチェックボックス（絞り込みではcategoryを出さない）
 *
 * @param array $args add_settings_fieldの引数（key、title）。
 */
function obentou_render_taxonomy_checkboxes( $args ) {
	$names = array();
	foreach ( obentou_get_taxonomies() as $name => $taxonomy ) {
		if ( 'filter_taxonomies' === $args['key'] && 'category' === $name ) {
			continue;
		}
		$names[ $name ] = $taxonomy->labels->name;
	}
	obentou_render_checkboxes( $args['key'], $names, $args['title'] );
}

/**
 * 設定画面を描く
 *
 * 「設定」メニュー配下なので、保存の通知はコアがsettings_errors()で出す。ここでは呼ばない。
 */
function obentou_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<p>ID列は常に表示します。隠すには、一覧の右上の「表示オプション」を使ってください。</p>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'obentou' );
			do_settings_sections( 'obentou' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}
