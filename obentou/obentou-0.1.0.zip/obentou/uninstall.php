<?php
/**
 * 削除時の後始末
 *
 * プラグインを「削除」したときだけ実行される（停止では走らない）。
 * 投稿のmenu_orderはコアの列なので触らない。
 *
 * マルチサイトでは、ネットワーク管理画面から削除したときにメインサイトの文脈で1回だけ走る。
 * 設定と順序のデータはサイトごとのテーブルにあるので、サイトを切り替えて全サイトから消す。
 * 更新情報のキャッシュ（site transient）はネットワークで共通なので、ループの外で1回だけ消す。
 *
 * @package Obentou
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * いまのサイトの設定と順序のデータを消す
 */
function obentou_uninstall_site() {
	delete_option( 'obentou_settings' );
	delete_option( 'obentou_order_state' );
	delete_metadata( 'term', 0, '_obentou_order', '', true );
}

if ( is_multisite() ) {
	$obentou_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);
	foreach ( $obentou_site_ids as $obentou_site_id ) {
		switch_to_blog( $obentou_site_id );
		obentou_uninstall_site();
		restore_current_blog();
	}
} else {
	obentou_uninstall_site();
}
delete_site_transient( 'obentou_update_info' );
