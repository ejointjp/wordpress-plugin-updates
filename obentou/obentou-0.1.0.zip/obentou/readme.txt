=== Obentou Admin Pack ===
Contributors: ejointjp
Tags: admin, columns, order, sort
Requires at least: 6.7
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

管理画面の一覧にID列・絞り込み・ドラッグ＆ドロップの並び替えを足す、小さな便利機能の詰め合わせ。

== Description ==

* ID列: 投稿・固定ページ・カスタム投稿タイプ・メディア・タクソノミー・ユーザーの一覧に、チェック欄の直後へID列を出します。投稿の一覧（固定ページ・カスタム投稿タイプを含む）とタクソノミーの一覧では、検索欄に数字だけを入れると、そのIDの項目を表示します（メディアとユーザーの一覧は通常の検索です）
* 絞り込み: 投稿一覧の上に、タクソノミーのドロップダウンと「親で絞り込み」を出します（設定で選べます）
* 並び替え: 固定ページ型の投稿タイプとタクソノミーの一覧に「並び替えモード」を足し、ドラッグで並び順を決めます。保存した順序は表側の並びにも反映されます

設定は「設定 > Obentou Admin Pack」。

並び替えを使うときの注意:

* 順序の保存は`save_post`を起こしません（更新日を動かさないため）。ページキャッシュのプラグインのキャッシュは自動では消えないので、保存したあとはキャッシュを削除してください。`obentou_post_order_saved` / `obentou_term_order_saved`のアクションで連携できます
* 並び替えモードは全件を1ページに出します。件数の多い投稿タイプ（数千件）には向きません

更新の確認のために、配布元のGitHub（`raw.githubusercontent.com`）から小さなファイル（`info.json`）を取得します。サイトのURLやデータは送りません。

== Changelog ==

= 0.1.0 =
* 初版。ID列、一覧の絞り込み、ドラッグ＆ドロップの並び替え
