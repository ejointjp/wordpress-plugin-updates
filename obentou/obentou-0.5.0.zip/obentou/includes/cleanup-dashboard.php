<?php
/**
 * ダッシュボードのウィジェットの片付け
 *
 * コアのウィジェットの一覧（表に最初から出す）、記録と適用のフック、設定画面の表の行。
 *
 * ウィジェットの登録は、コア（wp_dashboard_setup()）→ wp_dashboard_setupアクション → 旧式のwp_dashboard_widgetsフィルターの順で、
 * そのあとdo_action( 'do_meta_boxes', 'dashboard', 'normal', '' )が発火する。ここなら登録がすべて済んでいる。
 * 「ようこそ」パネルは、index.phpがwp_dashboard_setup()のあとでhas_action( 'welcome_panel' )を見て出すので、
 * welcome_panelアクションのコールバックをすべて外せば枠ごと出ない。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * コアのウィジェット（表に最初から出す。ID => 名前。表に出す順）
 *
 * @return array<string, string>
 */
function obentou_dashboard_core_widgets() {
	return array(
		'welcome-panel'         => 'ようこそ',
		'dashboard_site_health' => 'サイトヘルスステータス',
		'dashboard_right_now'   => '概要',
		'dashboard_activity'    => 'アクティビティ',
		'dashboard_quick_press' => 'クイックドラフト',
		'dashboard_primary'     => 'WordPressイベントとニュース',
	);
}

/**
 * ウィジェットの位置（remove_meta_box()に渡す）
 *
 * @return string[]
 */
function obentou_dashboard_contexts() {
	return array( 'normal', 'side', 'column3', 'column4' );
}

/**
 * 鍵（隠せない項目）。ダッシュボードにはない
 *
 * @return array
 */
function obentou_dashboard_locked() {
	return array();
}

/**
 * いま登録されているウィジェット（ID => タイトル）
 *
 * $wp_meta_boxes['dashboard'][位置][優先度][ID]を全部見る。消された項目はfalseなので飛ばす。
 *
 * wp_add_dashboard_widget()は、設定用のコールバックがあるウィジェットで、閲覧者がedit_dashboardを持つ（管理者は常に持つ）と、
 * タイトルの後ろに<span class="postbox-title-action">（「設定」か「キャンセル」のリンク）を足す。
 * 記録のタイトルが「○○ 設定」にならないよう、そのspanは除いて返す。
 *
 * @return array<string, string>
 */
function obentou_dashboard_registered_widgets() {
	global $wp_meta_boxes;
	$widgets = array();
	if ( empty( $wp_meta_boxes['dashboard'] ) || ! is_array( $wp_meta_boxes['dashboard'] ) ) {
		return $widgets;
	}
	foreach ( $wp_meta_boxes['dashboard'] as $priorities ) {
		if ( ! is_array( $priorities ) ) {
			continue;
		}
		foreach ( $priorities as $boxes ) {
			if ( ! is_array( $boxes ) ) {
				continue;
			}
			foreach ( $boxes as $box ) {
				if ( ! is_array( $box ) || empty( $box['id'] ) ) {
					continue;
				}
				$title                          = isset( $box['title'] ) ? (string) $box['title'] : '';
				$widgets[ (string) $box['id'] ] = (string) preg_replace( '#\s*<span class="postbox-title-action">.*?</span>#s', '', $title );
			}
		}
	}
	return $widgets;
}

/**
 * プラグインのウィジェットを記録に足す
 *
 * ツールバーの記録と同じく、足していくだけで、そのときの一覧で置き換えない。管理者によって出るウィジェットが違うと
 * （ログインした人ごとに条件を見て足すプラグインや、マルチサイトの特権管理者にだけ出るウィジェットがある）、
 * 置き換えでは別の管理者が開いたときに行が表から消え、その状態で保存すると非表示の設定まで消えるため。
 * もう出ないウィジェットの行は「記録をリセット」で消す。
 * 書くのは、記録にない新しいIDがあったときだけ。名前は最初に記録したものを残す（名前を最新にするのも「記録をリセット」）。
 * コアのものは入れない。最大300件。
 *
 * @param array<string, string> $widgets obentou_dashboard_registered_widgets()の値。
 */
function obentou_dashboard_record( $widgets ) {
	$seen    = obentou_cleanup_seen( 'obentou_dashboard_seen' );
	$changed = false;
	foreach ( array_diff_key( $widgets, obentou_dashboard_core_widgets() ) as $id => $title ) {
		if ( isset( $seen[ $id ] ) || count( $seen ) >= 300 ) {
			continue;
		}
		$seen[ $id ] = $title;
		$changed     = true;
	}
	if ( $changed ) {
		update_option( 'obentou_dashboard_seen', $seen );
	}
}

/**
 * 記録と非表示（do_meta_boxesアクション。画面dashboard、位置normalのとき1回だけ）
 *
 * ネットワーク管理画面（dashboard-network）とユーザー管理画面（dashboard-user）では画面IDが違うので動かない。
 *
 * @param string $screen_id 画面のID。
 * @param string $context   位置。
 */
function obentou_dashboard_apply( $screen_id, $context ) {
	static $done = false;
	if ( $done || 'dashboard' !== $screen_id || 'normal' !== $context ) {
		return;
	}
	$done = true;

	if ( current_user_can( 'manage_options' ) ) {
		obentou_dashboard_record( obentou_dashboard_registered_widgets() );
	}

	$settings = obentou_get_cleanup_settings( 'obentou_dashboard' );
	if ( ! $settings['hidden'] ) {
		return;
	}
	$hidden = obentou_cleanup_hidden_for_roles( $settings, obentou_menu_current_user_roles() );
	foreach ( array_keys( $hidden ) as $id ) {
		if ( 'welcome-panel' === $id ) {
			remove_all_actions( 'welcome_panel' );
			continue;
		}
		foreach ( obentou_dashboard_contexts() as $widget_context ) {
			remove_meta_box( $id, 'dashboard', $widget_context );
		}
	}
}
add_action( 'do_meta_boxes', 'obentou_dashboard_apply', PHP_INT_MAX, 2 );

/**
 * 設定画面の表の行（コアのウィジェット、次に記録したウィジェット）
 *
 * @return array[] 各行: id, name, children（空）。
 */
function obentou_dashboard_rows() {
	$rows = array();
	foreach ( obentou_dashboard_core_widgets() as $id => $name ) {
		$rows[] = array(
			'id'       => $id,
			'name'     => $name,
			'children' => array(),
		);
	}
	foreach ( obentou_cleanup_seen( 'obentou_dashboard_seen' ) as $id => $title ) {
		$id = (string) $id;
		if ( isset( obentou_dashboard_core_widgets()[ $id ] ) ) {
			continue;
		}
		$name   = obentou_cleanup_title_text( $title );
		$rows[] = array(
			'id'       => $id,
			'name'     => '' !== $name ? $name : $id,
			'children' => array(),
		);
	}
	return $rows;
}
