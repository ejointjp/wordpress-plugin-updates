<?php
/**
 * 投稿一覧の列幅
 *
 * 設定のresize_post_typesにある投稿タイプの一覧では、見出しの右端のドラッグで列幅を変えられるようにする（assets/column-width.js）。
 * 幅は利用者のブラウザ（localStorage）に、投稿タイプと列のキーごとに持つ。サーバーには保存しない。
 * 設定のauto_layout_post_typesにある投稿タイプの一覧は、コアの固定の列幅（.fixedのtable-layout: fixed）をやめ、中身に合わせる。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 開いている投稿一覧の投稿タイプ（投稿一覧でなければ空）
 *
 * @return string
 */
function obentou_column_width_post_type() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'edit' !== $screen->base || ! $screen->post_type ) {
		return '';
	}
	return $screen->post_type;
}

/**
 * 投稿タイプが、列幅の設定のどちらかに入っているか
 *
 * @param string $key       resize_post_types / auto_layout_post_types。
 * @param string $post_type 投稿タイプ名。
 * @return bool
 */
function obentou_is_column_width_post_type( $key, $post_type ) {
	return '' !== $post_type && post_type_exists( $post_type ) && in_array( $post_type, obentou_get_setting( $key ), true );
}

/**
 * 対象の投稿一覧に、列幅のスクリプトとスタイルを読み込む
 *
 * @param string $hook 管理画面のページ。
 */
function obentou_column_width_enqueue( $hook ) {
	if ( 'edit.php' !== $hook ) {
		return;
	}
	$post_type = obentou_column_width_post_type();
	$resize    = obentou_is_column_width_post_type( 'resize_post_types', $post_type );
	$auto      = obentou_is_column_width_post_type( 'auto_layout_post_types', $post_type );
	if ( ! $resize && ! $auto ) {
		return;
	}
	wp_enqueue_style( 'obentou-column-width', OBENTOU_URL . 'assets/column-width.css', array(), OBENTOU_VERSION );
	if ( ! $resize ) {
		return;
	}
	wp_enqueue_script( 'obentou-column-width', OBENTOU_URL . 'assets/column-width.js', array(), OBENTOU_VERSION, true );
	$data = array( 'storeKey' => 'obentou_column_widths_' . $post_type );
	wp_add_inline_script( 'obentou-column-width', 'var obentouColumnWidth = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', 'obentou_column_width_enqueue' );

/**
 * 列幅を中身に合わせる一覧の目印をbodyに付ける（CSSが表示の最初から効くように）
 *
 * @param string $classes bodyのクラス（空白区切り）。
 * @return string
 */
function obentou_column_width_body_class( $classes ) {
	if ( obentou_is_column_width_post_type( 'auto_layout_post_types', obentou_column_width_post_type() ) ) {
		$classes .= ' obentou-auto-layout';
	}
	return $classes;
}
add_filter( 'admin_body_class', 'obentou_column_width_body_class' );
