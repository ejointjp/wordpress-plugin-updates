<?php
/**
 * 選んだらすぐ絞り込む
 *
 * 一覧の上の「絞り込み」ボタン（#post-query-submit）と同じ囲みにあるドロップダウンを選んだら、ボタンを押したのと同じように送信する（assets/auto-filter.js）。
 * ボタンはJSで隠すので、JSが動かない環境ではボタンが残る。
 * コアがこのボタンを出すのは、投稿一覧（固定ページ・カスタム投稿タイプを含む）・メディアのリスト表示・コメントの一覧。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 「絞り込み」ボタンのある一覧に、スクリプトを読み込む
 *
 * @param string $hook 管理画面のページ。
 */
function obentou_auto_filter_enqueue( $hook ) {
	if ( ! in_array( $hook, array( 'edit.php', 'upload.php', 'edit-comments.php' ), true ) || ! obentou_is_auto_filter() ) {
		return;
	}
	wp_enqueue_script( 'obentou-auto-filter', OBENTOU_URL . 'assets/auto-filter.js', array(), OBENTOU_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'obentou_auto_filter_enqueue' );
