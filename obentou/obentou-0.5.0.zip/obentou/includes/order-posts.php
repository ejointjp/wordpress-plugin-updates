<?php
/**
 * 投稿の並び替え（順序列、保存、AJAX、表側の適用）
 *
 * 順序はコアのmenu_orderに持つ。保存は$wpdb->update()で直接書き、更新日を動かさない。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 対象の投稿タイプの一覧に「順序」列を足す
 */
function obentou_order_post_columns_init() {
	foreach ( obentou_get_setting( 'order_post_types' ) as $post_type ) {
		if ( ! post_type_exists( $post_type ) ) {
			continue;
		}
		add_filter( "manage_{$post_type}_posts_columns", 'obentou_add_order_column' );
		add_filter( "manage_edit-{$post_type}_sortable_columns", 'obentou_add_order_sortable_column' );
	}
}
add_action( 'admin_init', 'obentou_order_post_columns_init' );

/**
 * 列の一覧に「順序」を足す（末尾）
 *
 * @param array $columns 列のキー => 見出し。
 * @return array
 */
function obentou_add_order_column( $columns ) {
	$columns['obentou_order'] = '順序';
	return $columns;
}

/**
 * 「順序」列をmenu_orderでソート可にする
 *
 * @param array $columns ソート可の列。
 * @return array
 */
function obentou_add_order_sortable_column( $columns ) {
	$columns['obentou_order'] = 'menu_order';
	return $columns;
}

/**
 * 「順序」列の中身
 *
 * @param string $column  列のキー。
 * @param int    $post_id 投稿ID。
 */
function obentou_render_order_column( $column, $post_id ) {
	if ( 'obentou_order' === $column ) {
		echo (int) get_post_field( 'menu_order', $post_id );
	}
}
add_action( 'manage_posts_custom_column', 'obentou_render_order_column', 10, 2 );
add_action( 'manage_pages_custom_column', 'obentou_render_order_column', 10, 2 );

/**
 * 「順序」列は既定で隠す（見たい人だけ表示オプションで出す）
 *
 * @param string[]  $hidden 隠す列。
 * @param WP_Screen $screen 画面。
 * @return string[]
 */
function obentou_hide_order_column_by_default( $hidden, $screen ) {
	if ( $screen && 'edit' === $screen->base && obentou_is_order_post_type( $screen->post_type ) ) {
		$hidden[] = 'obentou_order';
	}
	return $hidden;
}
add_filter( 'default_hidden_columns', 'obentou_hide_order_column_by_default', 10, 2 );

/**
 * 投稿の順序を保存する
 *
 * 投稿タイプが合わないIDは飛ばす。値が変わる行だけ書く。
 *
 * @param string $post_type 投稿タイプ名。
 * @param array  $order     array( array( 'id' => int, 'position' => int ), ... )。
 * @return array|WP_Error array( 'updated' => int, 'skipped' => int, 'failed' => int )。
 */
function obentou_apply_post_order( $post_type, $order ) {
	global $wpdb;

	if ( ! obentou_is_order_post_type( $post_type ) ) {
		return new WP_Error( 'obentou_not_orderable', 'この投稿タイプは並び替えの対象ではありません。設定 > Obentou Admin Packで対象にしてください。' );
	}
	if ( ! is_array( $order ) || empty( $order ) ) {
		return new WP_Error( 'obentou_invalid_order', '並び替えのデータが不正です。ページを読み込み直して、もう一度並び替えてください。' );
	}

	// 下のget_post()が、キャッシュにない投稿の数だけクエリを走らせないよう、先にまとめて読み込む（タームとメタは使わないので読まない）
	$prime = array();
	foreach ( $order as $item ) {
		if ( isset( $item['id'] ) && absint( $item['id'] ) ) {
			$prime[] = absint( $item['id'] );
		}
	}
	_prime_post_caches( $prime, false, false );

	$result = array(
		'updated' => 0,
		'skipped' => 0,
		'failed'  => 0,
	);
	$ids    = array();
	foreach ( $order as $item ) {
		$id       = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
		$position = isset( $item['position'] ) ? absint( $item['position'] ) : 0;
		$post     = $id ? get_post( $id ) : null;
		if ( ! $post || $post->post_type !== $post_type ) {
			++$result['skipped'];
			continue;
		}
		if ( (int) $post->menu_order === $position ) {
			$ids[] = $id;
			continue;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- wp_update_post()は更新日を動かすので、menu_orderだけを直接書く
		$updated = $wpdb->update( $wpdb->posts, array( 'menu_order' => $position ), array( 'ID' => $id ), array( '%d' ), array( '%d' ) );
		if ( false === $updated ) {
			++$result['failed'];
			error_log( sprintf( 'Obentou Admin Pack: 投稿%dの順序を保存できませんでした（%s）。', $id, $wpdb->last_error ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- 失敗を運用側が気付けるように残す
			continue;
		}
		clean_post_cache( $id );
		++$result['updated'];
		$ids[] = $id;
	}

	if ( $ids ) {
		obentou_mark_order_saved( 'post_types', $post_type );
		do_action( 'obentou_post_order_saved', $post_type, $ids );
	}
	return $result;
}

/**
 * AJAX: 投稿の順序を保存する
 */
function obentou_ajax_save_post_order() {
	check_ajax_referer( 'obentou_order', 'nonce' );

	// タームの保存と同じく、文字列であることだけを確かめ、obentou_authorize_post_order()がpost_type_exists()と設定の許可リストで判定する
	$post_type = isset( $_POST['post_type'] ) ? wp_unslash( $_POST['post_type'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 登録済みの名前と許可リストに完全一致するものだけを通す（上のコメント）
	if ( ! is_string( $post_type ) ) {
		$post_type = '';
	}
	$object = obentou_authorize_post_order( $post_type );
	if ( is_wp_error( $object ) ) {
		obentou_send_order_result( $object );
	}
	$order = obentou_read_order_payload();
	if ( is_wp_error( $order ) ) {
		obentou_send_order_result( $order );
	}
	obentou_send_order_result( obentou_apply_post_order( $post_type, $order ) );
}
add_action( 'wp_ajax_obentou_save_post_order', 'obentou_ajax_save_post_order' );

/**
 * クエリが扱う投稿タイプを決める
 *
 * post_typeが入っていればそれ。タクソノミーのアーカイブなら、そのタクソノミーに属する投稿タイプ。ホームならpost。
 *
 * @param WP_Query $query クエリ。
 * @return string[] 決められなければ空。
 */
function obentou_resolve_query_post_types( $query ) {
	$post_type = $query->get( 'post_type' );
	if ( ! empty( $post_type ) ) {
		return 'any' === $post_type ? array() : array_values( (array) $post_type );
	}
	if ( $query->is_tax() || $query->is_category() || $query->is_tag() ) {
		$queried = $query->get_queried_object();
		if ( $queried instanceof WP_Term ) {
			$taxonomy = get_taxonomy( $queried->taxonomy );
			return $taxonomy ? array_values( (array) $taxonomy->object_type ) : array();
		}
		return array();
	}
	if ( $query->is_home() ) {
		return array( 'post' );
	}
	return array();
}

/**
 * 保存した順序をメインクエリに効かせる
 *
 * 一度も保存していない投稿タイプには効かせない（有効にしただけでブログが題名順になる事故を防ぐ）。
 * 管理画面で列のソートを指定しているときと、orderbyを指定したクエリ・検索・フィードは触らない。
 *
 * ただし並び替えモードの投稿一覧（edit.phpでobentou_sort=1）では、URLにorderbyがあるとき（利用者が選んだ列のソート）だけ抜け、
 * 検索中も、コアが「下書き」「レビュー待ち」のビューに入れる更新日順（orderby=modified）も保存順で上書きする。
 * 保存は見えている並びの上から0を振るので、保存順で出ていない一覧で保存すると、動かしていない項目の順序まで変わるため。
 * 一度も保存していない投稿タイプに効かせないのは、並び替えモードでも同じ。
 *
 * @param WP_Query $query クエリ。
 */
function obentou_apply_post_order_to_query( $query ) {
	global $pagenow;

	if ( ! $query->is_main_query() || $query->is_feed() ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 列のソートの有無を読むだけ
	if ( is_admin() && ! empty( $_GET['orderby'] ) ) {
		return;
	}
	$sort_mode = is_admin() && 'edit.php' === $pagenow && obentou_is_sort_mode();
	if ( ! $sort_mode && ( $query->get( 'orderby' ) || $query->is_search() ) ) {
		return;
	}
	$post_types = obentou_resolve_query_post_types( $query );
	if ( ! $post_types ) {
		return;
	}
	foreach ( $post_types as $post_type ) {
		if ( ! obentou_is_order_post_type( $post_type ) || ! obentou_has_saved_order( 'post_types', $post_type ) ) {
			return;
		}
	}
	$hierarchical = 1 === count( $post_types ) && is_post_type_hierarchical( $post_types[0] );
	$query->set(
		'orderby',
		$hierarchical
			? array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			)
			: array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			)
	);
}
add_action( 'pre_get_posts', 'obentou_apply_post_order_to_query', 20 );
