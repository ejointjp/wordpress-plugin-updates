<?php
/**
 * ツールバー（管理バー）の項目の片付け
 *
 * コアの項目の一覧と名前（表に最初から出す）、鍵、記録と適用のフック、設定画面の表の行。
 *
 * admin_bar_menuアクションはwp_admin_bar_render()の中で発火し、管理画面（in_admin_header）とサイト側（wp_body_open / wp_footer）の両方で走る。
 * コアの項目は優先度0〜9999で足されるので、PHP_INT_MAXで動けば全部そろっている。ただし、同じPHP_INT_MAXで動くあとのコールバックや、
 * wp_before_admin_bar_renderで足されるノードは、記録も非表示の対象にもならない。
 * 親のノードをremove_node()で消すと、子はコア（WP_Admin_Bar::_bind()）が描かない。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * コアの項目（表に最初から出す。ID => array( 親のID（トップは空）, 名前 )。表に出す順）
 *
 * コアがどの画面で足すかはwp-includes/admin-bar.phpによる。タイトルが文字として読めない項目（ロゴ、検索、件数のバッジ）があるので、
 * コアは決まった名前にする。
 *
 * @return array<string, array{0: string, 1: string}>
 */
function obentou_toolbar_core_nodes() {
	return array(
		'wp-logo'     => array( '', 'WordPressロゴ' ),
		'about'       => array( 'wp-logo', 'WordPressについて' ),
		'site-name'   => array( '', 'サイト名' ),
		'view-site'   => array( 'site-name', 'サイトを表示（管理画面）' ),
		'dashboard'   => array( 'site-name', 'ダッシュボード（サイト側）' ),
		'themes'      => array( 'site-name', 'テーマ（サイト側）' ),
		'widgets'     => array( 'site-name', 'ウィジェット（サイト側）' ),
		'menus'       => array( 'site-name', 'メニュー（サイト側）' ),
		'customize'   => array( '', 'カスタマイズ（サイト側）' ),
		'updates'     => array( '', '更新' ),
		'comments'    => array( '', 'コメント' ),
		'new-content' => array( '', '新規' ),
		'new-post'    => array( 'new-content', '投稿' ),
		'new-media'   => array( 'new-content', 'メディア' ),
		'new-page'    => array( 'new-content', '固定ページ' ),
		'new-user'    => array( 'new-content', 'ユーザー' ),
		'edit'        => array( '', '編集（サイト側で投稿を見ているとき）' ),
		'view'        => array( '', '表示（管理画面で投稿を編集しているとき）' ),
		'search'      => array( '', '検索（サイト側）' ),
		'my-account'  => array( '', 'アカウント' ),
		'user-info'   => array( 'my-account', 'プロフィール' ),
		'logout'      => array( 'my-account', 'ログアウト' ),
		'menu-toggle' => array( '', 'メニュー（管理画面のスマホ表示）' ),
	);
}

/**
 * 鍵（どのロールでも隠せない項目。ID => 理由）
 *
 * top-secondary（右側のグループ）とuser-actions（アカウントの下のグループ）はグループで、表の行には出ない。
 * 親を消すと子も描かれなくなるので、アカウントとログアウトを守るために入れてある。実行時はさらに、鍵の祖先を今のノードから探して守る
 * （obentou_toolbar_protected()）。
 *
 * @return array<string, string>
 */
function obentou_toolbar_locked() {
	return array(
		'my-account'    => '隠すとログアウトできなくなるため、隠せません',
		'logout'        => '隠すとログアウトできなくなるため、隠せません',
		'menu-toggle'   => '隠すとスマホで管理メニューが開けなくなるため、隠せません',
		'recovery-mode' => 'リカバリーモードを終了する入り口なので、隠せません',
		'top-secondary' => 'アカウントとログアウトを含むため、隠せません',
		'user-actions'  => 'アカウントとログアウトを含むため、隠せません',
	);
}

/**
 * 記録しないIDか（コアのノードのうち、表の固定の一覧（obentou_toolbar_core_nodes()）にないもの）
 *
 * コアは、WordPressロゴの下のリンク（wporg / documentation / learn / support-forums / feedback / contribute）や、
 * 画面によって出るノード（edit-site / plugins / site-editor / background / header / command-palette / preview / archive / get-shortlink）、
 * リンクマネージャーが有効なときの「新規」の下のリンク（new-link）、
 * マルチサイトのノード（my-sites / add-new-site / blog-* / network-admin*）も足す。
 * これらはプラグインのノードではないので、記録に入れて「プラグインの項目」として表に並べてはいけない。
 * new-*（投稿タイプごとの「新規」）は、プラグインの投稿タイプが足すものなので除かない（固定の一覧にあるnew-postなどは記録の側で除かれる。new-linkだけは上のとおりコアなので除く）。
 *
 * @param string $id ノードのID。
 * @return bool
 */
function obentou_toolbar_unrecorded( $id ) {
	$ids = array(
		'contribute',
		'wporg',
		'documentation',
		'learn',
		'support-forums',
		'feedback',
		'edit-site',
		'plugins',
		'site-editor',
		'background',
		'header',
		'command-palette',
		'preview',
		'archive',
		'get-shortlink',
		'new-link',
		'my-sites',
		'add-new-site',
		'recovery-mode',
	);
	if ( in_array( $id, $ids, true ) ) {
		return true;
	}
	foreach ( array( 'blog-', 'network-admin', 'my-sites' ) as $prefix ) {
		if ( 0 === strpos( $id, $prefix ) ) {
			return true;
		}
	}
	return false;
}

/**
 * 隠せないノードの集合（鍵と、その祖先）
 *
 * 親のノードを消すと、子はコア（WP_Admin_Bar::_bind()）が描かない。鍵のIDだけを除いても、祖先（グループを含む。
 * たとえばアカウントとログアウトを含むtop-secondaryやuser-actions）を隠せば鍵も消えてしまう。
 * そこで、今のノードで鍵から親（->parent）をたどって、祖先もまとめて守る。同じノードに戻ってきたらそこで止める。
 *
 * @param array $nodes $wp_admin_bar->get_nodes()（ID => ノード）。
 * @return array<string, true> ID => true。
 */
function obentou_toolbar_protected( $nodes ) {
	$protected = array();
	foreach ( array_keys( obentou_toolbar_locked() ) as $id ) {
		$current = (string) $id;
		while ( '' !== $current && isset( $nodes[ $current ] ) && ! isset( $protected[ $current ] ) ) {
			$protected[ $current ] = true;
			$current               = isset( $nodes[ $current ]->parent ) && is_string( $nodes[ $current ]->parent ) ? $nodes[ $current ]->parent : '';
		}
	}
	return $protected;
}

/**
 * ノードの親（グループを辿って、グループでない祖先。トップは空）
 *
 * @param array    $nodes $wp_admin_bar->get_nodes()（ID => ノード）。
 * @param stdClass $node  ノード。
 * @return string
 */
function obentou_toolbar_effective_parent( $nodes, $node ) {
	$parent = isset( $node->parent ) && is_string( $node->parent ) ? $node->parent : '';
	$guard  = 0;
	while ( '' !== $parent && isset( $nodes[ $parent ] ) && ! empty( $nodes[ $parent ]->group ) && $guard < 20 ) {
		$parent = isset( $nodes[ $parent ]->parent ) && is_string( $nodes[ $parent ]->parent ) ? $nodes[ $parent ]->parent : '';
		++$guard;
	}
	return $parent;
}

/**
 * プラグインのノードを記録に足す
 *
 * 書くのは、記録にない新しいIDと、親が変わったIDだけ（そのたびにoptionを書き換えないため）。
 * 名前が変わっても書き直さず、最初に記録した名前が残る（名前を最新にするのは設定画面の「記録をリセット」）。親が変わったときも名前は残す。
 * コアの項目とグループは入れない。最大300件。
 *
 * @param array $nodes $wp_admin_bar->get_nodes()（ID => ノード）。
 */
function obentou_toolbar_record( $nodes ) {
	$seen    = obentou_cleanup_seen( 'obentou_toolbar_seen' );
	$core    = obentou_toolbar_core_nodes();
	$changed = false;
	foreach ( $nodes as $node ) {
		if ( empty( $node->id ) || ! is_string( $node->id ) || ! empty( $node->group ) || isset( $core[ $node->id ] ) || obentou_toolbar_unrecorded( $node->id ) ) {
			continue;
		}
		$parent = obentou_toolbar_effective_parent( $nodes, $node );
		$title  = isset( $node->title ) && is_string( $node->title ) ? $node->title : '';
		if ( isset( $seen[ $node->id ] ) ) {
			$old = $seen[ $node->id ];
			if ( is_array( $old ) && isset( $old['parent'] ) && $old['parent'] === $parent ) {
				continue;
			}
			if ( is_array( $old ) && isset( $old['title'] ) && is_string( $old['title'] ) ) {
				$title = $old['title'];
			}
		} elseif ( count( $seen ) >= 300 ) {
			continue;
		}
		$seen[ $node->id ] = array(
			'title'  => $title,
			'parent' => $parent,
		);
		$changed           = true;
	}
	if ( $changed ) {
		update_option( 'obentou_toolbar_seen', $seen );
	}
}

/**
 * 記録と非表示（admin_bar_menuの最後）
 *
 * 隠すIDからは、鍵と、鍵の祖先（obentou_toolbar_protected()）を除く。
 *
 * @param WP_Admin_Bar $wp_admin_bar ツールバー。
 */
function obentou_toolbar_apply( $wp_admin_bar ) {
	if ( is_network_admin() || is_user_admin() ) {
		return;
	}
	$nodes = $wp_admin_bar->get_nodes();
	if ( ! $nodes ) {
		return;
	}
	if ( current_user_can( 'manage_options' ) ) {
		obentou_toolbar_record( $nodes );
	}

	$settings = obentou_get_cleanup_settings( 'obentou_toolbar' );
	if ( ! $settings['hidden'] ) {
		return;
	}
	$hidden = array_diff_key( obentou_cleanup_hidden_for_roles( $settings, obentou_menu_current_user_roles() ), obentou_toolbar_locked(), obentou_toolbar_protected( $nodes ) );
	foreach ( array_keys( $hidden ) as $id ) {
		$wp_admin_bar->remove_node( $id );
	}
}
add_action( 'admin_bar_menu', 'obentou_toolbar_apply', PHP_INT_MAX );

/**
 * 設定画面の表の行（2段。トップと、その下に子をまとめて並べる）
 *
 * コアの項目が表の順で先、記録だけにある項目はそのあとに記録の順（トップどうしも、同じ親の子どうしも）。
 * 親が記録にない項目と、親が自分自身の項目はトップにする。孫以降は、いちばん上の祖先の子として並べる
 * （親を隠せば子孫はコアが消すし、孫のIDを隠せば孫だけ消える）。
 *
 * @return array[] 各行: id, name, children（同じ形の配列。childrenは空）。
 */
function obentou_toolbar_rows() {
	$items = array();
	foreach ( obentou_toolbar_core_nodes() as $id => $def ) {
		$items[ $id ] = array(
			'name'   => $def[1],
			'parent' => $def[0],
		);
	}
	foreach ( obentou_cleanup_seen( 'obentou_toolbar_seen' ) as $id => $entry ) {
		$id = (string) $id;
		if ( isset( $items[ $id ] ) || ! is_array( $entry ) ) {
			continue;
		}
		$name         = obentou_cleanup_title_text( isset( $entry['title'] ) ? $entry['title'] : '' );
		$items[ $id ] = array(
			'name'   => '' !== $name ? $name : $id,
			'parent' => isset( $entry['parent'] ) && is_string( $entry['parent'] ) ? $entry['parent'] : '',
		);
	}

	// いちばん上の祖先を探す。親が知らないIDか自分自身なら、その項目がトップ
	$top_of = function ( $id ) use ( $items ) {
		$current = $id;
		$guard   = 0;
		while ( '' !== $items[ $current ]['parent'] && $items[ $current ]['parent'] !== $current && isset( $items[ $items[ $current ]['parent'] ] ) && $guard < 20 ) {
			$current = $items[ $current ]['parent'];
			++$guard;
		}
		return $current;
	};

	$tops     = array();
	$children = array();
	foreach ( $items as $id => $item ) {
		// 数字だけのIDは配列のキーでintになる。設定のIDは文字列で、画面が厳密に比べるので、文字列にそろえる
		$id  = (string) $id;
		$row = array(
			'id'       => $id,
			'name'     => $item['name'],
			'children' => array(),
		);
		$top = $top_of( $id );
		if ( $top === $id ) {
			$tops[ $id ] = $row;
		} else {
			$children[ $top ][] = $row;
		}
	}
	$rows = array();
	foreach ( $tops as $id => $row ) {
		if ( isset( $children[ $id ] ) ) {
			$row['children'] = $children[ $id ];
		}
		$rows[] = $row;
	}
	return $rows;
}
