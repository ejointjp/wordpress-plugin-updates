/**
 * 「ダッシュボード」「ツールバー」タブ（設定 > Obentou Admin Pack）
 *
 * 表はPHP（includes/cleanup-screen.php）が描く。ここで持つのは、
 * - 子の開閉
 * - チェックの連動（親を隠したロールの子は操作できなくする。閉じた親に隠した子があれば「一部非表示」）
 * - 送信前のJSON化（表全体をhidden欄1つで送る）と、「初期状態に戻す」「記録をリセット」の確認
 * JSが動かないあいだは、保存のボタンはdisabledで、hidden欄にはPHPが入れたいまの設定が入っている。
 * 初期化の途中で例外になったときも、この状態のまま残す（注意を消してボタンを有効にするのは、初期化の最後）。
 *
 * 行のデータ属性: data-id（項目のID）、data-parent（子なら親のID）。フォームのdata-kind（dashboard / toolbar）は確認の文言に使う
 */

/* global jQuery */

( function ( $ ) {
	'use strict';

	$( function () {
		var $form = $( '#obentou-cleanup-form' );
		var $list = $( '#obentou-cleanup-list' );
		if ( ! $form.length || ! $list.length ) {
			return;
		}
		var $json = $( '#obentou-cleanup-json' );
		var $save = $( '#obentou-cleanup-save' );
		var $reset = $( '#obentou-cleanup-reset' );
		var $resetSeen = $( '#obentou-cleanup-reset-seen' );
		var kindLabel = 'toolbar' === $form.attr( 'data-kind' ) ? 'ツールバー' : 'ダッシュボード';
		// 「記録をリセット」の確認の文言。ダッシュボードの記録はダッシュボードを開いたときにしか取らないので、保存の順番も添える
		var resetSeenMessage =
			'toolbar' === $form.attr( 'data-kind' )
				? '記録したプラグインの項目を表から消します（いま出ている項目は、画面を開き直すとまた記録されます）。消えた項目の非表示の設定は、次に保存したときに消えます。よろしいですか？'
				: '記録したプラグインのウィジェットを表から消します（いま出ているウィジェットは、ダッシュボードを開くとまた記録されます）。消えたウィジェットの非表示の設定は、次に保存したときに消えます。保存はダッシュボードを開いてからにしてください。よろしいですか？';
		var action = 'save';

		// 子の開閉
		$list.on( 'click', '.obentou-menu-toggle', function () {
			var $toggle = $( this );
			var $item = $toggle.closest( '.obentou-menu-item' );
			var open = ! $item.hasClass( 'is-open' );
			$item.toggleClass( 'is-open', open );
			$item.children( '.obentou-menu-sublist' ).prop( 'hidden', ! open );
			$toggle.attr( 'aria-expanded', open ? 'true' : 'false' );
			$toggle.find( '.dashicons' ).toggleClass( 'dashicons-arrow-right', ! open ).toggleClass( 'dashicons-arrow-down', open );
		} );

		// 親のチェック（ロールR）が外れていたら、同じロールの子のチェックを操作できなくする（親ごと隠れるため）。
		// 子に外れているチェックがあれば「一部非表示」を出す（CSSが、開いている親では隠す）
		function refreshItem( $item ) {
			var $row = $item.children( '.obentou-menu-row' );
			var $children = $item.children( '.obentou-menu-sublist' ).children( '.obentou-menu-item' );
			if ( ! $children.length ) {
				return;
			}
			$row.find( '.obentou-menu-show' ).each( function () {
				var role = $( this ).attr( 'data-role' );
				var inherit = ! this.checked;
				$children
					.children( '.obentou-menu-row' )
					.find( '.obentou-menu-show' )
					.filter( function () {
						return $( this ).attr( 'data-role' ) === role;
					} )
					.prop( 'disabled', inherit )
					.closest( '.obentou-menu-cell' )
					.toggleClass( 'obentou-menu-inherit', inherit );
			} );
			var partial = $children.children( '.obentou-menu-row' ).find( '.obentou-menu-show' ).filter( function () {
				return ! this.checked;
			} ).length > 0;
			$row.find( '.obentou-menu-partial' ).prop( 'hidden', ! partial );
		}
		$list.on( 'change', '.obentou-menu-show', function () {
			var $item = $( this ).closest( '.obentou-menu-item' );
			if ( $item.hasClass( 'obentou-menu-sub' ) ) {
				$item = $item.closest( '.obentou-menu-top' );
			}
			refreshItem( $item );
		} );
		$list.children( '.obentou-menu-item' ).each( function () {
			refreshItem( $( this ) );
		} );

		// 表全体をJSONにする。hiddenには、チェックが外れている欄だけを入れる（鍵の欄にはチェックがない）。
		// 親を隠して薄くなった子も、自分のチェックの状態で送る（親を戻したときに子の設定が残るように）
		function collect() {
			var data = { hidden: {} };
			$list.find( '.obentou-menu-item' ).each( function () {
				var $item = $( this );
				var id = $item.attr( 'data-id' );
				$item.children( '.obentou-menu-row' ).find( '.obentou-menu-show' ).each( function () {
					if ( this.checked ) {
						return;
					}
					var role = $( this ).attr( 'data-role' );
					if ( ! data.hidden[ role ] ) {
						data.hidden[ role ] = [];
					}
					data.hidden[ role ].push( id );
				} );
			} );
			return data;
		}

		// 取り消せない操作は確認する。取り消したら送らない
		$reset.on( 'click', function ( event ) {
			if ( ! window.confirm( kindLabel + 'の非表示の設定をすべて消して、WordPressの初期状態に戻します。よろしいですか？' ) ) {
				event.preventDefault();
				return;
			}
			action = 'reset';
		} );
		$resetSeen.on( 'click', function ( event ) {
			if ( ! window.confirm( resetSeenMessage ) ) {
				event.preventDefault();
				return;
			}
			action = 'reset_seen';
		} );
		$save.on( 'click', function () {
			action = 'save';
		} );

		// 送信の直前にhidden欄を埋める（Enterでの送信も通る）
		$form.on( 'submit', function () {
			var payload = collect();
			if ( 'reset' === action ) {
				payload = { reset: true };
			} else if ( 'reset_seen' === action ) {
				payload = { reset_seen: true };
			}
			$json.val( JSON.stringify( payload ) );
		} );

		// 初期化の最後に、「JavaScriptが動いていない」の注意を消して、ボタンを有効にする
		$( '.obentou-menu-nojs' ).remove();
		$save.prop( 'disabled', false );
		$reset.prop( 'disabled', false );
		$resetSeen.prop( 'disabled', false );
	} );
} )( jQuery );
