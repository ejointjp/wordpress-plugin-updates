/**
 * 投稿一覧の列幅をドラッグで変える
 *
 * 見出し（thead th）の右端にハンドルを置き、ドラッグで幅を変える。ダブルクリックで元の幅に戻す。
 * 幅は列のキー（thのid。コアが列のキーをそのまま入れる）ごとにlocalStorageへ保存する。
 * 位置で覚えると、表示オプションで列を出し入れしたときにずれるため。
 * 一覧が1列に積み重なる狭い画面（782px以下）では何もしない。
 */
( function () {
	'use strict';

	var config = window.obentouColumnWidth;
	var table = document.querySelector( '.wp-list-table' );
	if ( ! config || ! table ) {
		return;
	}
	if ( ! window.matchMedia( '(min-width: 783px)' ).matches ) {
		return;
	}

	var MIN_WIDTH = 40;
	var heads = Array.prototype.slice.call(
		table.querySelectorAll( 'thead th[id]' )
	);

	function load() {
		try {
			var saved = JSON.parse(
				window.localStorage.getItem( config.storeKey ) || '{}'
			);
			return saved && 'object' === typeof saved ? saved : {};
		} catch ( e ) {
			return {};
		}
	}

	function save() {
		var widths = {};
		heads.forEach( function ( th ) {
			if ( th.style.width ) {
				widths[ th.id ] = th.style.width;
			}
		} );
		try {
			window.localStorage.setItem(
				config.storeKey,
				JSON.stringify( widths )
			);
		} catch ( e ) {
			// 保存できない（プライベートブラウズなど）ときは、この画面のあいだだけ効かせる
		}
	}

	var saved = load();
	heads.forEach( function ( th ) {
		var width = saved[ th.id ];
		if ( 'string' === typeof width && /^\d+px$/.test( width ) ) {
			th.style.width = width;
		}
	} );

	heads.forEach( function ( th, index ) {
		// 最後の列は表の右端なので、ハンドルを置かない
		if ( index === heads.length - 1 ) {
			return;
		}

		var handle = document.createElement( 'span' );
		handle.className = 'obentou-column-resizer';
		handle.setAttribute( 'aria-hidden', 'true' );
		th.appendChild( handle );

		// 並べ替えのリンクの上にあるので、クリックが見出しに伝わらないようにする
		handle.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			event.stopPropagation();
		} );

		handle.addEventListener( 'dblclick', function ( event ) {
			event.preventDefault();
			event.stopPropagation();
			th.style.width = '';
			save();
		} );

		handle.addEventListener( 'pointerdown', function ( event ) {
			if ( 0 !== event.button ) {
				return;
			}
			event.preventDefault();
			event.stopPropagation();
			var startX = event.clientX;
			// styleのwidthは中身の幅（余白を含まない）なので、offsetWidthではなく計算後の幅から始める
			var startWidth = parseFloat( window.getComputedStyle( th ).width );
			handle.setPointerCapture( event.pointerId );
			document.body.classList.add( 'obentou-column-resizing' );

			function onMove( moveEvent ) {
				var width = Math.max(
					MIN_WIDTH,
					startWidth + moveEvent.clientX - startX
				);
				th.style.width = Math.round( width ) + 'px';
			}

			function onUp() {
				handle.removeEventListener( 'pointermove', onMove );
				handle.removeEventListener( 'pointerup', onUp );
				handle.removeEventListener( 'pointercancel', onUp );
				document.body.classList.remove( 'obentou-column-resizing' );
				save();
			}

			handle.addEventListener( 'pointermove', onMove );
			handle.addEventListener( 'pointerup', onUp );
			handle.addEventListener( 'pointercancel', onUp );
		} );
	} );
} )();
