/**
 * 一覧の上のドロップダウンを選んだら、「絞り込み」ボタンを押さずに絞り込む
 *
 * 「絞り込み」ボタン（#post-query-submit）と同じ囲み（.actions）にあるselectが対象。
 * 送信はボタンを押したときと同じにする（requestSubmit(button)で、ボタンの名前と値も送る）。
 * マウスやタッチで選んだらすぐ送る。キーボードで選んだときは送らずにボタンを出し、Enterかボタンで送る
 * （Windowsでは、閉じたselectで矢印キーを押すたびにchangeが起きるので、すぐ送ると目当ての項目まで進めない）。
 */
( function () {
	'use strict';

	var button = document.getElementById( 'post-query-submit' );
	var box = button && button.closest( '.actions' );
	if ( ! box || ! button.form ) {
		return;
	}
	var selects = box.querySelectorAll( 'select' );
	if ( ! selects.length ) {
		return;
	}

	button.style.display = 'none';

	function submit() {
		button.form.requestSubmit( button );
	}

	Array.prototype.forEach.call( selects, function ( select ) {
		var byKeyboard = false;

		select.addEventListener( 'pointerdown', function () {
			byKeyboard = false;
		} );
		select.addEventListener( 'keydown', function ( event ) {
			if ( 'Enter' === event.key ) {
				event.preventDefault();
				submit();
				return;
			}
			if ( 'Tab' !== event.key ) {
				byKeyboard = true;
			}
		} );
		select.addEventListener( 'change', function () {
			if ( byKeyboard ) {
				button.style.display = '';
				return;
			}
			submit();
		} );
	} );
} )();
