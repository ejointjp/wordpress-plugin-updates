<?php
/**
 * 「ダッシュボード」「ツールバー」タブ（設定 > Obentou Admin Pack）
 *
 * 2つのタブは同じ形の表（行が項目、列がロール、チェックがオンなら表示）なので、描画・register_setting・sanitize・スクリプトの読み込みをここにまとめる。
 * 項目の一覧と鍵は、includes/cleanup-dashboard.php / cleanup-toolbar.phpの関数から取る。
 * 表はPHPが描き、見た目は「管理メニュー」タブの表（assets/menu.css）のクラスをそのまま使う。並べ替えと名前の変更はない。
 * JS（assets/cleanup.js）は開閉・チェックの連動・送信前のJSON化・リセットの確認だけを持つ。
 *
 * 保存はSettings API。表全体をhidden欄（option名）1つのJSONで送る。option groupはタブごと（obentou_dashboard / obentou_toolbar）。
 *
 * @package Obentou
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 2つのタブの定義
 *
 * @return array<string, array{label: string, option: string, seen: string, rows: callable, locked: callable, sanitize: string, reset_seen: bool, intro: string}>
 */
function obentou_cleanup_tabs() {
	return array(
		'dashboard' => array(
			'label'      => 'ダッシュボード',
			'option'     => 'obentou_dashboard',
			'seen'       => 'obentou_dashboard_seen',
			'rows'       => 'obentou_dashboard_rows',
			'locked'     => 'obentou_dashboard_locked',
			'sanitize'   => 'obentou_sanitize_dashboard_settings',
			'reset_seen' => false,
			'intro'      => 'ダッシュボードのウィジェットと「ようこそ」パネルを、ロールごとに隠します。',
		),
		'toolbar'   => array(
			'label'      => 'ツールバー',
			'option'     => 'obentou_toolbar',
			'seen'       => 'obentou_toolbar_seen',
			'rows'       => 'obentou_toolbar_rows',
			'locked'     => 'obentou_toolbar_locked',
			'sanitize'   => 'obentou_sanitize_toolbar_settings',
			'reset_seen' => true,
			'intro'      => 'ツールバー（管理バー）の項目を、ロールごとに隠します。管理画面とサイト側の両方に効きます。',
		),
	);
}

/**
 * ダッシュボードの設定のsanitize
 *
 * @param mixed $input 送られてきた値。
 * @return array
 */
function obentou_sanitize_dashboard_settings( $input ) {
	return obentou_cleanup_sanitize( 'obentou_dashboard', $input, obentou_dashboard_locked(), '' );
}

/**
 * ツールバーの設定のsanitize
 *
 * @param mixed $input 送られてきた値。
 * @return array
 */
function obentou_sanitize_toolbar_settings( $input ) {
	return obentou_cleanup_sanitize( 'obentou_toolbar', $input, obentou_toolbar_locked(), 'obentou_toolbar_seen' );
}

/**
 * optionを登録する（option groupはoption名と同じ）
 */
function obentou_register_cleanup_settings() {
	foreach ( obentou_cleanup_tabs() as $tab ) {
		register_setting(
			$tab['option'],
			$tab['option'],
			array(
				'type'              => 'array',
				'sanitize_callback' => $tab['sanitize'],
				'default'           => array(),
			)
		);
	}
}
add_action( 'admin_init', 'obentou_register_cleanup_settings' );

/**
 * タブを描く（settings.phpのobentou_render_settings_page()から呼ぶ）
 *
 * 保存の結果の通知は、「設定」メニュー配下なのでコアが出す。ここで出すのは、保存されている設定が壊れているときの通知だけ。
 * JSが動くまで保存のボタンはdisabledにし、hidden欄にはいまの設定を入れておく。
 *
 * @param string $kind dashboard / toolbar。
 */
function obentou_render_cleanup_tab( $kind ) {
	$tabs = obentou_cleanup_tabs();
	if ( ! isset( $tabs[ $kind ] ) ) {
		return;
	}
	$tab = $tabs[ $kind ];
	if ( obentou_cleanup_settings_broken( $tab['option'] ) ) {
		wp_admin_notice( esc_html( '保存されている設定が読めません。「初期状態に戻す」で消してください。' ), array( 'type' => 'error' ) );
	}
	$settings = obentou_get_cleanup_settings( $tab['option'] );
	$roles    = wp_roles()->get_names();
	$rows     = call_user_func( $tab['rows'] );
	$locked   = call_user_func( $tab['locked'] );
	?>
	<p><?php echo esc_html( $tab['intro'] ); ?>隠すのは見た目だけです。元からそのロールに出ない項目のチェックを外しても、影響はありません。</p>
	<p>プラグインが足した項目は、管理者がその画面を開くとここに増えます。チェックを外してそのロールから隠します。</p>
	<form action="options.php" method="post" id="obentou-cleanup-form" data-kind="<?php echo esc_attr( $kind ); ?>">
		<?php settings_fields( $tab['option'] ); ?>
		<input type="hidden" name="<?php echo esc_attr( $tab['option'] ); ?>" id="obentou-cleanup-json" value="<?php echo esc_attr( wp_json_encode( $settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?>">
		<div class="notice notice-warning inline obentou-menu-nojs"><p>JavaScriptが動いていないため編集できません。</p></div>
		<div class="obentou-menu-table" style="--obentou-menu-roles: <?php echo (int) count( $roles ); ?>">
			<div class="obentou-menu-head">
				<span></span><span></span><span>項目</span>
				<?php foreach ( $roles as $name ) : ?>
					<span class="obentou-menu-role"><?php echo esc_html( translate_user_role( $name ) ); ?></span>
				<?php endforeach; ?>
			</div>
			<ul class="obentou-menu-list" id="obentou-cleanup-list">
				<?php
				foreach ( $rows as $row ) {
					obentou_render_cleanup_row( $row, $roles, $settings, $locked, '' );
				}
				?>
			</ul>
		</div>
		<p class="submit">
			<button type="submit" class="button button-primary" id="obentou-cleanup-save" disabled>変更を保存</button>
			<button type="submit" class="button" id="obentou-cleanup-reset" disabled>初期状態に戻す</button>
			<?php if ( $tab['reset_seen'] ) : ?>
				<button type="submit" class="button" id="obentou-cleanup-reset-seen" disabled>記録をリセット</button>
			<?php endif; ?>
		</p>
	</form>
	<?php
}

/**
 * 1行（子があれば子の行も）を描く
 *
 * 行の<li>と中の<div class="obentou-menu-row">は1行に出す（検証がgrepで1行ずつ見るため）。子の<ul>は次の行から。
 *
 * @param array  $row       行（id, name, children）。
 * @param array  $roles     wp_roles()->get_names()。
 * @param array  $settings  obentou_get_cleanup_settings()の値。
 * @param array  $locked    鍵のID => 理由。
 * @param string $parent_id 親のID。トップは空。
 */
function obentou_render_cleanup_row( $row, $roles, $settings, $locked, $parent_id ) {
	$is_sub = '' !== $parent_id;
	printf(
		'<li class="%1$s" data-id="%2$s" data-parent="%3$s"><div class="obentou-menu-row"><span></span>',
		esc_attr( 'obentou-menu-item ' . ( $is_sub ? 'obentou-menu-sub' : 'obentou-menu-top' ) ),
		esc_attr( $row['id'] ),
		esc_attr( $parent_id )
	);
	if ( $row['children'] ) {
		printf(
			'<button type="button" class="obentou-menu-toggle" aria-expanded="false" aria-label="%sの項目を開閉"><span class="dashicons dashicons-arrow-right" aria-hidden="true"></span></button>',
			esc_attr( $row['name'] )
		);
	} else {
		echo '<span></span>';
	}
	printf( '<span class="obentou-menu-name-cell"><span class="obentou-menu-name-static">%s</span>', esc_html( $row['name'] ) );
	if ( $row['children'] ) {
		echo '<span class="obentou-menu-partial" hidden>一部非表示</span>';
	}
	echo '</span>';
	foreach ( $roles as $role => $name ) {
		obentou_render_cleanup_cell( $row, $role, translate_user_role( $name ), $settings, $locked );
	}
	echo '</div>';
	if ( $row['children'] ) {
		echo "\n" . '<ul class="obentou-menu-sublist" hidden>' . "\n";
		foreach ( $row['children'] as $child ) {
			obentou_render_cleanup_row( $child, $roles, $settings, $locked, $row['id'] );
		}
		echo '</ul>';
	}
	echo '</li>' . "\n";
}

/**
 * ロールの欄を1つ描く（鍵なら鍵、ほかはチェック。「—」は出さない）
 *
 * ウィジェットとツールバーの項目は、プラグインがコードの中で条件を見て足すので、どのロールに出るかを前もって知る方法がない。
 *
 * @param array  $row       行。
 * @param string $role      ロールのslug。
 * @param string $role_name ロールの表示名。
 * @param array  $settings  obentou_get_cleanup_settings()の値。
 * @param array  $locked    鍵のID => 理由。
 */
function obentou_render_cleanup_cell( $row, $role, $role_name, $settings, $locked ) {
	if ( isset( $locked[ $row['id'] ] ) ) {
		printf(
			'<span class="obentou-menu-cell obentou-menu-lock" title="%1$s"><span class="dashicons dashicons-lock" aria-hidden="true"></span><span class="screen-reader-text">%1$s</span></span>',
			esc_attr( $locked[ $row['id'] ] )
		);
		return;
	}
	$is_hidden = isset( $settings['hidden'][ $role ] ) && in_array( $row['id'], $settings['hidden'][ $role ], true );
	printf(
		'<span class="obentou-menu-cell"><input type="checkbox" class="obentou-menu-show" data-role="%1$s" aria-label="%2$sに表示: %3$s"%4$s></span>',
		esc_attr( $role ),
		esc_attr( $role_name ),
		esc_attr( $row['name'] ),
		checked( ! $is_hidden, true, false )
	);
}

/**
 * 「ダッシュボード」「ツールバー」タブにスクリプトとスタイルを読み込む
 *
 * 表の見た目は「管理メニュー」タブのassets/menu.cssをそのまま使う。JSは別（並べ替えと名前の変更がないため）。
 *
 * @param string $hook 管理画面のページ（add_options_page()の戻り。settings_page_obentou）。
 */
function obentou_cleanup_enqueue( $hook ) {
	$tabs = obentou_cleanup_tabs();
	if ( 'settings_page_obentou' !== $hook || ! isset( $tabs[ obentou_get_settings_tab() ] ) ) {
		return;
	}
	wp_enqueue_style( 'obentou-menu', OBENTOU_URL . 'assets/menu.css', array(), OBENTOU_VERSION );
	wp_enqueue_script( 'obentou-cleanup', OBENTOU_URL . 'assets/cleanup.js', array( 'jquery' ), OBENTOU_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'obentou_cleanup_enqueue' );
